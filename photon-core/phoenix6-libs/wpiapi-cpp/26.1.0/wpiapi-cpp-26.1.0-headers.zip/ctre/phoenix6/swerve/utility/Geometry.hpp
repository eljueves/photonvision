/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
#pragma once

#include <frc/geometry/Pose2d.h>
#include <wpi/MathExtras.h>

namespace ctre {
namespace phoenix6 {
namespace swerve {

using wpi::Lerp;

using frc::Rotation2d;
using frc::Translation2d;
using frc::Transform2d;
using frc::Twist2d;
using frc::Pose2d;

}
}
}
