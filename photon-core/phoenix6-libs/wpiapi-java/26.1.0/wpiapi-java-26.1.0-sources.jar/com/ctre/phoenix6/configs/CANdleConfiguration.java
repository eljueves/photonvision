/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;

/**
 * Class for CTR Electronics' CANdle® branded device, a device that controls
 * LEDs over the CAN bus.
 *
 * This handles applying and refreshing the configurations for the {@link com.ctre.phoenix6.hardware.CANdle}.
 */
public class CANdleConfiguration implements ParentConfiguration, Cloneable {
    /**
     * True if we should factory default newer unsupported configs,
     * false to leave newer unsupported configs alone.
     * <p>
     * This flag addresses a corner case where the device may have
     * firmware with newer configs that didn't exist when this
     * version of the API was built. If this occurs and this
     * flag is true, unsupported new configs will be factory
     * defaulted to avoid unexpected behavior.
     * <p>
     * This is also the behavior in Phoenix 5, so this flag
     * is defaulted to true to match.
     */
    public boolean FutureProofConfigs = true;

    
    /**
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     */
    public CustomParamsConfigs CustomParams = new CustomParamsConfigs();
    
    /**
     * Configs related to CANdle LED control.
     * <p>
     * All the configs related to controlling LEDs with the CANdle,
     * including LED strip type and brightness.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link LEDConfigs#StripType}
     *   <li> {@link LEDConfigs#BrightnessScalar}
     *   <li> {@link LEDConfigs#LossOfSignalBehavior}
     * </ul>
     * 
     */
    public LEDConfigs LED = new LEDConfigs();
    
    /**
     * Configs related to general CANdle features.
     * <p>
     * This includes configs such as disabling the 5V rail and the
     * behavior of VBat output.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CANdleFeaturesConfigs#Enable5VRail}
     *   <li> {@link CANdleFeaturesConfigs#VBatOutputMode}
     *   <li> {@link CANdleFeaturesConfigs#StatusLedWhenActive}
     * </ul>
     * 
     */
    public CANdleFeaturesConfigs CANdleFeatures = new CANdleFeaturesConfigs();
    
    /**
     * Modifies this configuration's CustomParams parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     *
     * @param newCustomParams Parameter to modify
     * @return Itself
     */
    public final CANdleConfiguration withCustomParams(CustomParamsConfigs newCustomParams)
    {
        CustomParams = newCustomParams;
        return this;
    }
    
    /**
     * Modifies this configuration's LED parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs related to CANdle LED control.
     * <p>
     * All the configs related to controlling LEDs with the CANdle,
     * including LED strip type and brightness.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link LEDConfigs#StripType}
     *   <li> {@link LEDConfigs#BrightnessScalar}
     *   <li> {@link LEDConfigs#LossOfSignalBehavior}
     * </ul>
     * 
     *
     * @param newLED Parameter to modify
     * @return Itself
     */
    public final CANdleConfiguration withLED(LEDConfigs newLED)
    {
        LED = newLED;
        return this;
    }
    
    /**
     * Modifies this configuration's CANdleFeatures parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs related to general CANdle features.
     * <p>
     * This includes configs such as disabling the 5V rail and the
     * behavior of VBat output.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CANdleFeaturesConfigs#Enable5VRail}
     *   <li> {@link CANdleFeaturesConfigs#VBatOutputMode}
     *   <li> {@link CANdleFeaturesConfigs#StatusLedWhenActive}
     * </ul>
     * 
     *
     * @param newCANdleFeatures Parameter to modify
     * @return Itself
     */
    public final CANdleConfiguration withCANdleFeatures(CANdleFeaturesConfigs newCANdleFeatures)
    {
        CANdleFeatures = newCANdleFeatures;
        return this;
    }

    @Override
    public String toString() {
        String ss = "CANdleConfiguration\n";
        ss += CustomParams.toString();
        ss += LED.toString();
        ss += CANdleFeatures.toString();
        return ss;
    }

    /**
     * Get the serialized form of this configuration.
     *
     * @return Serialized form of this config group
     */
    public final String serialize() {
        String ss = "";
        ss += CustomParams.serialize();
        ss += LED.serialize();
        ss += CANdleFeatures.serialize();
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration.
     *
     * @return Return code of the deserialize method
     */
    public final StatusCode deserialize(String to_deserialize) {
        StatusCode err = StatusCode.OK;
        err = CustomParams.deserialize(to_deserialize);
        err = LED.deserialize(to_deserialize);
        err = CANdleFeatures.deserialize(to_deserialize);
        return err;
    }

    @Override
    public CANdleConfiguration clone() {
        var retval = new CANdleConfiguration();
        retval.FutureProofConfigs = FutureProofConfigs;
        retval.CustomParams = CustomParams.clone();
        retval.LED = LED.clone();
        retval.CANdleFeatures = CANdleFeatures.clone();
        return retval;
    }
}
