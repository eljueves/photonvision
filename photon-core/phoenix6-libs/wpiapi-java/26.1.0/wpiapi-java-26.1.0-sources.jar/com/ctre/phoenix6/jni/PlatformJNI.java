/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.jni;

public class PlatformJNI extends CtreJniWrapper {
    public static native int JNI_SimCreate(int type, int id);
    public static native int JNI_SimDestroy(int type, int id);
    public static native int JNI_SimDestroyAll();

    public static native int JNI_SimSetPhysicsInput(int type, int id, String physicsType, double value);
    public static native double JNI_SimGetPhysicsValue(int type, int id, String physicsType);
    public static native int JNI_SimGetLastError(int type, int id);

    public static native int JNI_ReportLegacySwerve();
}
