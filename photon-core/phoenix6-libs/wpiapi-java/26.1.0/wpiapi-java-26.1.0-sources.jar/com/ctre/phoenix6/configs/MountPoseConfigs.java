/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs for Pigeon 2's Mount Pose configuration.
 * <p>
 * These configs allow the Pigeon2 to be mounted in whatever
 * orientation that's desired and ensure the reported Yaw/Pitch/Roll
 * is from the robot's reference.
 */
public class MountPoseConfigs implements ParentConfiguration, Cloneable {
    /**
     * The mounting calibration yaw-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     */
    public double MountPoseYaw = 0;
    /**
     * The mounting calibration pitch-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     */
    public double MountPosePitch = 0;
    /**
     * The mounting calibration roll-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     */
    public double MountPoseRoll = 0;
    
    /**
     * Modifies this configuration's MountPoseYaw parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The mounting calibration yaw-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newMountPoseYaw Parameter to modify
     * @return Itself
     */
    public final MountPoseConfigs withMountPoseYaw(double newMountPoseYaw)
    {
        MountPoseYaw = newMountPoseYaw;
        return this;
    }
    
    /**
     * Modifies this configuration's MountPoseYaw parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The mounting calibration yaw-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newMountPoseYaw Parameter to modify
     * @return Itself
     */
    public final MountPoseConfigs withMountPoseYaw(Angle newMountPoseYaw)
    {
        MountPoseYaw = newMountPoseYaw.in(Degrees);
        return this;
    }
    
    /**
     * Helper method to get this configuration's MountPoseYaw parameter converted
     * to a unit type. If not using the Java units library, {@link #MountPoseYaw}
     * can be accessed directly instead.
     * <p>
     * The mounting calibration yaw-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @return MountPoseYaw
     */
    public final Angle getMountPoseYawMeasure()
    {
        return Degrees.of(MountPoseYaw);
    }
    
    /**
     * Modifies this configuration's MountPosePitch parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The mounting calibration pitch-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newMountPosePitch Parameter to modify
     * @return Itself
     */
    public final MountPoseConfigs withMountPosePitch(double newMountPosePitch)
    {
        MountPosePitch = newMountPosePitch;
        return this;
    }
    
    /**
     * Modifies this configuration's MountPosePitch parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The mounting calibration pitch-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newMountPosePitch Parameter to modify
     * @return Itself
     */
    public final MountPoseConfigs withMountPosePitch(Angle newMountPosePitch)
    {
        MountPosePitch = newMountPosePitch.in(Degrees);
        return this;
    }
    
    /**
     * Helper method to get this configuration's MountPosePitch parameter converted
     * to a unit type. If not using the Java units library, {@link #MountPosePitch}
     * can be accessed directly instead.
     * <p>
     * The mounting calibration pitch-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @return MountPosePitch
     */
    public final Angle getMountPosePitchMeasure()
    {
        return Degrees.of(MountPosePitch);
    }
    
    /**
     * Modifies this configuration's MountPoseRoll parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The mounting calibration roll-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newMountPoseRoll Parameter to modify
     * @return Itself
     */
    public final MountPoseConfigs withMountPoseRoll(double newMountPoseRoll)
    {
        MountPoseRoll = newMountPoseRoll;
        return this;
    }
    
    /**
     * Modifies this configuration's MountPoseRoll parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The mounting calibration roll-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newMountPoseRoll Parameter to modify
     * @return Itself
     */
    public final MountPoseConfigs withMountPoseRoll(Angle newMountPoseRoll)
    {
        MountPoseRoll = newMountPoseRoll.in(Degrees);
        return this;
    }
    
    /**
     * Helper method to get this configuration's MountPoseRoll parameter converted
     * to a unit type. If not using the Java units library, {@link #MountPoseRoll}
     * can be accessed directly instead.
     * <p>
     * The mounting calibration roll-component.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -360
     *   <li> <b>Maximum Value:</b> 360
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @return MountPoseRoll
     */
    public final Angle getMountPoseRollMeasure()
    {
        return Degrees.of(MountPoseRoll);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: MountPose\n";
        ss += "    MountPoseYaw: " + MountPoseYaw + " deg" + "\n";
        ss += "    MountPosePitch: " + MountPosePitch + " deg" + "\n";
        ss += "    MountPoseRoll: " + MountPoseRoll + " deg" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Pigeon2MountPoseYaw.value, MountPoseYaw);
        ss += ConfigJNI.Serializedouble(SpnValue.Pigeon2MountPosePitch.value, MountPosePitch);
        ss += ConfigJNI.Serializedouble(SpnValue.Pigeon2MountPoseRoll.value, MountPoseRoll);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        MountPoseYaw = ConfigJNI.Deserializedouble(SpnValue.Pigeon2MountPoseYaw.value, to_deserialize);
        MountPosePitch = ConfigJNI.Deserializedouble(SpnValue.Pigeon2MountPosePitch.value, to_deserialize);
        MountPoseRoll = ConfigJNI.Deserializedouble(SpnValue.Pigeon2MountPoseRoll.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public MountPoseConfigs clone() {
        try {
            return (MountPoseConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

