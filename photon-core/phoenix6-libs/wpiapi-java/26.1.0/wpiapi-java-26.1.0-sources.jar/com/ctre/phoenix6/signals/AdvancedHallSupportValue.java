/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Requires Phoenix Pro; Improves commutation and velocity measurement for
 * motors with hall sensors.  Talon can use advanced features to improve
 * commutation and velocity measurement when using a motor with hall sensors. 
 * This can improve peak efficiency by as high as 2% and reduce noise in the
 * measured velocity.
 */
public enum AdvancedHallSupportValue
{
    /**
     * Talon will utilize hall sensors without advanced features.
     */
    Disabled(0),
    /**
     * Requires Phoenix Pro; Talon uses advanced features to improve commutation and
     * velocity measurement when using hall sensors.  This can improve peak
     * efficiency by as high as 2% and reduce noise in the measured velocity.
     */
    Enabled(1),;

    public final int value;

    AdvancedHallSupportValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, AdvancedHallSupportValue> _map = null;
    static
    {
        _map = new HashMap<Integer, AdvancedHallSupportValue>();
        for (AdvancedHallSupportValue type : AdvancedHallSupportValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets AdvancedHallSupportValue from specified value
     * @param value Value of AdvancedHallSupportValue
     * @return AdvancedHallSupportValue of specified value
     */
    public static AdvancedHallSupportValue valueOf(int value)
    {
        AdvancedHallSupportValue retval = _map.get(value);
        if (retval != null) return retval;
        return AdvancedHallSupportValue.values()[0];
    }
}
