/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import static edu.wpi.first.units.Units.Degrees;

import java.util.Objects;
import java.util.Optional;

import edu.wpi.first.units.measure.Angle;
import edu.wpi.first.wpilibj.util.Color;
import edu.wpi.first.wpilibj.util.Color8Bit;

/**
 * Represents an RGBW color that can be applied to an LED.
 */
public class RGBWColor {
    /**
     * The red component of the color, within [0, 255].
     */
    public final int Red;
    /**
     * The green component of the color, within [0, 255].
     */
    public final int Green;
    /**
     * The blue component of the color, within [0, 255].
     */
    public final int Blue;
    /**
     * The white component of the color, within [0, 255].
     * Note that not all LED strips support the white component.
     */
    public final int White;

    /**
     * Creates a new RGBW color where all components are off.
     */
    public RGBWColor() {
        this(0, 0, 0, 0);
    }

    /**
     * Creates a new RGB color from the given 8-bit components.
     *
     * @param red The red component of the color, within [0, 255].
     * @param green The green component of the color, within [0, 255].
     * @param blue The blue component of the color, within [0, 255].
     */
    public RGBWColor(int red, int green, int blue) {
        this(red, green, blue, 0);
    }

    /**
     * Creates a new RGBW color from the given 8-bit components.
     *
     * @param red The red component of the color, within [0, 255].
     * @param green The green component of the color, within [0, 255].
     * @param blue The blue component of the color, within [0, 255].
     * @param white The white component of the color, within [0, 255].
     *              Note that not all LED strips support the white component.
     */
    public RGBWColor(int red, int green, int blue, int white) {
        Red = red;
        Green = green;
        Blue = blue;
        White = white;
    }

    /**
     * Creates a new RGBW color from a WPILib color.
     * The white component will be left 0.
     *
     * @param color The WPILib color
     */
    public RGBWColor(Color color) {
        this(
            (int)Math.round(color.red * 255.0),
            (int)Math.round(color.green * 255.0),
            (int)Math.round(color.blue * 255.0),
            0
        );
    }
    /**
     * Creates a new RGBW color from a WPILib 8-bit color.
     * The white component will be left 0.
     *
     * @param color The WPILib color
     */
    public RGBWColor(Color8Bit color) {
        this(color.red, color.green, color.blue, 0);
    }

    /**
     * Creates a new RGBW color from the given hex string.
     *
     * @param hex The color hex in the form "#RRGGBBWW" or "#RRGGBB".
     * @return The color if the hex is valid, otherwise {@link Optional#empty()}
     */
    public static Optional<RGBWColor> fromHex(String hex) {
        /* hex string is either 7 (RGB) or 9 (RGBW) characters and starts with # */
        if ((hex.length() != 7 && hex.length() != 9) || !hex.startsWith("#")) {
            return Optional.empty();
        }

        /* {r, g, b, w} */
        final int[] colors = new int[4];
        for (int i = 1; i < hex.length(); i += 2) {
            int upper = hexToNibble(hex.charAt(i));
            int lower = hexToNibble(hex.charAt(i + 1));
            if (upper < 0 || lower < 0) {
                return Optional.empty();
            }
            colors[(i - 1) / 2] = (upper << 4) | lower;
        }

        return Optional.of(new RGBWColor(colors[0], colors[1], colors[2], colors[3]));
    }

    /**
     * Creates a new RGBW color from the given HSV color.
     *
     * @param h The hue as an angle from [0, 360) deg, where 0 is red.
     * @param s The saturation as a scalar from [0, 1].
     * @param v The value as a scalar from [0, 1].
     * @return The corresponding RGB color; the white component will be 0.
     */
    public static RGBWColor fromHSV(double h, double s, double v) {
        /* wrap h to [0, 360) and clamp s and v */
        if (h < 0.0 || h >= 360.0) {
            h -= Math.floor(h / 360.0) * 360.0;
        }
        s = Math.max(0.0, Math.min(s, 1.0));
        v = Math.max(0.0, Math.min(v, 1.0));

        /* range between highest and lowest RGB components */
        double chroma = s * v;
        /* 6 regions of hue */
        double hue_region = h / 60.0;

        /* the highest RGB component */
        double maxf = v;
        /* the lowest RGB component */
        double minf = maxf - chroma;

        /* offset from max/min for the middle RGB component */
        double Xoffset = chroma * (hue_region - (int)hue_region);
        /* the middle RGB component; even regions from min, odd from max */
        double Xf = ((int)hue_region & 1) != 0
            ? maxf - Xoffset
            : minf + Xoffset;

        /* all scalars within [0, 1], scale to [0, 255] */
        int max = (int)Math.round(maxf * 255);
        int min = (int)Math.round(minf * 255);
        int X = (int)Math.round(Xf * 255);

        switch ((int)hue_region) {
            default:
            case 0:
                return new RGBWColor(max, X, min);
            case 1:
                return new RGBWColor(X, max, min);
            case 2:
                return new RGBWColor(min, max, X);
            case 3:
                return new RGBWColor(min, X, max);
            case 4:
                return new RGBWColor(X, min, max);
            case 5:
                return new RGBWColor(max, min, X);
        }
    }
    /**
     * Creates a new RGBW color from the given HSV color.
     *
     * @param h The hue as an angle from [0, 360) deg.
     * @param s The saturation as a scalar from [0, 1].
     * @param v The value as a scalar from [0, 1].
     * @return The corresponding RGB color; the white component will be 0.
     */
    public static RGBWColor fromHSV(Angle h, double s, double v) {
        return fromHSV(h.in(Degrees), s, v);
    }

    /**
     * Scales down the components of this color by the given brightness.
     * <p>
     * This function returns a new object every call. As a result,
     * we recommend that this is not called inside a tight loop.
     *
     * @param brightness The scalar to apply from [0, 1].
     * @return New color scaled by the given brightness
     */
    public final RGBWColor scaleBrightness(double brightness) {
        brightness = Math.max(0.0, Math.min(brightness, 1.0));
        return new RGBWColor(
            (int)Math.round(Red * brightness),
            (int)Math.round(Green * brightness),
            (int)Math.round(Blue * brightness),
            (int)Math.round(White * brightness)
        );
    }

    @Override
    public boolean equals(Object other) {
        if (other instanceof RGBWColor color) {
            return Red == color.Red &&
                Green == color.Green &&
                Blue == color.Blue &&
                White == color.White;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(Red, Green, Blue, White);
    }

    @Override
    public String toString() {
        return "RGBW(" + Red + ", " + Green + ", " + Blue + ", " + White + ")";
    }

    /**
     * Returns this RGBW color as a hex string.
     * @return A hex string in the format "#RRGGBBWW"
     */
    public final String toHexString() {
        StringBuilder hex = new StringBuilder(9);
        hex.append('#');
        hex.append(nibbleToHex((Red >> 4) & 0xF));
        hex.append(nibbleToHex(Red & 0xF));
        hex.append(nibbleToHex((Green >> 4) & 0xF));
        hex.append(nibbleToHex(Green & 0xF));
        hex.append(nibbleToHex((Blue >> 4) & 0xF));
        hex.append(nibbleToHex(Blue & 0xF));
        hex.append(nibbleToHex((White >> 4) & 0xF));
        hex.append(nibbleToHex(White & 0xF));
        return hex.toString();
    }

    private static int hexToNibble(char hex) {
        if ('A' <= hex && hex <= 'F') {
            return hex - 'A' + 10;
        } else if ('a' <= hex && hex <= 'f') {
            return hex - 'a' + 10;
        } else if ('0' <= hex && hex <= '9') {
            return hex - '0';
        } else {
            /* invalid */
            return -1;
        }
    }
    private static char nibbleToHex(int nibble) {
        if (nibble < 10) {
            return (char)(nibble + '0');
        } else {
            return (char)(nibble - 10 + 'A');
        }
    }
}
