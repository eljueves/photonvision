/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Gravity feedforward/feedback type.
 * <p>
 * This determines the type of the gravity feedforward/feedback.
 * <p>
 * Choose Elevator_Static for systems where the gravity feedforward is constant,
 * such as an elevator. The gravity feedforward output will always have the same
 * sign.
 * <p>
 * Choose Arm_Cosine for systems where the gravity feedback is dependent on the
 * angular position of the mechanism, such as an arm. The gravity feedback
 * output will vary depending on the mechanism angular position. Note that the
 * sensor offset and ratios must be configured so that the sensor reports a
 * position of 0 when the mechanism is horizonal (parallel to the ground), and
 * the reported sensor position is 1:1 with the mechanism.
 */
public enum GravityTypeValue
{
    /**
     * The system's gravity feedforward is constant, such as an elevator. The
     * gravity feedforward output will always have the same sign.
     */
    Elevator_Static(0),
    /**
     * The system's gravity feedback is dependent on the angular position of the
     * mechanism, such as an arm. The gravity feedback output will vary depending on
     * the mechanism angular position. Note that the sensor offset and ratios must
     * be configured so that the sensor reports a position of 0 when the mechanism
     * is horizonal (parallel to the ground), and the reported sensor position is
     * 1:1 with the mechanism.
     */
    Arm_Cosine(1),;

    public final int value;

    GravityTypeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, GravityTypeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, GravityTypeValue>();
        for (GravityTypeValue type : GravityTypeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets GravityTypeValue from specified value
     * @param value Value of GravityTypeValue
     * @return GravityTypeValue of specified value
     */
    public static GravityTypeValue valueOf(int value)
    {
        GravityTypeValue retval = _map.get(value);
        if (retval != null) return retval;
        return GravityTypeValue.values()[0];
    }
}
