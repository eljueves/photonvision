/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.sim;

import static edu.wpi.first.units.Units.*;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.hardware.core.CoreCANdi;
import com.ctre.phoenix6.hardware.CANdi;
import com.ctre.phoenix6.jni.PlatformJNI;
import com.ctre.phoenix6.signals.S1StateValue;
import com.ctre.phoenix6.signals.S2StateValue;

import edu.wpi.first.units.measure.*;

/**
 * Class to control the state of a simulated {@link CANdi}.
 */
public class CANdiSimState {
    private static final DeviceType kDevType = DeviceType.P6_CANdiType;

    private final int _id;

    /**
     * The orientation of the PWM1 sensor relative
     * to the robot chassis.
     * <p>
     * This value should not be changed based on the CANdi PWM1 invert.
     * Rather, this value should be changed when the mechanical linkage
     * between the sensor and the robot changes.
     */
    public ChassisReference Pwm1Orientation;
    /**
     * The offset of the PWM1 sensor position relative to the robot chassis,
     * in rotations. This offset is subtracted from the PWM1 position, allowing
     * for a non-zero sensor offset config to behave correctly in simulation.
     * <p>
     * This value should not be changed after initialization unless the
     * mechanical linkage between the sensor and the robot changes.
     */
    public double Pwm1SensorOffset = 0.0;

    /**
     * The orientation of the PWM2 sensor relative
     * to the robot chassis.
     * <p>
     * This value should not be changed based on the CANdi PWM2 invert.
     * Rather, this value should be changed when the mechanical linkage
     * between the sensor and the robot changes.
     */
    public ChassisReference Pwm2Orientation;
    /**
     * The offset of the PWM2 sensor position relative to the robot chassis,
     * in rotations. This offset is subtracted from the PWM2 position, allowing
     * for a non-zero sensor offset config to behave correctly in simulation.
     * <p>
     * This value should not be changed after initialization unless the
     * mechanical linkage between the sensor and the robot changes.
     */
    public double Pwm2SensorOffset = 0.0;

    /**
     * The orientation of the Quadrature sensor relative
     * to the robot chassis.
     * <p>
     * This value should not be changed based on the CANdi Quadrature invert.
     * Rather, this value should be changed when the mechanical linkage
     * between the sensor and the robot changes.
     */
    public ChassisReference QuadratureOrientation;
    /**
     * The number of quadrature edges per sensor rotation for an external
     * quadrature sensor attached to the CANdi.
     */
    public int QuadratureEdgesPerRotation = 4096;

    /**
     * Creates an object to control the state of the given {@link CANdi}.
     * <p>
     * Note the recommended method of accessing simulation features is to use
     * {@link CANdi#getSimState}.
     *
     * @param device Device to which this simulation state is attached
     */
    public CANdiSimState(CoreCANdi device) {
        this(
            device,
            ChassisReference.CounterClockwise_Positive,
            ChassisReference.CounterClockwise_Positive,
            ChassisReference.CounterClockwise_Positive
        );
    }

    /**
     * Creates an object to control the state of the given {@link CANdi}.
     * <p>
     * Note the recommended method of accessing simulation features is to use
     * {@link CANdi#getSimState}.
     *
     * @param device Device to which this simulation state is attached
     * @param pwm1Orientation Orientation of the PWM1 sensor relative to the robot chassis
     * @param pwm2Orientation Orientation of the PWM2 sensor relative to the robot chassis
     * @param quadratureOrientation Orientation of the Quadrature sensor relative to the robot chassis
     */
    public CANdiSimState(
        CoreCANdi device,
        ChassisReference pwm1Orientation,
        ChassisReference pwm2Orientation,
        ChassisReference quadratureOrientation
    ) {
        _id = device.getDeviceID();
        Pwm1Orientation = pwm1Orientation;
        Pwm2Orientation = pwm2Orientation;
        QuadratureOrientation = quadratureOrientation;
    }

    /**
     * Sets the simulated supply voltage of the CANdi.
     * <p>
     * The minimum allowed supply voltage is 4 V - values below this
     * will be promoted to 4 V.
     *
     * @param volts The supply voltage in Volts
     * @return Status code
     */
    public final StatusCode setSupplyVoltage(double volts) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "SupplyVoltage", volts));
    }
    /**
     * Sets the simulated supply voltage of the CANdi.
     * <p>
     * The minimum allowed supply voltage is 4 V - values below this
     * will be promoted to 4 V.
     *
     * @param voltage The supply voltage
     * @return Status code
     */
    public final StatusCode setSupplyVoltage(Voltage voltage) {
        return setSupplyVoltage(voltage.in(Volts));
    }

    /**
     * Sets the simulated output current of the CANdi.
     *
     * @param amps The output current in amps
     * @return Status code
     */
    public final StatusCode setOutputCurrent(double amps) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "RequestedOutputCurrent", amps));
    }
    /**
     * Sets the simulated output current of the CANdi.
     *
     * @param current The output current
     * @return Status code
     */
    public final StatusCode setOutputCurrent(Current current) {
        return setOutputCurrent(current.in(Amps));
    }

    /**
     * Sets the simulated PWM1 Rise to Rise timing of the CANdi.
     *
     * @param timeSeconds The time between two Rise events in seconds
     * @return Status code
     */
    public final StatusCode setPwm1RiseRise(double timeSeconds) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "PWM1RiseToRise", timeSeconds));
    }
    /**
     * Sets the simulated PWM1 Rise to Rise timing of the CANdi.
     *
     * @param time The time between two Rise events
     * @return Status code
     */
    public final StatusCode setPwm1RiseRise(Time time) {
        return setPwm1RiseRise(time.in(Seconds));
    }

    /**
     * Sets the simulated PWM1 Rise to Fall timing of the CANdi.
     *
     * @param timeSeconds The time between the Rise and Fall events in seconds
     * @return Status code
     */
    public final StatusCode setPwm1RiseFall(double timeSeconds) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "PWM1RiseToFall", timeSeconds));
    }
    /**
     * Sets the simulated PWM1 Rise to Fall timing of the CANdi.
     *
     * @param time The time between the Rise and Fall events
     * @return Status code
     */
    public final StatusCode setPwm1RiseFall(Time time) {
        return setPwm1RiseFall(time.in(Seconds));
    }

    /**
     * Sets whether a PWM sensor is connected to the S1 pin.
     *
     * @param connected True if sensor is connected
     * @return Status code
     */
    public final StatusCode setPwm1Connected(boolean connected) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "PWM1Connected", connected ? 1 : 0));
    }

    /**
     * Sets the simulated pulse width position of the CANdi. This is the position
     * of an external PWM encoder connected to the S1 pin.
     *
     * @param rotations The new position in rotations
     * @return Status code
     */
    public final StatusCode setPwm1Position(double rotations) {
        rotations -= Pwm1SensorOffset;
        if (Pwm1Orientation == ChassisReference.Clockwise_Positive) {
            rotations = -rotations;
        }
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "PWM1Position", rotations));
    }
    /**
     * Sets the simulated pulse width position of the CANdi. This is the position
     * of an external PWM encoder connected to the S1 pin.
     *
     * @param position The new position
     * @return Status code
     */
    public final StatusCode setPwm1Position(Angle position) {
        return setPwm1Position(position.in(Rotations));
    }

    /**
     * Sets the simulated pulse width velocity of the CANdi. This is the velocity
     * of an external PWM encoder connected to the S1 pin.
     *
     * @param rps The new velocity in rotations per second
     * @return Status code
     */
    public final StatusCode setPwm1Velocity(double rps) {
        if (Pwm1Orientation == ChassisReference.Clockwise_Positive) {
            rps = -rps;
        }
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "PWM1Velocity", rps));
    }
    /**
     * Sets the simulated pulse width velocity of the CANdi. This is the velocity
     * of an external PWM encoder connected to the S1 pin.
     *
     * @param velocity The new velocity
     * @return Status code
     */
    public final StatusCode setPwm1Velocity(AngularVelocity velocity) {
        return setPwm1Velocity(velocity.in(RotationsPerSecond));
    }

    /**
     * Sets the simulated PWM2 Rise to Rise timing of the CANdi.
     *
     * @param timeSeconds The time between two Rise events in seconds
     * @return Status code
     */
    public final StatusCode setPwm2RiseRise(double timeSeconds) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "PWM2RiseToRise", timeSeconds));
    }
    /**
     * Sets the simulated PWM2 Rise to Rise timing of the CANdi.
     *
     * @param time The time between two Rise events
     * @return Status code
     */
    public final StatusCode setPwm2RiseRise(Time time) {
        return setPwm2RiseRise(time.in(Seconds));
    }

    /**
     * Sets the simulated PWM2 Rise to Fall timing of the CANdi.
     *
     * @param timeSeconds The time between the Rise and Fall events in seconds
     * @return Status code
     */
    public final StatusCode setPwm2RiseFall(double timeSeconds) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "PWM2RiseToFall", timeSeconds));
    }
    /**
     * Sets the simulated PWM2 Rise to Fall timing of the CANdi.
     *
     * @param time The time between the Rise and Fall events
     * @return Status code
     */
    public final StatusCode setPwm2RiseFall(Time time) {
        return setPwm2RiseFall(time.in(Seconds));
    }

    /**
     * Sets whether a PWM sensor is connected to the S2 pin.
     *
     * @param connected True if sensor is connected
     * @return Status code
     */
    public final StatusCode setPwm2Connected(boolean connected) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "PWM2Connected", connected ? 1 : 0));
    }

    /**
     * Sets the simulated pulse width position of the CANdi. This is the position
     * of an external PWM encoder connected to the S2 pin.
     *
     * @param rotations The new position in rotations
     * @return Status code
     */
    public final StatusCode setPwm2Position(double rotations) {
        rotations -= Pwm2SensorOffset;
        if (Pwm2Orientation == ChassisReference.Clockwise_Positive) {
            rotations = -rotations;
        }
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "PWM2Position", rotations));
    }
    /**
     * Sets the simulated pulse width position of the CANdi. This is the position
     * of an external PWM encoder connected to the S2 pin.
     *
     * @param position The new position
     * @return Status code
     */
    public final StatusCode setPwm2Position(Angle position) {
        return setPwm2Position(position.in(Rotations));
    }

    /**
     * Sets the simulated pulse width velocity of the CANdi. This is the velocity
     * of an external PWM encoder connected to the S2 pin.
     *
     * @param rps The new velocity in rotations per second
     * @return Status code
     */
    public final StatusCode setPwm2Velocity(double rps) {
        if (Pwm2Orientation == ChassisReference.Clockwise_Positive) {
            rps = -rps;
        }
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "PWM2Velocity", rps));
    }
    /**
     * Sets the simulated pulse width velocity of the CANdi. This is the velocity
     * of an external PWM encoder connected to the S2 pin.
     *
     * @param velocity The new velocity
     * @return Status code
     */
    public final StatusCode setPwm2Velocity(AngularVelocity velocity) {
        return setPwm2Velocity(velocity.in(RotationsPerSecond));
    }

    /**
     * Sets the simulated raw quadrature position of the CANdi.
     * <p>
     * Inputs to this function over time should be continuous, as user calls of {@link CANdi#setQuadraturePosition} will be accounted for in the callee.
     * <p>
     * The CANdi integrates this to calculate the true reported quadrature position.
     * <p>
     * When using the WPI Sim GUI, you will notice a readonly {@code position} and settable {@code rawPositionInput}.
     * The readonly signal is the emulated position which will match self-test in Tuner and the hardware API.
     * Changes to {@code rawPositionInput} will be integrated into the emulated position.
     * This way a simulator can modify the position without overriding hardware API calls for home-ing the sensor.
     *
     * @param rotations The raw position in rotations
     * @return Status code
     */
    public final StatusCode setRawQuadraturePosition(double rotations) {
        if (QuadratureOrientation == ChassisReference.Clockwise_Positive) {
            rotations = -rotations;
        }
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "RawQuadraturePosition", rotations * QuadratureEdgesPerRotation));
    }
    /**
     * Sets the simulated raw quadrature position of the CANdi.
     * <p>
     * Inputs to this function over time should be continuous, as user calls of {@link CANdi#setQuadraturePosition} will be accounted for in the callee.
     * <p>
     * The CANdi integrates this to calculate the true reported quadrature position.
     * <p>
     * When using the WPI Sim GUI, you will notice a readonly {@code position} and settable {@code rawPositionInput}.
     * The readonly signal is the emulated position which will match self-test in Tuner and the hardware API.
     * Changes to {@code rawPositionInput} will be integrated into the emulated position.
     * This way a simulator can modify the position without overriding hardware API calls for home-ing the sensor.
     *
     * @param position The raw position
     * @return Status code
     */
    public final StatusCode setRawQuadraturePosition(Angle position) {
        return setRawQuadraturePosition(position.in(Rotations));
    }

    /**
     * Sets the simulated quadrature velocity of the CANdi.
     *
     * @param rps The new velocity in rotations per second
     * @return Status code
     */
    public final StatusCode setQuadratureVelocity(double rps) {
        if (QuadratureOrientation == ChassisReference.Clockwise_Positive) {
            rps = -rps;
        }
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "QuadratureVelocity", rps * QuadratureEdgesPerRotation));
    }
    /**
     * Sets the simulated pulse width velocity of the CANdi.
     *
     * @param velocity The new velocity
     * @return Status code
     */
    public final StatusCode setQuadratureVelocity(AngularVelocity velocity) {
        return setQuadratureVelocity(velocity.in(RotationsPerSecond));
    }

    /**
     * Sets the state of the S1 pin
     *
     * @param state The state to set the S1 pin to
     * @return Status code
     */
    public final StatusCode setS1State(S1StateValue state) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "S1State", state.value));
    }
    /**
     * Sets the state of the S2 pin
     *
     * @param state The state to set the S2 pin to
     * @return Status code
     */
    public final StatusCode setS2State(S2StateValue state) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "S2State", state.value));
    }
}
