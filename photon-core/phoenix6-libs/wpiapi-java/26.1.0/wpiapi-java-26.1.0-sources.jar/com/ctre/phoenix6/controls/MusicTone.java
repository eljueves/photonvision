/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.jni.ControlJNI;
import com.ctre.phoenix6.hardware.traits.*;

import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Plays a single tone at the user specified frequency.
 */
public final class MusicTone implements ControlRequest, Cloneable {
    /**
     * Sound frequency to play.  A value of zero will silence the device. The
     * effective frequency range is 10-20000 Hz.  Any nonzero frequency less than 10
     * Hz will be capped to 10 Hz.  Any frequency above 20 kHz will be capped to 20
     * kHz.
     * 
     * <ul>
     *   <li> Units: Hz
     * </ul>
     * 
     */
    public double AudioFrequency;

    /**
     * The frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     */
    public double UpdateFreqHz = 100;

    /**
     * Plays a single tone at the user specified frequency.
     * 
     * @param AudioFrequency Sound frequency to play.  A value of zero will silence
     *                       the device. The effective frequency range is 10-20000
     *                       Hz.  Any nonzero frequency less than 10 Hz will be
     *                       capped to 10 Hz.  Any frequency above 20 kHz will be
     *                       capped to 20 kHz.
     */
    public MusicTone(double AudioFrequency) {
        this.AudioFrequency = AudioFrequency;
    }

    /**
     * Plays a single tone at the user specified frequency.
     * 
     * @param AudioFrequency Sound frequency to play.  A value of zero will silence
     *                       the device. The effective frequency range is 10-20000
     *                       Hz.  Any nonzero frequency less than 10 Hz will be
     *                       capped to 10 Hz.  Any frequency above 20 kHz will be
     *                       capped to 20 kHz.
     */
    public MusicTone(Frequency AudioFrequency) {
        this(AudioFrequency.in(Hertz));
    }

    @Override
    public String getName() {
        return "MusicTone";
    }

    @Override
    public String toString() {
        String ss = "Control: MusicTone\n";
        ss += "    AudioFrequency: " + AudioFrequency + " Hz" + "\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlMusicTone(
                network, deviceHash, UpdateFreqHz, AudioFrequency));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String, String>();
        controlInfo.put("Name", getName());
        controlInfo.put("AudioFrequency", String.valueOf(this.AudioFrequency));
        return controlInfo;
    }
    
    /**
     * Modifies this Control Request's AudioFrequency parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Sound frequency to play.  A value of zero will silence the device. The
     * effective frequency range is 10-20000 Hz.  Any nonzero frequency less than 10
     * Hz will be capped to 10 Hz.  Any frequency above 20 kHz will be capped to 20
     * kHz.
     * 
     * <ul>
     *   <li> Units: Hz
     * </ul>
     * 
     *
     * @param newAudioFrequency Parameter to modify
     * @return Itself
     */
    public MusicTone withAudioFrequency(double newAudioFrequency) {
        AudioFrequency = newAudioFrequency;
        return this;
    }
    
    /**
     * Modifies this Control Request's AudioFrequency parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Sound frequency to play.  A value of zero will silence the device. The
     * effective frequency range is 10-20000 Hz.  Any nonzero frequency less than 10
     * Hz will be capped to 10 Hz.  Any frequency above 20 kHz will be capped to 20
     * kHz.
     * 
     * <ul>
     *   <li> Units: Hz
     * </ul>
     * 
     *
     * @param newAudioFrequency Parameter to modify
     * @return Itself
     */
    public MusicTone withAudioFrequency(Frequency newAudioFrequency) {
        AudioFrequency = newAudioFrequency.in(Hertz);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's AudioFrequency parameter converted
     * to a unit type. If not using the Java units library, {@link #AudioFrequency}
     * can be accessed directly instead.
     * <p>
     * Sound frequency to play.  A value of zero will silence the device. The
     * effective frequency range is 10-20000 Hz.  Any nonzero frequency less than 10
     * Hz will be capped to 10 Hz.  Any frequency above 20 kHz will be capped to 20
     * kHz.
     * 
     * <ul>
     *   <li> Units: Hz
     * </ul>
     * 
     *
     * @return AudioFrequency
     */
    public Frequency getAudioFrequencyMeasure() {
        return Hertz.of(AudioFrequency);
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public MusicTone withUpdateFreqHz(double newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public MusicTone withUpdateFreqHz(Frequency newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz.in(Hertz);
        return this;
    }

    @Override
    public MusicTone clone() {
        try {
            return (MusicTone)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

