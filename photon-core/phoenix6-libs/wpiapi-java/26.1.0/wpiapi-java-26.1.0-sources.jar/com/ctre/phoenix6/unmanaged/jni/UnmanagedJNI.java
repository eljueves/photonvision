/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.unmanaged.jni;

import com.ctre.phoenix6.jni.CtreJniWrapper;

public class UnmanagedJNI extends CtreJniWrapper {
    public static native void JNI_FeedEnable(int timeoutMs);

    public static native boolean JNI_GetEnableState();

    public static native int JNI_GetPhoenixVersion();

    public static native void JNI_LoadPhoenix();

    public static native int JNI_IoControl(int ioControlCode, long ioControlParam);

    public static native void JNI_SetPhoenixDiagnosticsStartTime(double startTimeSeconds);

    public static native int JNI_GetApiCompliancy();

    public static native void JNI_IoControlArray(double[] vals);
}
