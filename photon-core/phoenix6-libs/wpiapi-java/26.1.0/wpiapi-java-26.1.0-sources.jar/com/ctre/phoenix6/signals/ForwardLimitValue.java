/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Forward Limit Pin.
 */
public enum ForwardLimitValue
{
    ClosedToGround(0),
    Open(1),;

    public final int value;

    ForwardLimitValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, ForwardLimitValue> _map = null;
    static
    {
        _map = new HashMap<Integer, ForwardLimitValue>();
        for (ForwardLimitValue type : ForwardLimitValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets ForwardLimitValue from specified value
     * @param value Value of ForwardLimitValue
     * @return ForwardLimitValue of specified value
     */
    public static ForwardLimitValue valueOf(int value)
    {
        ForwardLimitValue retval = _map.get(value);
        if (retval != null) return retval;
        return ForwardLimitValue.values()[0];
    }
}
