/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The type of animation running in slot 5 of the CANdle.
 */
public enum Animation5TypeValue
{
    /**
     * No animation.
     */
    Empty(0),
    /**
     * Color flow animation.
     */
    ColorFlow(1),
    /**
     * Fire animation.
     */
    Fire(2),
    /**
     * Larson animation.
     */
    Larson(3),
    /**
     * Rainbow animation.
     */
    Rainbow(4),
    /**
     * RGB Fade animation.
     */
    RgbFade(5),
    /**
     * Single fade animation.
     */
    SingleFade(6),
    /**
     * Strobe animation.
     */
    Strobe(7),
    /**
     * Twinkle animation.
     */
    Twinkle(8),
    /**
     * Twinkle off animation.
     */
    TwinkleOff(9),;

    public final int value;

    Animation5TypeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, Animation5TypeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, Animation5TypeValue>();
        for (Animation5TypeValue type : Animation5TypeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets Animation5TypeValue from specified value
     * @param value Value of Animation5TypeValue
     * @return Animation5TypeValue of specified value
     */
    public static Animation5TypeValue valueOf(int value)
    {
        Animation5TypeValue retval = _map.get(value);
        if (retval != null) return retval;
        return Animation5TypeValue.values()[0];
    }
}
