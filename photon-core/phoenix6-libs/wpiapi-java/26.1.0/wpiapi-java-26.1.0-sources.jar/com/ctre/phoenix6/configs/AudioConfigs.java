/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

/**
 * Configs that affect audible components of the device.
 * <p>
 * Includes configuration for the beep on boot.
 */
public class AudioConfigs implements ParentConfiguration, Cloneable {
    /**
     * If true, the TalonFX will beep during boot-up.  This is useful for
     * general debugging, and defaults to true.  If rotor is moving during
     * boot-up, the beep will not occur regardless of this setting.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     */
    public boolean BeepOnBoot = true;
    /**
     * If true, the TalonFX will beep during configuration API calls if
     * device is disabled.  This is useful for general debugging, and
     * defaults to true.  Note that if the rotor is moving, the beep will
     * not occur regardless of this setting.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     */
    public boolean BeepOnConfig = true;
    /**
     * If true, the TalonFX will allow Orchestra and MusicTone requests
     * during disabled state.  This can be used to address corner cases
     * when music features are needed when disabled.  This setting
     * defaults to false.  Note that if the rotor is moving, music
     * features are always disabled regardless of this setting.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean AllowMusicDurDisable = false;
    
    /**
     * Modifies this configuration's BeepOnBoot parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If true, the TalonFX will beep during boot-up.  This is useful for
     * general debugging, and defaults to true.  If rotor is moving during
     * boot-up, the beep will not occur regardless of this setting.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     *
     * @param newBeepOnBoot Parameter to modify
     * @return Itself
     */
    public final AudioConfigs withBeepOnBoot(boolean newBeepOnBoot)
    {
        BeepOnBoot = newBeepOnBoot;
        return this;
    }
    
    /**
     * Modifies this configuration's BeepOnConfig parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If true, the TalonFX will beep during configuration API calls if
     * device is disabled.  This is useful for general debugging, and
     * defaults to true.  Note that if the rotor is moving, the beep will
     * not occur regardless of this setting.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     *
     * @param newBeepOnConfig Parameter to modify
     * @return Itself
     */
    public final AudioConfigs withBeepOnConfig(boolean newBeepOnConfig)
    {
        BeepOnConfig = newBeepOnConfig;
        return this;
    }
    
    /**
     * Modifies this configuration's AllowMusicDurDisable parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If true, the TalonFX will allow Orchestra and MusicTone requests
     * during disabled state.  This can be used to address corner cases
     * when music features are needed when disabled.  This setting
     * defaults to false.  Note that if the rotor is moving, music
     * features are always disabled regardless of this setting.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newAllowMusicDurDisable Parameter to modify
     * @return Itself
     */
    public final AudioConfigs withAllowMusicDurDisable(boolean newAllowMusicDurDisable)
    {
        AllowMusicDurDisable = newAllowMusicDurDisable;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: Audio\n";
        ss += "    BeepOnBoot: " + BeepOnBoot + "\n";
        ss += "    BeepOnConfig: " + BeepOnConfig + "\n";
        ss += "    AllowMusicDurDisable: " + AllowMusicDurDisable + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_BeepOnBoot.value, BeepOnBoot);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_BeepOnConfig.value, BeepOnConfig);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_AllowMusicDurDisable.value, AllowMusicDurDisable);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        BeepOnBoot = ConfigJNI.Deserializeboolean(SpnValue.Config_BeepOnBoot.value, to_deserialize);
        BeepOnConfig = ConfigJNI.Deserializeboolean(SpnValue.Config_BeepOnConfig.value, to_deserialize);
        AllowMusicDurDisable = ConfigJNI.Deserializeboolean(SpnValue.Config_AllowMusicDurDisable.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public AudioConfigs clone() {
        try {
            return (AudioConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

