/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.core;

import com.ctre.phoenix6.hardware.ParentDevice;
import com.ctre.phoenix6.controls.*;
import com.ctre.phoenix6.configs.*;
import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.jni.PlatformJNI;
import com.ctre.phoenix6.sim.DeviceType;
import com.ctre.phoenix6.sim.CANrangeSimState;
import com.ctre.phoenix6.*;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;
import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Class for CANrange, a CAN based Time of Flight (ToF) sensor that measures the
 * distance to the front of the device.
 * 
 * <pre>
 * // Constants used in CANrange construction
 * final int kCANrangeId = 0;
 * final CANBus kCANrangeCANbus = new CANBus("canivore");
 * 
 * // Construct the CANrange
 * final CANrange canrange = new CANrange(kCANrangeId, kCANrangeCANbus);
 * 
 * // Configure the CANrange for basic use
 * CANrangeConfiguration configs = new CANrangeConfiguration();
 * 
 * // Write these configs to the CANrange
 * canrange.getConfigurator().apply(configs);
 * 
 * // Get Distance
 * var distance = canrange.getDistance();
 * 
 * // Refresh and print these values
 * System.out.println("Distance is " + distance.refresh().toString());
 * </pre>
 */
public class CoreCANrange extends ParentDevice
{
    private CANrangeConfigurator _configurator;

    /**
     * Constructs a new CANrange object.
     * <p>
     * Constructs the device using the default CAN bus for the system
     * (see {@link CANBus#CANBus()}).
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     */
    public CoreCANrange(int deviceId)
    {
        this(deviceId, new CANBus());
    }

    /**
     * Constructs a new CANrange object.
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     * @param canbus      Name of the CAN bus this device is on. Possible CAN bus strings are:
     *                    <ul>
     *                      <li>"rio" for the native roboRIO CAN bus
     *                      <li>CANivore name or serial number
     *                      <li>SocketCAN interface (non-FRC Linux only)
     *                      <li>"*" for any CANivore seen by the program
     *                      <li>empty string (default) to select the default for the system:
     *                      <ul>
     *                        <li>"rio" on roboRIO
     *                        <li>"can0" on Linux
     *                        <li>"*" on Windows
     *                      </ul>
     *                    </ul>
     *
     * @deprecated Constructing devices with a CAN bus string is deprecated for removal
     * in the 2027 season. Construct devices using a {@link CANBus} instance instead.
     */
    @Deprecated(since = "2026", forRemoval = true)
    public CoreCANrange(int deviceId, String canbus)
    {
        this(deviceId, new CANBus(canbus));
    }

    /**
     * Constructs a new CANrange object.
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     * @param canbus      The CAN bus this device is on
     */
    public CoreCANrange(int deviceId, CANBus canbus)
    {
        super(deviceId, "canrange", canbus);
        _configurator = new CANrangeConfigurator(this.deviceIdentifier);
        PlatformJNI.JNI_SimCreate(DeviceType.P6_CANrangeType.value, deviceId);
    }

    /**
     * Gets the configurator to use with this device's configs
     *
     * @return Configurator for this object
     */
    public final CANrangeConfigurator getConfigurator()
    {
        return this._configurator;
    }


    private CANrangeSimState _simState = null;
    /**
     * Get the simulation state for this device.
     * <p>
     * This function reuses an allocated simulation state
     * object, so it is safe to call this function multiple
     * times in a robot loop.
     *
     * @return Simulation state
     */
    public final CANrangeSimState getSimState() {
        if (_simState == null)
            _simState = new CANrangeSimState(this);
        return _simState;
    }


        
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMajor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMajor()
    {
        return getVersionMajor(true);
    }
    
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMajor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMajor(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Major.value, "VersionMajor", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMinor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMinor()
    {
        return getVersionMinor(true);
    }
    
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMinor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMinor(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Minor.value, "VersionMinor", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBugfix Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBugfix()
    {
        return getVersionBugfix(true);
    }
    
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBugfix Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBugfix(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Bugfix.value, "VersionBugfix", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBuild Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBuild()
    {
        return getVersionBuild(true);
    }
    
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBuild Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBuild(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Build.value, "VersionBuild", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Version Status Signal Object
     */
    public final StatusSignal<Integer> getVersion()
    {
        return getVersion(true);
    }
    
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Version Status Signal Object
     */
    public final StatusSignal<Integer> getVersion(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Full.value, "Version", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return FaultField Status Signal Object
     */
    public final StatusSignal<Integer> getFaultField()
    {
        return getFaultField(true);
    }
    
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return FaultField Status Signal Object
     */
    public final StatusSignal<Integer> getFaultField(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.AllFaults.value, "FaultField", Integer.class, val -> (int)val, true, refresh);
        return retval;
    }
        
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFaultField Status Signal Object
     */
    public final StatusSignal<Integer> getStickyFaultField()
    {
        return getStickyFaultField(true);
    }
    
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFaultField Status Signal Object
     */
    public final StatusSignal<Integer> getStickyFaultField(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.AllStickyFaults.value, "StickyFaultField", Integer.class, val -> (int)val, true, refresh);
        return retval;
    }
        
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return IsProLicensed Status Signal Object
     */
    public final StatusSignal<Boolean> getIsProLicensed()
    {
        return getIsProLicensed(true);
    }
    
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return IsProLicensed Status Signal Object
     */
    public final StatusSignal<Boolean> getIsProLicensed(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_IsProLicensed.value, "IsProLicensed", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Measured supply voltage to the CANrange.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 4
     *   <li> <b>Maximum Value:</b> 16.75
     *   <li> <b>Default Value:</b> 4
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return SupplyVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getSupplyVoltage()
    {
        return getSupplyVoltage(true);
    }
    
    /**
     * Measured supply voltage to the CANrange.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 4
     *   <li> <b>Maximum Value:</b> 16.75
     *   <li> <b>Default Value:</b> 4
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return SupplyVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getSupplyVoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_SupplyVoltage.value, "SupplyVoltage", Voltage.class, val -> Volts.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Distance to the nearest object in the configured field of view of
     * the CANrange.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 65.535
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> m
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Distance Status Signal Object
     */
    public final StatusSignal<Distance> getDistance()
    {
        return getDistance(true);
    }
    
    /**
     * Distance to the nearest object in the configured field of view of
     * the CANrange.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 65.535
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> m
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Distance Status Signal Object
     */
    public final StatusSignal<Distance> getDistance(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_Distance_Meters.value, "Distance", Distance.class, val -> Meters.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Timestamp of the most recent measurements. This is not synchronized
     * to any other clock source.
     * <p>
     * Users can use this to check when the measurements are updated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 65.535
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> s
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MeasurementTime Status Signal Object
     */
    public final StatusSignal<Time> getMeasurementTime()
    {
        return getMeasurementTime(true);
    }
    
    /**
     * Timestamp of the most recent measurements. This is not synchronized
     * to any other clock source.
     * <p>
     * Users can use this to check when the measurements are updated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 65.535
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> s
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MeasurementTime Status Signal Object
     */
    public final StatusSignal<Time> getMeasurementTime(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_MeasTime.value, "MeasurementTime", Time.class, val -> Seconds.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Approximate signal strength of the measurement. A higher value
     * indicates a higher strength of signal.
     * <p>
     * A value of ~2500 is typical when detecting an object under
     * short-range conditions.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 65535
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return SignalStrength Status Signal Object
     */
    public final StatusSignal<Double> getSignalStrength()
    {
        return getSignalStrength(true);
    }
    
    /**
     * Approximate signal strength of the measurement. A higher value
     * indicates a higher strength of signal.
     * <p>
     * A value of ~2500 is typical when detecting an object under
     * short-range conditions.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 65535
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return SignalStrength Status Signal Object
     */
    public final StatusSignal<Double> getSignalStrength(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_SignalStrength.value, "SignalStrength", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * Whether the CANrange detects an object using the configured
     * proximity parameters.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> 0
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return IsDetected Status Signal Object
     */
    public final StatusSignal<Boolean> getIsDetected()
    {
        return getIsDetected(true);
    }
    
    /**
     * Whether the CANrange detects an object using the configured
     * proximity parameters.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> 0
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return IsDetected Status Signal Object
     */
    public final StatusSignal<Boolean> getIsDetected(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_ProximityDetected.value, "IsDetected", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Health of the distance measurement.
     * 
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MeasurementHealth Status Signal Object
     */
    public final StatusSignal<MeasurementHealthValue> getMeasurementHealth()
    {
        return getMeasurementHealth(true);
    }
    
    /**
     * Health of the distance measurement.
     * 
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MeasurementHealth Status Signal Object
     */
    public final StatusSignal<MeasurementHealthValue> getMeasurementHealth(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_MeasState.value, "MeasurementHealth", MeasurementHealthValue.class, val -> MeasurementHealthValue.valueOf((int)val), true, refresh);
        return retval;
    }
        
    /**
     * The amount of ambient infrared light that the sensor is detecting.
     * For ideal operation, this should be as low as possible.
     * <p>
     * Short-range mode reduces the influence of ambient infrared light.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 65535
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AmbientSignal Status Signal Object
     */
    public final StatusSignal<Double> getAmbientSignal()
    {
        return getAmbientSignal(true);
    }
    
    /**
     * The amount of ambient infrared light that the sensor is detecting.
     * For ideal operation, this should be as low as possible.
     * <p>
     * Short-range mode reduces the influence of ambient infrared light.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 65535
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AmbientSignal Status Signal Object
     */
    public final StatusSignal<Double> getAmbientSignal(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_AmbientSignal.value, "AmbientSignal", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * Standard Deviation of the distance measurement.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.3107000000000002
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> m
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DistanceStdDev Status Signal Object
     */
    public final StatusSignal<Distance> getDistanceStdDev()
    {
        return getDistanceStdDev(true);
    }
    
    /**
     * Standard Deviation of the distance measurement.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.3107000000000002
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> m
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DistanceStdDev Status Signal Object
     */
    public final StatusSignal<Distance> getDistanceStdDev(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_DistanceStdDev.value, "DistanceStdDev", Distance.class, val -> Meters.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The actual center of the FOV in the X direction. This takes into
     * account the user-configured FOVCenterX and FOVRangeX.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16.0
     *   <li> <b>Maximum Value:</b> 15.875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RealFOVCenterX Status Signal Object
     */
    public final StatusSignal<Angle> getRealFOVCenterX()
    {
        return getRealFOVCenterX(true);
    }
    
    /**
     * The actual center of the FOV in the X direction. This takes into
     * account the user-configured FOVCenterX and FOVRangeX.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16.0
     *   <li> <b>Maximum Value:</b> 15.875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RealFOVCenterX Status Signal Object
     */
    public final StatusSignal<Angle> getRealFOVCenterX(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_RealFOVCenterX.value, "RealFOVCenterX", Angle.class, val -> Degrees.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The actual center of the FOV in the Y direction. This takes into
     * account the user-configured FOVCenterY and FOVRangeY.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16.0
     *   <li> <b>Maximum Value:</b> 15.875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RealFOVCenterY Status Signal Object
     */
    public final StatusSignal<Angle> getRealFOVCenterY()
    {
        return getRealFOVCenterY(true);
    }
    
    /**
     * The actual center of the FOV in the Y direction. This takes into
     * account the user-configured FOVCenterY and FOVRangeY.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16.0
     *   <li> <b>Maximum Value:</b> 15.875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RealFOVCenterY Status Signal Object
     */
    public final StatusSignal<Angle> getRealFOVCenterY(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_RealFOVCenterY.value, "RealFOVCenterY", Angle.class, val -> Degrees.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The actual range of the FOV in the X direction. This takes into
     * account the user-configured FOVRangeX.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 31.875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RealFOVRangeX Status Signal Object
     */
    public final StatusSignal<Angle> getRealFOVRangeX()
    {
        return getRealFOVRangeX(true);
    }
    
    /**
     * The actual range of the FOV in the X direction. This takes into
     * account the user-configured FOVRangeX.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 31.875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RealFOVRangeX Status Signal Object
     */
    public final StatusSignal<Angle> getRealFOVRangeX(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_RealFOVRangeX.value, "RealFOVRangeX", Angle.class, val -> Degrees.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The actual range of the FOV in the Y direction. This takes into
     * account the user-configured FOVRangeY.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 31.875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RealFOVRangeY Status Signal Object
     */
    public final StatusSignal<Angle> getRealFOVRangeY()
    {
        return getRealFOVRangeY(true);
    }
    
    /**
     * The actual range of the FOV in the Y direction. This takes into
     * account the user-configured FOVRangeY.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 31.875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RealFOVRangeY Status Signal Object
     */
    public final StatusSignal<Angle> getRealFOVRangeY(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANrange_RealFOVRangeY.value, "RealFOVRangeY", Angle.class, val -> Degrees.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Hardware()
    {
        return getFault_Hardware(true);
    }
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Hardware(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_Hardware.value, "Fault_Hardware", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Hardware()
    {
        return getStickyFault_Hardware(true);
    }
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Hardware(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_Hardware.value, "StickyFault_Hardware", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Undervoltage()
    {
        return getFault_Undervoltage(true);
    }
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Undervoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_Undervoltage.value, "Fault_Undervoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Undervoltage()
    {
        return getStickyFault_Undervoltage(true);
    }
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Undervoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_Undervoltage.value, "StickyFault_Undervoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootDuringEnable()
    {
        return getFault_BootDuringEnable(true);
    }
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootDuringEnable(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_BootDuringEnable.value, "Fault_BootDuringEnable", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootDuringEnable()
    {
        return getStickyFault_BootDuringEnable(true);
    }
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootDuringEnable(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_BootDuringEnable.value, "StickyFault_BootDuringEnable", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_UnlicensedFeatureInUse()
    {
        return getFault_UnlicensedFeatureInUse(true);
    }
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_UnlicensedFeatureInUse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_UnlicensedFeatureInUse.value, "Fault_UnlicensedFeatureInUse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse()
    {
        return getStickyFault_UnlicensedFeatureInUse(true);
    }
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_UnlicensedFeatureInUse.value, "StickyFault_UnlicensedFeatureInUse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }

    

    /**
     * Control device with generic control request object.
     * <p>
     * User must make sure the specified object is castable to a valid control request,
     * otherwise this function will fail at run-time and return the NotSupported StatusCode
     *
     * @param request Control object to request of the device
     * @return Status Code of the request, 0 is OK
     */
    public final StatusCode setControl(ControlRequest request)
    {
        
        return StatusCode.NotSupported;
    }

    
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults() {
        return clearStickyFaults(0.100);
    }
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults(double timeoutSeconds) {
        return getConfigurator().clearStickyFaults(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware() {
        return clearStickyFault_Hardware(0.100);
    }
    /**
     * Clear sticky fault: Hardware fault occurred
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Hardware(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage() {
        return clearStickyFault_Undervoltage(0.100);
    }
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Undervoltage(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable() {
        return clearStickyFault_BootDuringEnable(0.100);
    }
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_BootDuringEnable(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse() {
        return clearStickyFault_UnlicensedFeatureInUse(0.100);
    }
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_UnlicensedFeatureInUse(timeoutSeconds);
    }
}

