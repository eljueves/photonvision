/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * What value the Signal 1 input (S1IN) needs to be for the CTR Electronics'
 * CANdi™ to detect as Closed.
 * <p>
 * Devices using the S1 input as a remote limit switch will treat the switch as
 * closed when the S1 input is this state.
 */
public enum S1CloseStateValue
{
    /**
     * The S1 input will be treated as closed when it is not floating.
     */
    CloseWhenNotFloating(0),
    /**
     * The S1 input will be treated as closed when it is floating.
     */
    CloseWhenFloating(1),
    /**
     * The S1 input will be treated as closed when it is not High.
     */
    CloseWhenNotHigh(2),
    /**
     * The S1 input will be treated as closed when it is High.
     */
    CloseWhenHigh(3),
    /**
     * The S1 input will be treated as closed when it is not Low.
     */
    CloseWhenNotLow(4),
    /**
     * The S1 input will be treated as closed when it is Low.
     */
    CloseWhenLow(5),;

    public final int value;

    S1CloseStateValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, S1CloseStateValue> _map = null;
    static
    {
        _map = new HashMap<Integer, S1CloseStateValue>();
        for (S1CloseStateValue type : S1CloseStateValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets S1CloseStateValue from specified value
     * @param value Value of S1CloseStateValue
     * @return S1CloseStateValue of specified value
     */
    public static S1CloseStateValue valueOf(int value)
    {
        S1CloseStateValue retval = _map.get(value);
        if (retval != null) return retval;
        return S1CloseStateValue.values()[0];
    }
}
