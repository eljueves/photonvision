/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.traits;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.*;
import com.ctre.phoenix6.controls.compound.*;

/**
 * Contains all control functions available for devices that support Talon
 * controls.
 */
public interface HasTalonControls extends CommonDevice
{
    
    
    /**
     * Request a specified motor duty cycle.
     * <p>
     * This control mode will output a proportion of the supplied voltage
     * which is supplied by the user.
     * <ul>
     *   <li> <b>DutyCycleOut Parameters:</b> 
     *   <ul>
     *     <li> <b>Output:</b> Proportion of supply voltage to apply in fractional
     *                         units between -1 and +1
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DutyCycleOut request);
    
    /**
     * Request a specified voltage.
     * <p>
     * This control mode will attempt to apply the specified voltage to
     * the motor. If the supply voltage is below the requested voltage,
     * the motor controller will output the supply voltage.
     * <ul>
     *   <li> <b>VoltageOut Parameters:</b> 
     *   <ul>
     *     <li> <b>Output:</b> Voltage to attempt to drive at
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(VoltageOut request);
    
    /**
     * Request PID to target position with duty cycle feedforward.
     * <p>
     * This control mode will set the motor's position setpoint to the
     * position specified by the user. In addition, it will apply an
     * additional duty cycle as an arbitrary feedforward value.
     * <ul>
     *   <li> <b>PositionDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>Velocity:</b> Velocity to drive toward in rotations per second.
     *                           This is typically used for motion profiles
     *                           generated by the robot program.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in fractional units between
     *                              -1 and +1. This is added to the output of the
     *                              onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(PositionDutyCycle request);
    
    /**
     * Request PID to target position with voltage feedforward
     * <p>
     * This control mode will set the motor's position setpoint to the
     * position specified by the user. In addition, it will apply an
     * additional voltage as an arbitrary feedforward value.
     * <ul>
     *   <li> <b>PositionVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>Velocity:</b> Velocity to drive toward in rotations per second.
     *                           This is typically used for motion profiles
     *                           generated by the robot program.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in volts. This is added to
     *                              the output of the onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(PositionVoltage request);
    
    /**
     * Request PID to target velocity with duty cycle feedforward.
     * <p>
     * This control mode will set the motor's velocity setpoint to the
     * velocity specified by the user. In addition, it will apply an
     * additional voltage as an arbitrary feedforward value.
     * <ul>
     *   <li> <b>VelocityDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>Velocity:</b> Velocity to drive toward in rotations per second.
     *     <li> <b>Acceleration:</b> Acceleration to drive toward in rotations per
     *                               second squared. This is typically used for
     *                               motion profiles generated by the robot program.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in fractional units between
     *                              -1 and +1. This is added to the output of the
     *                              onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(VelocityDutyCycle request);
    
    /**
     * Request PID to target velocity with voltage feedforward.
     * <p>
     * This control mode will set the motor's velocity setpoint to the
     * velocity specified by the user. In addition, it will apply an
     * additional voltage as an arbitrary feedforward value.
     * <ul>
     *   <li> <b>VelocityVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>Velocity:</b> Velocity to drive toward in rotations per second.
     *     <li> <b>Acceleration:</b> Acceleration to drive toward in rotations per
     *                               second squared. This is typically used for
     *                               motion profiles generated by the robot program.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in volts This is added to
     *                              the output of the onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(VelocityVoltage request);
    
    /**
     * Requests Motion Magic® to target a final position using a motion
     * profile.  Users can optionally provide a duty cycle feedforward.
     * <p>
     * Motion Magic® produces a motion profile in real-time while
     * attempting to honor the Cruise Velocity, Acceleration, and
     * (optional) Jerk specified via the Motion Magic® configuration
     * values.  This control mode does not use the Expo_kV or Expo_kA
     * configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is duty cycle
     * based, so relevant closed-loop gains will use fractional duty cycle
     * for the numerator:  +1.0 represents full forward output.
     * <ul>
     *   <li> <b>MotionMagicDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in fractional units between
     *                              -1 and +1. This is added to the output of the
     *                              onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(MotionMagicDutyCycle request);
    
    /**
     * Requests Motion Magic® to target a final position using a motion
     * profile.  Users can optionally provide a voltage feedforward.
     * <p>
     * Motion Magic® produces a motion profile in real-time while
     * attempting to honor the Cruise Velocity, Acceleration, and
     * (optional) Jerk specified via the Motion Magic® configuration
     * values.  This control mode does not use the Expo_kV or Expo_kA
     * configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is
     * voltage-based, so relevant closed-loop gains will use Volts for the
     * numerator.
     * <ul>
     *   <li> <b>MotionMagicVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in volts. This is added to
     *                              the output of the onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(MotionMagicVoltage request);
    
    /**
     * Requests Motion Magic® to target a final velocity using a motion
     * profile.  This allows smooth transitions between velocity set
     * points.  Users can optionally provide a duty cycle feedforward.
     * <p>
     * Motion Magic® Velocity produces a motion profile in real-time while
     * attempting to honor the specified Acceleration and (optional) Jerk.
     *  This control mode does not use the CruiseVelocity, Expo_kV, or
     * Expo_kA configs.
     * <p>
     * If the specified acceleration is zero, the Acceleration under
     * Motion Magic® configuration parameter is used instead.  This allows
     * for runtime adjustment of acceleration for advanced users.  Jerk is
     * also specified in the Motion Magic® persistent configuration
     * values.  If Jerk is set to zero, Motion Magic® will produce a
     * trapezoidal acceleration profile.
     * <p>
     * Target velocity can also be changed on-the-fly and Motion Magic®
     * will do its best to adjust the profile.  This control mode is duty
     * cycle based, so relevant closed-loop gains will use fractional duty
     * cycle for the numerator:  +1.0 represents full forward output.
     * <ul>
     *   <li> <b>MotionMagicVelocityDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>Velocity:</b> Target velocity to drive toward in rotations per
     *                           second.  This can be changed on-the fly.
     *     <li> <b>Acceleration:</b> This is the absolute Acceleration to use
     *                               generating the profile.  If this parameter is
     *                               zero, the Acceleration persistent configuration
     *                               parameter is used instead. Acceleration is in
     *                               rotations per second squared.  If nonzero, the
     *                               signage does not matter as the absolute value
     *                               is used.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in fractional units between
     *                              -1 and +1. This is added to the output of the
     *                              onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(MotionMagicVelocityDutyCycle request);
    
    /**
     * Requests Motion Magic® to target a final velocity using a motion
     * profile.  This allows smooth transitions between velocity set
     * points.  Users can optionally provide a voltage feedforward.
     * <p>
     * Motion Magic® Velocity produces a motion profile in real-time while
     * attempting to honor the specified Acceleration and (optional) Jerk.
     *  This control mode does not use the CruiseVelocity, Expo_kV, or
     * Expo_kA configs.
     * <p>
     * If the specified acceleration is zero, the Acceleration under
     * Motion Magic® configuration parameter is used instead.  This allows
     * for runtime adjustment of acceleration for advanced users.  Jerk is
     * also specified in the Motion Magic® persistent configuration
     * values.  If Jerk is set to zero, Motion Magic® will produce a
     * trapezoidal acceleration profile.
     * <p>
     * Target velocity can also be changed on-the-fly and Motion Magic®
     * will do its best to adjust the profile.  This control mode is
     * voltage-based, so relevant closed-loop gains will use Volts for the
     * numerator.
     * <ul>
     *   <li> <b>MotionMagicVelocityVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>Velocity:</b> Target velocity to drive toward in rotations per
     *                           second.  This can be changed on-the fly.
     *     <li> <b>Acceleration:</b> This is the absolute Acceleration to use
     *                               generating the profile.  If this parameter is
     *                               zero, the Acceleration persistent configuration
     *                               parameter is used instead. Acceleration is in
     *                               rotations per second squared.  If nonzero, the
     *                               signage does not matter as the absolute value
     *                               is used.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in volts. This is added to
     *                              the output of the onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(MotionMagicVelocityVoltage request);
    
    /**
     * Requests Motion Magic® to target a final position using an
     * exponential motion profile.  Users can optionally provide a duty
     * cycle feedforward.
     * <p>
     * Motion Magic® Expo produces a motion profile in real-time while
     * attempting to honor the Cruise Velocity (optional) and the
     * mechanism kV and kA, specified via the Motion Magic® configuration
     * values.  Note that unlike the slot gains, the Expo_kV and Expo_kA
     * configs are always in output units of Volts.
     * <p>
     * Setting Cruise Velocity to 0 will allow the profile to run to the
     * max possible velocity based on Expo_kV.  This control mode does not
     * use the Acceleration or Jerk configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is duty cycle
     * based, so relevant closed-loop gains will use fractional duty cycle
     * for the numerator:  +1.0 represents full forward output.
     * <ul>
     *   <li> <b>MotionMagicExpoDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in fractional units between
     *                              -1 and +1. This is added to the output of the
     *                              onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(MotionMagicExpoDutyCycle request);
    
    /**
     * Requests Motion Magic® to target a final position using an
     * exponential motion profile.  Users can optionally provide a voltage
     * feedforward.
     * <p>
     * Motion Magic® Expo produces a motion profile in real-time while
     * attempting to honor the Cruise Velocity (optional) and the
     * mechanism kV and kA, specified via the Motion Magic® configuration
     * values.  Note that unlike the slot gains, the Expo_kV and Expo_kA
     * configs are always in output units of Volts.
     * <p>
     * Setting Cruise Velocity to 0 will allow the profile to run to the
     * max possible velocity based on Expo_kV.  This control mode does not
     * use the Acceleration or Jerk configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is
     * voltage-based, so relevant closed-loop gains will use Volts for the
     * numerator.
     * <ul>
     *   <li> <b>MotionMagicExpoVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in volts. This is added to
     *                              the output of the onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(MotionMagicExpoVoltage request);
    
    /**
     * Requests Motion Magic® to target a final position using a motion
     * profile.  This dynamic request allows runtime changes to Cruise
     * Velocity, Acceleration, and (optional) Jerk.  Users can optionally
     * provide a duty cycle feedforward.
     * <p>
     * Motion Magic® produces a motion profile in real-time while
     * attempting to honor the specified Cruise Velocity, Acceleration,
     * and (optional) Jerk.  This control mode does not use the Expo_kV or
     * Expo_kA configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile. This control mode is duty cycle
     * based, so relevant closed-loop gains will use fractional duty cycle
     * for the numerator:  +1.0 represents full forward output.
     * <ul>
     *   <li> <b>DynamicMotionMagicDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>Velocity:</b> Cruise velocity for profiling.  The signage does
     *                           not matter as the device will use the absolute
     *                           value for profile generation.
     *     <li> <b>Acceleration:</b> Acceleration for profiling.  The signage does
     *                               not matter as the device will use the absolute
     *                               value for profile generation
     *     <li> <b>Jerk:</b> Jerk for profiling.  The signage does not matter as the
     *                       device will use the absolute value for profile
     *                       generation.
     *                       <p>
     *                       Jerk is optional; if this is set to zero, then Motion
     *                       Magic® will not apply a Jerk limit.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in fractional units between
     *                              -1 and +1. This is added to the output of the
     *                              onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DynamicMotionMagicDutyCycle request);
    
    /**
     * Requests Motion Magic® to target a final position using a motion
     * profile.  This dynamic request allows runtime changes to Cruise
     * Velocity, Acceleration, and (optional) Jerk.  Users can optionally
     * provide a voltage feedforward.
     * <p>
     * Motion Magic® produces a motion profile in real-time while
     * attempting to honor the specified Cruise Velocity, Acceleration,
     * and (optional) Jerk.  This control mode does not use the Expo_kV or
     * Expo_kA configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is
     * voltage-based, so relevant closed-loop gains will use Volts for the
     * numerator.
     * <ul>
     *   <li> <b>DynamicMotionMagicVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>Velocity:</b> Cruise velocity for profiling.  The signage does
     *                           not matter as the device will use the absolute
     *                           value for profile generation.
     *     <li> <b>Acceleration:</b> Acceleration for profiling.  The signage does
     *                               not matter as the device will use the absolute
     *                               value for profile generation.
     *     <li> <b>Jerk:</b> Jerk for profiling.  The signage does not matter as the
     *                       device will use the absolute value for profile
     *                       generation.
     *                       <p>
     *                       Jerk is optional; if this is set to zero, then Motion
     *                       Magic® will not apply a Jerk limit.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in volts. This is added to
     *                              the output of the onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DynamicMotionMagicVoltage request);
    
    /**
     * Requests Motion Magic® Expo to target a final position using an
     * exponential motion profile.  This dynamic request allows runtime
     * changes to the profile kV, kA, and (optional) Cruise Velocity. 
     * Users can optionally provide a duty cycle feedforward.
     * <p>
     * Motion Magic® Expo produces a motion profile in real-time while
     * attempting to honor the specified Cruise Velocity (optional) and
     * the mechanism kV and kA.  Note that unlike the slot gains, the
     * Expo_kV and Expo_kA parameters are always in output units of Volts.
     * <p>
     * Setting the Cruise Velocity to 0 will allow the profile to run to
     * the max possible velocity based on Expo_kV.  This control mode does
     * not use the Acceleration or Jerk configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile. This control mode is duty cycle
     * based, so relevant closed-loop gains will use fractional duty cycle
     * for the numerator:  +1.0 represents full forward output.
     * <ul>
     *   <li> <b>DynamicMotionMagicExpoDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>kV:</b> Mechanism kV for profiling.  Unlike the kV slot gain,
     *                     this is always in units of V/rps.
     *                     <p>
     *                     This represents the amount of voltage necessary to hold a
     *                     velocity.  In terms of the Motion Magic® Expo profile, a
     *                     higher kV results in a slower maximum velocity.
     *     <li> <b>kA:</b> Mechanism kA for profiling.  Unlike the kA slot gain,
     *                     this is always in units of V/rps².
     *                     <p>
     *                     This represents the amount of voltage necessary to
     *                     achieve an acceleration.  In terms of the Motion Magic®
     *                     Expo profile, a higher kA results in a slower
     *                     acceleration.
     *     <li> <b>Velocity:</b> Cruise velocity for profiling.  The signage does
     *                           not matter as the device will use the absolute
     *                           value for profile generation.  Setting this to 0
     *                           will allow the profile to run to the max possible
     *                           velocity based on Expo_kV.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in fractional units between
     *                              -1 and +1. This is added to the output of the
     *                              onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DynamicMotionMagicExpoDutyCycle request);
    
    /**
     * Requests Motion Magic® Expo to target a final position using an
     * exponential motion profile.  This dynamic request allows runtime
     * changes to the profile kV, kA, and (optional) Cruise Velocity. 
     * Users can optionally provide a voltage feedforward.
     * <p>
     * Motion Magic® Expo produces a motion profile in real-time while
     * attempting to honor the specified Cruise Velocity (optional) and
     * the mechanism kV and kA.  Note that unlike the slot gains, the
     * Expo_kV and Expo_kA parameters are always in output units of Volts.
     * <p>
     * Setting the Cruise Velocity to 0 will allow the profile to run to
     * the max possible velocity based on Expo_kV.  This control mode does
     * not use the Acceleration or Jerk configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is
     * voltage-based, so relevant closed-loop gains will use Volts for the
     * numerator.
     * <ul>
     *   <li> <b>DynamicMotionMagicExpoVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>kV:</b> Mechanism kV for profiling.  Unlike the kV slot gain,
     *                     this is always in units of V/rps.
     *                     <p>
     *                     This represents the amount of voltage necessary to hold a
     *                     velocity.  In terms of the Motion Magic® Expo profile, a
     *                     higher kV results in a slower maximum velocity.
     *     <li> <b>kA:</b> Mechanism kA for profiling.  Unlike the kA slot gain,
     *                     this is always in units of V/rps².
     *                     <p>
     *                     This represents the amount of voltage necessary to
     *                     achieve an acceleration.  In terms of the Motion Magic®
     *                     Expo profile, a higher kA results in a slower
     *                     acceleration.
     *     <li> <b>Velocity:</b> Cruise velocity for profiling.  The signage does
     *                           not matter as the device will use the absolute
     *                           value for profile generation.  Setting this to 0
     *                           will allow the profile to run to the max possible
     *                           velocity based on Expo_kV.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>FeedForward:</b> Feedforward to apply in volts. This is added to
     *                              the output of the onboard feedforward terms.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DynamicMotionMagicExpoVoltage request);
    
    /**
     * Request a specified motor duty cycle with a differential position
     * closed-loop.
     * <p>
     * This control mode will output a proportion of the supplied voltage
     * which is supplied by the user. It will also set the motor's
     * differential position setpoint to the specified position.
     * <ul>
     *   <li> <b>DifferentialDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageOutput:</b> Proportion of supply voltage to apply on the
     *                                Average axis in fractional units between -1
     *                                and +1.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive towards
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialDutyCycle request);
    
    /**
     * Request a specified voltage with a differential position
     * closed-loop.
     * <p>
     * This control mode will attempt to apply the specified voltage to
     * the motor. If the supply voltage is below the requested voltage,
     * the motor controller will output the supply voltage. It will also
     * set the motor's differential position setpoint to the specified
     * position.
     * <ul>
     *   <li> <b>DifferentialVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageOutput:</b> Voltage to attempt to drive at on the Average
     *                                axis.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive towards
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialVoltage request);
    
    /**
     * Request PID to target position with a differential position
     * setpoint.
     * <p>
     * This control mode will set the motor's position setpoint to the
     * position specified by the user. It will also set the motor's
     * differential position setpoint to the specified position.
     * <ul>
     *   <li> <b>DifferentialPositionDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>AveragePosition:</b> Average position to drive toward in
     *                                  rotations.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive toward
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>AverageSlot:</b> Select which gains are applied to the average
     *                              controller by selecting the slot.  Use the
     *                              configuration api to set the gain values for the
     *                              selected slot before enabling this feature. Slot
     *                              must be within [0,2].
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialPositionDutyCycle request);
    
    /**
     * Request PID to target position with a differential position
     * setpoint
     * <p>
     * This control mode will set the motor's position setpoint to the
     * position specified by the user. It will also set the motor's
     * differential position setpoint to the specified position.
     * <ul>
     *   <li> <b>DifferentialPositionVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>AveragePosition:</b> Average position to drive toward in
     *                                  rotations.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive toward
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>AverageSlot:</b> Select which gains are applied to the average
     *                              controller by selecting the slot.  Use the
     *                              configuration api to set the gain values for the
     *                              selected slot before enabling this feature. Slot
     *                              must be within [0,2].
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialPositionVoltage request);
    
    /**
     * Request PID to target velocity with a differential position
     * setpoint.
     * <p>
     * This control mode will set the motor's velocity setpoint to the
     * velocity specified by the user. It will also set the motor's
     * differential position setpoint to the specified position.
     * <ul>
     *   <li> <b>DifferentialVelocityDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageVelocity:</b> Average velocity to drive toward in
     *                                  rotations per second.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive toward
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>AverageSlot:</b> Select which gains are applied to the average
     *                              controller by selecting the slot.  Use the
     *                              configuration api to set the gain values for the
     *                              selected slot before enabling this feature. Slot
     *                              must be within [0,2].
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialVelocityDutyCycle request);
    
    /**
     * Request PID to target velocity with a differential position
     * setpoint.
     * <p>
     * This control mode will set the motor's velocity setpoint to the
     * velocity specified by the user. It will also set the motor's
     * differential position setpoint to the specified position.
     * <ul>
     *   <li> <b>DifferentialVelocityVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageVelocity:</b> Average velocity to drive toward in
     *                                  rotations per second.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive toward
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>AverageSlot:</b> Select which gains are applied to the average
     *                              controller by selecting the slot.  Use the
     *                              configuration api to set the gain values for the
     *                              selected slot before enabling this feature. Slot
     *                              must be within [0,2].
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialVelocityVoltage request);
    
    /**
     * Requests Motion Magic® to target a final position using a motion
     * profile, and PID to a differential position setpoint.
     * <p>
     * Motion Magic® produces a motion profile in real-time while
     * attempting to honor the Cruise Velocity, Acceleration, and
     * (optional) Jerk specified via the Motion Magic® configuration
     * values.  This control mode does not use the Expo_kV or Expo_kA
     * configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is duty cycle
     * based, so relevant closed-loop gains will use fractional duty cycle
     * for the numerator:  +1.0 represents full forward output.
     * <ul>
     *   <li> <b>DifferentialMotionMagicDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>AveragePosition:</b> Average position to drive toward in
     *                                  rotations.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive toward
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>AverageSlot:</b> Select which gains are applied to the average
     *                              controller by selecting the slot.  Use the
     *                              configuration api to set the gain values for the
     *                              selected slot before enabling this feature. Slot
     *                              must be within [0,2].
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialMotionMagicDutyCycle request);
    
    /**
     * Requests Motion Magic® to target a final position using a motion
     * profile, and PID to a differential position setpoint.
     * <p>
     * Motion Magic® produces a motion profile in real-time while
     * attempting to honor the Cruise Velocity, Acceleration, and
     * (optional) Jerk specified via the Motion Magic® configuration
     * values.  This control mode does not use the Expo_kV or Expo_kA
     * configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is
     * voltage-based, so relevant closed-loop gains will use Volts for the
     * numerator.
     * <ul>
     *   <li> <b>DifferentialMotionMagicVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>AveragePosition:</b> Average position to drive toward in
     *                                  rotations.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive toward
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>AverageSlot:</b> Select which gains are applied to the average
     *                              controller by selecting the slot.  Use the
     *                              configuration api to set the gain values for the
     *                              selected slot before enabling this feature. Slot
     *                              must be within [0,2].
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialMotionMagicVoltage request);
    
    /**
     * Requests Motion Magic® to target a final position using an
     * exponential motion profile, and PID to a differential position
     * setpoint.
     * <p>
     * Motion Magic® Expo produces a motion profile in real-time while
     * attempting to honor the Cruise Velocity (optional) and the
     * mechanism kV and kA, specified via the Motion Magic® configuration
     * values.  Note that unlike the slot gains, the Expo_kV and Expo_kA
     * configs are always in output units of Volts.
     * <p>
     * Setting Cruise Velocity to 0 will allow the profile to run to the
     * max possible velocity based on Expo_kV.  This control mode does not
     * use the Acceleration or Jerk configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is duty cycle
     * based, so relevant closed-loop gains will use fractional duty cycle
     * for the numerator:  +1.0 represents full forward output.
     * <ul>
     *   <li> <b>DifferentialMotionMagicExpoDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>AveragePosition:</b> Average position to drive toward in
     *                                  rotations.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive toward
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>AverageSlot:</b> Select which gains are applied to the average
     *                              controller by selecting the slot.  Use the
     *                              configuration api to set the gain values for the
     *                              selected slot before enabling this feature. Slot
     *                              must be within [0,2].
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialMotionMagicExpoDutyCycle request);
    
    /**
     * Requests Motion Magic® to target a final position using an
     * exponential motion profile, and PID to a differential position
     * setpoint.
     * <p>
     * Motion Magic® Expo produces a motion profile in real-time while
     * attempting to honor the Cruise Velocity (optional) and the
     * mechanism kV and kA, specified via the Motion Magic® configuration
     * values.  Note that unlike the slot gains, the Expo_kV and Expo_kA
     * configs are always in output units of Volts.
     * <p>
     * Setting Cruise Velocity to 0 will allow the profile to run to the
     * max possible velocity based on Expo_kV.  This control mode does not
     * use the Acceleration or Jerk configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is
     * voltage-based, so relevant closed-loop gains will use Volts for the
     * numerator.
     * <ul>
     *   <li> <b>DifferentialMotionMagicExpoVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>AveragePosition:</b> Average position to drive toward in
     *                                  rotations.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive toward
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>AverageSlot:</b> Select which gains are applied to the average
     *                              controller by selecting the slot.  Use the
     *                              configuration api to set the gain values for the
     *                              selected slot before enabling this feature. Slot
     *                              must be within [0,2].
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialMotionMagicExpoVoltage request);
    
    /**
     * Requests Motion Magic® to target a final velocity using a motion
     * profile, and PID to a differential position setpoint.  This allows
     * smooth transitions between velocity set points.
     * <p>
     * Motion Magic® Velocity produces a motion profile in real-time while
     * attempting to honor the specified Acceleration and (optional) Jerk.
     *  This control mode does not use the CruiseVelocity, Expo_kV, or
     * Expo_kA configs.
     * <p>
     * Acceleration and jerk are specified in the Motion Magic® persistent
     * configuration values.  If Jerk is set to zero, Motion Magic® will
     * produce a trapezoidal acceleration profile.
     * <p>
     * Target velocity can also be changed on-the-fly and Motion Magic®
     * will do its best to adjust the profile.  This control mode is duty
     * cycle based, so relevant closed-loop gains will use fractional duty
     * cycle for the numerator:  +1.0 represents full forward output.
     * <ul>
     *   <li> <b>DifferentialMotionMagicVelocityDutyCycle Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageVelocity:</b> Average velocity to drive toward in
     *                                  rotations per second.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive toward
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>AverageSlot:</b> Select which gains are applied to the average
     *                              controller by selecting the slot.  Use the
     *                              configuration api to set the gain values for the
     *                              selected slot before enabling this feature. Slot
     *                              must be within [0,2].
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialMotionMagicVelocityDutyCycle request);
    
    /**
     * Requests Motion Magic® to target a final velocity using a motion
     * profile, and PID to a differential position setpoint.  This allows
     * smooth transitions between velocity set points.
     * <p>
     * Motion Magic® Velocity produces a motion profile in real-time while
     * attempting to honor the specified Acceleration and (optional) Jerk.
     *  This control mode does not use the CruiseVelocity, Expo_kV, or
     * Expo_kA configs.
     * <p>
     * Acceleration and jerk are specified in the Motion Magic® persistent
     * configuration values.  If Jerk is set to zero, Motion Magic® will
     * produce a trapezoidal acceleration profile.
     * <p>
     * Target velocity can also be changed on-the-fly and Motion Magic®
     * will do its best to adjust the profile.  This control mode is
     * voltage-based, so relevant closed-loop gains will use Volts for the
     * numerator.
     * <ul>
     *   <li> <b>DifferentialMotionMagicVelocityVoltage Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageVelocity:</b> Average velocity to drive toward in
     *                                  rotations per second.
     *     <li> <b>DifferentialPosition:</b> Differential position to drive toward
     *                                       in rotations.
     *     <li> <b>EnableFOC:</b> Set to true to use FOC commutation (requires
     *                            Phoenix Pro), which increases peak power by ~15%
     *                            on supported devices (see {@link SupportsFOC}).
     *                            Set to false to use trapezoidal commutation.
     *                            <p>
     *                            FOC improves motor performance by leveraging
     *                            torque (current) control.  However, this may be
     *                            inconvenient for applications that require
     *                            specifying duty cycle or voltage.  CTR-Electronics
     *                            has developed a hybrid method that combines the
     *                            performances gains of FOC while still allowing
     *                            applications to provide duty cycle or voltage
     *                            demand.  This not to be confused with simple
     *                            sinusoidal control or phase voltage control which
     *                            lacks the performance gains.
     *     <li> <b>AverageSlot:</b> Select which gains are applied to the average
     *                              controller by selecting the slot.  Use the
     *                              configuration api to set the gain values for the
     *                              selected slot before enabling this feature. Slot
     *                              must be within [0,2].
     *     <li> <b>DifferentialSlot:</b> Select which gains are applied to the
     *                                   differential controller by selecting the
     *                                   slot.  Use the configuration api to set the
     *                                   gain values for the selected slot before
     *                                   enabling this feature. Slot must be within
     *                                   [0,2].
     *     <li> <b>OverrideBrakeDurNeutral:</b> Set to true to static-brake the
     *                                          rotor when output is zero (or within
     *                                          deadband).  Set to false to use the
     *                                          NeutralMode configuration setting
     *                                          (default). This flag exists to
     *                                          provide the fundamental behavior of
     *                                          this control when output is zero,
     *                                          which is to provide 0V to the motor.
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialMotionMagicVelocityVoltage request);
    
    /**
     * Follow the motor output of another Talon.
     * <p>
     * If Talon is in torque control, the torque is copied - which will
     * increase the total torque applied. If Talon is in duty cycle output
     * control, the duty cycle is matched. If Talon is in voltage output
     * control, the motor voltage is matched. Motor direction either
     * matches the leader's configured direction or opposes it based on
     * the MotorAlignment.
     * <p>
     * The leader must enable the status signal corresponding to its
     * control output type (DutyCycle, MotorVoltage, TorqueCurrent). The
     * update rate of the status signal determines the update rate of the
     * follower's output and should be no slower than 20 Hz.
     * <ul>
     *   <li> <b>Follower Parameters:</b> 
     *   <ul>
     *     <li> <b>LeaderID:</b> Device ID of the leader to follow.
     *     <li> <b>MotorAlignment:</b> Set to Aligned for motor invert to match the
     *                                 leader's configured Invert - which is typical
     *                                 when leader and follower are mechanically
     *                                 linked and spin in the same direction.  Set
     *                                 to Opposed for motor invert to oppose the
     *                                 leader's configured Invert - this is typical
     *                                 where the leader and follower mechanically
     *                                 spin in opposite directions.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Follower request);
    
    /**
     * Follow the motor output of another Talon while ignoring the
     * leader's invert setting.
     * <p>
     * If Talon is in torque control, the torque is copied - which will
     * increase the total torque applied. If Talon is in duty cycle output
     * control, the duty cycle is matched. If Talon is in voltage output
     * control, the motor voltage is matched. Motor direction is strictly
     * determined by the configured invert and not the leader. If you want
     * motor direction to match or oppose the leader, use Follower
     * instead.
     * <p>
     * The leader must enable the status signal corresponding to its
     * control output type (DutyCycle, MotorVoltage, TorqueCurrent). The
     * update rate of the status signal determines the update rate of the
     * follower's output and should be no slower than 20 Hz.
     * <ul>
     *   <li> <b>StrictFollower Parameters:</b> 
     *   <ul>
     *     <li> <b>LeaderID:</b> Device ID of the leader to follow.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(StrictFollower request);
    
    /**
     * Follow the differential motor output of another Talon.
     * <p>
     * If Talon is in torque control, the differential torque is copied -
     * which will increase the total torque applied. If Talon is in duty
     * cycle output control, the differential duty cycle is matched. If
     * Talon is in voltage output control, the differential motor voltage
     * is matched. Motor direction either matches leader's configured
     * direction or opposes it based on the MotorAlignment.
     * <p>
     * The leader must enable its DifferentialOutput status signal. The
     * update rate of the status signal determines the update rate of the
     * follower's output and should be no slower than 20 Hz.
     * <ul>
     *   <li> <b>DifferentialFollower Parameters:</b> 
     *   <ul>
     *     <li> <b>LeaderID:</b> Device ID of the differential leader to follow.
     *     <li> <b>MotorAlignment:</b> Set to Aligned for motor invert to match the
     *                                 leader's configured Invert - which is typical
     *                                 when leader and follower are mechanically
     *                                 linked and spin in the same direction.  Set
     *                                 to Opposed for motor invert to oppose the
     *                                 leader's configured Invert - this is typical
     *                                 where the leader and follower mechanically
     *                                 spin in opposite directions.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialFollower request);
    
    /**
     * Follow the differential motor output of another Talon while
     * ignoring the leader's invert setting.
     * <p>
     * If Talon is in torque control, the differential torque is copied -
     * which will increase the total torque applied. If Talon is in duty
     * cycle output control, the differential duty cycle is matched. If
     * Talon is in voltage output control, the differential motor voltage
     * is matched. Motor direction is strictly determined by the
     * configured invert and not the leader. If you want motor direction
     * to match or oppose the leader, use DifferentialFollower instead.
     * <p>
     * The leader must enable its DifferentialOutput status signal. The
     * update rate of the status signal determines the update rate of the
     * follower's output and should be no slower than 20 Hz.
     * <ul>
     *   <li> <b>DifferentialStrictFollower Parameters:</b> 
     *   <ul>
     *     <li> <b>LeaderID:</b> Device ID of the differential leader to follow.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DifferentialStrictFollower request);
    
    /**
     * Applies full neutral-brake by shorting motor leads together.
     * <ul>
     *   <li> <b>StaticBrake Parameters:</b> 
     *   <ul>
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(StaticBrake request);
    
    /**
     * Request neutral output of actuator. The applied brake type is
     * determined by the NeutralMode configuration.
     * <ul>
     *   <li> <b>NeutralOut Parameters:</b> 
     *   <ul>
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(NeutralOut request);
    
    /**
     * Request coast neutral output of actuator.  The bridge is disabled
     * and the rotor is allowed to coast.
     * <ul>
     *   <li> <b>CoastOut Parameters:</b> 
     *   <ul>
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(CoastOut request);
    
    /**
     * Differential control with duty cycle average target and position
     * difference target.
     * <ul>
     *   <li> <b>Diff_DutyCycleOut_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average DutyCycleOut request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_DutyCycleOut_Position request);
    
    /**
     * Differential control with position average target and position
     * difference target using duty cycle control.
     * <ul>
     *   <li> <b>Diff_PositionDutyCycle_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average PositionDutyCycle request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_PositionDutyCycle_Position request);
    
    /**
     * Differential control with velocity average target and position
     * difference target using duty cycle control.
     * <ul>
     *   <li> <b>Diff_VelocityDutyCycle_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VelocityDutyCYcle request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VelocityDutyCycle_Position request);
    
    /**
     * Differential control with Motion Magic® average target and position
     * difference target using duty cycle control.
     * <ul>
     *   <li> <b>Diff_MotionMagicDutyCycle_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicDutyCycle request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicDutyCycle_Position request);
    
    /**
     * Differential control with Motion Magic® Expo average target and
     * position difference target using duty cycle control.
     * <ul>
     *   <li> <b>Diff_MotionMagicExpoDutyCycle_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicExpoDutyCycle request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicExpoDutyCycle_Position request);
    
    /**
     * Differential control with Motion Magic® Velocity average target and
     * position difference target using duty cycle control.
     * <ul>
     *   <li> <b>Diff_MotionMagicVelocityDutyCycle_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVelocityDutyCycle request
     *                                 of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVelocityDutyCycle_Position request);
    
    /**
     * Differential control with duty cycle average target and velocity
     * difference target.
     * <ul>
     *   <li> <b>Diff_DutyCycleOut_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average DutyCycleOut request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_DutyCycleOut_Velocity request);
    
    /**
     * Differential control with position average target and velocity
     * difference target using duty cycle control.
     * <ul>
     *   <li> <b>Diff_PositionDutyCycle_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average PositionDutyCycle request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_PositionDutyCycle_Velocity request);
    
    /**
     * Differential control with velocity average target and velocity
     * difference target using duty cycle control.
     * <ul>
     *   <li> <b>Diff_VelocityDutyCycle_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VelocityDutyCycle request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VelocityDutyCycle_Velocity request);
    
    /**
     * Differential control with Motion Magic® average target and velocity
     * difference target using duty cycle control.
     * <ul>
     *   <li> <b>Diff_MotionMagicDutyCycle_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicDutyCycle request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicDutyCycle_Velocity request);
    
    /**
     * Differential control with Motion Magic® Expo average target and
     * velocity difference target using duty cycle control.
     * <ul>
     *   <li> <b>Diff_MotionMagicExpoDutyCycle_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicExpoDutyCycle request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicExpoDutyCycle_Velocity request);
    
    /**
     * Differential control with Motion Magic® Velocity average target and
     * velocity difference target using duty cycle control.
     * <ul>
     *   <li> <b>Diff_MotionMagicVelocityDutyCycle_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVelocityDutyCycle request
     *                                 of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityDutyCycle request
     *                                      of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVelocityDutyCycle_Velocity request);
    
    /**
     * Differential control with duty cycle average target and duty cycle
     * difference target.
     * <ul>
     *   <li> <b>Diff_DutyCycleOut_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average DutyCycleOut request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential DutyCycleOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_DutyCycleOut_Open request);
    
    /**
     * Differential control with position average target and duty cycle
     * difference target.
     * <ul>
     *   <li> <b>Diff_PositionDutyCycle_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average PositionDutyCycle request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential DutyCycleOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_PositionDutyCycle_Open request);
    
    /**
     * Differential control with velocity average target and duty cycle
     * difference target.
     * <ul>
     *   <li> <b>Diff_VelocityDutyCycle_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VelocityDutyCYcle request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential DutyCycleOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VelocityDutyCycle_Open request);
    
    /**
     * Differential control with Motion Magic® average target and duty
     * cycle difference target.
     * <ul>
     *   <li> <b>Diff_MotionMagicDutyCycle_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicDutyCycle request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential DutyCycleOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicDutyCycle_Open request);
    
    /**
     * Differential control with Motion Magic® Expo average target and
     * duty cycle difference target.
     * <ul>
     *   <li> <b>Diff_MotionMagicExpoDutyCycle_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicExpoDutyCycle request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential DutyCycleOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicExpoDutyCycle_Open request);
    
    /**
     * Differential control with Motion Magic® Velocity average target and
     * duty cycle difference target.
     * <ul>
     *   <li> <b>Diff_MotionMagicVelocityDutyCycle_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVelocityDutyCycle request
     *                                 of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential DutyCycleOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVelocityDutyCycle_Open request);
    
    /**
     * Differential control with voltage average target and position
     * difference target.
     * <ul>
     *   <li> <b>Diff_VoltageOut_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VoltageOut request of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VoltageOut_Position request);
    
    /**
     * Differential control with position average target and position
     * difference target using voltage control.
     * <ul>
     *   <li> <b>Diff_PositionVoltage_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average PositionVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_PositionVoltage_Position request);
    
    /**
     * Differential control with velocity average target and position
     * difference target using voltage control.
     * <ul>
     *   <li> <b>Diff_VelocityVoltage_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VelocityVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VelocityVoltage_Position request);
    
    /**
     * Differential control with Motion Magic® average target and position
     * difference target using voltage control.
     * <ul>
     *   <li> <b>Diff_MotionMagicVoltage_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVoltage_Position request);
    
    /**
     * Differential control with Motion Magic® Expo average target and
     * position difference target using voltage control.
     * <ul>
     *   <li> <b>Diff_MotionMagicExpoVoltage_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicExpoVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicExpoVoltage_Position request);
    
    /**
     * Differential control with Motion Magic® Velocity average target and
     * position difference target using voltage control.
     * <ul>
     *   <li> <b>Diff_MotionMagicVelocityVoltage_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVelocityVoltage request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVelocityVoltage_Position request);
    
    /**
     * Differential control with voltage average target and velocity
     * difference target.
     * <ul>
     *   <li> <b>Diff_VoltageOut_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VoltageOut request of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VoltageOut_Velocity request);
    
    /**
     * Differential control with position average target and velocity
     * difference target using voltage control.
     * <ul>
     *   <li> <b>Diff_PositionVoltage_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average PositionVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_PositionVoltage_Velocity request);
    
    /**
     * Differential control with velocity average target and velocity
     * difference target using voltage control.
     * <ul>
     *   <li> <b>Diff_VelocityVoltage_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VelocityVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VelocityVoltage_Velocity request);
    
    /**
     * Differential control with Motion Magic® average target and velocity
     * difference target using voltage control.
     * <ul>
     *   <li> <b>Diff_MotionMagicVoltage_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVoltage_Velocity request);
    
    /**
     * Differential control with Motion Magic® Expo average target and
     * velocity difference target using voltage control.
     * <ul>
     *   <li> <b>Diff_MotionMagicExpoVoltage_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicExpoVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicExpoVoltage_Velocity request);
    
    /**
     * Differential control with Motion Magic® Velocity average target and
     * velocity difference target using voltage control.
     * <ul>
     *   <li> <b>Diff_MotionMagicVelocityVoltage_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVelocityVoltage request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityVoltage request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVelocityVoltage_Velocity request);
    
    /**
     * Differential control with voltage average target and voltage
     * difference target.
     * <ul>
     *   <li> <b>Diff_VoltageOut_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VoltageOut request of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VoltageOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VoltageOut_Open request);
    
    /**
     * Differential control with position average target and voltage
     * difference target.
     * <ul>
     *   <li> <b>Diff_PositionVoltage_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average PositionVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VoltageOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_PositionVoltage_Open request);
    
    /**
     * Differential control with velocity average target and voltage
     * difference target.
     * <ul>
     *   <li> <b>Diff_VelocityVoltage_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VelocityVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VoltageOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VelocityVoltage_Open request);
    
    /**
     * Differential control with Motion Magic® average target and voltage
     * difference target.
     * <ul>
     *   <li> <b>Diff_MotionMagicVoltage_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VoltageOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVoltage_Open request);
    
    /**
     * Differential control with Motion Magic® Expo average target and
     * voltage difference target.
     * <ul>
     *   <li> <b>Diff_MotionMagicExpoVoltage_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicExpoVoltage request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VoltageOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicExpoVoltage_Open request);
    
    /**
     * Differential control with Motion Magic® Velocity average target and
     * voltage difference target.
     * <ul>
     *   <li> <b>Diff_MotionMagicVelocityVoltage_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVelocityVoltage request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VoltageOut request of the
     *                                      mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVelocityVoltage_Open request);

    /**
     * Control device with generic control request object.
     * <p>
     * User must make sure the specified object is castable to a valid control request,
     * otherwise this function will fail at run-time and return the NotSupported StatusCode
     *
     * @param request Control object to request of the device
     * @return Status Code of the request, 0 is OK
     */
    StatusCode setControl(ControlRequest request);
    
}

