/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;
import com.ctre.phoenix6.hardware.core.CoreCANcoder;
import com.ctre.phoenix6.hardware.core.CorePigeon2;
import com.ctre.phoenix6.hardware.core.CoreCANdi;

/**
 * Configs that affect the feedback of this motor controller.
 * <p>
 * Includes feedback sensor source, any offsets for the feedback
 * sensor, and various ratios to describe the relationship between the
 * sensor and the mechanism for closed looping.
 */
public class FeedbackConfigs implements ParentConfiguration, Cloneable {
    /**
     * The offset added to the absolute integrated rotor sensor.  This can
     * be used to zero the rotor in applications that are within one rotor
     * rotation.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double FeedbackRotorOffset = 0.0;
    /**
     * The ratio of sensor rotations to the mechanism's output, where a
     * ratio greater than 1 is a reduction.
     * <p>
     * This is equivalent to the mechanism's gear ratio if the sensor is
     * located on the input of a gearbox.  If sensor is on the output of a
     * gearbox, then this is typically set to 1.
     * <p>
     * We recommend against using this config to perform onboard unit
     * conversions.  Instead, unit conversions should be performed in
     * robot code using the units library.
     * <p>
     * If this is set to zero, the device will reset back to one.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1000
     *   <li> <b>Maximum Value:</b> 1000
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     */
    public double SensorToMechanismRatio = 1.0;
    /**
     * The ratio of motor rotor rotations to remote sensor rotations,
     * where a ratio greater than 1 is a reduction.
     * <p>
     * The Talon FX is capable of fusing a remote CANcoder with its rotor
     * sensor to produce a high-bandwidth sensor source.  This feature
     * requires specifying the ratio between the motor rotor and the
     * remote sensor.
     * <p>
     * If this is set to zero, the device will reset back to one.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1000
     *   <li> <b>Maximum Value:</b> 1000
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     */
    public double RotorToSensorRatio = 1.0;
    /**
     * Choose what sensor source is reported via API and used by
     * closed-loop and limit features.  The default is RotorSensor, which
     * uses the internal rotor sensor in the Talon.
     * <p>
     * Choose Remote* to use another sensor on the same CAN bus (this also
     * requires setting FeedbackRemoteSensorID).  Talon will update its
     * position and velocity whenever the remote sensor publishes its
     * information on CAN bus, and the Talon internal rotor will not be
     * used.
     * <p>
     * Choose Fused* (requires Phoenix Pro) and Talon will fuse another
     * sensor's information with the internal rotor, which provides the
     * best possible position and velocity for accuracy and bandwidth
     * (this also requires setting FeedbackRemoteSensorID).  This was
     * developed for applications such as swerve-azimuth.
     * <p>
     * Choose Sync* (requires Phoenix Pro) and Talon will synchronize its
     * internal rotor position against another sensor, then continue to
     * use the rotor sensor for closed loop control (this also requires
     * setting FeedbackRemoteSensorID).  The Talon will report if its
     * internal position differs significantly from the reported remote
     * sensor position.  This was developed for mechanisms where there is
     * a risk of the sensor failing in such a way that it reports a
     * position that does not match the mechanism, such as the sensor
     * mounting assembly breaking off.
     * <p>
     * Choose RemotePigeon2Yaw, RemotePigeon2Pitch, and RemotePigeon2Roll
     * to use another Pigeon2 on the same CAN bus (this also requires
     * setting FeedbackRemoteSensorID).  Talon will update its position to
     * match the selected value whenever Pigeon2 publishes its information
     * on CAN bus. Note that the Talon position will be in rotations and
     * not degrees.
     * <p>
     * Note: When the feedback source is changed to Fused* or Sync*, the
     * Talon needs a period of time to fuse before sensor-based
     * (soft-limit, closed loop, etc.) features are used. This period of
     * time is determined by the update frequency of the remote sensor's
     * Position signal.
     * 
     */
    public FeedbackSensorSourceValue FeedbackSensorSource = FeedbackSensorSourceValue.RotorSensor;
    /**
     * Device ID of which remote device to use.  This is not used if the
     * Sensor Source is the internal rotor sensor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int FeedbackRemoteSensorID = 0;
    /**
     * The configurable time constant of the Kalman velocity filter. The
     * velocity Kalman filter will adjust to act as a low-pass with this
     * value as its time constant.
     * <p>
     * If the user is aiming for an expected cutoff frequency, the
     * frequency is calculated as 1 / (2 * π * τ) with τ being the time
     * constant.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     */
    public double VelocityFilterTimeConstant = 0;
    
    /**
     * Modifies this configuration's FeedbackRotorOffset parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The offset added to the absolute integrated rotor sensor.  This can
     * be used to zero the rotor in applications that are within one rotor
     * rotation.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newFeedbackRotorOffset Parameter to modify
     * @return Itself
     */
    public final FeedbackConfigs withFeedbackRotorOffset(double newFeedbackRotorOffset)
    {
        FeedbackRotorOffset = newFeedbackRotorOffset;
        return this;
    }
    
    /**
     * Modifies this configuration's FeedbackRotorOffset parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The offset added to the absolute integrated rotor sensor.  This can
     * be used to zero the rotor in applications that are within one rotor
     * rotation.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newFeedbackRotorOffset Parameter to modify
     * @return Itself
     */
    public final FeedbackConfigs withFeedbackRotorOffset(Angle newFeedbackRotorOffset)
    {
        FeedbackRotorOffset = newFeedbackRotorOffset.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's FeedbackRotorOffset parameter converted
     * to a unit type. If not using the Java units library, {@link #FeedbackRotorOffset}
     * can be accessed directly instead.
     * <p>
     * The offset added to the absolute integrated rotor sensor.  This can
     * be used to zero the rotor in applications that are within one rotor
     * rotation.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return FeedbackRotorOffset
     */
    public final Angle getFeedbackRotorOffsetMeasure()
    {
        return Rotations.of(FeedbackRotorOffset);
    }
    
    /**
     * Modifies this configuration's SensorToMechanismRatio parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The ratio of sensor rotations to the mechanism's output, where a
     * ratio greater than 1 is a reduction.
     * <p>
     * This is equivalent to the mechanism's gear ratio if the sensor is
     * located on the input of a gearbox.  If sensor is on the output of a
     * gearbox, then this is typically set to 1.
     * <p>
     * We recommend against using this config to perform onboard unit
     * conversions.  Instead, unit conversions should be performed in
     * robot code using the units library.
     * <p>
     * If this is set to zero, the device will reset back to one.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1000
     *   <li> <b>Maximum Value:</b> 1000
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     *
     * @param newSensorToMechanismRatio Parameter to modify
     * @return Itself
     */
    public final FeedbackConfigs withSensorToMechanismRatio(double newSensorToMechanismRatio)
    {
        SensorToMechanismRatio = newSensorToMechanismRatio;
        return this;
    }
    
    /**
     * Modifies this configuration's RotorToSensorRatio parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The ratio of motor rotor rotations to remote sensor rotations,
     * where a ratio greater than 1 is a reduction.
     * <p>
     * The Talon FX is capable of fusing a remote CANcoder with its rotor
     * sensor to produce a high-bandwidth sensor source.  This feature
     * requires specifying the ratio between the motor rotor and the
     * remote sensor.
     * <p>
     * If this is set to zero, the device will reset back to one.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1000
     *   <li> <b>Maximum Value:</b> 1000
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     *
     * @param newRotorToSensorRatio Parameter to modify
     * @return Itself
     */
    public final FeedbackConfigs withRotorToSensorRatio(double newRotorToSensorRatio)
    {
        RotorToSensorRatio = newRotorToSensorRatio;
        return this;
    }
    
    /**
     * Modifies this configuration's FeedbackSensorSource parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Choose what sensor source is reported via API and used by
     * closed-loop and limit features.  The default is RotorSensor, which
     * uses the internal rotor sensor in the Talon.
     * <p>
     * Choose Remote* to use another sensor on the same CAN bus (this also
     * requires setting FeedbackRemoteSensorID).  Talon will update its
     * position and velocity whenever the remote sensor publishes its
     * information on CAN bus, and the Talon internal rotor will not be
     * used.
     * <p>
     * Choose Fused* (requires Phoenix Pro) and Talon will fuse another
     * sensor's information with the internal rotor, which provides the
     * best possible position and velocity for accuracy and bandwidth
     * (this also requires setting FeedbackRemoteSensorID).  This was
     * developed for applications such as swerve-azimuth.
     * <p>
     * Choose Sync* (requires Phoenix Pro) and Talon will synchronize its
     * internal rotor position against another sensor, then continue to
     * use the rotor sensor for closed loop control (this also requires
     * setting FeedbackRemoteSensorID).  The Talon will report if its
     * internal position differs significantly from the reported remote
     * sensor position.  This was developed for mechanisms where there is
     * a risk of the sensor failing in such a way that it reports a
     * position that does not match the mechanism, such as the sensor
     * mounting assembly breaking off.
     * <p>
     * Choose RemotePigeon2Yaw, RemotePigeon2Pitch, and RemotePigeon2Roll
     * to use another Pigeon2 on the same CAN bus (this also requires
     * setting FeedbackRemoteSensorID).  Talon will update its position to
     * match the selected value whenever Pigeon2 publishes its information
     * on CAN bus. Note that the Talon position will be in rotations and
     * not degrees.
     * <p>
     * Note: When the feedback source is changed to Fused* or Sync*, the
     * Talon needs a period of time to fuse before sensor-based
     * (soft-limit, closed loop, etc.) features are used. This period of
     * time is determined by the update frequency of the remote sensor's
     * Position signal.
     * 
     *
     * @param newFeedbackSensorSource Parameter to modify
     * @return Itself
     */
    public final FeedbackConfigs withFeedbackSensorSource(FeedbackSensorSourceValue newFeedbackSensorSource)
    {
        FeedbackSensorSource = newFeedbackSensorSource;
        return this;
    }
    
    /**
     * Modifies this configuration's FeedbackRemoteSensorID parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Device ID of which remote device to use.  This is not used if the
     * Sensor Source is the internal rotor sensor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newFeedbackRemoteSensorID Parameter to modify
     * @return Itself
     */
    public final FeedbackConfigs withFeedbackRemoteSensorID(int newFeedbackRemoteSensorID)
    {
        FeedbackRemoteSensorID = newFeedbackRemoteSensorID;
        return this;
    }
    
    /**
     * Modifies this configuration's VelocityFilterTimeConstant parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The configurable time constant of the Kalman velocity filter. The
     * velocity Kalman filter will adjust to act as a low-pass with this
     * value as its time constant.
     * <p>
     * If the user is aiming for an expected cutoff frequency, the
     * frequency is calculated as 1 / (2 * π * τ) with τ being the time
     * constant.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newVelocityFilterTimeConstant Parameter to modify
     * @return Itself
     */
    public final FeedbackConfigs withVelocityFilterTimeConstant(double newVelocityFilterTimeConstant)
    {
        VelocityFilterTimeConstant = newVelocityFilterTimeConstant;
        return this;
    }
    
    /**
     * Modifies this configuration's VelocityFilterTimeConstant parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The configurable time constant of the Kalman velocity filter. The
     * velocity Kalman filter will adjust to act as a low-pass with this
     * value as its time constant.
     * <p>
     * If the user is aiming for an expected cutoff frequency, the
     * frequency is calculated as 1 / (2 * π * τ) with τ being the time
     * constant.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newVelocityFilterTimeConstant Parameter to modify
     * @return Itself
     */
    public final FeedbackConfigs withVelocityFilterTimeConstant(Time newVelocityFilterTimeConstant)
    {
        VelocityFilterTimeConstant = newVelocityFilterTimeConstant.in(Seconds);
        return this;
    }
    
    /**
     * Helper method to get this configuration's VelocityFilterTimeConstant parameter converted
     * to a unit type. If not using the Java units library, {@link #VelocityFilterTimeConstant}
     * can be accessed directly instead.
     * <p>
     * The configurable time constant of the Kalman velocity filter. The
     * velocity Kalman filter will adjust to act as a low-pass with this
     * value as its time constant.
     * <p>
     * If the user is aiming for an expected cutoff frequency, the
     * frequency is calculated as 1 / (2 * π * τ) with τ being the time
     * constant.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @return VelocityFilterTimeConstant
     */
    public final Time getVelocityFilterTimeConstantMeasure()
    {
        return Seconds.of(VelocityFilterTimeConstant);
    }
    
    /**
     * Helper method to configure this feedback group to use
     * RemoteCANcoder by passing in the CANcoder object.
     * <p>
     * When using RemoteCANcoder, the Talon will use another CANcoder on
     * the same CAN bus. The Talon will update its position and velocity
     * whenever CANcoder publishes its information on CAN bus, and the
     * Talon internal rotor will not be used.
     * 
     * @param device CANcoder reference to use for RemoteCANcoder
     * @return Itself
     */
    public final FeedbackConfigs withRemoteCANcoder(CoreCANcoder device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.RemoteCANcoder;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use FusedCANcoder
     * by passing in the CANcoder object.
     * <p>
     * When using FusedCANcoder (requires Phoenix Pro), the Talon will
     * fuse another CANcoder's information with the internal rotor, which
     * provides the best possible position and velocity for accuracy and
     * bandwidth. FusedCANcoder was developed for applications such as
     * swerve-azimuth.
     * 
     * @param device CANcoder reference to use for FusedCANcoder
     * @return Itself
     */
    public final FeedbackConfigs withFusedCANcoder(CoreCANcoder device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.FusedCANcoder;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use SyncCANcoder
     * by passing in the CANcoder object.
     * <p>
     * When using SyncCANcoder (requires Phoenix Pro), the Talon will
     * synchronize its internal rotor position against another CANcoder,
     * then continue to use the rotor sensor for closed loop control. The
     * Talon will report if its internal position differs significantly
     * from the reported CANcoder position. SyncCANcoder was developed for
     * mechanisms where there is a risk of the CANcoder failing in such a
     * way that it reports a position that does not match the mechanism,
     * such as the sensor mounting assembly breaking off.
     * 
     * @param device CANcoder reference to use for SyncCANcoder
     * @return Itself
     */
    public final FeedbackConfigs withSyncCANcoder(CoreCANcoder device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.SyncCANcoder;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use
     * RemotePigeon2Yaw by passing in the Pigeon2 object.
     * <p>
     * When using RemotePigeon2Yaw, the Talon will use another Pigeon2 on
     * the same CAN bus. The Talon will update its position to match the
     * Pigeon2 yaw whenever Pigeon2 publishes its information on CAN bus.
     * Note that the Talon position will be in rotations and not degrees.
     * 
     * @param device Pigeon2 reference to use for RemotePigeon2Yaw
     * @return Itself
     */
    public final FeedbackConfigs withRemotePigeon2Yaw(CorePigeon2 device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.RemotePigeon2Yaw;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use
     * RemotePigeon2Pitch by passing in the Pigeon2 object.
     * <p>
     * When using RemotePigeon2Pitch, the Talon will use another Pigeon2
     * on the same CAN bus. The Talon will update its position to match
     * the Pigeon2 pitch whenever Pigeon2 publishes its information on CAN
     * bus. Note that the Talon position will be in rotations and not
     * degrees.
     * 
     * @param device Pigeon2 reference to use for RemotePigeon2Pitch
     * @return Itself
     */
    public final FeedbackConfigs withRemotePigeon2Pitch(CorePigeon2 device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.RemotePigeon2Pitch;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use
     * RemotePigeon2Roll by passing in the Pigeon2 object.
     * <p>
     * When using RemotePigeon2Roll, the Talon will use another Pigeon2 on
     * the same CAN bus. The Talon will update its position to match the
     * Pigeon2 roll whenever Pigeon2 publishes its information on CAN bus.
     * Note that the Talon position will be in rotations and not degrees.
     * 
     * @param device Pigeon2 reference to use for RemotePigeon2Roll
     * @return Itself
     */
    public final FeedbackConfigs withRemotePigeon2Roll(CorePigeon2 device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.RemotePigeon2Roll;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteCANdi
     * PWM 1 by passing in the CANdi object.
     * <p>
     * When using RemoteCANdi, the Talon will use another CTR Electronics'
     * CANdi™ on the same CAN bus. The Talon will update its position and
     * velocity whenever the CTR Electronics' CANdi™ publishes its
     * information on CAN bus, and the Talon commutation sensor will not
     * be used.
     * 
     * @param device CANdi reference to use for RemoteCANdi
     * @return Itself
     */
    public final FeedbackConfigs withRemoteCANdiPWM1(CoreCANdi device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.RemoteCANdiPWM1;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteCANdi
     * PWM 2 by passing in the CANdi object.
     * <p>
     * When using RemoteCANdi, the Talon will use another CTR Electronics'
     * CANdi™ on the same CAN bus. The Talon will update its position and
     * velocity whenever the CTR Electronics' CANdi™ publishes its
     * information on CAN bus, and the Talon commutation sensor will not
     * be used.
     * 
     * @param device CANdi reference to use for RemoteCANdi
     * @return Itself
     */
    public final FeedbackConfigs withRemoteCANdiPWM2(CoreCANdi device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.RemoteCANdiPWM2;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteCANdi
     * Quadrature by passing in the CANdi object.
     * <p>
     * When using RemoteCANdi, the Talon will use another CTR Electronics'
     * CANdi™ on the same CAN bus. The Talon will update its position and
     * velocity whenever the CTR Electronics' CANdi™ publishes its
     * information on CAN bus, and the Talon commutation sensor will not
     * be used.
     * 
     * @param device CANdi reference to use for RemoteCANdi
     * @return Itself
     */
    public final FeedbackConfigs withRemoteCANdiQuadrature(CoreCANdi device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.RemoteCANdiQuadrature;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use FusedCANdi
     * PWM 1 by passing in the CANdi object.
     * <p>
     * When using FusedCANdi (requires Phoenix Pro), the Talon will fuse
     * another CANdi™ branded device's information with the internal
     * rotor, which provides the best possible position and velocity for
     * accuracy and bandwidth.
     * 
     * @param device CANdi reference to use for FusedCANdi
     * @return Itself
     */
    public final FeedbackConfigs withFusedCANdiPWM1(CoreCANdi device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.FusedCANdiPWM1;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use FusedCANdi
     * PWM 2 by passing in the CANdi object.
     * <p>
     * When using FusedCANdi (requires Phoenix Pro), the Talon will fuse
     * another CANdi™ branded device's information with the internal
     * rotor, which provides the best possible position and velocity for
     * accuracy and bandwidth.
     * 
     * @param device CANdi reference to use for FusedCANdi
     * @return Itself
     */
    public final FeedbackConfigs withFusedCANdiPWM2(CoreCANdi device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.FusedCANdiPWM2;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use FusedCANdi
     * Quadrature by passing in the CANdi object.
     * <p>
     * When using FusedCANdi (requires Phoenix Pro), the Talon will fuse
     * another CANdi™ branded device's information with the internal
     * rotor, which provides the best possible position and velocity for
     * accuracy and bandwidth.
     * 
     * @param device CANdi reference to use for FusedCANdi
     * @return Itself
     */
    public final FeedbackConfigs withFusedCANdiQuadrature(CoreCANdi device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.FusedCANdiQuadrature;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use SyncCANdi PWM
     * 1 by passing in the CANdi object.
     * <p>
     * When using SyncCANdi (requires Phoenix Pro), the Talon will
     * synchronize its internal rotor position against another CANdi™
     * branded device, then continue to use the rotor sensor for closed
     * loop control. The Talon will report if its internal position
     * differs significantly from the reported CANdi™ branded device's
     * position. SyncCANdi was developed for mechanisms where there is a
     * risk of the CANdi™ branded device failing in such a way that it
     * reports a position that does not match the mechanism, such as the
     * sensor mounting assembly breaking off.
     * 
     * @param device CANdi reference to use for SyncCANdi
     * @return Itself
     */
    public final FeedbackConfigs withSyncCANdiPWM1(CoreCANdi device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.SyncCANdiPWM1;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use SyncCANdi PWM
     * 2 by passing in the CANdi object.
     * <p>
     * When using SyncCANdi (requires Phoenix Pro), the Talon will
     * synchronize its internal rotor position against another CANdi™
     * branded device, then continue to use the rotor sensor for closed
     * loop control. The Talon will report if its internal position
     * differs significantly from the reported CANdi™ branded device's
     * position. SyncCANdi was developed for mechanisms where there is a
     * risk of the CANdi™ branded device failing in such a way that it
     * reports a position that does not match the mechanism, such as the
     * sensor mounting assembly breaking off.
     * 
     * @param device CANdi reference to use for SyncCANdi
     * @return Itself
     */
    public final FeedbackConfigs withSyncCANdiPWM2(CoreCANdi device)
    {
        FeedbackSensorSource = FeedbackSensorSourceValue.SyncCANdiPWM2;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    

    @Override
    public String toString() {
        String ss = "Config Group: Feedback\n";
        ss += "    FeedbackRotorOffset: " + FeedbackRotorOffset + " rotations" + "\n";
        ss += "    SensorToMechanismRatio: " + SensorToMechanismRatio + " scalar" + "\n";
        ss += "    RotorToSensorRatio: " + RotorToSensorRatio + " scalar" + "\n";
        ss += "    FeedbackSensorSource: " + FeedbackSensorSource + "\n";
        ss += "    FeedbackRemoteSensorID: " + FeedbackRemoteSensorID + "\n";
        ss += "    VelocityFilterTimeConstant: " + VelocityFilterTimeConstant + " seconds" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_FeedbackRotorOffset.value, FeedbackRotorOffset);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_SensorToMechanismRatio.value, SensorToMechanismRatio);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_RotorToSensorRatio.value, RotorToSensorRatio);
        ss += ConfigJNI.Serializeint(SpnValue.Config_FeedbackSensorSource.value, FeedbackSensorSource.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_FeedbackRemoteSensorID.value, FeedbackRemoteSensorID);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_VelocityFilterTimeConstant.value, VelocityFilterTimeConstant);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        FeedbackRotorOffset = ConfigJNI.Deserializedouble(SpnValue.Config_FeedbackRotorOffset.value, to_deserialize);
        SensorToMechanismRatio = ConfigJNI.Deserializedouble(SpnValue.Config_SensorToMechanismRatio.value, to_deserialize);
        RotorToSensorRatio = ConfigJNI.Deserializedouble(SpnValue.Config_RotorToSensorRatio.value, to_deserialize);
        FeedbackSensorSource = FeedbackSensorSourceValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_FeedbackSensorSource.value, to_deserialize));
        FeedbackRemoteSensorID = ConfigJNI.Deserializeint(SpnValue.Config_FeedbackRemoteSensorID.value, to_deserialize);
        VelocityFilterTimeConstant = ConfigJNI.Deserializedouble(SpnValue.Config_VelocityFilterTimeConstant.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public FeedbackConfigs clone() {
        try {
            return (FeedbackConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

