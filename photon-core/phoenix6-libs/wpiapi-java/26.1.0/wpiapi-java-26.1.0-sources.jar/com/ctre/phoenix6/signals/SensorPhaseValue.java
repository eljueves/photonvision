/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The relationship between the motor controlled by a Talon and the external
 * sensor connected to the data port. This does not affect the commutation
 * sensor or remote sensors.
 * <p>
 * To determine the sensor phase, set this config to Aligned and drive the motor
 * with positive output. If the reported sensor velocity is positive, then the
 * phase is Aligned. If the reported sensor velocity is negative, then the phase
 * is Opposed.
 * <p>
 * The sensor direction is automatically inverted along with motor invert, so
 * the sensor phase does not need to be changed when motor invert changes.
 */
public enum SensorPhaseValue
{
    /**
     * The sensor direction is normally aligned with the motor.
     */
    Aligned(0),
    /**
     * The sensor direction is normally opposed to the motor.
     */
    Opposed(1),;

    public final int value;

    SensorPhaseValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, SensorPhaseValue> _map = null;
    static
    {
        _map = new HashMap<Integer, SensorPhaseValue>();
        for (SensorPhaseValue type : SensorPhaseValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets SensorPhaseValue from specified value
     * @param value Value of SensorPhaseValue
     * @return SensorPhaseValue of specified value
     */
    public static SensorPhaseValue valueOf(int value)
    {
        SensorPhaseValue retval = _map.get(value);
        if (retval != null) return retval;
        return SensorPhaseValue.values()[0];
    }
}
