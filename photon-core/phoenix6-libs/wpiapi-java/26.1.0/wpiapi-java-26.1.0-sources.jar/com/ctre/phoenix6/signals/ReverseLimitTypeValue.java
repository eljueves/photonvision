/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Determines if the reverse limit switch is normally-open (default) or
 * normally-closed.
 */
public enum ReverseLimitTypeValue
{
    NormallyOpen(0),
    NormallyClosed(1),;

    public final int value;

    ReverseLimitTypeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, ReverseLimitTypeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, ReverseLimitTypeValue>();
        for (ReverseLimitTypeValue type : ReverseLimitTypeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets ReverseLimitTypeValue from specified value
     * @param value Value of ReverseLimitTypeValue
     * @return ReverseLimitTypeValue of specified value
     */
    public static ReverseLimitTypeValue valueOf(int value)
    {
        ReverseLimitTypeValue retval = _map.get(value);
        if (retval != null) return retval;
        return ReverseLimitTypeValue.values()[0];
    }
}
