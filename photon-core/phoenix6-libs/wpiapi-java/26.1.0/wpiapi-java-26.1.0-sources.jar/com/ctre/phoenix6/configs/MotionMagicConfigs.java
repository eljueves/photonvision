/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs for Motion Magic®.
 * <p>
 * Includes Velocity, Acceleration, Jerk, and Expo parameters.
 */
public class MotionMagicConfigs implements ParentConfiguration, Cloneable {
    /**
     * This is the maximum velocity Motion Magic® based control modes are
     * allowed to use.  Motion Magic® Velocity control modes do not use
     * this config.
     * <p>
     * When using Motion Magic® Expo control modes, setting this to 0 will
     * allow the profile to run to the max possible velocity based on
     * Expo_kV.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec
     * </ul>
     */
    public double MotionMagicCruiseVelocity = 0;
    /**
     * This is the target acceleration Motion Magic® based control modes
     * are allowed to use.  Motion Magic® Expo control modes do not use
     * this config.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec²
     * </ul>
     */
    public double MotionMagicAcceleration = 0;
    /**
     * This is the target jerk (acceleration derivative) Motion Magic®
     * based control modes are allowed to use.  Motion Magic® Expo control
     * modes do not use this config.  This allows Motion Magic® to
     * generate S-Curve profiles.
     * <p>
     * Jerk is optional; if this is set to zero, then Motion Magic® will
     * not apply a Jerk limit.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec³
     * </ul>
     */
    public double MotionMagicJerk = 0;
    /**
     * This is the target kV used only by Motion Magic® Expo control
     * modes. Unlike the kV slot gain, this is always in units of V/rps.
     * <p>
     * This represents the amount of voltage necessary to hold a velocity.
     * In terms of the Motion Magic® Expo profile, a higher kV results in
     * a slower maximum velocity.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.001
     *   <li> <b>Maximum Value:</b> 100
     *   <li> <b>Default Value:</b> 0.12
     *   <li> <b>Units:</b> V/rps
     * </ul>
     */
    public double MotionMagicExpo_kV = 0.12;
    /**
     * This is the target kA used only by Motion Magic® Expo control
     * modes. Unlike the kA slot gain, this is always in units of V/rps².
     * <p>
     * This represents the amount of voltage necessary to achieve an
     * acceleration. In terms of the Motion Magic® Expo profile, a higher
     * kA results in a slower acceleration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 1e-05
     *   <li> <b>Maximum Value:</b> 100
     *   <li> <b>Default Value:</b> 0.1
     *   <li> <b>Units:</b> V/rps²
     * </ul>
     */
    public double MotionMagicExpo_kA = 0.1;
    
    /**
     * Modifies this configuration's MotionMagicCruiseVelocity parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This is the maximum velocity Motion Magic® based control modes are
     * allowed to use.  Motion Magic® Velocity control modes do not use
     * this config.
     * <p>
     * When using Motion Magic® Expo control modes, setting this to 0 will
     * allow the profile to run to the max possible velocity based on
     * Expo_kV.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec
     * </ul>
     *
     * @param newMotionMagicCruiseVelocity Parameter to modify
     * @return Itself
     */
    public final MotionMagicConfigs withMotionMagicCruiseVelocity(double newMotionMagicCruiseVelocity)
    {
        MotionMagicCruiseVelocity = newMotionMagicCruiseVelocity;
        return this;
    }
    
    /**
     * Modifies this configuration's MotionMagicCruiseVelocity parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This is the maximum velocity Motion Magic® based control modes are
     * allowed to use.  Motion Magic® Velocity control modes do not use
     * this config.
     * <p>
     * When using Motion Magic® Expo control modes, setting this to 0 will
     * allow the profile to run to the max possible velocity based on
     * Expo_kV.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec
     * </ul>
     *
     * @param newMotionMagicCruiseVelocity Parameter to modify
     * @return Itself
     */
    public final MotionMagicConfigs withMotionMagicCruiseVelocity(AngularVelocity newMotionMagicCruiseVelocity)
    {
        MotionMagicCruiseVelocity = newMotionMagicCruiseVelocity.in(RotationsPerSecond);
        return this;
    }
    
    /**
     * Helper method to get this configuration's MotionMagicCruiseVelocity parameter converted
     * to a unit type. If not using the Java units library, {@link #MotionMagicCruiseVelocity}
     * can be accessed directly instead.
     * <p>
     * This is the maximum velocity Motion Magic® based control modes are
     * allowed to use.  Motion Magic® Velocity control modes do not use
     * this config.
     * <p>
     * When using Motion Magic® Expo control modes, setting this to 0 will
     * allow the profile to run to the max possible velocity based on
     * Expo_kV.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec
     * </ul>
     *
     * @return MotionMagicCruiseVelocity
     */
    public final AngularVelocity getMotionMagicCruiseVelocityMeasure()
    {
        return RotationsPerSecond.of(MotionMagicCruiseVelocity);
    }
    
    /**
     * Modifies this configuration's MotionMagicAcceleration parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This is the target acceleration Motion Magic® based control modes
     * are allowed to use.  Motion Magic® Expo control modes do not use
     * this config.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec²
     * </ul>
     *
     * @param newMotionMagicAcceleration Parameter to modify
     * @return Itself
     */
    public final MotionMagicConfigs withMotionMagicAcceleration(double newMotionMagicAcceleration)
    {
        MotionMagicAcceleration = newMotionMagicAcceleration;
        return this;
    }
    
    /**
     * Modifies this configuration's MotionMagicAcceleration parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This is the target acceleration Motion Magic® based control modes
     * are allowed to use.  Motion Magic® Expo control modes do not use
     * this config.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec²
     * </ul>
     *
     * @param newMotionMagicAcceleration Parameter to modify
     * @return Itself
     */
    public final MotionMagicConfigs withMotionMagicAcceleration(AngularAcceleration newMotionMagicAcceleration)
    {
        MotionMagicAcceleration = newMotionMagicAcceleration.in(RotationsPerSecondPerSecond);
        return this;
    }
    
    /**
     * Helper method to get this configuration's MotionMagicAcceleration parameter converted
     * to a unit type. If not using the Java units library, {@link #MotionMagicAcceleration}
     * can be accessed directly instead.
     * <p>
     * This is the target acceleration Motion Magic® based control modes
     * are allowed to use.  Motion Magic® Expo control modes do not use
     * this config.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec²
     * </ul>
     *
     * @return MotionMagicAcceleration
     */
    public final AngularAcceleration getMotionMagicAccelerationMeasure()
    {
        return RotationsPerSecondPerSecond.of(MotionMagicAcceleration);
    }
    
    /**
     * Modifies this configuration's MotionMagicJerk parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This is the target jerk (acceleration derivative) Motion Magic®
     * based control modes are allowed to use.  Motion Magic® Expo control
     * modes do not use this config.  This allows Motion Magic® to
     * generate S-Curve profiles.
     * <p>
     * Jerk is optional; if this is set to zero, then Motion Magic® will
     * not apply a Jerk limit.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec³
     * </ul>
     *
     * @param newMotionMagicJerk Parameter to modify
     * @return Itself
     */
    public final MotionMagicConfigs withMotionMagicJerk(double newMotionMagicJerk)
    {
        MotionMagicJerk = newMotionMagicJerk;
        return this;
    }
    
    /**
     * Modifies this configuration's MotionMagicJerk parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This is the target jerk (acceleration derivative) Motion Magic®
     * based control modes are allowed to use.  Motion Magic® Expo control
     * modes do not use this config.  This allows Motion Magic® to
     * generate S-Curve profiles.
     * <p>
     * Jerk is optional; if this is set to zero, then Motion Magic® will
     * not apply a Jerk limit.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec³
     * </ul>
     *
     * @param newMotionMagicJerk Parameter to modify
     * @return Itself
     */
    public final MotionMagicConfigs withMotionMagicJerk(Velocity<AngularAccelerationUnit> newMotionMagicJerk)
    {
        MotionMagicJerk = newMotionMagicJerk.in(RotationsPerSecondPerSecond.per(Second));
        return this;
    }
    
    /**
     * Helper method to get this configuration's MotionMagicJerk parameter converted
     * to a unit type. If not using the Java units library, {@link #MotionMagicJerk}
     * can be accessed directly instead.
     * <p>
     * This is the target jerk (acceleration derivative) Motion Magic®
     * based control modes are allowed to use.  Motion Magic® Expo control
     * modes do not use this config.  This allows Motion Magic® to
     * generate S-Curve profiles.
     * <p>
     * Jerk is optional; if this is set to zero, then Motion Magic® will
     * not apply a Jerk limit.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 9999
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rot per sec³
     * </ul>
     *
     * @return MotionMagicJerk
     */
    public final Velocity<AngularAccelerationUnit> getMotionMagicJerkMeasure()
    {
        return RotationsPerSecondPerSecond.per(Second).of(MotionMagicJerk);
    }
    
    /**
     * Modifies this configuration's MotionMagicExpo_kV parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This is the target kV used only by Motion Magic® Expo control
     * modes. Unlike the kV slot gain, this is always in units of V/rps.
     * <p>
     * This represents the amount of voltage necessary to hold a velocity.
     * In terms of the Motion Magic® Expo profile, a higher kV results in
     * a slower maximum velocity.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.001
     *   <li> <b>Maximum Value:</b> 100
     *   <li> <b>Default Value:</b> 0.12
     *   <li> <b>Units:</b> V/rps
     * </ul>
     *
     * @param newMotionMagicExpo_kV Parameter to modify
     * @return Itself
     */
    public final MotionMagicConfigs withMotionMagicExpo_kV(double newMotionMagicExpo_kV)
    {
        MotionMagicExpo_kV = newMotionMagicExpo_kV;
        return this;
    }
    
    /**
     * Modifies this configuration's MotionMagicExpo_kV parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This is the target kV used only by Motion Magic® Expo control
     * modes. Unlike the kV slot gain, this is always in units of V/rps.
     * <p>
     * This represents the amount of voltage necessary to hold a velocity.
     * In terms of the Motion Magic® Expo profile, a higher kV results in
     * a slower maximum velocity.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.001
     *   <li> <b>Maximum Value:</b> 100
     *   <li> <b>Default Value:</b> 0.12
     *   <li> <b>Units:</b> V/rps
     * </ul>
     *
     * @param newMotionMagicExpo_kV Parameter to modify
     * @return Itself
     */
    public final MotionMagicConfigs withMotionMagicExpo_kV(Per<VoltageUnit, AngularVelocityUnit> newMotionMagicExpo_kV)
    {
        MotionMagicExpo_kV = newMotionMagicExpo_kV.in(Volts.per(RotationsPerSecond));
        return this;
    }
    
    /**
     * Helper method to get this configuration's MotionMagicExpo_kV parameter converted
     * to a unit type. If not using the Java units library, {@link #MotionMagicExpo_kV}
     * can be accessed directly instead.
     * <p>
     * This is the target kV used only by Motion Magic® Expo control
     * modes. Unlike the kV slot gain, this is always in units of V/rps.
     * <p>
     * This represents the amount of voltage necessary to hold a velocity.
     * In terms of the Motion Magic® Expo profile, a higher kV results in
     * a slower maximum velocity.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.001
     *   <li> <b>Maximum Value:</b> 100
     *   <li> <b>Default Value:</b> 0.12
     *   <li> <b>Units:</b> V/rps
     * </ul>
     *
     * @return MotionMagicExpo_kV
     */
    public final Per<VoltageUnit, AngularVelocityUnit> getMotionMagicExpo_kVMeasure()
    {
        return Volts.per(RotationsPerSecond).ofNative(MotionMagicExpo_kV);
    }
    
    /**
     * Modifies this configuration's MotionMagicExpo_kA parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This is the target kA used only by Motion Magic® Expo control
     * modes. Unlike the kA slot gain, this is always in units of V/rps².
     * <p>
     * This represents the amount of voltage necessary to achieve an
     * acceleration. In terms of the Motion Magic® Expo profile, a higher
     * kA results in a slower acceleration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 1e-05
     *   <li> <b>Maximum Value:</b> 100
     *   <li> <b>Default Value:</b> 0.1
     *   <li> <b>Units:</b> V/rps²
     * </ul>
     *
     * @param newMotionMagicExpo_kA Parameter to modify
     * @return Itself
     */
    public final MotionMagicConfigs withMotionMagicExpo_kA(double newMotionMagicExpo_kA)
    {
        MotionMagicExpo_kA = newMotionMagicExpo_kA;
        return this;
    }
    
    /**
     * Modifies this configuration's MotionMagicExpo_kA parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This is the target kA used only by Motion Magic® Expo control
     * modes. Unlike the kA slot gain, this is always in units of V/rps².
     * <p>
     * This represents the amount of voltage necessary to achieve an
     * acceleration. In terms of the Motion Magic® Expo profile, a higher
     * kA results in a slower acceleration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 1e-05
     *   <li> <b>Maximum Value:</b> 100
     *   <li> <b>Default Value:</b> 0.1
     *   <li> <b>Units:</b> V/rps²
     * </ul>
     *
     * @param newMotionMagicExpo_kA Parameter to modify
     * @return Itself
     */
    public final MotionMagicConfigs withMotionMagicExpo_kA(Per<VoltageUnit, AngularAccelerationUnit> newMotionMagicExpo_kA)
    {
        MotionMagicExpo_kA = newMotionMagicExpo_kA.in(Volts.per(RotationsPerSecondPerSecond));
        return this;
    }
    
    /**
     * Helper method to get this configuration's MotionMagicExpo_kA parameter converted
     * to a unit type. If not using the Java units library, {@link #MotionMagicExpo_kA}
     * can be accessed directly instead.
     * <p>
     * This is the target kA used only by Motion Magic® Expo control
     * modes. Unlike the kA slot gain, this is always in units of V/rps².
     * <p>
     * This represents the amount of voltage necessary to achieve an
     * acceleration. In terms of the Motion Magic® Expo profile, a higher
     * kA results in a slower acceleration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 1e-05
     *   <li> <b>Maximum Value:</b> 100
     *   <li> <b>Default Value:</b> 0.1
     *   <li> <b>Units:</b> V/rps²
     * </ul>
     *
     * @return MotionMagicExpo_kA
     */
    public final Per<VoltageUnit, AngularAccelerationUnit> getMotionMagicExpo_kAMeasure()
    {
        return Volts.per(RotationsPerSecondPerSecond).ofNative(MotionMagicExpo_kA);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: MotionMagic\n";
        ss += "    MotionMagicCruiseVelocity: " + MotionMagicCruiseVelocity + " rot per sec" + "\n";
        ss += "    MotionMagicAcceleration: " + MotionMagicAcceleration + " rot per sec²" + "\n";
        ss += "    MotionMagicJerk: " + MotionMagicJerk + " rot per sec³" + "\n";
        ss += "    MotionMagicExpo_kV: " + MotionMagicExpo_kV + " V/rps" + "\n";
        ss += "    MotionMagicExpo_kA: " + MotionMagicExpo_kA + " V/rps²" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_MotionMagicCruiseVelocity.value, MotionMagicCruiseVelocity);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_MotionMagicAcceleration.value, MotionMagicAcceleration);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_MotionMagicJerk.value, MotionMagicJerk);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_MotionMagicExpo_kV.value, MotionMagicExpo_kV);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_MotionMagicExpo_kA.value, MotionMagicExpo_kA);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        MotionMagicCruiseVelocity = ConfigJNI.Deserializedouble(SpnValue.Config_MotionMagicCruiseVelocity.value, to_deserialize);
        MotionMagicAcceleration = ConfigJNI.Deserializedouble(SpnValue.Config_MotionMagicAcceleration.value, to_deserialize);
        MotionMagicJerk = ConfigJNI.Deserializedouble(SpnValue.Config_MotionMagicJerk.value, to_deserialize);
        MotionMagicExpo_kV = ConfigJNI.Deserializedouble(SpnValue.Config_MotionMagicExpo_kV.value, to_deserialize);
        MotionMagicExpo_kA = ConfigJNI.Deserializedouble(SpnValue.Config_MotionMagicExpo_kA.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public MotionMagicConfigs clone() {
        try {
            return (MotionMagicConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

