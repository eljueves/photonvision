/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6;

import java.util.HashMap;
import java.util.Map;

import edu.wpi.first.epilogue.logging.EpilogueBackend;
import edu.wpi.first.epilogue.logging.NestedBackend;
import edu.wpi.first.units.Measure;
import edu.wpi.first.units.Unit;
import edu.wpi.first.util.protobuf.Protobuf;
import edu.wpi.first.util.struct.Struct;
import us.hebi.quickbuf.ProtoMessage;

/**
 * A backend implementation that saves information to a CTRE hoot file on disk
 * using the Phoenix 6 {@link SignalLogger}.
 */
public class HootEpilogueBackend implements EpilogueBackend, AutoCloseable {
    private static final Map<String, NestedBackend> m_subLoggers = new HashMap<>();

    /**
     * Creates a new hoot backend for Epilogue. This immediately starts the
     * {@link SignalLogger} and automatically stops it on {@link #close}.
     */
    public HootEpilogueBackend() {
        SignalLogger.start();
    }

    @Override
    public void close() {
        SignalLogger.stop();
    }

    @Override
    public EpilogueBackend getNested(String path) {
        return m_subLoggers.computeIfAbsent(path, k -> new NestedBackend(k, this));
    }

    @Override
    public void log(String identifier, int value) {
        SignalLogger.writeInteger(identifier, value);
    }

    @Override
    public void log(String identifier, long value) {
        SignalLogger.writeInteger(identifier, value);
    }

    @Override
    public void log(String identifier, float value) {
        SignalLogger.writeFloat(identifier, value);
    }

    @Override
    public void log(String identifier, double value) {
        SignalLogger.writeDouble(identifier, value);
    }

    @Override
    public void log(String identifier, boolean value) {
        SignalLogger.writeBoolean(identifier, value);
    }

    @Override
    public void log(String identifier, byte[] value) {
        SignalLogger.writeRaw(identifier, value);
    }

    @Override
    public void log(String identifier, int[] value) {
        final long[] widened = new long[value.length];
        for (int i = 0; i < value.length; ++i) {
            widened[i] = value[i];
        }
        SignalLogger.writeIntegerArray(identifier, widened);
    }

    @Override
    public void log(String identifier, long[] value) {
        SignalLogger.writeIntegerArray(identifier, value);
    }

    @Override
    public void log(String identifier, float[] value) {
        SignalLogger.writeFloatArray(identifier, value);
    }

    @Override
    public void log(String identifier, double[] value) {
        SignalLogger.writeDoubleArray(identifier, value);
    }

    @Override
    public void log(String identifier, boolean[] value) {
        SignalLogger.writeBooleanArray(identifier, value);
    }

    @Override
    public void log(String identifier, String value) {
        SignalLogger.writeString(identifier, value);
    }

    @Override
    public void log(String identifier, String[] value) {
        SignalLogger.writeStringArray(identifier, value);
    }

    @Override
    public <T> void log(String identifier, T value, Struct<T> struct) {
        SignalLogger.writeStruct(identifier, struct, value);
    }

    @Override
    public <T> void log(String identifier, T[] value, Struct<T> struct) {
        SignalLogger.writeStructArray(identifier, struct, value);
    }

    @Override
    public <T, M extends ProtoMessage<M>> void log(String identifier, T value, Protobuf<T, M> proto) {
        SignalLogger.writeProtobuf(identifier, proto, value);
    }

    @Override
    public void log(String identifier, Measure<?> value) {
        SignalLogger.writeDouble(identifier, value.baseUnitMagnitude(), value.baseUnit().symbol());
    }

    @Override
    public <U extends Unit> void log(String identifier, Measure<U> value, U unit) {
        SignalLogger.writeValue(identifier, value, unit);
    }
}
