/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The applied output of the bridge.
 */
public enum BridgeOutputValue
{
    BridgeReq_Coast(0),
    BridgeReq_Brake(1),
    BridgeReq_Trapez(6),
    BridgeReq_FOCTorque(7),
    BridgeReq_MusicTone(8),
    BridgeReq_FOCEasy(9),
    BridgeReq_FaultBrake(12),
    BridgeReq_FaultCoast(13),
    BridgeReq_ActiveBrake(14),
    BridgeReq_VariableBrake(15),;

    public final int value;

    BridgeOutputValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, BridgeOutputValue> _map = null;
    static
    {
        _map = new HashMap<Integer, BridgeOutputValue>();
        for (BridgeOutputValue type : BridgeOutputValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets BridgeOutputValue from specified value
     * @param value Value of BridgeOutputValue
     * @return BridgeOutputValue of specified value
     */
    public static BridgeOutputValue valueOf(int value)
    {
        BridgeOutputValue retval = _map.get(value);
        if (retval != null) return retval;
        return BridgeOutputValue.values()[0];
    }
}
