/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether the closed-loop is running on position or velocity.
 */
public enum DiffPIDRefPIDErr_ClosedLoopModeValue
{
    Position(0),
    Velocity(1),;

    public final int value;

    DiffPIDRefPIDErr_ClosedLoopModeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, DiffPIDRefPIDErr_ClosedLoopModeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, DiffPIDRefPIDErr_ClosedLoopModeValue>();
        for (DiffPIDRefPIDErr_ClosedLoopModeValue type : DiffPIDRefPIDErr_ClosedLoopModeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets DiffPIDRefPIDErr_ClosedLoopModeValue from specified value
     * @param value Value of DiffPIDRefPIDErr_ClosedLoopModeValue
     * @return DiffPIDRefPIDErr_ClosedLoopModeValue of specified value
     */
    public static DiffPIDRefPIDErr_ClosedLoopModeValue valueOf(int value)
    {
        DiffPIDRefPIDErr_ClosedLoopModeValue retval = _map.get(value);
        if (retval != null) return retval;
        return DiffPIDRefPIDErr_ClosedLoopModeValue.values()[0];
    }
}
