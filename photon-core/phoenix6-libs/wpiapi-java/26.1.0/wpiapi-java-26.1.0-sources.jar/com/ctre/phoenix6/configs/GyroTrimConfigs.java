/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

/**
 * Configs to trim the Pigeon2's gyroscope.
 * <p>
 * Pigeon2 allows the user to trim the gyroscope's sensitivity. While
 * this isn't necessary for the Pigeon2, as it comes calibrated
 * out-of-the-box, users can make use of this to make the Pigeon2 even
 * more accurate for their application.
 */
public class GyroTrimConfigs implements ParentConfiguration, Cloneable {
    /**
     * The gyro scalar component for the X axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -180
     *   <li> <b>Maximum Value:</b> 180
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg per rotation
     * </ul>
     */
    public double GyroScalarX = 0;
    /**
     * The gyro scalar component for the Y axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -180
     *   <li> <b>Maximum Value:</b> 180
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg per rotation
     * </ul>
     */
    public double GyroScalarY = 0;
    /**
     * The gyro scalar component for the Z axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -180
     *   <li> <b>Maximum Value:</b> 180
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg per rotation
     * </ul>
     */
    public double GyroScalarZ = 0;
    
    /**
     * Modifies this configuration's GyroScalarX parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The gyro scalar component for the X axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -180
     *   <li> <b>Maximum Value:</b> 180
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg per rotation
     * </ul>
     *
     * @param newGyroScalarX Parameter to modify
     * @return Itself
     */
    public final GyroTrimConfigs withGyroScalarX(double newGyroScalarX)
    {
        GyroScalarX = newGyroScalarX;
        return this;
    }
    
    /**
     * Modifies this configuration's GyroScalarY parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The gyro scalar component for the Y axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -180
     *   <li> <b>Maximum Value:</b> 180
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg per rotation
     * </ul>
     *
     * @param newGyroScalarY Parameter to modify
     * @return Itself
     */
    public final GyroTrimConfigs withGyroScalarY(double newGyroScalarY)
    {
        GyroScalarY = newGyroScalarY;
        return this;
    }
    
    /**
     * Modifies this configuration's GyroScalarZ parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The gyro scalar component for the Z axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -180
     *   <li> <b>Maximum Value:</b> 180
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg per rotation
     * </ul>
     *
     * @param newGyroScalarZ Parameter to modify
     * @return Itself
     */
    public final GyroTrimConfigs withGyroScalarZ(double newGyroScalarZ)
    {
        GyroScalarZ = newGyroScalarZ;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: GyroTrim\n";
        ss += "    GyroScalarX: " + GyroScalarX + " deg per rotation" + "\n";
        ss += "    GyroScalarY: " + GyroScalarY + " deg per rotation" + "\n";
        ss += "    GyroScalarZ: " + GyroScalarZ + " deg per rotation" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Pigeon2GyroScalarX.value, GyroScalarX);
        ss += ConfigJNI.Serializedouble(SpnValue.Pigeon2GyroScalarY.value, GyroScalarY);
        ss += ConfigJNI.Serializedouble(SpnValue.Pigeon2GyroScalarZ.value, GyroScalarZ);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        GyroScalarX = ConfigJNI.Deserializedouble(SpnValue.Pigeon2GyroScalarX.value, to_deserialize);
        GyroScalarY = ConfigJNI.Deserializedouble(SpnValue.Pigeon2GyroScalarY.value, to_deserialize);
        GyroScalarZ = ConfigJNI.Deserializedouble(SpnValue.Pigeon2GyroScalarZ.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public GyroTrimConfigs clone() {
        try {
            return (GyroTrimConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

