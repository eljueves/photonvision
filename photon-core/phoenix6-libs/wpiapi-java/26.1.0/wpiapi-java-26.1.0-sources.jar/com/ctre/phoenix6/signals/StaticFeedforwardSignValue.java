/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Static feedforward sign during position closed loop.
 * <p>
 * This determines the sign of the applied kS during position closed-loop modes.
 * The default behavior uses the velocity reference sign. This works well with
 * velocity closed loop, Motion Magic® controls, and position closed loop when
 * velocity reference is specified (motion profiling).
 * <p>
 * However, when using position closed loop with zero velocity reference (no
 * motion profiling), the application may want to apply static feedforward based
 * on the sign of closed loop error instead. When doing so, we recommend using
 * the minimal amount of kS, otherwise the motor output may dither when closed
 * loop error is near zero.
 */
public enum StaticFeedforwardSignValue
{
    /**
     * Use the velocity reference sign. This works well with velocity closed loop,
     * Motion Magic® controls, and position closed loop when velocity reference is
     * specified (motion profiling).
     */
    UseVelocitySign(0),
    /**
     * Use the sign of closed loop error. This is useful when using position closed
     * loop with zero velocity reference (no motion profiling). We recommend the
     * minimal amount of kS, otherwise the motor output may dither when closed loop
     * error is near zero.
     */
    UseClosedLoopSign(1),;

    public final int value;

    StaticFeedforwardSignValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, StaticFeedforwardSignValue> _map = null;
    static
    {
        _map = new HashMap<Integer, StaticFeedforwardSignValue>();
        for (StaticFeedforwardSignValue type : StaticFeedforwardSignValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets StaticFeedforwardSignValue from specified value
     * @param value Value of StaticFeedforwardSignValue
     * @return StaticFeedforwardSignValue of specified value
     */
    public static StaticFeedforwardSignValue valueOf(int value)
    {
        StaticFeedforwardSignValue retval = _map.get(value);
        if (retval != null) return retval;
        return StaticFeedforwardSignValue.values()[0];
    }
}
