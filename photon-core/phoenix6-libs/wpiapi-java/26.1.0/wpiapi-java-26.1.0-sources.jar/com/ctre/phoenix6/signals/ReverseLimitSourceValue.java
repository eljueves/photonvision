/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Determines where to poll the reverse limit switch.  This defaults to the
 * reverse limit switch pin on the limit switch connector.
 * <p>
 * Choose RemoteTalonFX to use the reverse limit switch attached to another
 * Talon FX on the same CAN bus (this also requires setting
 * ReverseLimitRemoteSensorID).
 * <p>
 * Choose RemoteCANifier to use the reverse limit switch attached to another
 * CANifier on the same CAN bus (this also requires setting
 * ReverseLimitRemoteSensorID).
 * <p>
 * Choose RemoteCANcoder to use another CANcoder on the same CAN bus (this also
 * requires setting ReverseLimitRemoteSensorID).  The reverse limit will assert
 * when the CANcoder magnet strength changes from BAD (red) to ADEQUATE (orange)
 * or GOOD (green).
 */
public enum ReverseLimitSourceValue
{
    /**
     * Use the reverse limit switch pin on the limit switch connector.
     */
    LimitSwitchPin(0),
    /**
     * Use the reverse limit switch attached to another Talon FX on the same CAN bus
     * (this also requires setting ReverseLimitRemoteSensorID).
     */
    RemoteTalonFX(1),
    /**
     * Use the reverse limit switch attached to another CANifier on the same CAN bus
     * (this also requires setting ReverseLimitRemoteSensorID).
     */
    RemoteCANifier(2),
    /**
     * Use another CANcoder on the same CAN bus (this also requires setting
     * ReverseLimitRemoteSensorID).  The reverse limit will assert when the CANcoder
     * magnet strength changes from BAD (red) to ADEQUATE (orange) or GOOD (green).
     */
    RemoteCANcoder(4),
    /**
     * Use another CANrange on the same CAN bus (this also requires setting
     * ReverseLimitRemoteSensorID).  The reverse limit will assert when the CANrange
     * proximity detect is tripped.
     */
    RemoteCANrange(6),
    /**
     * Use another CTR Electronics' CANdi™ on the same CAN bus (this also requires
     * setting ForwardLimitRemoteSensorID).  The forward limit will assert when the
     * CTR Electronics' CANdi™ Signal 1 Input (S1IN) pin matches the configured
     * closed state.
     */
    RemoteCANdiS1(7),
    /**
     * Use another CTR Electronics' CANdi™ on the same CAN bus (this also requires
     * setting ForwardLimitRemoteSensorID).  The forward limit will assert when
     * CANdi™ Signal 2 Input (S2IN) pin matches the configured closed state.
     */
    RemoteCANdiS2(8),
    /**
     * Disable the reverse limit switch.
     */
    Disabled(3),;

    public final int value;

    ReverseLimitSourceValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, ReverseLimitSourceValue> _map = null;
    static
    {
        _map = new HashMap<Integer, ReverseLimitSourceValue>();
        for (ReverseLimitSourceValue type : ReverseLimitSourceValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets ReverseLimitSourceValue from specified value
     * @param value Value of ReverseLimitSourceValue
     * @return ReverseLimitSourceValue of specified value
     */
    public static ReverseLimitSourceValue valueOf(int value)
    {
        ReverseLimitSourceValue retval = _map.get(value);
        if (retval != null) return retval;
        return ReverseLimitSourceValue.values()[0];
    }
}
