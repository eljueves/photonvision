/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs that affect Voltage control types.
 * <p>
 * Includes peak output voltages and other configs affecting voltage
 * measurements.
 */
public class VoltageConfigs implements ParentConfiguration, Cloneable {
    /**
     * The time constant (in seconds) of the low-pass filter for the
     * supply voltage.
     * <p>
     * This impacts the filtering for the reported supply voltage, and any
     * control strategies that use the supply voltage (such as voltage
     * control on a motor controller).
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 0.1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     */
    public double SupplyVoltageTimeConstant = 0;
    /**
     * Maximum (forward) output during voltage based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> 16
     *   <li> <b>Units:</b> V
     * </ul>
     */
    public double PeakForwardVoltage = 16;
    /**
     * Minimum (reverse) output during voltage based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> -16
     *   <li> <b>Units:</b> V
     * </ul>
     */
    public double PeakReverseVoltage = -16;
    
    /**
     * Modifies this configuration's SupplyVoltageTimeConstant parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The time constant (in seconds) of the low-pass filter for the
     * supply voltage.
     * <p>
     * This impacts the filtering for the reported supply voltage, and any
     * control strategies that use the supply voltage (such as voltage
     * control on a motor controller).
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 0.1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newSupplyVoltageTimeConstant Parameter to modify
     * @return Itself
     */
    public final VoltageConfigs withSupplyVoltageTimeConstant(double newSupplyVoltageTimeConstant)
    {
        SupplyVoltageTimeConstant = newSupplyVoltageTimeConstant;
        return this;
    }
    
    /**
     * Modifies this configuration's SupplyVoltageTimeConstant parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The time constant (in seconds) of the low-pass filter for the
     * supply voltage.
     * <p>
     * This impacts the filtering for the reported supply voltage, and any
     * control strategies that use the supply voltage (such as voltage
     * control on a motor controller).
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 0.1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newSupplyVoltageTimeConstant Parameter to modify
     * @return Itself
     */
    public final VoltageConfigs withSupplyVoltageTimeConstant(Time newSupplyVoltageTimeConstant)
    {
        SupplyVoltageTimeConstant = newSupplyVoltageTimeConstant.in(Seconds);
        return this;
    }
    
    /**
     * Helper method to get this configuration's SupplyVoltageTimeConstant parameter converted
     * to a unit type. If not using the Java units library, {@link #SupplyVoltageTimeConstant}
     * can be accessed directly instead.
     * <p>
     * The time constant (in seconds) of the low-pass filter for the
     * supply voltage.
     * <p>
     * This impacts the filtering for the reported supply voltage, and any
     * control strategies that use the supply voltage (such as voltage
     * control on a motor controller).
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 0.1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @return SupplyVoltageTimeConstant
     */
    public final Time getSupplyVoltageTimeConstantMeasure()
    {
        return Seconds.of(SupplyVoltageTimeConstant);
    }
    
    /**
     * Modifies this configuration's PeakForwardVoltage parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Maximum (forward) output during voltage based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> 16
     *   <li> <b>Units:</b> V
     * </ul>
     *
     * @param newPeakForwardVoltage Parameter to modify
     * @return Itself
     */
    public final VoltageConfigs withPeakForwardVoltage(double newPeakForwardVoltage)
    {
        PeakForwardVoltage = newPeakForwardVoltage;
        return this;
    }
    
    /**
     * Modifies this configuration's PeakForwardVoltage parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Maximum (forward) output during voltage based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> 16
     *   <li> <b>Units:</b> V
     * </ul>
     *
     * @param newPeakForwardVoltage Parameter to modify
     * @return Itself
     */
    public final VoltageConfigs withPeakForwardVoltage(Voltage newPeakForwardVoltage)
    {
        PeakForwardVoltage = newPeakForwardVoltage.in(Volts);
        return this;
    }
    
    /**
     * Helper method to get this configuration's PeakForwardVoltage parameter converted
     * to a unit type. If not using the Java units library, {@link #PeakForwardVoltage}
     * can be accessed directly instead.
     * <p>
     * Maximum (forward) output during voltage based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> 16
     *   <li> <b>Units:</b> V
     * </ul>
     *
     * @return PeakForwardVoltage
     */
    public final Voltage getPeakForwardVoltageMeasure()
    {
        return Volts.of(PeakForwardVoltage);
    }
    
    /**
     * Modifies this configuration's PeakReverseVoltage parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Minimum (reverse) output during voltage based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> -16
     *   <li> <b>Units:</b> V
     * </ul>
     *
     * @param newPeakReverseVoltage Parameter to modify
     * @return Itself
     */
    public final VoltageConfigs withPeakReverseVoltage(double newPeakReverseVoltage)
    {
        PeakReverseVoltage = newPeakReverseVoltage;
        return this;
    }
    
    /**
     * Modifies this configuration's PeakReverseVoltage parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Minimum (reverse) output during voltage based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> -16
     *   <li> <b>Units:</b> V
     * </ul>
     *
     * @param newPeakReverseVoltage Parameter to modify
     * @return Itself
     */
    public final VoltageConfigs withPeakReverseVoltage(Voltage newPeakReverseVoltage)
    {
        PeakReverseVoltage = newPeakReverseVoltage.in(Volts);
        return this;
    }
    
    /**
     * Helper method to get this configuration's PeakReverseVoltage parameter converted
     * to a unit type. If not using the Java units library, {@link #PeakReverseVoltage}
     * can be accessed directly instead.
     * <p>
     * Minimum (reverse) output during voltage based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> -16
     *   <li> <b>Units:</b> V
     * </ul>
     *
     * @return PeakReverseVoltage
     */
    public final Voltage getPeakReverseVoltageMeasure()
    {
        return Volts.of(PeakReverseVoltage);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: Voltage\n";
        ss += "    SupplyVoltageTimeConstant: " + SupplyVoltageTimeConstant + " seconds" + "\n";
        ss += "    PeakForwardVoltage: " + PeakForwardVoltage + " V" + "\n";
        ss += "    PeakReverseVoltage: " + PeakReverseVoltage + " V" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_SupplyVLowpassTau.value, SupplyVoltageTimeConstant);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_PeakForwardV.value, PeakForwardVoltage);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_PeakReverseV.value, PeakReverseVoltage);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        SupplyVoltageTimeConstant = ConfigJNI.Deserializedouble(SpnValue.Config_SupplyVLowpassTau.value, to_deserialize);
        PeakForwardVoltage = ConfigJNI.Deserializedouble(SpnValue.Config_PeakForwardV.value, to_deserialize);
        PeakReverseVoltage = ConfigJNI.Deserializedouble(SpnValue.Config_PeakReverseV.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public VoltageConfigs clone() {
        try {
            return (VoltageConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

