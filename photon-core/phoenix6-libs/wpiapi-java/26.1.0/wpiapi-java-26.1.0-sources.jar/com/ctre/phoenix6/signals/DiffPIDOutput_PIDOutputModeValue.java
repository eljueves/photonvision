/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The output mode of the differential PID controller.
 */
public enum DiffPIDOutput_PIDOutputModeValue
{
    DutyCycle(0),
    Voltage(1),
    TorqueCurrentFOC(2),;

    public final int value;

    DiffPIDOutput_PIDOutputModeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, DiffPIDOutput_PIDOutputModeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, DiffPIDOutput_PIDOutputModeValue>();
        for (DiffPIDOutput_PIDOutputModeValue type : DiffPIDOutput_PIDOutputModeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets DiffPIDOutput_PIDOutputModeValue from specified value
     * @param value Value of DiffPIDOutput_PIDOutputModeValue
     * @return DiffPIDOutput_PIDOutputModeValue of specified value
     */
    public static DiffPIDOutput_PIDOutputModeValue valueOf(int value)
    {
        DiffPIDOutput_PIDOutputModeValue retval = _map.get(value);
        if (retval != null) return retval;
        return DiffPIDOutput_PIDOutputModeValue.values()[0];
    }
}
