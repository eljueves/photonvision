/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6;

import java.util.function.DoubleFunction;
import java.util.function.Supplier;

import com.ctre.phoenix6.hardware.DeviceIdentifier;
import com.ctre.phoenix6.hardware.ParentDevice.MapGenerator;

import edu.wpi.first.units.Measure;

/**
 * Represents a status signal with data of type T, and
 * operations available to retrieve information about
 * the signal.
 */
public class StatusSignal<T> extends BaseStatusSignal implements Cloneable {
    private final Class<T> classOfSignal;
    private final DoubleFunction<T> toValue;

    public StatusSignal(
        DeviceIdentifier deviceIdentifier, int spn, String signalName,
        Runnable reportIfOldFunc, Class<T> classOfSignal, DoubleFunction<T> toValue
    ) {
        super(deviceIdentifier, spn, signalName, reportIfOldFunc);
        this.classOfSignal = classOfSignal;
        this.toValue = toValue;
    }

    public StatusSignal(
        DeviceIdentifier deviceIdentifier, int spn, String signalName,
        Runnable reportIfOldFunc, MapGenerator unitsGenerator,
        Class<T> classOfSignal, DoubleFunction<T> toValue
    ) {
        super(deviceIdentifier, spn, signalName, reportIfOldFunc, unitsGenerator);
        this.classOfSignal = classOfSignal;
        this.toValue = toValue;
    }

    /* Constructor for an invalid StatusSignal */
    public StatusSignal(StatusCode error, Class<T> classOfSignal, DoubleFunction<T> toValue) {
        super(error);
        this.classOfSignal = classOfSignal;
        this.toValue = toValue;
    }

    public final Class<T> getTypeClass() {
        return classOfSignal;
    }

    @Override
    public StatusSignal<T> clone() {
        try {
            @SuppressWarnings("unchecked")
            StatusSignal<T> toReturn = StatusSignal.class.cast(super.clone());
            toReturn.timestamps = timestamps.clone();
            toReturn.jni = jni.clone();
            return toReturn;
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            return new StatusSignal<T>(StatusCode.InvalidParamValue, classOfSignal, toValue);
        }
    }

    /**
     * Gets the cached value from this status signal.
     * <p>
     * Gets the cached value. To make sure the value is up-to-date call
     * {@link #refresh()} or {@link #waitForUpdate(double)}
     *
     * @return Cached value
     */
    public final T getValue() {
        return toValue.apply(baseValue);
    }

    /**
     * Refreshes the value of this status signal.
     * <p>
     * If the user application caches this StatusSignal object
     * instead of periodically fetching it from the hardware device,
     * this function must be called to fetch fresh data.
     * <p>
     * This performs a non-blocking refresh operation. If you want to wait until you
     * receive the signal, call {@link #waitForUpdate(double)} instead.
     *
     * @param reportError Whether to report any errors to the Driver Station/stderr.
     *                    Defaults true
     *
     * @return Reference to itself
     */
    public final StatusSignal<T> refresh(boolean reportError) {
        refreshValue(false, 0, reportError); // Don't block and error if signal is older than a default timeout
        return this;
    }

    /**
     * Refreshes the value of this status signal.
     * <p>
     * If the user application caches this StatusSignal object
     * instead of periodically fetching it from the hardware device,
     * this function must be called to fetch fresh data.
     * <p>
     * This performs a non-blocking refresh operation. If you want to wait until you
     * receive the signal, call {@link #waitForUpdate(double)} instead.
     *
     * @return Reference to itself
     */
    public final StatusSignal<T> refresh() {
        return refresh(true);
    }

    /**
     * Waits up to timeoutSec to get the up-to-date status signal value.
     * <p>
     * This performs a blocking refresh operation. If you want to non-blocking
     * refresh the signal, call {@link #refresh()} instead.
     *
     * @param timeoutSec  Maximum time to wait for the signal to update
     * @param reportError Whether to report any errors to the Driver Station/stderr.
     *                    Defaults true
     *
     * @return Reference to itself
     */
    public final StatusSignal<T> waitForUpdate(double timeoutSec, boolean reportError) {
        refreshValue(true, timeoutSec, reportError);
        return this;
    }

    /**
     * Waits up to timeoutSec to get the up-to-date status signal value.
     * <p>
     * This performs a blocking refresh operation. If you want to non-blocking
     * refresh the signal, call {@link #refresh()} instead.
     *
     * @param timeoutSec Maximum time to wait for the signal to update
     *
     * @return Reference to itself
     */
    public final StatusSignal<T> waitForUpdate(double timeoutSec) {
        return waitForUpdate(timeoutSec, true);
    }

    /**
     * Checks whether the signal is near a target value within the
     * given tolerance.
     *
     * @param target The target value of the signal
     * @param tolerance The error tolerance between the target and measured values
     * @return Whether the signal is near the target value
     */
    public final boolean isNear(double target, double tolerance) {
        return Math.abs(getValueAsDouble() - target) <= tolerance;
    }

    /**
     * Checks whether the signal is near a target value within the
     * given tolerance. This signal must be a numeric or unit type.
     *
     * @param target The target value of the signal
     * @param tolerance The error tolerance between the target and measured values
     * @return Whether the signal is near the target value
     */
    public final boolean isNear(T target, T tolerance) {
        var value = getValue();
        if (value == null || classOfSignal.isEnum()) {
            return false;
        } else if (value instanceof Measure<?> meas) {
            return Math.abs(meas.baseUnitMagnitude() - ((Measure<?>)target).baseUnitMagnitude()) <=
                Math.abs(((Measure<?>)tolerance).baseUnitMagnitude());
        } else {
            return Math.abs((double)value - (double)target) <= (double)tolerance;
        }
    }

    /**
     * Returns a lambda that calls {@link #refresh} and {@link #getValue} on this object.
     * This is useful for command-based programming.
     *
     * @return Supplier that refreshes this signal and returns it
     */
    public final Supplier<T> asSupplier() {
        return () -> refresh().getValue();
    }

    @Override
    public String toString() {
        var value = getValue();
        if (value == null || units == null) {
            return "Invalid signal";
        } else if (value instanceof Measure) {
            return getValueAsDouble() + " " + units;
        } else {
            return value.toString() + " " + units;
        }
    }

    /**
     * Information from a single measurement of a status signal.
     */
    public static class SignalMeasurement<V> {
        /**
         * The name of the signal
         */
        public String name;
        /**
         * The value of the signal
         */
        public V value;
        /**
         * Timestamp of when the data point was taken, in seconds
         */
        public double timestamp;
        /**
         * The units of the signal measurement
         */
        public String units;
        /**
         * Status code response of getting the data
         */
        public StatusCode status;
    };

    /**
     * Get a basic data-only container with a copy of the current signal data.
     * <p>
     * If looking for Phoenix 6 logging features, see the {@link SignalLogger}
     * class instead.
     * <p>
     * This function returns a new object every call. As a result, we recommend that
     * this is not called inside a tight loop.
     *
     * @return Basic structure with all relevant information
     */
    public final SignalMeasurement<T> getDataCopy() {
        SignalMeasurement<T> toRet = new SignalMeasurement<T>();
        toRet.name = getName();
        toRet.value = getValue();
        toRet.timestamp = getTimestamp().getTime();
        toRet.units = getUnits();
        toRet.status = getStatus();
        return toRet;
    }
}
