/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.wpiutils;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.ctre.phoenix6.SignalLogger;
import com.ctre.phoenix6.unmanaged.Unmanaged;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.Notifier;

public final class AutoFeedEnable implements AutoCloseable {
    private static final AutoFeedEnable autoFeedEnable = new AutoFeedEnable();

    private final Notifier _enableNotifier;
    private final Lock _lck = new ReentrantLock();
    private int _startCount = 0;

    public static AutoFeedEnable getInstance() {
        return autoFeedEnable;
    }

    private AutoFeedEnable() {
        _enableNotifier = new Notifier(() -> {
            String robotMode;
            if (DriverStation.isEnabled()) {
                Unmanaged.feedEnable(100);

                if (DriverStation.isAutonomous()) {
                    robotMode = "Autonomous";
                } else if (DriverStation.isTest()) {
                    robotMode = "Test";
                } else {
                    robotMode = "Teleop";
                }
            } else {
                Unmanaged.feedEnable(0);

                if (DriverStation.isEStopped()) {
                    robotMode = "EStopped";
                } else {
                    robotMode = "Disabled";
                }
            }

            String allianceStation = "";
            switch (DriverStation.getRawAllianceStation()) {
                case Red1:
                    allianceStation = "Red 1";
                    break;
                case Red2:
                    allianceStation = "Red 2";
                    break;
                case Red3:
                    allianceStation = "Red 3";
                    break;
                case Blue1:
                    allianceStation = "Blue 1";
                    break;
                case Blue2:
                    allianceStation = "Blue 2";
                    break;
                case Blue3:
                    allianceStation = "Blue 3";
                    break;
                default:
                    break;
            }

            SignalLogger.writeString("RobotMode", robotMode);
            SignalLogger.writeString("AllianceStation", allianceStation);
            SignalLogger.writeBoolean("DS:IsDSAttached", DriverStation.isDSAttached());
            SignalLogger.writeBoolean("DS:IsFMSAttached", DriverStation.isFMSAttached());
        });
    }

    /**
     * Starts feeding the enable signal to CTRE actuators.
     */
    public void start() {
        _lck.lock();
        try {
            if (_startCount < Integer.MAX_VALUE) {
                if (_startCount++ == 0) {
                    /* start if we were previously at 0 */
                    _enableNotifier.startPeriodic(0.010);
                }
            }
        } finally {
            _lck.unlock();
        }
    }

    /**
     * Stops feeding the enable signal to CTRE actuators. The
     * enable signal will only be stopped when all actuators
     * have requested to stop the enable signal.
     */
    public void stop() {
        _lck.lock();
        try {
            if (_startCount > 0) {
                if (--_startCount == 0) {
                    /* stop if we are now at 0 */
                    _enableNotifier.stop();
                }
            }
        } finally {
            _lck.unlock();
        }
    }

    @Override
    public void close() {
        _enableNotifier.close();
    }
}
