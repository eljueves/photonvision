/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether the closed-loop is running on position or velocity.
 */
public enum PIDRefSlopeECUTime_ClosedLoopModeValue
{
    Position(0),
    Velocity(1),;

    public final int value;

    PIDRefSlopeECUTime_ClosedLoopModeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, PIDRefSlopeECUTime_ClosedLoopModeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, PIDRefSlopeECUTime_ClosedLoopModeValue>();
        for (PIDRefSlopeECUTime_ClosedLoopModeValue type : PIDRefSlopeECUTime_ClosedLoopModeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets PIDRefSlopeECUTime_ClosedLoopModeValue from specified value
     * @param value Value of PIDRefSlopeECUTime_ClosedLoopModeValue
     * @return PIDRefSlopeECUTime_ClosedLoopModeValue of specified value
     */
    public static PIDRefSlopeECUTime_ClosedLoopModeValue valueOf(int value)
    {
        PIDRefSlopeECUTime_ClosedLoopModeValue retval = _map.get(value);
        if (retval != null) return retval;
        return PIDRefSlopeECUTime_ClosedLoopModeValue.values()[0];
    }
}
