/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6;

import java.util.HashMap;

/**
 * Information about the timestamp of a signal.
 */
public final class Timestamp {

    /**
     * Source of the timestamp.
     */
    public enum TimestampSource {
        /**
         * Timestamp as reported by the system.
         * This timestamp is captured when the system receives the signal value.
         * <p>
         * This timestamp is present on all systems and is guaranteed to be monotonic.
         * However, this timestamp is the least accurate due to latency from processing
         * delays within the system.
         */
        System(0),
        /**
         * Timestamp as reported by the CANivore.
         * This timestamp is captured when the CANivore receives the signal value.
         * <p>
         * The CANivore is synchronized to the system monotonic clock and benefits
         * from reduced latency over the {@link TimestampSource#System System} timestamp.
         * <p>
         * On the native roboRIO CAN bus, this timestamp is equivalent to the {@link TimestampSource#System System} timestamp.
         * <p>
         * When used with CANivore, the only inaccuracy in this measurement is latency
         * from CAN bus arbitration.
         */
        CANivore(1),
        /**
         * This timestamp source requires Phoenix Pro.
         * <p>
         * Timestamp as reported by the device.
         * This timestamp is captured when the device transmits the signal value.
         * Because it is timestamped in the device, it is the most accurate timestamp source.
         * <p>
         * This timestamp is synchronized to the CANivore clock, which is itself synchronized
         * to the system monotonic clock. As a result, this timestamp source requires a CANivore.
         * <p>
         * It can be assumed there is no latency between this timestamp and when the data was taken.
         */
        Device(2);

        public final int value;

        TimestampSource(int initValue) {
            this.value = initValue;
        }

        private static HashMap<Integer, TimestampSource> _map = null;
        static {
            _map = new HashMap<Integer, TimestampSource>();
            for (TimestampSource type : TimestampSource.values()) {
                _map.put(type.value, type);
            }
        }

        /**
         * Gets TimestampSource from specified value
         *
         * @param value Value of TimestampSouce
         * @return TimestampSource of specified value
         */
        public static TimestampSource valueOf(int value) {
            TimestampSource retval = _map.get(value);
            if (retval != null)
                return retval;
            return TimestampSource.values()[0];
        }
    }

    private double time;
    private TimestampSource source;
    private boolean valid;

    /**
     * Construct a new Timestamp for the given source.
     *
     * @param time The time in seconds
     * @param source The timestamp source
     */
    Timestamp(double time, TimestampSource source) {
        this(time, source, true);
    }
    /**
     * Construct a new Timestamp for the given source.
     *
     * @param time The time in seconds
     * @param source The timestamp source
     * @param valid Whether the timestamp is valid (true by default)
     */
    Timestamp(double time, TimestampSource source, boolean valid) {
        update(time, source, valid);
    }
    /**
     * Construct a new invalid Timestamp.
     */
    Timestamp() {
        this.valid = false;
    }

    void update(double time, TimestampSource source, boolean valid) {
        this.time = time;
        this.source = source;
        this.valid = valid;
    }

    /**
     * Get the time in seconds as reported from this timestamp
     *
     * @return Time in seconds
     */
    public double getTime() {
        return time;
    }

    /**
     * Get the source of this timestamp
     *
     * @return Source of this timestamp
     */
    public TimestampSource getSource() {
        return source;
    }

    /**
     * Get the latency of this timestamp compared to now
     *
     * @return Difference between now and this timestamp
     */
    public double getLatency() {
        return Utils.getCurrentTimeSeconds() - time;
    }

    /**
     * Returns if this Timestamp is valid or not.
     *
     * @return true when this is valid
     */
    public boolean isValid() {
        return valid;
    }
}
