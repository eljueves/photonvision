/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Invert state of the device as seen from the front of the motor.
 */
public enum InvertedValue
{
    /**
     * Positive motor output results in counter-clockwise motion.
     */
    CounterClockwise_Positive(0),
    /**
     * Positive motor output results in clockwise motion.
     */
    Clockwise_Positive(1),;

    public final int value;

    InvertedValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, InvertedValue> _map = null;
    static
    {
        _map = new HashMap<Integer, InvertedValue>();
        for (InvertedValue type : InvertedValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets InvertedValue from specified value
     * @param value Value of InvertedValue
     * @return InvertedValue of specified value
     */
    public static InvertedValue valueOf(int value)
    {
        InvertedValue retval = _map.get(value);
        if (retval != null) return retval;
        return InvertedValue.values()[0];
    }
}
