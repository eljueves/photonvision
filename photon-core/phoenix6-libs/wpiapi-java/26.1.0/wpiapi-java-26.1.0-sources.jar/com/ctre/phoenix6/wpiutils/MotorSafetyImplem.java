/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.wpiutils;

import edu.wpi.first.wpilibj.MotorSafety;

/**
 * Implem of MotorSafety interface from WPILib. This also allows late/lazy
 * construction of WPILib's motor safety object.
 */
public final class MotorSafetyImplem extends MotorSafety {
    private final Runnable m_stopMotor;
    private final String m_description;

    /**
     * Constructor for MotorSafetyImplem
     * @param stopMotor Lambda to stop the motor
     * @param description Description of motor controller
     */
    public MotorSafetyImplem(Runnable stopMotor, String description) {
        m_stopMotor = stopMotor;
        m_description = description;
    }

    /**
     * Stops the controller
     */
    public void stopMotor() { m_stopMotor.run(); }

    /**
     * @return Description of motor controller
     */
    public String getDescription() { return m_description; }
}
