/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * System state of the device.
 */
public enum System_StateValue
{
    Bootup_0(0),
    Bootup_1(1),
    Bootup_2(2),
    Bootup_3(3),
    Bootup_4(4),
    Bootup_5(5),
    Bootup_6(6),
    Bootup_7(7),
    BootBeep(8),
    ControlDisabled(9),
    ControlEnabled(10),
    ControlEnabled_11(11),
    Fault(12),
    Recover(13),
    NotLicensed(14),
    Production(15),;

    public final int value;

    System_StateValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, System_StateValue> _map = null;
    static
    {
        _map = new HashMap<Integer, System_StateValue>();
        for (System_StateValue type : System_StateValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets System_StateValue from specified value
     * @param value Value of System_StateValue
     * @return System_StateValue of specified value
     */
    public static System_StateValue valueOf(int value)
    {
        System_StateValue retval = _map.get(value);
        if (retval != null) return retval;
        return System_StateValue.values()[0];
    }
}
