/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;

/**
 * Class for CANcoder, a CAN based magnetic encoder that provides absolute and
 * relative position along with filtered velocity.
 *
 * This handles applying and refreshing the configurations for the {@link com.ctre.phoenix6.hardware.CANcoder}.
 */
public class CANcoderConfiguration implements ParentConfiguration, Cloneable {
    /**
     * True if we should factory default newer unsupported configs,
     * false to leave newer unsupported configs alone.
     * <p>
     * This flag addresses a corner case where the device may have
     * firmware with newer configs that didn't exist when this
     * version of the API was built. If this occurs and this
     * flag is true, unsupported new configs will be factory
     * defaulted to avoid unexpected behavior.
     * <p>
     * This is also the behavior in Phoenix 5, so this flag
     * is defaulted to true to match.
     */
    public boolean FutureProofConfigs = true;

    
    /**
     * Configs that affect the magnet sensor and how to interpret it.
     * <p>
     * Includes sensor direction, the sensor discontinuity point, and the
     * magnet offset.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link MagnetSensorConfigs#SensorDirection}
     *   <li> {@link MagnetSensorConfigs#MagnetOffset}
     *   <li> {@link MagnetSensorConfigs#AbsoluteSensorDiscontinuityPoint}
     * </ul>
     * 
     */
    public MagnetSensorConfigs MagnetSensor = new MagnetSensorConfigs();
    
    /**
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     */
    public CustomParamsConfigs CustomParams = new CustomParamsConfigs();
    
    /**
     * Modifies this configuration's MagnetSensor parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect the magnet sensor and how to interpret it.
     * <p>
     * Includes sensor direction, the sensor discontinuity point, and the
     * magnet offset.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link MagnetSensorConfigs#SensorDirection}
     *   <li> {@link MagnetSensorConfigs#MagnetOffset}
     *   <li> {@link MagnetSensorConfigs#AbsoluteSensorDiscontinuityPoint}
     * </ul>
     * 
     *
     * @param newMagnetSensor Parameter to modify
     * @return Itself
     */
    public final CANcoderConfiguration withMagnetSensor(MagnetSensorConfigs newMagnetSensor)
    {
        MagnetSensor = newMagnetSensor;
        return this;
    }
    
    /**
     * Modifies this configuration's CustomParams parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     *
     * @param newCustomParams Parameter to modify
     * @return Itself
     */
    public final CANcoderConfiguration withCustomParams(CustomParamsConfigs newCustomParams)
    {
        CustomParams = newCustomParams;
        return this;
    }

    @Override
    public String toString() {
        String ss = "CANcoderConfiguration\n";
        ss += MagnetSensor.toString();
        ss += CustomParams.toString();
        return ss;
    }

    /**
     * Get the serialized form of this configuration.
     *
     * @return Serialized form of this config group
     */
    public final String serialize() {
        String ss = "";
        ss += MagnetSensor.serialize();
        ss += CustomParams.serialize();
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration.
     *
     * @return Return code of the deserialize method
     */
    public final StatusCode deserialize(String to_deserialize) {
        StatusCode err = StatusCode.OK;
        err = MagnetSensor.deserialize(to_deserialize);
        err = CustomParams.deserialize(to_deserialize);
        return err;
    }

    @Override
    public CANcoderConfiguration clone() {
        var retval = new CANcoderConfiguration();
        retval.FutureProofConfigs = FutureProofConfigs;
        retval.MagnetSensor = MagnetSensor.clone();
        retval.CustomParams = CustomParams.clone();
        return retval;
    }
}
