/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * State of the Signal 1 input (S1IN).
 */
public enum S1StateValue
{
    /**
     * Input is not driven high or low, it is disconnected from load.
     */
    Floating(0),
    /**
     * Input is driven low (below 0.5V).
     */
    Low(1),
    /**
     * Input is driven high (above 3V).
     */
    High(2),;

    public final int value;

    S1StateValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, S1StateValue> _map = null;
    static
    {
        _map = new HashMap<Integer, S1StateValue>();
        for (S1StateValue type : S1StateValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets S1StateValue from specified value
     * @param value Value of S1StateValue
     * @return S1StateValue of specified value
     */
    public static S1StateValue valueOf(int value)
    {
        S1StateValue retval = _map.get(value);
        if (retval != null) return retval;
        return S1StateValue.values()[0];
    }
}
