/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.sim;

import static edu.wpi.first.units.Units.*;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.hardware.core.CorePigeon2;
import com.ctre.phoenix6.hardware.Pigeon2;
import com.ctre.phoenix6.jni.PlatformJNI;

import edu.wpi.first.units.measure.*;

/**
 * Class to control the state of a simulated {@link Pigeon2}.
 */
public class Pigeon2SimState {
    private static final DeviceType kDevType = DeviceType.P6_Pigeon2Type;

    private final int _id;

    /**
     * Creates an object to control the state of the given {@link Pigeon2}.
     * <p>
     * Note the recommended method of accessing simulation features is to use
     * {@link Pigeon2#getSimState}.
     * 
     * @param device Device to which this simulation state is attached
     */
    public Pigeon2SimState(CorePigeon2 device) {
        _id = device.getDeviceID();
    }

    /**
     * Sets the simulated supply voltage of the Pigeon2.
     * <p>
     * The minimum allowed supply voltage is 4 V - values below this
     * will be promoted to 4 V.
     *
     * @param volts The supply voltage in Volts
     * @return Status code
     */
    public final StatusCode setSupplyVoltage(double volts) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "SupplyVoltage", volts));
    }
    /**
     * Sets the simulated supply voltage of the Pigeon2.
     * <p>
     * The minimum allowed supply voltage is 4 V - values below this
     * will be promoted to 4 V.
     *
     * @param voltage The supply voltage
     * @return Status code
     */
    public final StatusCode setSupplyVoltage(Voltage voltage) {
        return setSupplyVoltage(voltage.in(Volts));
    }

    /**
     * Sets the simulated raw yaw of the Pigeon2.
     * <p>
     * Inputs to this function over time should be continuous, as user calls of {@link Pigeon2#setYaw} will be accounted for in the callee.
     * <p>
     * The Pigeon2 integrates this to calculate the true reported yaw.
     * <p>
     * When using the WPI Sim GUI, you will notice a readonly {@code yaw} and settable {@code rawYawInput}.
     * The readonly signal is the emulated yaw which will match self-test in Tuner and the hardware API.
     * Changes to {@code rawYawInput} will be integrated into the emulated yaw.
     * This way a simulator can modify the yaw without overriding hardware API calls for home-ing the sensor.
     *
     * @param deg The yaw in degrees
     * @return Status code
     */
    public final StatusCode setRawYaw(double deg) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "RawYaw", deg));
    }
    /**
     * Sets the simulated raw yaw of the Pigeon2.
     * <p>
     * Inputs to this function over time should be continuous, as user calls of {@link Pigeon2#setYaw} will be accounted for in the callee.
     * <p>
     * The Pigeon2 integrates this to calculate the true reported yaw.
     * <p>
     * When using the WPI Sim GUI, you will notice a readonly {@code yaw} and settable {@code rawYawInput}.
     * The readonly signal is the emulated yaw which will match self-test in Tuner and the hardware API.
     * Changes to {@code rawYawInput} will be integrated into the emulated yaw.
     * This way a simulator can modify the yaw without overriding hardware API calls for home-ing the sensor.
     *
     * @param yaw The yaw
     * @return Status code
     */
    public final StatusCode setRawYaw(Angle yaw) {
        return setRawYaw(yaw.in(Degrees));
    }

    /**
     * Adds to the simulated yaw of the Pigeon2.
     *
     * @param dDeg The change in yaw in degrees
     * @return Status code
     */
    public final StatusCode addYaw(double dDeg) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "AddYaw", dDeg));
    }
    /**
     * Adds to the simulated yaw of the Pigeon2.
     *
     * @param dYaw The change in yaw
     * @return Status code
     */
    public final StatusCode addYaw(Angle dYaw) {
        return addYaw(dYaw.in(Degrees));
    }

    /**
     * Sets the simulated pitch of the Pigeon2.
     *
     * @param deg The pitch in degrees
     * @return Status code
     */
    public final StatusCode setPitch(double deg) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "Pitch", deg));
    }
    /**
     * Sets the simulated pitch of the Pigeon2.
     *
     * @param pitch The pitch
     * @return Status code
     */
    public final StatusCode setPitch(Angle pitch) {
        return setPitch(pitch.in(Degrees));
    }

    /**
     * Sets the simulated roll of the Pigeon2.
     *
     * @param deg The roll in degrees
     * @return Status code
     */
    public final StatusCode setRoll(double deg) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "Roll", deg));
    }
    /**
     * Sets the simulated roll of the Pigeon2.
     *
     * @param roll The roll
     * @return Status code
     */
    public final StatusCode setRoll(Angle roll) {
        return setRoll(roll.in(Degrees));
    }

    /**
     * Sets the simulated angular velocity X component of the Pigeon2.
     *
     * @param dps The X component of the angular velocity in degrees per second
     * @return Status code
     */
    public final StatusCode setAngularVelocityX(double dps) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "AngularVelocityX", dps));
    }
    /**
     * Sets the simulated angular velocity X component of the Pigeon2.
     *
     * @param angularVel The X component of the angular velocity
     * @return Status code
     */
    public final StatusCode setAngularVelocityX(AngularVelocity angularVel) {
        return setAngularVelocityX(angularVel.in(DegreesPerSecond));
    }

    /**
     * Sets the simulated angular velocity Y component of the Pigeon2.
     *
     * @param dps The Y component of the angular velocity in degrees per second
     * @return Status code
     */
    public final StatusCode setAngularVelocityY(double dps) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "AngularVelocityY", dps));
    }
    /**
     * Sets the simulated angular velocity Y component of the Pigeon2.
     *
     * @param angularVel The Y component of the angular velocity
     * @return Status code
     */
    public final StatusCode setAngularVelocityY(AngularVelocity angularVel) {
        return setAngularVelocityY(angularVel.in(DegreesPerSecond));
    }

    /**
     * Sets the simulated angular velocity Z component of the Pigeon2.
     *
     * @param dps The Z component of the angular velocity in degrees per second
     * @return Status code
     */
    public final StatusCode setAngularVelocityZ(double dps) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "AngularVelocityZ", dps));
    }
    /**
     * Sets the simulated angular velocity Z component of the Pigeon2.
     *
     * @param angularVel The Z component of the angular velocity
     * @return Status code
     */
    public final StatusCode setAngularVelocityZ(AngularVelocity angularVel) {
        return setAngularVelocityZ(angularVel.in(DegreesPerSecond));
    }
}
