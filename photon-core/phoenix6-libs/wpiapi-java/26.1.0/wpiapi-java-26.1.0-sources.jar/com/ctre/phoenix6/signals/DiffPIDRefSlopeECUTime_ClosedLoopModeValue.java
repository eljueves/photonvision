/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether the closed-loop is running on position or velocity.
 */
public enum DiffPIDRefSlopeECUTime_ClosedLoopModeValue
{
    Position(0),
    Velocity(1),;

    public final int value;

    DiffPIDRefSlopeECUTime_ClosedLoopModeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, DiffPIDRefSlopeECUTime_ClosedLoopModeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, DiffPIDRefSlopeECUTime_ClosedLoopModeValue>();
        for (DiffPIDRefSlopeECUTime_ClosedLoopModeValue type : DiffPIDRefSlopeECUTime_ClosedLoopModeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets DiffPIDRefSlopeECUTime_ClosedLoopModeValue from specified value
     * @param value Value of DiffPIDRefSlopeECUTime_ClosedLoopModeValue
     * @return DiffPIDRefSlopeECUTime_ClosedLoopModeValue of specified value
     */
    public static DiffPIDRefSlopeECUTime_ClosedLoopModeValue valueOf(int value)
    {
        DiffPIDRefSlopeECUTime_ClosedLoopModeValue retval = _map.get(value);
        if (retval != null) return retval;
        return DiffPIDRefSlopeECUTime_ClosedLoopModeValue.values()[0];
    }
}
