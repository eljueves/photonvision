/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether the closed-loop is running on position or velocity.
 */
public enum PIDRefPIDErr_ClosedLoopModeValue
{
    Position(0),
    Velocity(1),;

    public final int value;

    PIDRefPIDErr_ClosedLoopModeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, PIDRefPIDErr_ClosedLoopModeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, PIDRefPIDErr_ClosedLoopModeValue>();
        for (PIDRefPIDErr_ClosedLoopModeValue type : PIDRefPIDErr_ClosedLoopModeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets PIDRefPIDErr_ClosedLoopModeValue from specified value
     * @param value Value of PIDRefPIDErr_ClosedLoopModeValue
     * @return PIDRefPIDErr_ClosedLoopModeValue of specified value
     */
    public static PIDRefPIDErr_ClosedLoopModeValue valueOf(int value)
    {
        PIDRefPIDErr_ClosedLoopModeValue retval = _map.get(value);
        if (retval != null) return retval;
        return PIDRefPIDErr_ClosedLoopModeValue.values()[0];
    }
}
