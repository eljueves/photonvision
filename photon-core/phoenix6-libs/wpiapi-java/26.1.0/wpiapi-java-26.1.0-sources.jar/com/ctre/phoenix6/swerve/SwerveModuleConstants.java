/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.swerve;

import java.util.HashMap;

import com.ctre.phoenix6.configs.ClosedLoopGeneralConfigs;
import com.ctre.phoenix6.configs.CurrentLimitsConfigs;
import com.ctre.phoenix6.configs.FeedbackConfigs;
import com.ctre.phoenix6.configs.MagnetSensorConfigs;
import com.ctre.phoenix6.configs.MotionMagicConfigs;
import com.ctre.phoenix6.configs.MotorOutputConfigs;
import com.ctre.phoenix6.configs.ParentConfiguration;
import com.ctre.phoenix6.configs.Slot0Configs;
import com.ctre.phoenix6.configs.TorqueCurrentConfigs;
import com.ctre.phoenix6.signals.ExternalFeedbackSensorSourceValue;
import com.ctre.phoenix6.signals.FeedbackSensorSourceValue;
import com.ctre.phoenix6.swerve.jni.SwerveJNI;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * All constants for a swerve module.
 */
public class SwerveModuleConstants<
    DriveMotorConfigsT extends ParentConfiguration,
    SteerMotorConfigsT extends ParentConfiguration,
    EncoderConfigsT extends ParentConfiguration
> {
    /**
     * Supported closed-loop output types.
     */
    public enum ClosedLoopOutputType {
        Voltage(0),
        /** Requires Pro */
        TorqueCurrentFOC(1);

        public final int value;

        ClosedLoopOutputType(int initValue) {
            this.value = initValue;
        }

        private static HashMap<Integer, ClosedLoopOutputType> _map = null;
        static {
            _map = new HashMap<Integer, ClosedLoopOutputType>();
            for (ClosedLoopOutputType type : ClosedLoopOutputType.values()) {
                _map.put(type.value, type);
            }
        }

        /**
         * Gets ClosedLoopOutputType from specified value
         *
         * @param value Value of ClosedLoopOutputType
         * @return ClosedLoopOutputType of specified value
         */
        public static ClosedLoopOutputType valueOf(int value) {
            ClosedLoopOutputType retval = _map.get(value);
            if (retval != null)
                return retval;
            return ClosedLoopOutputType.values()[0];
        }
    }

    /**
     * Supported feedback sensors for the steer motors.
     */
    public enum SteerFeedbackType {
        /**
         * Requires Pro; Use {@link FeedbackSensorSourceValue#FusedCANcoder}
         * for the steer motor.
         */
        FusedCANcoder(0),
        /**
         * Requires Pro; Use {@link FeedbackSensorSourceValue#SyncCANcoder}
         * for the steer motor.
         */
        SyncCANcoder(1),
        /**
         * Use {@link FeedbackSensorSourceValue#RemoteCANcoder}
         * for the steer motor.
         */
        RemoteCANcoder(2),
        /**
         * Requires Pro; Use {@link FeedbackSensorSourceValue#FusedCANdiPWM1}
         * for the steer motor.
         */
        FusedCANdiPWM1(3),
        /**
         * Requires Pro; Use {@link FeedbackSensorSourceValue#FusedCANdiPWM2}
         * for the steer motor.
         */
        FusedCANdiPWM2(4),
        /**
         * Requires Pro; Use {@link FeedbackSensorSourceValue#SyncCANdiPWM1}
         * for the steer motor.
         */
        SyncCANdiPWM1(5),
        /**
         * Requires Pro; Use {@link FeedbackSensorSourceValue#SyncCANdiPWM2}
         * for the steer motor.
         */
        SyncCANdiPWM2(6),
        /**
         * Use {@link FeedbackSensorSourceValue#RemoteCANdiPWM1}
         * for the steer motor.
         */
        RemoteCANdiPWM1(7),
        /**
         * Use {@link FeedbackSensorSourceValue#RemoteCANdiPWM2}
         * for the steer motor.
         */
        RemoteCANdiPWM2(8),
        /**
         * Use {@link ExternalFeedbackSensorSourceValue#PulseWidth}
         * for the steer motor. This requires Talon FXS.
         */
        TalonFXS_PulseWidth(9);

        public final int value;

        SteerFeedbackType(int initValue) {
            this.value = initValue;
        }

        private static HashMap<Integer, SteerFeedbackType> _map = null;
        static {
            _map = new HashMap<Integer, SteerFeedbackType>();
            for (SteerFeedbackType type : SteerFeedbackType.values()) {
                _map.put(type.value, type);
            }
        }

        /**
         * Gets SteerFeedbackType from specified value
         *
         * @param value Value of SteerFeedbackType
         * @return SteerFeedbackType of specified value
         */
        public static SteerFeedbackType valueOf(int value) {
            SteerFeedbackType retval = _map.get(value);
            if (retval != null)
                return retval;
            return SteerFeedbackType.values()[0];
        }
    }
    
    /**
     * Supported motor arrangements for the drive motors.
     */
    public enum DriveMotorArrangement {
        /**
         * Talon FX integrated brushless motor.
         */
        TalonFX_Integrated(0),
        /**
         * Third party NEO brushless motor connected to a Talon FXS over JST.
         */
        TalonFXS_NEO_JST(1),
        /**
         * Third party VORTEX brushless motor connected to a Talon FXS over JST.
         */
        TalonFXS_VORTEX_JST(2);

        public final int value;

        DriveMotorArrangement(int initValue) {
            this.value = initValue;
        }

        private static HashMap<Integer, DriveMotorArrangement> _map = null;
        static {
            _map = new HashMap<Integer, DriveMotorArrangement>();
            for (DriveMotorArrangement type : DriveMotorArrangement.values()) {
                _map.put(type.value, type);
            }
        }

        /**
         * Gets DriveMotorArrangement from specified value
         *
         * @param value Value of DriveMotorArrangement
         * @return DriveMotorArrangement of specified value
         */
        public static DriveMotorArrangement valueOf(int value) {
            DriveMotorArrangement retval = _map.get(value);
            if (retval != null)
                return retval;
            return DriveMotorArrangement.values()[0];
        }
    };

    /**
     * Supported motor arrangements for the steer motors.
     */
    public enum SteerMotorArrangement {
        /**
         * Talon FX integrated brushless motor.
         */
        TalonFX_Integrated(0),
        /**
         * CTR Electronics Minion® brushless motor connected to a Talon FXS over JST.
         */
        TalonFXS_Minion_JST(1),
        /**
         * Third party NEO brushless motor connected to a Talon FXS over JST.
         */
        TalonFXS_NEO_JST(2),
        /**
         * Third party VORTEX brushless motor connected to a Talon FXS over JST.
         */
        TalonFXS_VORTEX_JST(3),
        /**
         * Third party NEO550 brushless motor connected to a Talon FXS over JST.
         */
        TalonFXS_NEO550_JST(4),
        /**
         * Brushed motor connected to a Talon FXS on terminals A and B.
         */
        TalonFXS_Brushed_AB(5),
        /**
         * Brushed motor connected to a Talon FXS on terminals A and C.
         */
        TalonFXS_Brushed_AC(6),
        /**
         * Brushed motor connected to a Talon FXS on terminals B and C.
         */
        TalonFXS_Brushed_BC(7);

        public final int value;

        SteerMotorArrangement(int initValue) {
            this.value = initValue;
        }

        private static HashMap<Integer, SteerMotorArrangement> _map = null;
        static {
            _map = new HashMap<Integer, SteerMotorArrangement>();
            for (SteerMotorArrangement type : SteerMotorArrangement.values()) {
                _map.put(type.value, type);
            }
        }

        /**
         * Gets SteerMotorArrangement from specified value
         *
         * @param value Value of SteerMotorArrangement
         * @return SteerMotorArrangement of specified value
         */
        public static SteerMotorArrangement valueOf(int value) {
            SteerMotorArrangement retval = _map.get(value);
            if (retval != null)
                return retval;
            return SteerMotorArrangement.values()[0];
        }
    };

    /**
     * CAN ID of the steer motor.
     */
    public int SteerMotorId = 0;
    /**
     * CAN ID of the drive motor.
     */
    public int DriveMotorId = 0;
    /**
     * CAN ID of the absolute encoder used for azimuth.
     */
    public int EncoderId = 0;
    /**
     * Offset of the azimuth encoder.
     */
    public double EncoderOffset = 0;
    /**
     * The location of this module's wheels relative to the physical center of the
     * robot in meters along the X axis of the robot.
     */
    public double LocationX = 0;
    /**
     * The location of this module's wheels relative to the physical center of the
     * robot in meters along the Y axis of the robot.
     */
    public double LocationY = 0;
    /**
     * True if the drive motor is inverted.
     */
    public boolean DriveMotorInverted = false;
    /**
     * True if the steer motor is inverted from the azimuth. The azimuth should
     * rotate counter-clockwise (as seen from the top of the robot) for a positive
     * motor output.
     */
    public boolean SteerMotorInverted = false;
    /**
     * True if the azimuth encoder is inverted from the azimuth. The encoder should
     * report a positive velocity when the azimuth rotates counter-clockwise (as
     * seen from the top of the robot).
     */
    public boolean EncoderInverted = false;
    /**
     * Gear ratio between the drive motor and the wheel.
     */
    public double DriveMotorGearRatio = 0;
    /**
     * Gear ratio between the steer motor and the azimuth encoder. For example, the
     * SDS Mk4 has a steering ratio of 12.8.
     */
    public double SteerMotorGearRatio = 0;
    /**
     * Coupled gear ratio between the azimuth encoder and the drive motor.
     * <p>
     * For a typical swerve module, the azimuth turn motor also drives the wheel a
     * nontrivial amount, which affects the accuracy of odometry and control. This
     * ratio represents the number of rotations of the drive motor caused by a
     * rotation of the azimuth.
     */
    public double CouplingGearRatio = 0;
    /**
     * Radius of the driving wheel in meters.
     */
    public double WheelRadius = 0;
    /**
     * The steer motor closed-loop gains.
     * <p>
     * The steer motor uses the control ouput type specified by {@link
     * #SteerMotorClosedLoopOutput} and any {@link SwerveModule.SteerRequestType}.
     * These gains operate on azimuth rotations (after the gear ratio).
     */
    public Slot0Configs SteerMotorGains = new Slot0Configs();
    /**
     * The drive motor closed-loop gains.
     * <p>
     * When using closed-loop control, the drive motor uses the control output type
     * specified by {@link #DriveMotorClosedLoopOutput} and any closed-loop {@link
     * SwerveModule.DriveRequestType}. These gains operate on motor rotor rotations
     * (before the gear ratio).
     */
    public Slot0Configs DriveMotorGains = new Slot0Configs();
    /**
     * The closed-loop output type to use for the steer motors.
     */
    public ClosedLoopOutputType SteerMotorClosedLoopOutput = ClosedLoopOutputType.Voltage;
    /**
     * The closed-loop output type to use for the drive motors.
     */
    public ClosedLoopOutputType DriveMotorClosedLoopOutput = ClosedLoopOutputType.Voltage;
    /**
     * The maximum amount of stator current the drive motors can apply without
     * slippage.
     */
    public double SlipCurrent = 120;
    /**
     * When using open-loop drive control, this specifies the speed at which the
     * robot travels when driven with 12 volts. This is used to approximate the
     * output for a desired velocity. If using closed loop control, this value is
     * ignored.
     */
    public double SpeedAt12Volts = 0;
    /**
     * Choose the motor used for the drive motor.
     * <p>
     * If using a Talon FX, this should be set to TalonFX_Integrated. If using a
     * Talon FXS, this should be set to the motor attached to the Talon FXS.
     */
    public DriveMotorArrangement DriveMotorType = DriveMotorArrangement.TalonFX_Integrated;
    /**
     * Choose the motor used for the steer motor.
     * <p>
     * If using a Talon FX, this should be set to TalonFX_Integrated. If using a
     * Talon FXS, this should be set to the motor attached to the Talon FXS.
     */
    public SteerMotorArrangement SteerMotorType = SteerMotorArrangement.TalonFX_Integrated;
    /**
     * Choose how the feedback sensors should be configured.
     * <p>
     * If the robot does not support Pro, then this should be set to RemoteCANcoder.
     * Otherwise, users have the option to use either FusedCANcoder or SyncCANcoder
     * depending on if there is a risk that the CANcoder can fail in a way to
     * provide "good" data.
     * <p>
     * If this is set to FusedCANcoder or SyncCANcoder when the steer motor is not
     * Pro-licensed, the device will automatically fall back to RemoteCANcoder and
     * report a UsingProFeatureOnUnlicensedDevice status code.
     */
    public SteerFeedbackType FeedbackSource = SteerFeedbackType.FusedCANcoder;
    /**
     * The initial configs used to configure the drive motor of the swerve module.
     * The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * The list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MotorOutputConfigs#NeutralMode} (Brake mode, overwritten with
     *        {@link SwerveDrivetrain#configNeutralMode})
     *   <li> {@link MotorOutputConfigs#Inverted} ({@link
     *        SwerveModuleConstants#DriveMotorInverted})
     *   <li> {@link Slot0Configs} ({@link #DriveMotorGains})
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimit} / {@link
     *        TorqueCurrentConfigs#PeakForwardTorqueCurrent} / {@link
     *        TorqueCurrentConfigs#PeakReverseTorqueCurrent} ({@link #SlipCurrent})
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimitEnable} (Enabled)
     *   <li> {@link FeedbackConfigs#RotorToSensorRatio} / {@link
     *        FeedbackConfigs#SensorToMechanismRatio} (1.0)
     * </ul>
     * 
     */
    public DriveMotorConfigsT DriveMotorInitialConfigs = null;
    /**
     * The initial configs used to configure the steer motor of the swerve module.
     * The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * The list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MotorOutputConfigs#NeutralMode} (Brake mode)
     *   <li> {@link MotorOutputConfigs#Inverted} ({@link
     *        SwerveModuleConstants#SteerMotorInverted})
     *   <li> {@link Slot0Configs} ({@link #SteerMotorGains})
     *   <li> {@link FeedbackConfigs#FeedbackRemoteSensorID} ({@link
     *        SwerveModuleConstants#EncoderId})
     *   <li> {@link FeedbackConfigs#FeedbackSensorSource} ({@link #FeedbackSource})
     *   <li> {@link FeedbackConfigs#RotorToSensorRatio} ({@link
     *        #SteerMotorGearRatio})
     *   <li> {@link FeedbackConfigs#SensorToMechanismRatio} (1.0)
     *   <li> {@link MotionMagicConfigs#MotionMagicExpo_kV} / {@link
     *        MotionMagicConfigs#MotionMagicExpo_kA} (Calculated from gear ratios)
     *   <li> {@link ClosedLoopGeneralConfigs#ContinuousWrap} (true)
     * </ul>
     * 
     */
    public SteerMotorConfigsT SteerMotorInitialConfigs = null;
    /**
     * The initial configs used to configure the azimuth encoder of the swerve
     * module. The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * For CANcoder, the list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MagnetSensorConfigs#MagnetOffset} ({@link
     *        SwerveModuleConstants#EncoderOffset})
     *   <li> {@link MagnetSensorConfigs#SensorDirection} ({@link
     *        SwerveModuleConstants#EncoderInverted})
     * </ul>
     * 
     */
    public EncoderConfigsT EncoderInitialConfigs = null;
    /**
     * Simulated azimuthal inertia.
     */
    public double SteerInertia = 0.01;
    /**
     * Simulated drive inertia.
     */
    public double DriveInertia = 0.01;
    /**
     * Simulated steer voltage required to overcome friction.
     */
    public double SteerFrictionVoltage = 0.2;
    /**
     * Simulated drive voltage required to overcome friction.
     */
    public double DriveFrictionVoltage = 0.2;
    
    /**
     * Modifies the SteerMotorId parameter and returns itself.
     * <p>
     * CAN ID of the steer motor.
     *
     * @param newSteerMotorId Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorId(int newSteerMotorId) {
        this.SteerMotorId = newSteerMotorId;
        return this;
    }
    
    /**
     * Modifies the DriveMotorId parameter and returns itself.
     * <p>
     * CAN ID of the drive motor.
     *
     * @param newDriveMotorId Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorId(int newDriveMotorId) {
        this.DriveMotorId = newDriveMotorId;
        return this;
    }
    
    /**
     * Modifies the EncoderId parameter and returns itself.
     * <p>
     * CAN ID of the absolute encoder used for azimuth.
     *
     * @param newEncoderId Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withEncoderId(int newEncoderId) {
        this.EncoderId = newEncoderId;
        return this;
    }
    
    /**
     * Modifies the EncoderOffset parameter and returns itself.
     * <p>
     * Offset of the azimuth encoder.
     *
     * @param newEncoderOffset Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withEncoderOffset(double newEncoderOffset) {
        this.EncoderOffset = newEncoderOffset;
        return this;
    }
    
    /**
     * Modifies the EncoderOffset parameter and returns itself.
     * <p>
     * Offset of the azimuth encoder.
     *
     * @param newEncoderOffset Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withEncoderOffset(Angle newEncoderOffset) {
        this.EncoderOffset = newEncoderOffset.in(Rotations);
        return this;
    }
    
    /**
     * Modifies the LocationX parameter and returns itself.
     * <p>
     * The location of this module's wheels relative to the physical center of the
     * robot in meters along the X axis of the robot.
     *
     * @param newLocationX Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withLocationX(double newLocationX) {
        this.LocationX = newLocationX;
        return this;
    }
    
    /**
     * Modifies the LocationX parameter and returns itself.
     * <p>
     * The location of this module's wheels relative to the physical center of the
     * robot in meters along the X axis of the robot.
     *
     * @param newLocationX Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withLocationX(Distance newLocationX) {
        this.LocationX = newLocationX.in(Meters);
        return this;
    }
    
    /**
     * Modifies the LocationY parameter and returns itself.
     * <p>
     * The location of this module's wheels relative to the physical center of the
     * robot in meters along the Y axis of the robot.
     *
     * @param newLocationY Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withLocationY(double newLocationY) {
        this.LocationY = newLocationY;
        return this;
    }
    
    /**
     * Modifies the LocationY parameter and returns itself.
     * <p>
     * The location of this module's wheels relative to the physical center of the
     * robot in meters along the Y axis of the robot.
     *
     * @param newLocationY Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withLocationY(Distance newLocationY) {
        this.LocationY = newLocationY.in(Meters);
        return this;
    }
    
    /**
     * Modifies the DriveMotorInverted parameter and returns itself.
     * <p>
     * True if the drive motor is inverted.
     *
     * @param newDriveMotorInverted Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorInverted(boolean newDriveMotorInverted) {
        this.DriveMotorInverted = newDriveMotorInverted;
        return this;
    }
    
    /**
     * Modifies the SteerMotorInverted parameter and returns itself.
     * <p>
     * True if the steer motor is inverted from the azimuth. The azimuth should
     * rotate counter-clockwise (as seen from the top of the robot) for a positive
     * motor output.
     *
     * @param newSteerMotorInverted Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorInverted(boolean newSteerMotorInverted) {
        this.SteerMotorInverted = newSteerMotorInverted;
        return this;
    }
    
    /**
     * Modifies the EncoderInverted parameter and returns itself.
     * <p>
     * True if the azimuth encoder is inverted from the azimuth. The encoder should
     * report a positive velocity when the azimuth rotates counter-clockwise (as
     * seen from the top of the robot).
     *
     * @param newEncoderInverted Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withEncoderInverted(boolean newEncoderInverted) {
        this.EncoderInverted = newEncoderInverted;
        return this;
    }
    
    /**
     * Modifies the DriveMotorGearRatio parameter and returns itself.
     * <p>
     * Gear ratio between the drive motor and the wheel.
     *
     * @param newDriveMotorGearRatio Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorGearRatio(double newDriveMotorGearRatio) {
        this.DriveMotorGearRatio = newDriveMotorGearRatio;
        return this;
    }
    
    /**
     * Modifies the SteerMotorGearRatio parameter and returns itself.
     * <p>
     * Gear ratio between the steer motor and the azimuth encoder. For example, the
     * SDS Mk4 has a steering ratio of 12.8.
     *
     * @param newSteerMotorGearRatio Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorGearRatio(double newSteerMotorGearRatio) {
        this.SteerMotorGearRatio = newSteerMotorGearRatio;
        return this;
    }
    
    /**
     * Modifies the CouplingGearRatio parameter and returns itself.
     * <p>
     * Coupled gear ratio between the azimuth encoder and the drive motor.
     * <p>
     * For a typical swerve module, the azimuth turn motor also drives the wheel a
     * nontrivial amount, which affects the accuracy of odometry and control. This
     * ratio represents the number of rotations of the drive motor caused by a
     * rotation of the azimuth.
     *
     * @param newCouplingGearRatio Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withCouplingGearRatio(double newCouplingGearRatio) {
        this.CouplingGearRatio = newCouplingGearRatio;
        return this;
    }
    
    /**
     * Modifies the WheelRadius parameter and returns itself.
     * <p>
     * Radius of the driving wheel in meters.
     *
     * @param newWheelRadius Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withWheelRadius(double newWheelRadius) {
        this.WheelRadius = newWheelRadius;
        return this;
    }
    
    /**
     * Modifies the WheelRadius parameter and returns itself.
     * <p>
     * Radius of the driving wheel in meters.
     *
     * @param newWheelRadius Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withWheelRadius(Distance newWheelRadius) {
        this.WheelRadius = newWheelRadius.in(Meters);
        return this;
    }
    
    /**
     * Modifies the SteerMotorGains parameter and returns itself.
     * <p>
     * The steer motor closed-loop gains.
     * <p>
     * The steer motor uses the control ouput type specified by {@link
     * #SteerMotorClosedLoopOutput} and any {@link SwerveModule.SteerRequestType}.
     * These gains operate on azimuth rotations (after the gear ratio).
     *
     * @param newSteerMotorGains Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorGains(Slot0Configs newSteerMotorGains) {
        this.SteerMotorGains = newSteerMotorGains;
        return this;
    }
    
    /**
     * Modifies the DriveMotorGains parameter and returns itself.
     * <p>
     * The drive motor closed-loop gains.
     * <p>
     * When using closed-loop control, the drive motor uses the control output type
     * specified by {@link #DriveMotorClosedLoopOutput} and any closed-loop {@link
     * SwerveModule.DriveRequestType}. These gains operate on motor rotor rotations
     * (before the gear ratio).
     *
     * @param newDriveMotorGains Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorGains(Slot0Configs newDriveMotorGains) {
        this.DriveMotorGains = newDriveMotorGains;
        return this;
    }
    
    /**
     * Modifies the SteerMotorClosedLoopOutput parameter and returns itself.
     * <p>
     * The closed-loop output type to use for the steer motors.
     *
     * @param newSteerMotorClosedLoopOutput Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorClosedLoopOutput(ClosedLoopOutputType newSteerMotorClosedLoopOutput) {
        this.SteerMotorClosedLoopOutput = newSteerMotorClosedLoopOutput;
        return this;
    }
    
    /**
     * Modifies the DriveMotorClosedLoopOutput parameter and returns itself.
     * <p>
     * The closed-loop output type to use for the drive motors.
     *
     * @param newDriveMotorClosedLoopOutput Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorClosedLoopOutput(ClosedLoopOutputType newDriveMotorClosedLoopOutput) {
        this.DriveMotorClosedLoopOutput = newDriveMotorClosedLoopOutput;
        return this;
    }
    
    /**
     * Modifies the SlipCurrent parameter and returns itself.
     * <p>
     * The maximum amount of stator current the drive motors can apply without
     * slippage.
     *
     * @param newSlipCurrent Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSlipCurrent(double newSlipCurrent) {
        this.SlipCurrent = newSlipCurrent;
        return this;
    }
    
    /**
     * Modifies the SlipCurrent parameter and returns itself.
     * <p>
     * The maximum amount of stator current the drive motors can apply without
     * slippage.
     *
     * @param newSlipCurrent Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSlipCurrent(Current newSlipCurrent) {
        this.SlipCurrent = newSlipCurrent.in(Amps);
        return this;
    }
    
    /**
     * Modifies the SpeedAt12Volts parameter and returns itself.
     * <p>
     * When using open-loop drive control, this specifies the speed at which the
     * robot travels when driven with 12 volts. This is used to approximate the
     * output for a desired velocity. If using closed loop control, this value is
     * ignored.
     *
     * @param newSpeedAt12Volts Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSpeedAt12Volts(double newSpeedAt12Volts) {
        this.SpeedAt12Volts = newSpeedAt12Volts;
        return this;
    }
    
    /**
     * Modifies the SpeedAt12Volts parameter and returns itself.
     * <p>
     * When using open-loop drive control, this specifies the speed at which the
     * robot travels when driven with 12 volts. This is used to approximate the
     * output for a desired velocity. If using closed loop control, this value is
     * ignored.
     *
     * @param newSpeedAt12Volts Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSpeedAt12Volts(LinearVelocity newSpeedAt12Volts) {
        this.SpeedAt12Volts = newSpeedAt12Volts.in(MetersPerSecond);
        return this;
    }
    
    /**
     * Modifies the DriveMotorType parameter and returns itself.
     * <p>
     * Choose the motor used for the drive motor.
     * <p>
     * If using a Talon FX, this should be set to TalonFX_Integrated. If using a
     * Talon FXS, this should be set to the motor attached to the Talon FXS.
     *
     * @param newDriveMotorType Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorType(DriveMotorArrangement newDriveMotorType) {
        this.DriveMotorType = newDriveMotorType;
        return this;
    }
    
    /**
     * Modifies the SteerMotorType parameter and returns itself.
     * <p>
     * Choose the motor used for the steer motor.
     * <p>
     * If using a Talon FX, this should be set to TalonFX_Integrated. If using a
     * Talon FXS, this should be set to the motor attached to the Talon FXS.
     *
     * @param newSteerMotorType Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorType(SteerMotorArrangement newSteerMotorType) {
        this.SteerMotorType = newSteerMotorType;
        return this;
    }
    
    /**
     * Modifies the FeedbackSource parameter and returns itself.
     * <p>
     * Choose how the feedback sensors should be configured.
     * <p>
     * If the robot does not support Pro, then this should be set to RemoteCANcoder.
     * Otherwise, users have the option to use either FusedCANcoder or SyncCANcoder
     * depending on if there is a risk that the CANcoder can fail in a way to
     * provide "good" data.
     * <p>
     * If this is set to FusedCANcoder or SyncCANcoder when the steer motor is not
     * Pro-licensed, the device will automatically fall back to RemoteCANcoder and
     * report a UsingProFeatureOnUnlicensedDevice status code.
     *
     * @param newFeedbackSource Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withFeedbackSource(SteerFeedbackType newFeedbackSource) {
        this.FeedbackSource = newFeedbackSource;
        return this;
    }
    
    /**
     * Modifies the DriveMotorInitialConfigs parameter and returns itself.
     * <p>
     * The initial configs used to configure the drive motor of the swerve module.
     * The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * The list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MotorOutputConfigs#NeutralMode} (Brake mode, overwritten with
     *        {@link SwerveDrivetrain#configNeutralMode})
     *   <li> {@link MotorOutputConfigs#Inverted} ({@link
     *        SwerveModuleConstants#DriveMotorInverted})
     *   <li> {@link Slot0Configs} ({@link #DriveMotorGains})
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimit} / {@link
     *        TorqueCurrentConfigs#PeakForwardTorqueCurrent} / {@link
     *        TorqueCurrentConfigs#PeakReverseTorqueCurrent} ({@link #SlipCurrent})
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimitEnable} (Enabled)
     *   <li> {@link FeedbackConfigs#RotorToSensorRatio} / {@link
     *        FeedbackConfigs#SensorToMechanismRatio} (1.0)
     * </ul>
     * 
     *
     * @param newDriveMotorInitialConfigs Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorInitialConfigs(DriveMotorConfigsT newDriveMotorInitialConfigs) {
        this.DriveMotorInitialConfigs = newDriveMotorInitialConfigs;
        return this;
    }
    
    /**
     * Modifies the SteerMotorInitialConfigs parameter and returns itself.
     * <p>
     * The initial configs used to configure the steer motor of the swerve module.
     * The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * The list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MotorOutputConfigs#NeutralMode} (Brake mode)
     *   <li> {@link MotorOutputConfigs#Inverted} ({@link
     *        SwerveModuleConstants#SteerMotorInverted})
     *   <li> {@link Slot0Configs} ({@link #SteerMotorGains})
     *   <li> {@link FeedbackConfigs#FeedbackRemoteSensorID} ({@link
     *        SwerveModuleConstants#EncoderId})
     *   <li> {@link FeedbackConfigs#FeedbackSensorSource} ({@link #FeedbackSource})
     *   <li> {@link FeedbackConfigs#RotorToSensorRatio} ({@link
     *        #SteerMotorGearRatio})
     *   <li> {@link FeedbackConfigs#SensorToMechanismRatio} (1.0)
     *   <li> {@link MotionMagicConfigs#MotionMagicExpo_kV} / {@link
     *        MotionMagicConfigs#MotionMagicExpo_kA} (Calculated from gear ratios)
     *   <li> {@link ClosedLoopGeneralConfigs#ContinuousWrap} (true)
     * </ul>
     * 
     *
     * @param newSteerMotorInitialConfigs Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorInitialConfigs(SteerMotorConfigsT newSteerMotorInitialConfigs) {
        this.SteerMotorInitialConfigs = newSteerMotorInitialConfigs;
        return this;
    }
    
    /**
     * Modifies the EncoderInitialConfigs parameter and returns itself.
     * <p>
     * The initial configs used to configure the azimuth encoder of the swerve
     * module. The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * For CANcoder, the list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MagnetSensorConfigs#MagnetOffset} ({@link
     *        SwerveModuleConstants#EncoderOffset})
     *   <li> {@link MagnetSensorConfigs#SensorDirection} ({@link
     *        SwerveModuleConstants#EncoderInverted})
     * </ul>
     * 
     *
     * @param newEncoderInitialConfigs Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withEncoderInitialConfigs(EncoderConfigsT newEncoderInitialConfigs) {
        this.EncoderInitialConfigs = newEncoderInitialConfigs;
        return this;
    }
    
    /**
     * Modifies the SteerInertia parameter and returns itself.
     * <p>
     * Simulated azimuthal inertia.
     *
     * @param newSteerInertia Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerInertia(double newSteerInertia) {
        this.SteerInertia = newSteerInertia;
        return this;
    }
    
    /**
     * Modifies the SteerInertia parameter and returns itself.
     * <p>
     * Simulated azimuthal inertia.
     *
     * @param newSteerInertia Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerInertia(MomentOfInertia newSteerInertia) {
        this.SteerInertia = newSteerInertia.in(KilogramSquareMeters);
        return this;
    }
    
    /**
     * Modifies the DriveInertia parameter and returns itself.
     * <p>
     * Simulated drive inertia.
     *
     * @param newDriveInertia Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveInertia(double newDriveInertia) {
        this.DriveInertia = newDriveInertia;
        return this;
    }
    
    /**
     * Modifies the DriveInertia parameter and returns itself.
     * <p>
     * Simulated drive inertia.
     *
     * @param newDriveInertia Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveInertia(MomentOfInertia newDriveInertia) {
        this.DriveInertia = newDriveInertia.in(KilogramSquareMeters);
        return this;
    }
    
    /**
     * Modifies the SteerFrictionVoltage parameter and returns itself.
     * <p>
     * Simulated steer voltage required to overcome friction.
     *
     * @param newSteerFrictionVoltage Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerFrictionVoltage(double newSteerFrictionVoltage) {
        this.SteerFrictionVoltage = newSteerFrictionVoltage;
        return this;
    }
    
    /**
     * Modifies the SteerFrictionVoltage parameter and returns itself.
     * <p>
     * Simulated steer voltage required to overcome friction.
     *
     * @param newSteerFrictionVoltage Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerFrictionVoltage(Voltage newSteerFrictionVoltage) {
        this.SteerFrictionVoltage = newSteerFrictionVoltage.in(Volts);
        return this;
    }
    
    /**
     * Modifies the DriveFrictionVoltage parameter and returns itself.
     * <p>
     * Simulated drive voltage required to overcome friction.
     *
     * @param newDriveFrictionVoltage Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveFrictionVoltage(double newDriveFrictionVoltage) {
        this.DriveFrictionVoltage = newDriveFrictionVoltage;
        return this;
    }
    
    /**
     * Modifies the DriveFrictionVoltage parameter and returns itself.
     * <p>
     * Simulated drive voltage required to overcome friction.
     *
     * @param newDriveFrictionVoltage Parameter to modify
     * @return this object
     */
    public SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveFrictionVoltage(Voltage newDriveFrictionVoltage) {
        this.DriveFrictionVoltage = newDriveFrictionVoltage.in(Volts);
        return this;
    }
    
    static long createNativeInstance(SwerveModuleConstants<?, ?, ?>[] constantsArr) {
        final long retval = SwerveJNI.JNI_CreateModuleConstantsArr(constantsArr.length);
        for (int i = 0; i < constantsArr.length; ++i) {
            final var constants = constantsArr[i];
            SwerveJNI.JNI_SetModuleConstants(
                retval, i,
                constants.SteerMotorId,
                constants.DriveMotorId,
                constants.EncoderId,
                constants.EncoderOffset,
                constants.LocationX,
                constants.LocationY,
                constants.DriveMotorInverted,
                constants.SteerMotorInverted,
                constants.EncoderInverted,
                constants.DriveMotorGearRatio,
                constants.SteerMotorGearRatio,
                constants.CouplingGearRatio,
                constants.WheelRadius,
                constants.SteerMotorClosedLoopOutput.value,
                constants.DriveMotorClosedLoopOutput.value,
                constants.SlipCurrent,
                constants.SpeedAt12Volts,
                constants.DriveMotorType.value,
                constants.SteerMotorType.value,
                constants.FeedbackSource.value,
                constants.SteerInertia,
                constants.DriveInertia,
                constants.SteerFrictionVoltage,
                constants.DriveFrictionVoltage
            );
        }
        return retval;
    }
}
