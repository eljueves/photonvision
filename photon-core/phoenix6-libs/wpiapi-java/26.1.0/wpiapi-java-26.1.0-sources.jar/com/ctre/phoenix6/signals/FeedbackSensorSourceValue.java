/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Choose what sensor source is reported via API and used by closed-loop and
 * limit features.  The default is RotorSensor, which uses the internal rotor
 * sensor in the Talon.
 * <p>
 * Choose Remote* to use another sensor on the same CAN bus (this also requires
 * setting FeedbackRemoteSensorID).  Talon will update its position and velocity
 * whenever the remote sensor publishes its information on CAN bus, and the
 * Talon internal rotor will not be used.
 * <p>
 * Choose Fused* (requires Phoenix Pro) and Talon will fuse another sensor's
 * information with the internal rotor, which provides the best possible
 * position and velocity for accuracy and bandwidth (this also requires setting
 * FeedbackRemoteSensorID).  This was developed for applications such as
 * swerve-azimuth.
 * <p>
 * Choose Sync* (requires Phoenix Pro) and Talon will synchronize its internal
 * rotor position against another sensor, then continue to use the rotor sensor
 * for closed loop control (this also requires setting FeedbackRemoteSensorID). 
 * The Talon will report if its internal position differs significantly from the
 * reported remote sensor position.  This was developed for mechanisms where
 * there is a risk of the sensor failing in such a way that it reports a
 * position that does not match the mechanism, such as the sensor mounting
 * assembly breaking off.
 * <p>
 * Choose RemotePigeon2Yaw, RemotePigeon2Pitch, and RemotePigeon2Roll to use
 * another Pigeon2 on the same CAN bus (this also requires setting
 * FeedbackRemoteSensorID).  Talon will update its position to match the
 * selected value whenever Pigeon2 publishes its information on CAN bus. Note
 * that the Talon position will be in rotations and not degrees.
 * <p>
 * Note: When the feedback source is changed to Fused* or Sync*, the Talon needs
 * a period of time to fuse before sensor-based (soft-limit, closed loop, etc.)
 * features are used. This period of time is determined by the update frequency
 * of the remote sensor's Position signal.
 */
public enum FeedbackSensorSourceValue
{
    /**
     * Use the internal rotor sensor in the Talon.
     */
    RotorSensor(0),
    /**
     * Use another CANcoder on the same CAN bus (this also requires setting
     * FeedbackRemoteSensorID).  Talon will update its position and velocity
     * whenever CANcoder publishes its information on CAN bus, and the Talon
     * internal rotor will not be used.
     */
    RemoteCANcoder(1),
    /**
     * Use another Pigeon2 on the same CAN bus (this also requires setting
     * FeedbackRemoteSensorID).  Talon will update its position to match the Pigeon2
     * yaw whenever Pigeon2 publishes its information on CAN bus. Note that the
     * Talon position will be in rotations and not degrees.
     */
    RemotePigeon2Yaw(2),
    /**
     * Use another Pigeon2 on the same CAN bus (this also requires setting
     * FeedbackRemoteSensorID).  Talon will update its position to match the Pigeon2
     * pitch whenever Pigeon2 publishes its information on CAN bus. Note that the
     * Talon position will be in rotations and not degrees.
     */
    RemotePigeon2Pitch(3),
    /**
     * Use another Pigeon2 on the same CAN bus (this also requires setting
     * FeedbackRemoteSensorID).  Talon will update its position to match the Pigeon2
     * roll whenever Pigeon2 publishes its information on CAN bus. Note that the
     * Talon position will be in rotations and not degrees.
     */
    RemotePigeon2Roll(4),
    /**
     * Requires Phoenix Pro; Talon will fuse another CANcoder's information with the
     * internal rotor, which provides the best possible position and velocity for
     * accuracy and bandwidth (this also requires setting FeedbackRemoteSensorID). 
     * FusedCANcoder was developed for applications such as swerve-azimuth.
     */
    FusedCANcoder(5),
    /**
     * Requires Phoenix Pro; Talon will synchronize its internal rotor position
     * against another CANcoder, then continue to use the rotor sensor for closed
     * loop control (this also requires setting FeedbackRemoteSensorID).  The Talon
     * will report if its internal position differs significantly from the reported
     * CANcoder position.  SyncCANcoder was developed for mechanisms where there is
     * a risk of the CANcoder failing in such a way that it reports a position that
     * does not match the mechanism, such as the sensor mounting assembly breaking
     * off.
     */
    SyncCANcoder(6),
    /**
     * Use a pulse-width encoder remotely attached to the Sensor Input 1 (S1IN) on
     * the CTR Electronics' CANdi™ (this also requires setting
     * FeedbackRemoteSensorID). Talon will update its position and velocity whenever
     * the CTR Electronics' CANdi™ publishes its information on CAN bus, and the
     * Talon internal rotor will not be used.
     */
    RemoteCANdiPWM1(9),
    /**
     * Use a pulse-width encoder remotely attached to the Sensor Input 2 (S2IN) on
     * the CTR Electronics' CANdi™ (this also requires setting
     * FeedbackRemoteSensorID). Talon will update its position and velocity whenever
     * the CTR Electronics' CANdi™ publishes its information on CAN bus, and the
     * Talon internal rotor will not be used.
     */
    RemoteCANdiPWM2(10),
    /**
     * Use a quadrature encoder remotely attached to the two Sensor Inputs on the
     * CTR Electronics' CANdi™ (this also requires setting FeedbackRemoteSensorID).
     * Talon will update its position and velocity whenever the CTR Electronics'
     * CANdi™ publishes its information on CAN bus, and the Talon internal rotor
     * will not be used.
     */
    RemoteCANdiQuadrature(11),
    /**
     * Requires Phoenix Pro; Talon will fuse a pulse-width encoder remotely attached
     * to the Sensor Input 1 (S1IN) on the CTR Electronics' CANdi™, which provides
     * the best possible position and velocity for accuracy and bandwidth (this also
     * requires setting FeedbackRemoteSensorID).  FusedCANdi was developed for
     * applications such as swerve-azimuth.
     */
    FusedCANdiPWM1(12),
    /**
     * Requires Phoenix Pro; Talon will fuse a pulse-width encoder remotely attached
     * to the Sensor Input 2 (S2IN) on the CTR Electronics' CANdi™, which provides
     * the best possible position and velocity for accuracy and bandwidth (this also
     * requires setting FeedbackRemoteSensorID).  FusedCANdi was developed for
     * applications such as swerve-azimuth.
     */
    FusedCANdiPWM2(13),
    /**
     * Requires Phoenix Pro; Talon will fuse a qaudrature encoder remotely attached
     * to the two Sensor Inputs on the CTR Electronics' CANdi™. This provides
     * velocity and relative position measurements. This also requires setting
     * FeedbackRemoteSensorID.
     */
    FusedCANdiQuadrature(14),
    /**
     * Requires Phoenix Pro; Talon will synchronize its internal rotor position
     * against the pulse-width encoder attached to Sensor Input 1 (S1IN), then
     * continue to use the rotor sensor for closed loop control (this also requires
     * setting FeedbackRemoteSensorID).  The Talon will report if its internal
     * position differs significantly from the reported PWM position.  SyncCANdi was
     * developed for mechanisms where there is a risk of the CTR Electronics' CANdi™
     * failing in such a way that it reports a position that does not match the
     * mechanism, such as the sensor mounting assembly breaking off.
     */
    SyncCANdiPWM1(15),
    /**
     * Requires Phoenix Pro; Talon will synchronize its internal rotor position
     * against the pulse-width encoder attached to Sensor Input 1 (S1IN), then
     * continue to use the rotor sensor for closed loop control (this also requires
     * setting FeedbackRemoteSensorID).  The Talon will report if its internal
     * position differs significantly from the reported PWM position.  SyncCANdi was
     * developed for mechanisms where there is a risk of the CTR Electronics' CANdi™
     * failing in such a way that it reports a position that does not match the
     * mechanism, such as the sensor mounting assembly breaking off.
     */
    SyncCANdiPWM2(16),;

    public final int value;

    FeedbackSensorSourceValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, FeedbackSensorSourceValue> _map = null;
    static
    {
        _map = new HashMap<Integer, FeedbackSensorSourceValue>();
        for (FeedbackSensorSourceValue type : FeedbackSensorSourceValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets FeedbackSensorSourceValue from specified value
     * @param value Value of FeedbackSensorSourceValue
     * @return FeedbackSensorSourceValue of specified value
     */
    public static FeedbackSensorSourceValue valueOf(int value)
    {
        FeedbackSensorSourceValue retval = _map.get(value);
        if (retval != null) return retval;
        return FeedbackSensorSourceValue.values()[0];
    }
}
