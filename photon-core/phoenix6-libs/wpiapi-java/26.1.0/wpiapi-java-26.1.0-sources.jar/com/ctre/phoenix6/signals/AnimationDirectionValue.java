/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Direction of the animation.
 */
public enum AnimationDirectionValue
{
    /**
     * The animation starts at the specified LED start index and moves towards the
     * LED end index.
     */
    Forward(0),
    /**
     * The animation starts at the specified LED end index and moves towards the LED
     * start index.
     */
    Backward(1),;

    public final int value;

    AnimationDirectionValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, AnimationDirectionValue> _map = null;
    static
    {
        _map = new HashMap<Integer, AnimationDirectionValue>();
        for (AnimationDirectionValue type : AnimationDirectionValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets AnimationDirectionValue from specified value
     * @param value Value of AnimationDirectionValue
     * @return AnimationDirectionValue of specified value
     */
    public static AnimationDirectionValue valueOf(int value)
    {
        AnimationDirectionValue retval = _map.get(value);
        if (retval != null) return retval;
        return AnimationDirectionValue.values()[0];
    }
}
