/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs related to using a custom brushless motor that is not
 * formally supported by Talon FXS.
 * <p>
 * Configs are only used when Motor Arrangement is set to Custom
 * Brushless Motor.  Note this feature will only work device is not
 * FRC-Locked.
 * <p>
 * Users are responsible for ensuring that these configs are accurate
 * to the motor. CTR Electronics is not responsible for damage caused
 * by an incorrect custom motor configuration.
 */
public class CustomBrushlessMotorConfigs implements ParentConfiguration, Cloneable {
    /**
     * Kv constant of the connected custom brushless motor. This can
     * usually be determined by consulting the motor manufacturer data
     * sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 2047
     *   <li> <b>Default Value:</b> 500
     *   <li> <b>Units:</b> RPM/V
     * </ul>
     */
    public double MotorKv = 500;
    /**
     * Number of pole pairs in the connected custom brushless motor
     * (number of poles divided by 2). This can usually be determined by
     * consulting the motor manufacturer data sheet.
     * <p>
     * For example, if motor has ten poles, then specify five pole pairs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 1
     *   <li> <b>Maximum Value:</b> 8
     *   <li> <b>Default Value:</b> 1
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int PolePairCount = 1;
    /**
     * Expected Hall Value when motor controller applies A+ and B-.
     * <p>
     * Hall Values are little endian [CBA].  For example, if halls report:
     * HA=0, HB=0, HC=1, then the Hall Value is 4.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 6
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int HallDuringAB = 0;
    /**
     * Expected Hall Value when motor controller applies A+ and C-.
     * <p>
     * Hall Values are little endian [CBA].  For example, if halls report:
     * HA=0, HB=0, HC=1, then the Hall Value is 4.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 6
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int HallDuringAC = 0;
    /**
     * Optional configuration to correct clockwise versus
     * counter-clockwise rotor spin.
     * <p>
     * Depending on the mechanical design of the motor, rotor may spin
     * clockwise during positive output when Inverted is set to
     * counterclockwise.  This configuration can be toggled so that the
     * rest of the API is canonically true.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean HallCCWSelect = false;
    /**
     * Determines expected Hall direction for rotor velocity signage.
     * <p>
     * If RotorVelocity is signed opposite of applied voltage, flip this
     * configuration.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean HallDirection = false;
    
    /**
     * Modifies this configuration's MotorKv parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Kv constant of the connected custom brushless motor. This can
     * usually be determined by consulting the motor manufacturer data
     * sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 2047
     *   <li> <b>Default Value:</b> 500
     *   <li> <b>Units:</b> RPM/V
     * </ul>
     *
     * @param newMotorKv Parameter to modify
     * @return Itself
     */
    public final CustomBrushlessMotorConfigs withMotorKv(double newMotorKv)
    {
        MotorKv = newMotorKv;
        return this;
    }
    
    /**
     * Modifies this configuration's MotorKv parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Kv constant of the connected custom brushless motor. This can
     * usually be determined by consulting the motor manufacturer data
     * sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 2047
     *   <li> <b>Default Value:</b> 500
     *   <li> <b>Units:</b> RPM/V
     * </ul>
     *
     * @param newMotorKv Parameter to modify
     * @return Itself
     */
    public final CustomBrushlessMotorConfigs withMotorKv(Per<AngularVelocityUnit, VoltageUnit> newMotorKv)
    {
        MotorKv = newMotorKv.in(RPM.per(Volt));
        return this;
    }
    
    /**
     * Helper method to get this configuration's MotorKv parameter converted
     * to a unit type. If not using the Java units library, {@link #MotorKv}
     * can be accessed directly instead.
     * <p>
     * Kv constant of the connected custom brushless motor. This can
     * usually be determined by consulting the motor manufacturer data
     * sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 2047
     *   <li> <b>Default Value:</b> 500
     *   <li> <b>Units:</b> RPM/V
     * </ul>
     *
     * @return MotorKv
     */
    public final Per<AngularVelocityUnit, VoltageUnit> getMotorKvMeasure()
    {
        return RPM.per(Volt).ofNative(MotorKv);
    }
    
    /**
     * Modifies this configuration's PolePairCount parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Number of pole pairs in the connected custom brushless motor
     * (number of poles divided by 2). This can usually be determined by
     * consulting the motor manufacturer data sheet.
     * <p>
     * For example, if motor has ten poles, then specify five pole pairs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 1
     *   <li> <b>Maximum Value:</b> 8
     *   <li> <b>Default Value:</b> 1
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newPolePairCount Parameter to modify
     * @return Itself
     */
    public final CustomBrushlessMotorConfigs withPolePairCount(int newPolePairCount)
    {
        PolePairCount = newPolePairCount;
        return this;
    }
    
    /**
     * Modifies this configuration's HallDuringAB parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Expected Hall Value when motor controller applies A+ and B-.
     * <p>
     * Hall Values are little endian [CBA].  For example, if halls report:
     * HA=0, HB=0, HC=1, then the Hall Value is 4.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 6
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newHallDuringAB Parameter to modify
     * @return Itself
     */
    public final CustomBrushlessMotorConfigs withHallDuringAB(int newHallDuringAB)
    {
        HallDuringAB = newHallDuringAB;
        return this;
    }
    
    /**
     * Modifies this configuration's HallDuringAC parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Expected Hall Value when motor controller applies A+ and C-.
     * <p>
     * Hall Values are little endian [CBA].  For example, if halls report:
     * HA=0, HB=0, HC=1, then the Hall Value is 4.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 6
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newHallDuringAC Parameter to modify
     * @return Itself
     */
    public final CustomBrushlessMotorConfigs withHallDuringAC(int newHallDuringAC)
    {
        HallDuringAC = newHallDuringAC;
        return this;
    }
    
    /**
     * Modifies this configuration's HallCCWSelect parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Optional configuration to correct clockwise versus
     * counter-clockwise rotor spin.
     * <p>
     * Depending on the mechanical design of the motor, rotor may spin
     * clockwise during positive output when Inverted is set to
     * counterclockwise.  This configuration can be toggled so that the
     * rest of the API is canonically true.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newHallCCWSelect Parameter to modify
     * @return Itself
     */
    public final CustomBrushlessMotorConfigs withHallCCWSelect(boolean newHallCCWSelect)
    {
        HallCCWSelect = newHallCCWSelect;
        return this;
    }
    
    /**
     * Modifies this configuration's HallDirection parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Determines expected Hall direction for rotor velocity signage.
     * <p>
     * If RotorVelocity is signed opposite of applied voltage, flip this
     * configuration.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newHallDirection Parameter to modify
     * @return Itself
     */
    public final CustomBrushlessMotorConfigs withHallDirection(boolean newHallDirection)
    {
        HallDirection = newHallDirection;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: CustomBrushlessMotor\n";
        ss += "    MotorKv: " + MotorKv + " RPM/V" + "\n";
        ss += "    PolePairCount: " + PolePairCount + "\n";
        ss += "    HallDuringAB: " + HallDuringAB + "\n";
        ss += "    HallDuringAC: " + HallDuringAC + "\n";
        ss += "    HallCCWSelect: " + HallCCWSelect + "\n";
        ss += "    HallDirection: " + HallDirection + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_CustomMot_Kv.value, MotorKv);
        ss += ConfigJNI.Serializeint(SpnValue.Config_CustomMot_NumPolePairs.value, PolePairCount);
        ss += ConfigJNI.Serializeint(SpnValue.Config_CustomMot_Hall_AB.value, HallDuringAB);
        ss += ConfigJNI.Serializeint(SpnValue.Config_CustomMot_Hall_AC.value, HallDuringAC);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_CustomMot_Hall_CCW_Select.value, HallCCWSelect);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_CustomMot_Hall_Direction.value, HallDirection);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        MotorKv = ConfigJNI.Deserializedouble(SpnValue.Config_CustomMot_Kv.value, to_deserialize);
        PolePairCount = ConfigJNI.Deserializeint(SpnValue.Config_CustomMot_NumPolePairs.value, to_deserialize);
        HallDuringAB = ConfigJNI.Deserializeint(SpnValue.Config_CustomMot_Hall_AB.value, to_deserialize);
        HallDuringAC = ConfigJNI.Deserializeint(SpnValue.Config_CustomMot_Hall_AC.value, to_deserialize);
        HallCCWSelect = ConfigJNI.Deserializeboolean(SpnValue.Config_CustomMot_Hall_CCW_Select.value, to_deserialize);
        HallDirection = ConfigJNI.Deserializeboolean(SpnValue.Config_CustomMot_Hall_Direction.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public CustomBrushlessMotorConfigs clone() {
        try {
            return (CustomBrushlessMotorConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

