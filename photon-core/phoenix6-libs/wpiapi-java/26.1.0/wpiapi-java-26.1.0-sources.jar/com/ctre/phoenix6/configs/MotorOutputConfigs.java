/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs that directly affect motor output.
 * <p>
 * Includes motor invert, neutral mode, and other features related to
 * motor output.
 */
public class MotorOutputConfigs implements ParentConfiguration, Cloneable {
    /**
     * Invert state of the device as seen from the front of the motor.
     * 
     */
    public InvertedValue Inverted = InvertedValue.CounterClockwise_Positive;
    /**
     * The state of the motor controller bridge when output is neutral or
     * disabled.
     * 
     */
    public NeutralModeValue NeutralMode = NeutralModeValue.Coast;
    /**
     * Configures the output deadband duty cycle during duty cycle and
     * voltage based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 0.25
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> fractional
     * </ul>
     */
    public double DutyCycleNeutralDeadband = 0;
    /**
     * Maximum (forward) output during duty cycle based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 1
     *   <li> <b>Units:</b> fractional
     * </ul>
     */
    public double PeakForwardDutyCycle = 1;
    /**
     * Minimum (reverse) output during duty cycle based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> -1
     *   <li> <b>Units:</b> fractional
     * </ul>
     */
    public double PeakReverseDutyCycle = -1;
    /**
     * When a control request UseTimesync is enabled, this determines the
     * time-sychronized frequency at which control requests are applied.
     * <p>
     * The application of the control request will be delayed until the
     * next timesync boundary at the frequency defined by this config.
     * When set to 0 Hz, timesync will never be used for control requests,
     * regardless of the value of UseTimesync.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 50
     *   <li> <b>Maximum Value:</b> 500
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> Hz
     * </ul>
     */
    public double ControlTimesyncFreqHz = 0;
    
    /**
     * Modifies this configuration's Inverted parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Invert state of the device as seen from the front of the motor.
     * 
     *
     * @param newInverted Parameter to modify
     * @return Itself
     */
    public final MotorOutputConfigs withInverted(InvertedValue newInverted)
    {
        Inverted = newInverted;
        return this;
    }
    
    /**
     * Modifies this configuration's NeutralMode parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The state of the motor controller bridge when output is neutral or
     * disabled.
     * 
     *
     * @param newNeutralMode Parameter to modify
     * @return Itself
     */
    public final MotorOutputConfigs withNeutralMode(NeutralModeValue newNeutralMode)
    {
        NeutralMode = newNeutralMode;
        return this;
    }
    
    /**
     * Modifies this configuration's DutyCycleNeutralDeadband parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configures the output deadband duty cycle during duty cycle and
     * voltage based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 0.25
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> fractional
     * </ul>
     *
     * @param newDutyCycleNeutralDeadband Parameter to modify
     * @return Itself
     */
    public final MotorOutputConfigs withDutyCycleNeutralDeadband(double newDutyCycleNeutralDeadband)
    {
        DutyCycleNeutralDeadband = newDutyCycleNeutralDeadband;
        return this;
    }
    
    /**
     * Modifies this configuration's PeakForwardDutyCycle parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Maximum (forward) output during duty cycle based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 1
     *   <li> <b>Units:</b> fractional
     * </ul>
     *
     * @param newPeakForwardDutyCycle Parameter to modify
     * @return Itself
     */
    public final MotorOutputConfigs withPeakForwardDutyCycle(double newPeakForwardDutyCycle)
    {
        PeakForwardDutyCycle = newPeakForwardDutyCycle;
        return this;
    }
    
    /**
     * Modifies this configuration's PeakReverseDutyCycle parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Minimum (reverse) output during duty cycle based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> -1
     *   <li> <b>Units:</b> fractional
     * </ul>
     *
     * @param newPeakReverseDutyCycle Parameter to modify
     * @return Itself
     */
    public final MotorOutputConfigs withPeakReverseDutyCycle(double newPeakReverseDutyCycle)
    {
        PeakReverseDutyCycle = newPeakReverseDutyCycle;
        return this;
    }
    
    /**
     * Modifies this configuration's ControlTimesyncFreqHz parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * When a control request UseTimesync is enabled, this determines the
     * time-sychronized frequency at which control requests are applied.
     * <p>
     * The application of the control request will be delayed until the
     * next timesync boundary at the frequency defined by this config.
     * When set to 0 Hz, timesync will never be used for control requests,
     * regardless of the value of UseTimesync.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 50
     *   <li> <b>Maximum Value:</b> 500
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> Hz
     * </ul>
     *
     * @param newControlTimesyncFreqHz Parameter to modify
     * @return Itself
     */
    public final MotorOutputConfigs withControlTimesyncFreqHz(double newControlTimesyncFreqHz)
    {
        ControlTimesyncFreqHz = newControlTimesyncFreqHz;
        return this;
    }
    
    /**
     * Modifies this configuration's ControlTimesyncFreqHz parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * When a control request UseTimesync is enabled, this determines the
     * time-sychronized frequency at which control requests are applied.
     * <p>
     * The application of the control request will be delayed until the
     * next timesync boundary at the frequency defined by this config.
     * When set to 0 Hz, timesync will never be used for control requests,
     * regardless of the value of UseTimesync.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 50
     *   <li> <b>Maximum Value:</b> 500
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> Hz
     * </ul>
     *
     * @param newControlTimesyncFreqHz Parameter to modify
     * @return Itself
     */
    public final MotorOutputConfigs withControlTimesyncFreqHz(Frequency newControlTimesyncFreqHz)
    {
        ControlTimesyncFreqHz = newControlTimesyncFreqHz.in(Hertz);
        return this;
    }
    
    /**
     * Helper method to get this configuration's ControlTimesyncFreqHz parameter converted
     * to a unit type. If not using the Java units library, {@link #ControlTimesyncFreqHz}
     * can be accessed directly instead.
     * <p>
     * When a control request UseTimesync is enabled, this determines the
     * time-sychronized frequency at which control requests are applied.
     * <p>
     * The application of the control request will be delayed until the
     * next timesync boundary at the frequency defined by this config.
     * When set to 0 Hz, timesync will never be used for control requests,
     * regardless of the value of UseTimesync.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 50
     *   <li> <b>Maximum Value:</b> 500
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> Hz
     * </ul>
     *
     * @return ControlTimesyncFreqHz
     */
    public final Frequency getControlTimesyncFreqHzMeasure()
    {
        return Hertz.of(ControlTimesyncFreqHz);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: MotorOutput\n";
        ss += "    Inverted: " + Inverted + "\n";
        ss += "    NeutralMode: " + NeutralMode + "\n";
        ss += "    DutyCycleNeutralDeadband: " + DutyCycleNeutralDeadband + " fractional" + "\n";
        ss += "    PeakForwardDutyCycle: " + PeakForwardDutyCycle + " fractional" + "\n";
        ss += "    PeakReverseDutyCycle: " + PeakReverseDutyCycle + " fractional" + "\n";
        ss += "    ControlTimesyncFreqHz: " + ControlTimesyncFreqHz + " Hz" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeint(SpnValue.Config_Inverted.value, Inverted.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_NeutralMode.value, NeutralMode.value);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_DutyCycleNeutralDB.value, DutyCycleNeutralDeadband);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_PeakForwardDC.value, PeakForwardDutyCycle);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_PeakReverseDC.value, PeakReverseDutyCycle);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_ControlTimesyncFreq.value, ControlTimesyncFreqHz);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        Inverted = InvertedValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_Inverted.value, to_deserialize));
        NeutralMode = NeutralModeValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_NeutralMode.value, to_deserialize));
        DutyCycleNeutralDeadband = ConfigJNI.Deserializedouble(SpnValue.Config_DutyCycleNeutralDB.value, to_deserialize);
        PeakForwardDutyCycle = ConfigJNI.Deserializedouble(SpnValue.Config_PeakForwardDC.value, to_deserialize);
        PeakReverseDutyCycle = ConfigJNI.Deserializedouble(SpnValue.Config_PeakReverseDC.value, to_deserialize);
        ControlTimesyncFreqHz = ConfigJNI.Deserializedouble(SpnValue.Config_ControlTimesyncFreq.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public MotorOutputConfigs clone() {
        try {
            return (MotorOutputConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

