/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;

/**
 * Class for CTR Electronics' CANdi™ branded device, a device that integrates
 * digital signals into the existing CAN bus network.
 *
 * This handles applying and refreshing the configurations for the {@link com.ctre.phoenix6.hardware.CANdi}.
 */
public class CANdiConfiguration implements ParentConfiguration, Cloneable {
    /**
     * True if we should factory default newer unsupported configs,
     * false to leave newer unsupported configs alone.
     * <p>
     * This flag addresses a corner case where the device may have
     * firmware with newer configs that didn't exist when this
     * version of the API was built. If this occurs and this
     * flag is true, unsupported new configs will be factory
     * defaulted to avoid unexpected behavior.
     * <p>
     * This is also the behavior in Phoenix 5, so this flag
     * is defaulted to true to match.
     */
    public boolean FutureProofConfigs = true;

    
    /**
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     */
    public CustomParamsConfigs CustomParams = new CustomParamsConfigs();
    
    /**
     * Configs related to the CANdi™ branded device's digital I/O settings
     * <p>
     * Contains float-state settings and when to assert the S1/S2 inputs.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link DigitalInputsConfigs#S1FloatState}
     *   <li> {@link DigitalInputsConfigs#S2FloatState}
     *   <li> {@link DigitalInputsConfigs#S1CloseState}
     *   <li> {@link DigitalInputsConfigs#S2CloseState}
     * </ul>
     * 
     */
    public DigitalInputsConfigs DigitalInputs = new DigitalInputsConfigs();
    
    /**
     * Configs related to the CANdi™ branded device's quadrature interface
     * using both the S1IN and S2IN inputs
     * <p>
     * All the configs related to the quadrature interface for the CANdi™
     * branded device , including encoder edges per revolution and sensor
     * direction.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link QuadratureConfigs#QuadratureEdgesPerRotation}
     *   <li> {@link QuadratureConfigs#SensorDirection}
     * </ul>
     * 
     */
    public QuadratureConfigs Quadrature = new QuadratureConfigs();
    
    /**
     * Configs related to the CANdi™ branded device's PWM interface on the
     * Signal 1 input (S1IN)
     * <p>
     * All the configs related to the PWM interface for the CANdi™ branded
     * device on S1, including absolute sensor offset, absolute sensor
     * discontinuity point and sensor direction.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link PWM1Configs#AbsoluteSensorOffset}
     *   <li> {@link PWM1Configs#AbsoluteSensorDiscontinuityPoint}
     *   <li> {@link PWM1Configs#SensorDirection}
     * </ul>
     * 
     */
    public PWM1Configs PWM1 = new PWM1Configs();
    
    /**
     * Configs related to the CANdi™ branded device's PWM interface on the
     * Signal 2 input (S2IN)
     * <p>
     * All the configs related to the PWM interface for the CANdi™ branded
     * device on S1, including absolute sensor offset, absolute sensor
     * discontinuity point and sensor direction.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link PWM2Configs#AbsoluteSensorOffset}
     *   <li> {@link PWM2Configs#AbsoluteSensorDiscontinuityPoint}
     *   <li> {@link PWM2Configs#SensorDirection}
     * </ul>
     * 
     */
    public PWM2Configs PWM2 = new PWM2Configs();
    
    /**
     * Modifies this configuration's CustomParams parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     *
     * @param newCustomParams Parameter to modify
     * @return Itself
     */
    public final CANdiConfiguration withCustomParams(CustomParamsConfigs newCustomParams)
    {
        CustomParams = newCustomParams;
        return this;
    }
    
    /**
     * Modifies this configuration's DigitalInputs parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs related to the CANdi™ branded device's digital I/O settings
     * <p>
     * Contains float-state settings and when to assert the S1/S2 inputs.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link DigitalInputsConfigs#S1FloatState}
     *   <li> {@link DigitalInputsConfigs#S2FloatState}
     *   <li> {@link DigitalInputsConfigs#S1CloseState}
     *   <li> {@link DigitalInputsConfigs#S2CloseState}
     * </ul>
     * 
     *
     * @param newDigitalInputs Parameter to modify
     * @return Itself
     */
    public final CANdiConfiguration withDigitalInputs(DigitalInputsConfigs newDigitalInputs)
    {
        DigitalInputs = newDigitalInputs;
        return this;
    }
    
    /**
     * Modifies this configuration's Quadrature parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs related to the CANdi™ branded device's quadrature interface
     * using both the S1IN and S2IN inputs
     * <p>
     * All the configs related to the quadrature interface for the CANdi™
     * branded device , including encoder edges per revolution and sensor
     * direction.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link QuadratureConfigs#QuadratureEdgesPerRotation}
     *   <li> {@link QuadratureConfigs#SensorDirection}
     * </ul>
     * 
     *
     * @param newQuadrature Parameter to modify
     * @return Itself
     */
    public final CANdiConfiguration withQuadrature(QuadratureConfigs newQuadrature)
    {
        Quadrature = newQuadrature;
        return this;
    }
    
    /**
     * Modifies this configuration's PWM1 parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs related to the CANdi™ branded device's PWM interface on the
     * Signal 1 input (S1IN)
     * <p>
     * All the configs related to the PWM interface for the CANdi™ branded
     * device on S1, including absolute sensor offset, absolute sensor
     * discontinuity point and sensor direction.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link PWM1Configs#AbsoluteSensorOffset}
     *   <li> {@link PWM1Configs#AbsoluteSensorDiscontinuityPoint}
     *   <li> {@link PWM1Configs#SensorDirection}
     * </ul>
     * 
     *
     * @param newPWM1 Parameter to modify
     * @return Itself
     */
    public final CANdiConfiguration withPWM1(PWM1Configs newPWM1)
    {
        PWM1 = newPWM1;
        return this;
    }
    
    /**
     * Modifies this configuration's PWM2 parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs related to the CANdi™ branded device's PWM interface on the
     * Signal 2 input (S2IN)
     * <p>
     * All the configs related to the PWM interface for the CANdi™ branded
     * device on S1, including absolute sensor offset, absolute sensor
     * discontinuity point and sensor direction.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link PWM2Configs#AbsoluteSensorOffset}
     *   <li> {@link PWM2Configs#AbsoluteSensorDiscontinuityPoint}
     *   <li> {@link PWM2Configs#SensorDirection}
     * </ul>
     * 
     *
     * @param newPWM2 Parameter to modify
     * @return Itself
     */
    public final CANdiConfiguration withPWM2(PWM2Configs newPWM2)
    {
        PWM2 = newPWM2;
        return this;
    }

    @Override
    public String toString() {
        String ss = "CANdiConfiguration\n";
        ss += CustomParams.toString();
        ss += DigitalInputs.toString();
        ss += Quadrature.toString();
        ss += PWM1.toString();
        ss += PWM2.toString();
        return ss;
    }

    /**
     * Get the serialized form of this configuration.
     *
     * @return Serialized form of this config group
     */
    public final String serialize() {
        String ss = "";
        ss += CustomParams.serialize();
        ss += DigitalInputs.serialize();
        ss += Quadrature.serialize();
        ss += PWM1.serialize();
        ss += PWM2.serialize();
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration.
     *
     * @return Return code of the deserialize method
     */
    public final StatusCode deserialize(String to_deserialize) {
        StatusCode err = StatusCode.OK;
        err = CustomParams.deserialize(to_deserialize);
        err = DigitalInputs.deserialize(to_deserialize);
        err = Quadrature.deserialize(to_deserialize);
        err = PWM1.deserialize(to_deserialize);
        err = PWM2.deserialize(to_deserialize);
        return err;
    }

    @Override
    public CANdiConfiguration clone() {
        var retval = new CANdiConfiguration();
        retval.FutureProofConfigs = FutureProofConfigs;
        retval.CustomParams = CustomParams.clone();
        retval.DigitalInputs = DigitalInputs.clone();
        retval.Quadrature = Quadrature.clone();
        retval.PWM1 = PWM1.clone();
        retval.PWM2 = PWM2.clone();
        return retval;
    }
}
