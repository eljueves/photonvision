/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.jni;

import com.ctre.phoenix6.jni.CtreJniWrapper;

public class HardwareJNI extends CtreJniWrapper {
    public enum Context {
        ContextAPI(0),
        ContextDiagServer(1);

        public final int value;

        private Context(int value) {
            this.value = value;
        }
    }

    public static native int getDeviceHash(int deviceId, String model, String canbus);
}
