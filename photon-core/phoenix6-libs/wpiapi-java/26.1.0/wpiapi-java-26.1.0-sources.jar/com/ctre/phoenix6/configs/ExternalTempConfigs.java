/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs related to using an independent thermister for
 * automatically disabling a motor when a threshold has been reached.
 * <p>
 * Configs are only used when Motor Arrangement is set to Custom
 * Brushless Motor or Brushed.  Note this feature will only work
 * device is not FRC-Locked.
 * <p>
 * Users are responsible for ensuring that these configs are accurate
 * to the motor. CTR Electronics is not responsible for damage caused
 * by an incorrect custom motor configuration.
 */
public class ExternalTempConfigs implements ParentConfiguration, Cloneable {
    /**
     * Threshold for thermal faulting a custom motor.
     * <p>
     * The motor controller will fault if the connected motor thermistor
     * exceeds this value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 150
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     */
    public double ThermistorMaxTemperature = 0;
    /**
     * Beta K value for the connected NTC thermistor. This can usually be
     * determined by consulting the motor manufacturer data sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 8000
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> K
     * </ul>
     */
    public double ThermistorBeta = 0;
    /**
     * The thermistor resistance for the connected NTC thermistor as
     * measured at 25'C. This can usually be determined by consulting the
     * motor manufacturer data sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 400
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> kOhm
     * </ul>
     */
    public double ThermistorR0 = 0;
    /**
     * Whether a temperature sensor should be required for motor control.
     * This configuration is ignored in FRC environments and defaults to
     * Required.
     * 
     */
    public TempSensorRequiredValue TempSensorRequired = TempSensorRequiredValue.Required;
    
    /**
     * Modifies this configuration's ThermistorMaxTemperature parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Threshold for thermal faulting a custom motor.
     * <p>
     * The motor controller will fault if the connected motor thermistor
     * exceeds this value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 150
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     *
     * @param newThermistorMaxTemperature Parameter to modify
     * @return Itself
     */
    public final ExternalTempConfigs withThermistorMaxTemperature(double newThermistorMaxTemperature)
    {
        ThermistorMaxTemperature = newThermistorMaxTemperature;
        return this;
    }
    
    /**
     * Modifies this configuration's ThermistorMaxTemperature parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Threshold for thermal faulting a custom motor.
     * <p>
     * The motor controller will fault if the connected motor thermistor
     * exceeds this value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 150
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     *
     * @param newThermistorMaxTemperature Parameter to modify
     * @return Itself
     */
    public final ExternalTempConfigs withThermistorMaxTemperature(Temperature newThermistorMaxTemperature)
    {
        ThermistorMaxTemperature = newThermistorMaxTemperature.in(Celsius);
        return this;
    }
    
    /**
     * Helper method to get this configuration's ThermistorMaxTemperature parameter converted
     * to a unit type. If not using the Java units library, {@link #ThermistorMaxTemperature}
     * can be accessed directly instead.
     * <p>
     * Threshold for thermal faulting a custom motor.
     * <p>
     * The motor controller will fault if the connected motor thermistor
     * exceeds this value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 150
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     *
     * @return ThermistorMaxTemperature
     */
    public final Temperature getThermistorMaxTemperatureMeasure()
    {
        return Celsius.of(ThermistorMaxTemperature);
    }
    
    /**
     * Modifies this configuration's ThermistorBeta parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Beta K value for the connected NTC thermistor. This can usually be
     * determined by consulting the motor manufacturer data sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 8000
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> K
     * </ul>
     *
     * @param newThermistorBeta Parameter to modify
     * @return Itself
     */
    public final ExternalTempConfigs withThermistorBeta(double newThermistorBeta)
    {
        ThermistorBeta = newThermistorBeta;
        return this;
    }
    
    /**
     * Modifies this configuration's ThermistorBeta parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Beta K value for the connected NTC thermistor. This can usually be
     * determined by consulting the motor manufacturer data sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 8000
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> K
     * </ul>
     *
     * @param newThermistorBeta Parameter to modify
     * @return Itself
     */
    public final ExternalTempConfigs withThermistorBeta(Temperature newThermistorBeta)
    {
        ThermistorBeta = newThermistorBeta.in(Kelvin);
        return this;
    }
    
    /**
     * Helper method to get this configuration's ThermistorBeta parameter converted
     * to a unit type. If not using the Java units library, {@link #ThermistorBeta}
     * can be accessed directly instead.
     * <p>
     * Beta K value for the connected NTC thermistor. This can usually be
     * determined by consulting the motor manufacturer data sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 8000
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> K
     * </ul>
     *
     * @return ThermistorBeta
     */
    public final Temperature getThermistorBetaMeasure()
    {
        return Kelvin.of(ThermistorBeta);
    }
    
    /**
     * Modifies this configuration's ThermistorR0 parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The thermistor resistance for the connected NTC thermistor as
     * measured at 25'C. This can usually be determined by consulting the
     * motor manufacturer data sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 400
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> kOhm
     * </ul>
     *
     * @param newThermistorR0 Parameter to modify
     * @return Itself
     */
    public final ExternalTempConfigs withThermistorR0(double newThermistorR0)
    {
        ThermistorR0 = newThermistorR0;
        return this;
    }
    
    /**
     * Modifies this configuration's ThermistorR0 parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The thermistor resistance for the connected NTC thermistor as
     * measured at 25'C. This can usually be determined by consulting the
     * motor manufacturer data sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 400
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> kOhm
     * </ul>
     *
     * @param newThermistorR0 Parameter to modify
     * @return Itself
     */
    public final ExternalTempConfigs withThermistorR0(Resistance newThermistorR0)
    {
        ThermistorR0 = newThermistorR0.in(KiloOhms);
        return this;
    }
    
    /**
     * Helper method to get this configuration's ThermistorR0 parameter converted
     * to a unit type. If not using the Java units library, {@link #ThermistorR0}
     * can be accessed directly instead.
     * <p>
     * The thermistor resistance for the connected NTC thermistor as
     * measured at 25'C. This can usually be determined by consulting the
     * motor manufacturer data sheet.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 400
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> kOhm
     * </ul>
     *
     * @return ThermistorR0
     */
    public final Resistance getThermistorR0Measure()
    {
        return KiloOhms.of(ThermistorR0);
    }
    
    /**
     * Modifies this configuration's TempSensorRequired parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Whether a temperature sensor should be required for motor control.
     * This configuration is ignored in FRC environments and defaults to
     * Required.
     * 
     *
     * @param newTempSensorRequired Parameter to modify
     * @return Itself
     */
    public final ExternalTempConfigs withTempSensorRequired(TempSensorRequiredValue newTempSensorRequired)
    {
        TempSensorRequired = newTempSensorRequired;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: ExternalTemp\n";
        ss += "    ThermistorMaxTemperature: " + ThermistorMaxTemperature + " ℃" + "\n";
        ss += "    ThermistorBeta: " + ThermistorBeta + " K" + "\n";
        ss += "    ThermistorR0: " + ThermistorR0 + " kOhm" + "\n";
        ss += "    TempSensorRequired: " + TempSensorRequired + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_CustomMot_Thermistor_MaxTemp.value, ThermistorMaxTemperature);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_CustomMot_Thermistor_Beta.value, ThermistorBeta);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_CustomMot_Thermistor_R0.value, ThermistorR0);
        ss += ConfigJNI.Serializeint(SpnValue.Config_TempSensorSelection.value, TempSensorRequired.value);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        ThermistorMaxTemperature = ConfigJNI.Deserializedouble(SpnValue.Config_CustomMot_Thermistor_MaxTemp.value, to_deserialize);
        ThermistorBeta = ConfigJNI.Deserializedouble(SpnValue.Config_CustomMot_Thermistor_Beta.value, to_deserialize);
        ThermistorR0 = ConfigJNI.Deserializedouble(SpnValue.Config_CustomMot_Thermistor_R0.value, to_deserialize);
        TempSensorRequired = TempSensorRequiredValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_TempSensorSelection.value, to_deserialize));
        return  StatusCode.OK;
    }

    @Override
    public ExternalTempConfigs clone() {
        try {
            return (ExternalTempConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

