/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.wpiutils;

import edu.wpi.first.hal.HALValue;

public final class CallbackHelper {
    public static double getRawValue(HALValue value) {
        switch(value.getType()) {
        case HALValue.kDouble:
            return value.getDouble();
        case HALValue.kBoolean:
            return value.getBoolean() ? 1 : 0;
        case HALValue.kInt:
            return value.getLong();
        case HALValue.kLong:
            return value.getLong();
        case HALValue.kEnum:
            return value.getLong();
        default:
            return 0;
        }
    }
}
