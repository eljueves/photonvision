/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * State of the Signal 2 input (S2IN).
 */
public enum S2StateValue
{
    /**
     * Input is not driven high or low, it is disconnected from load.
     */
    Floating(0),
    /**
     * Input is driven low (below 0.5V).
     */
    Low(1),
    /**
     * Input is driven high (above 3V).
     */
    High(2),;

    public final int value;

    S2StateValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, S2StateValue> _map = null;
    static
    {
        _map = new HashMap<Integer, S2StateValue>();
        for (S2StateValue type : S2StateValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets S2StateValue from specified value
     * @param value Value of S2StateValue
     * @return S2StateValue of specified value
     */
    public static S2StateValue valueOf(int value)
    {
        S2StateValue retval = _map.get(value);
        if (retval != null) return retval;
        return S2StateValue.values()[0];
    }
}
