/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs related to constants used for differential control of a
 * mechanism.
 * <p>
 * Includes the differential peak outputs.
 */
public class DifferentialConstantsConfigs implements ParentConfiguration, Cloneable {
    /**
     * Maximum differential output during duty cycle based differential
     * control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> fractional
     * </ul>
     */
    public double PeakDifferentialDutyCycle = 1.0;
    /**
     * Maximum differential output during voltage based differential
     * control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> 16
     *   <li> <b>Units:</b> V
     * </ul>
     */
    public double PeakDifferentialVoltage = 16;
    /**
     * Maximum differential output during torque current based
     * differential control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> 800
     *   <li> <b>Units:</b> A
     * </ul>
     */
    public double PeakDifferentialTorqueCurrent = 800;
    
    /**
     * Modifies this configuration's PeakDifferentialDutyCycle parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Maximum differential output during duty cycle based differential
     * control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> fractional
     * </ul>
     *
     * @param newPeakDifferentialDutyCycle Parameter to modify
     * @return Itself
     */
    public final DifferentialConstantsConfigs withPeakDifferentialDutyCycle(double newPeakDifferentialDutyCycle)
    {
        PeakDifferentialDutyCycle = newPeakDifferentialDutyCycle;
        return this;
    }
    
    /**
     * Modifies this configuration's PeakDifferentialVoltage parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Maximum differential output during voltage based differential
     * control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> 16
     *   <li> <b>Units:</b> V
     * </ul>
     *
     * @param newPeakDifferentialVoltage Parameter to modify
     * @return Itself
     */
    public final DifferentialConstantsConfigs withPeakDifferentialVoltage(double newPeakDifferentialVoltage)
    {
        PeakDifferentialVoltage = newPeakDifferentialVoltage;
        return this;
    }
    
    /**
     * Modifies this configuration's PeakDifferentialVoltage parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Maximum differential output during voltage based differential
     * control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> 16
     *   <li> <b>Units:</b> V
     * </ul>
     *
     * @param newPeakDifferentialVoltage Parameter to modify
     * @return Itself
     */
    public final DifferentialConstantsConfigs withPeakDifferentialVoltage(Voltage newPeakDifferentialVoltage)
    {
        PeakDifferentialVoltage = newPeakDifferentialVoltage.in(Volts);
        return this;
    }
    
    /**
     * Helper method to get this configuration's PeakDifferentialVoltage parameter converted
     * to a unit type. If not using the Java units library, {@link #PeakDifferentialVoltage}
     * can be accessed directly instead.
     * <p>
     * Maximum differential output during voltage based differential
     * control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 32
     *   <li> <b>Default Value:</b> 16
     *   <li> <b>Units:</b> V
     * </ul>
     *
     * @return PeakDifferentialVoltage
     */
    public final Voltage getPeakDifferentialVoltageMeasure()
    {
        return Volts.of(PeakDifferentialVoltage);
    }
    
    /**
     * Modifies this configuration's PeakDifferentialTorqueCurrent parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Maximum differential output during torque current based
     * differential control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> 800
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newPeakDifferentialTorqueCurrent Parameter to modify
     * @return Itself
     */
    public final DifferentialConstantsConfigs withPeakDifferentialTorqueCurrent(double newPeakDifferentialTorqueCurrent)
    {
        PeakDifferentialTorqueCurrent = newPeakDifferentialTorqueCurrent;
        return this;
    }
    
    /**
     * Modifies this configuration's PeakDifferentialTorqueCurrent parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Maximum differential output during torque current based
     * differential control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> 800
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newPeakDifferentialTorqueCurrent Parameter to modify
     * @return Itself
     */
    public final DifferentialConstantsConfigs withPeakDifferentialTorqueCurrent(Current newPeakDifferentialTorqueCurrent)
    {
        PeakDifferentialTorqueCurrent = newPeakDifferentialTorqueCurrent.in(Amps);
        return this;
    }
    
    /**
     * Helper method to get this configuration's PeakDifferentialTorqueCurrent parameter converted
     * to a unit type. If not using the Java units library, {@link #PeakDifferentialTorqueCurrent}
     * can be accessed directly instead.
     * <p>
     * Maximum differential output during torque current based
     * differential control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> 800
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @return PeakDifferentialTorqueCurrent
     */
    public final Current getPeakDifferentialTorqueCurrentMeasure()
    {
        return Amps.of(PeakDifferentialTorqueCurrent);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: DifferentialConstants\n";
        ss += "    PeakDifferentialDutyCycle: " + PeakDifferentialDutyCycle + " fractional" + "\n";
        ss += "    PeakDifferentialVoltage: " + PeakDifferentialVoltage + " V" + "\n";
        ss += "    PeakDifferentialTorqueCurrent: " + PeakDifferentialTorqueCurrent + " A" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_PeakDiffDC.value, PeakDifferentialDutyCycle);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_PeakDiffV.value, PeakDifferentialVoltage);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_PeakDiffTorqCurr.value, PeakDifferentialTorqueCurrent);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        PeakDifferentialDutyCycle = ConfigJNI.Deserializedouble(SpnValue.Config_PeakDiffDC.value, to_deserialize);
        PeakDifferentialVoltage = ConfigJNI.Deserializedouble(SpnValue.Config_PeakDiffV.value, to_deserialize);
        PeakDifferentialTorqueCurrent = ConfigJNI.Deserializedouble(SpnValue.Config_PeakDiffTorqCurr.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public DifferentialConstantsConfigs clone() {
        try {
            return (DifferentialConstantsConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

