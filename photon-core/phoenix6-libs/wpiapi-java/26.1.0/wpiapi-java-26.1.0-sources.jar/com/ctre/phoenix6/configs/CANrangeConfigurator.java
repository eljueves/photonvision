/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.hardware.DeviceIdentifier;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

/**
 * Class for CANrange, a CAN based Time of Flight (ToF) sensor that measures the
 * distance to the front of the device.
 *
 * This defines all configurations for the {@link com.ctre.phoenix6.hardware.CANrange}.
 */
public class CANrangeConfigurator extends ParentConfigurator {
    public CANrangeConfigurator(DeviceIdentifier id) {
        super(id);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CANrangeConfiguration configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CANrangeConfiguration configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CANrangeConfiguration configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CANrangeConfiguration configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, configs.FutureProofConfigs, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CustomParamsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CustomParamsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CustomParamsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CustomParamsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(ToFParamsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(ToFParamsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(ToFParamsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(ToFParamsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(ProximityParamsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(ProximityParamsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(ProximityParamsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(ProximityParamsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(FovParamsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(FovParamsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(FovParamsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(FovParamsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }

    
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults() {
        return clearStickyFaults(DefaultTimeoutSeconds);
    }
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.SPN_ClearStickyFaults.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware() {
        return clearStickyFault_Hardware(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_Hardware.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage() {
        return clearStickyFault_Undervoltage(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_Undervoltage.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable() {
        return clearStickyFault_BootDuringEnable(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_BootDuringEnable.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse() {
        return clearStickyFault_UnlicensedFeatureInUse(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_UnlicensedFeatureInUse.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
}
