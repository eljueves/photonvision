/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

/**
 * Configs to enable/disable various features of the Pigeon2.
 * <p>
 * These configs allow the user to enable or disable various aspects
 * of the Pigeon2.
 */
public class Pigeon2FeaturesConfigs implements ParentConfiguration, Cloneable {
    /**
     * Turns on or off the magnetometer fusing for 9-axis. FRC users are
     * not recommended to turn this on, as the magnetic influence of the
     * robot will likely negatively affect the performance of the Pigeon2.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean EnableCompass = false;
    /**
     * Disables using the temperature compensation feature.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean DisableTemperatureCompensation = false;
    /**
     * Disables using the no-motion calibration feature.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean DisableNoMotionCalibration = false;
    
    /**
     * Modifies this configuration's EnableCompass parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Turns on or off the magnetometer fusing for 9-axis. FRC users are
     * not recommended to turn this on, as the magnetic influence of the
     * robot will likely negatively affect the performance of the Pigeon2.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newEnableCompass Parameter to modify
     * @return Itself
     */
    public final Pigeon2FeaturesConfigs withEnableCompass(boolean newEnableCompass)
    {
        EnableCompass = newEnableCompass;
        return this;
    }
    
    /**
     * Modifies this configuration's DisableTemperatureCompensation parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Disables using the temperature compensation feature.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newDisableTemperatureCompensation Parameter to modify
     * @return Itself
     */
    public final Pigeon2FeaturesConfigs withDisableTemperatureCompensation(boolean newDisableTemperatureCompensation)
    {
        DisableTemperatureCompensation = newDisableTemperatureCompensation;
        return this;
    }
    
    /**
     * Modifies this configuration's DisableNoMotionCalibration parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Disables using the no-motion calibration feature.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newDisableNoMotionCalibration Parameter to modify
     * @return Itself
     */
    public final Pigeon2FeaturesConfigs withDisableNoMotionCalibration(boolean newDisableNoMotionCalibration)
    {
        DisableNoMotionCalibration = newDisableNoMotionCalibration;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: Pigeon2Features\n";
        ss += "    EnableCompass: " + EnableCompass + "\n";
        ss += "    DisableTemperatureCompensation: " + DisableTemperatureCompensation + "\n";
        ss += "    DisableNoMotionCalibration: " + DisableNoMotionCalibration + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeboolean(SpnValue.Pigeon2UseCompass.value, EnableCompass);
        ss += ConfigJNI.Serializeboolean(SpnValue.Pigeon2DisableTemperatureCompensation.value, DisableTemperatureCompensation);
        ss += ConfigJNI.Serializeboolean(SpnValue.Pigeon2DisableNoMotionCalibration.value, DisableNoMotionCalibration);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        EnableCompass = ConfigJNI.Deserializeboolean(SpnValue.Pigeon2UseCompass.value, to_deserialize);
        DisableTemperatureCompensation = ConfigJNI.Deserializeboolean(SpnValue.Pigeon2DisableTemperatureCompensation.value, to_deserialize);
        DisableNoMotionCalibration = ConfigJNI.Deserializeboolean(SpnValue.Pigeon2DisableNoMotionCalibration.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public Pigeon2FeaturesConfigs clone() {
        try {
            return (Pigeon2FeaturesConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

