/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * If a brushed motor is selected with Motor Arrangement, this config determines
 * which of three leads to use.
 */
public enum BrushedMotorWiringValue
{
    /**
     * Third party brushed DC motor with two leads.
     * Motor leads: Use terminal A for the motor red lead and terminal B for the
     * motor black lead (motor leads may be flipped to correct for clockwise vs
     * counterclockwise).
     * Note that the invert configuration can still be used to invert rotor
     * orientation.
     * Gadgeteer Connector: quadrature [A, B] are on pins [7, 5], limit [forward,
     * reverse] are on pins [4, 8], and pulse width position is on pin [9].
     */
    Leads_A_and_B(0),
    /**
     * Third party brushed DC motor with two leads.
     * Motor leads: Use terminal A for the motor red lead and terminal C for the
     * motor black lead (motor leads may be flipped to correct for clockwise vs
     * counterclockwise).
     * Note that the invert configuration can still be used to reverse rotor
     * orientation.
     * Gadgeteer Connector: quadrature [A, B] are on pins [7, 5], limit [forward,
     * reverse] are on pins [4, 8], and pulse width position is on pin [9].
     */
    Leads_A_and_C(1),
    /**
     * Third party brushed DC motor with two leads.
     * Motor leads: Use terminal B for the motor red lead and terminal C for the
     * motor black lead (motor leads may be flipped to correct for clockwise vs
     * counterclockwise).
     * Note that the invert configuration can still be used to reverse rotor
     * orientation.
     * Gadgeteer Connector: quadrature [A, B] are on pins [7, 5], limit [forward,
     * reverse] are on pins [4, 8], and pulse width position is on pin [9].
     */
    Leads_B_and_C(2),;

    public final int value;

    BrushedMotorWiringValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, BrushedMotorWiringValue> _map = null;
    static
    {
        _map = new HashMap<Integer, BrushedMotorWiringValue>();
        for (BrushedMotorWiringValue type : BrushedMotorWiringValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets BrushedMotorWiringValue from specified value
     * @param value Value of BrushedMotorWiringValue
     * @return BrushedMotorWiringValue of specified value
     */
    public static BrushedMotorWiringValue valueOf(int value)
    {
        BrushedMotorWiringValue retval = _map.get(value);
        if (retval != null) return retval;
        return BrushedMotorWiringValue.values()[0];
    }
}
