/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs that affect how software-limit switches behave.
 * <p>
 * Includes enabling software-limit switches and the threshold at
 * which they are tripped.
 */
public class SoftwareLimitSwitchConfigs implements ParentConfiguration, Cloneable {
    /**
     * If enabled, the motor output is set to neutral if position exceeds
     * ForwardSoftLimitThreshold and forward output is requested.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean ForwardSoftLimitEnable = false;
    /**
     * If enabled, the motor output is set to neutral if position exceeds
     * ReverseSoftLimitThreshold and reverse output is requested.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean ReverseSoftLimitEnable = false;
    /**
     * Position threshold for forward soft limit features.
     * ForwardSoftLimitEnable must be enabled for this to take effect.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double ForwardSoftLimitThreshold = 0;
    /**
     * Position threshold for reverse soft limit features.
     * ReverseSoftLimitEnable must be enabled for this to take effect.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double ReverseSoftLimitThreshold = 0;
    
    /**
     * Modifies this configuration's ForwardSoftLimitEnable parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If enabled, the motor output is set to neutral if position exceeds
     * ForwardSoftLimitThreshold and forward output is requested.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newForwardSoftLimitEnable Parameter to modify
     * @return Itself
     */
    public final SoftwareLimitSwitchConfigs withForwardSoftLimitEnable(boolean newForwardSoftLimitEnable)
    {
        ForwardSoftLimitEnable = newForwardSoftLimitEnable;
        return this;
    }
    
    /**
     * Modifies this configuration's ReverseSoftLimitEnable parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If enabled, the motor output is set to neutral if position exceeds
     * ReverseSoftLimitThreshold and reverse output is requested.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newReverseSoftLimitEnable Parameter to modify
     * @return Itself
     */
    public final SoftwareLimitSwitchConfigs withReverseSoftLimitEnable(boolean newReverseSoftLimitEnable)
    {
        ReverseSoftLimitEnable = newReverseSoftLimitEnable;
        return this;
    }
    
    /**
     * Modifies this configuration's ForwardSoftLimitThreshold parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Position threshold for forward soft limit features.
     * ForwardSoftLimitEnable must be enabled for this to take effect.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newForwardSoftLimitThreshold Parameter to modify
     * @return Itself
     */
    public final SoftwareLimitSwitchConfigs withForwardSoftLimitThreshold(double newForwardSoftLimitThreshold)
    {
        ForwardSoftLimitThreshold = newForwardSoftLimitThreshold;
        return this;
    }
    
    /**
     * Modifies this configuration's ForwardSoftLimitThreshold parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Position threshold for forward soft limit features.
     * ForwardSoftLimitEnable must be enabled for this to take effect.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newForwardSoftLimitThreshold Parameter to modify
     * @return Itself
     */
    public final SoftwareLimitSwitchConfigs withForwardSoftLimitThreshold(Angle newForwardSoftLimitThreshold)
    {
        ForwardSoftLimitThreshold = newForwardSoftLimitThreshold.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's ForwardSoftLimitThreshold parameter converted
     * to a unit type. If not using the Java units library, {@link #ForwardSoftLimitThreshold}
     * can be accessed directly instead.
     * <p>
     * Position threshold for forward soft limit features.
     * ForwardSoftLimitEnable must be enabled for this to take effect.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return ForwardSoftLimitThreshold
     */
    public final Angle getForwardSoftLimitThresholdMeasure()
    {
        return Rotations.of(ForwardSoftLimitThreshold);
    }
    
    /**
     * Modifies this configuration's ReverseSoftLimitThreshold parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Position threshold for reverse soft limit features.
     * ReverseSoftLimitEnable must be enabled for this to take effect.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newReverseSoftLimitThreshold Parameter to modify
     * @return Itself
     */
    public final SoftwareLimitSwitchConfigs withReverseSoftLimitThreshold(double newReverseSoftLimitThreshold)
    {
        ReverseSoftLimitThreshold = newReverseSoftLimitThreshold;
        return this;
    }
    
    /**
     * Modifies this configuration's ReverseSoftLimitThreshold parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Position threshold for reverse soft limit features.
     * ReverseSoftLimitEnable must be enabled for this to take effect.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newReverseSoftLimitThreshold Parameter to modify
     * @return Itself
     */
    public final SoftwareLimitSwitchConfigs withReverseSoftLimitThreshold(Angle newReverseSoftLimitThreshold)
    {
        ReverseSoftLimitThreshold = newReverseSoftLimitThreshold.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's ReverseSoftLimitThreshold parameter converted
     * to a unit type. If not using the Java units library, {@link #ReverseSoftLimitThreshold}
     * can be accessed directly instead.
     * <p>
     * Position threshold for reverse soft limit features.
     * ReverseSoftLimitEnable must be enabled for this to take effect.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return ReverseSoftLimitThreshold
     */
    public final Angle getReverseSoftLimitThresholdMeasure()
    {
        return Rotations.of(ReverseSoftLimitThreshold);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: SoftwareLimitSwitch\n";
        ss += "    ForwardSoftLimitEnable: " + ForwardSoftLimitEnable + "\n";
        ss += "    ReverseSoftLimitEnable: " + ReverseSoftLimitEnable + "\n";
        ss += "    ForwardSoftLimitThreshold: " + ForwardSoftLimitThreshold + " rotations" + "\n";
        ss += "    ReverseSoftLimitThreshold: " + ReverseSoftLimitThreshold + " rotations" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_ForwardSoftLimitEnable.value, ForwardSoftLimitEnable);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_ReverseSoftLimitEnable.value, ReverseSoftLimitEnable);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_ForwardSoftLimitThreshold.value, ForwardSoftLimitThreshold);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_ReverseSoftLimitThreshold.value, ReverseSoftLimitThreshold);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        ForwardSoftLimitEnable = ConfigJNI.Deserializeboolean(SpnValue.Config_ForwardSoftLimitEnable.value, to_deserialize);
        ReverseSoftLimitEnable = ConfigJNI.Deserializeboolean(SpnValue.Config_ReverseSoftLimitEnable.value, to_deserialize);
        ForwardSoftLimitThreshold = ConfigJNI.Deserializedouble(SpnValue.Config_ForwardSoftLimitThreshold.value, to_deserialize);
        ReverseSoftLimitThreshold = ConfigJNI.Deserializedouble(SpnValue.Config_ReverseSoftLimitThreshold.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public SoftwareLimitSwitchConfigs clone() {
        try {
            return (SoftwareLimitSwitchConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

