/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.hardware.DeviceIdentifier;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Class description for the Pigeon 2 IMU sensor that measures orientation.
 *
 * This defines all configurations for the {@link com.ctre.phoenix6.hardware.Pigeon2}.
 */
public class Pigeon2Configurator extends ParentConfigurator {
    public Pigeon2Configurator(DeviceIdentifier id) {
        super(id);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(Pigeon2Configuration configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(Pigeon2Configuration configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(Pigeon2Configuration configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(Pigeon2Configuration configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, configs.FutureProofConfigs, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(MountPoseConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(MountPoseConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(MountPoseConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(MountPoseConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(GyroTrimConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(GyroTrimConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(GyroTrimConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(GyroTrimConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(Pigeon2FeaturesConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(Pigeon2FeaturesConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(Pigeon2FeaturesConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(Pigeon2FeaturesConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CustomParamsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CustomParamsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CustomParamsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CustomParamsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }

    
    /**
     * The yaw to set the Pigeon2 to right now.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in deg.
     * @return StatusCode of the set command
     */
    public final StatusCode setYaw(double newValue) {
        return setYaw(newValue, DefaultTimeoutSeconds);
    }
    /**
     * The yaw to set the Pigeon2 to right now.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in deg.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setYaw(double newValue, double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.Pigeon2_SetYaw.value, newValue);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * The yaw to set the Pigeon2 to right now.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in deg.
     * @return StatusCode of the set command
     */
    public final StatusCode setYaw(Angle newValue) {
        return setYaw(newValue.in(Degrees));
    }
    /**
     * The yaw to set the Pigeon2 to right now.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in deg.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setYaw(Angle newValue, double timeoutSeconds) {
        return setYaw(newValue.in(Degrees), timeoutSeconds);
    }
    
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults() {
        return clearStickyFaults(DefaultTimeoutSeconds);
    }
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.SPN_ClearStickyFaults.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware() {
        return clearStickyFault_Hardware(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_Hardware.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage() {
        return clearStickyFault_Undervoltage(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_Undervoltage.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable() {
        return clearStickyFault_BootDuringEnable(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_BootDuringEnable.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse() {
        return clearStickyFault_UnlicensedFeatureInUse(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_UnlicensedFeatureInUse.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Bootup checks failed: Accelerometer
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupAccelerometer() {
        return clearStickyFault_BootupAccelerometer(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Bootup checks failed: Accelerometer
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupAccelerometer(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_PIGEON2_BootupAccel.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Bootup checks failed: Gyroscope
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupGyroscope() {
        return clearStickyFault_BootupGyroscope(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Bootup checks failed: Gyroscope
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupGyroscope(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_PIGEON2_BootupGyros.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Bootup checks failed: Magnetometer
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupMagnetometer() {
        return clearStickyFault_BootupMagnetometer(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Bootup checks failed: Magnetometer
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupMagnetometer(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_PIGEON2_BootupMagne.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Motion Detected during bootup.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootIntoMotion() {
        return clearStickyFault_BootIntoMotion(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Motion Detected during bootup.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootIntoMotion(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_PIGEON2_BootIntoMotion.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Motion stack data acquisition was slower than
     * expected
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_DataAcquiredLate() {
        return clearStickyFault_DataAcquiredLate(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Motion stack data acquisition was slower than
     * expected
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_DataAcquiredLate(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_PIGEON2_DataAcquiredLate.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Motion stack loop time was slower than
     * expected.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_LoopTimeSlow() {
        return clearStickyFault_LoopTimeSlow(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Motion stack loop time was slower than
     * expected.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_LoopTimeSlow(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_PIGEON2_LoopTimeSlow.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Magnetometer values are saturated
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedMagnetometer() {
        return clearStickyFault_SaturatedMagnetometer(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Magnetometer values are saturated
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedMagnetometer(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_PIGEON2_SaturatedMagne.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Accelerometer values are saturated
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedAccelerometer() {
        return clearStickyFault_SaturatedAccelerometer(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Accelerometer values are saturated
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedAccelerometer(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_PIGEON2_SaturatedAccel.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Gyroscope values are saturated
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedGyroscope() {
        return clearStickyFault_SaturatedGyroscope(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Gyroscope values are saturated
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedGyroscope(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_PIGEON2_SaturatedGyros.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
}
