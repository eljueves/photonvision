/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether device is locked by FRC.
 */
public enum FrcLockValue
{
    Frc_Locked(1),
    Frc_Unlocked(0),;

    public final int value;

    FrcLockValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, FrcLockValue> _map = null;
    static
    {
        _map = new HashMap<Integer, FrcLockValue>();
        for (FrcLockValue type : FrcLockValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets FrcLockValue from specified value
     * @param value Value of FrcLockValue
     * @return FrcLockValue of specified value
     */
    public static FrcLockValue valueOf(int value)
    {
        FrcLockValue retval = _map.get(value);
        if (retval != null) return retval;
        return FrcLockValue.values()[0];
    }
}
