/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.jni;

public class CANBusJNI extends CtreJniWrapper {
    public float busUtilization;
    public int busOffCount;
    public int txFullCount;
    public int rec;
    public int tec;

    public static native boolean JNI_IsNetworkFD(String canbus);

    public native int JNI_GetStatus(String canbus);
}
