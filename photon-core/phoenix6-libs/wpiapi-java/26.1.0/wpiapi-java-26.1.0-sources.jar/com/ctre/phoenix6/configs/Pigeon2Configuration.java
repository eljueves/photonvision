/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;

/**
 * Class description for the Pigeon 2 IMU sensor that measures orientation.
 *
 * This handles applying and refreshing the configurations for the {@link com.ctre.phoenix6.hardware.Pigeon2}.
 */
public class Pigeon2Configuration implements ParentConfiguration, Cloneable {
    /**
     * True if we should factory default newer unsupported configs,
     * false to leave newer unsupported configs alone.
     * <p>
     * This flag addresses a corner case where the device may have
     * firmware with newer configs that didn't exist when this
     * version of the API was built. If this occurs and this
     * flag is true, unsupported new configs will be factory
     * defaulted to avoid unexpected behavior.
     * <p>
     * This is also the behavior in Phoenix 5, so this flag
     * is defaulted to true to match.
     */
    public boolean FutureProofConfigs = true;

    
    /**
     * Configs for Pigeon 2's Mount Pose configuration.
     * <p>
     * These configs allow the Pigeon2 to be mounted in whatever
     * orientation that's desired and ensure the reported Yaw/Pitch/Roll
     * is from the robot's reference.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link MountPoseConfigs#MountPoseYaw}
     *   <li> {@link MountPoseConfigs#MountPosePitch}
     *   <li> {@link MountPoseConfigs#MountPoseRoll}
     * </ul>
     * 
     */
    public MountPoseConfigs MountPose = new MountPoseConfigs();
    
    /**
     * Configs to trim the Pigeon2's gyroscope.
     * <p>
     * Pigeon2 allows the user to trim the gyroscope's sensitivity. While
     * this isn't necessary for the Pigeon2, as it comes calibrated
     * out-of-the-box, users can make use of this to make the Pigeon2 even
     * more accurate for their application.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link GyroTrimConfigs#GyroScalarX}
     *   <li> {@link GyroTrimConfigs#GyroScalarY}
     *   <li> {@link GyroTrimConfigs#GyroScalarZ}
     * </ul>
     * 
     */
    public GyroTrimConfigs GyroTrim = new GyroTrimConfigs();
    
    /**
     * Configs to enable/disable various features of the Pigeon2.
     * <p>
     * These configs allow the user to enable or disable various aspects
     * of the Pigeon2.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link Pigeon2FeaturesConfigs#EnableCompass}
     *   <li> {@link
     * Pigeon2FeaturesConfigs#DisableTemperatureCompensation}
     *   <li> {@link Pigeon2FeaturesConfigs#DisableNoMotionCalibration}
     * </ul>
     * 
     */
    public Pigeon2FeaturesConfigs Pigeon2Features = new Pigeon2FeaturesConfigs();
    
    /**
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     */
    public CustomParamsConfigs CustomParams = new CustomParamsConfigs();
    
    /**
     * Modifies this configuration's MountPose parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs for Pigeon 2's Mount Pose configuration.
     * <p>
     * These configs allow the Pigeon2 to be mounted in whatever
     * orientation that's desired and ensure the reported Yaw/Pitch/Roll
     * is from the robot's reference.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link MountPoseConfigs#MountPoseYaw}
     *   <li> {@link MountPoseConfigs#MountPosePitch}
     *   <li> {@link MountPoseConfigs#MountPoseRoll}
     * </ul>
     * 
     *
     * @param newMountPose Parameter to modify
     * @return Itself
     */
    public final Pigeon2Configuration withMountPose(MountPoseConfigs newMountPose)
    {
        MountPose = newMountPose;
        return this;
    }
    
    /**
     * Modifies this configuration's GyroTrim parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs to trim the Pigeon2's gyroscope.
     * <p>
     * Pigeon2 allows the user to trim the gyroscope's sensitivity. While
     * this isn't necessary for the Pigeon2, as it comes calibrated
     * out-of-the-box, users can make use of this to make the Pigeon2 even
     * more accurate for their application.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link GyroTrimConfigs#GyroScalarX}
     *   <li> {@link GyroTrimConfigs#GyroScalarY}
     *   <li> {@link GyroTrimConfigs#GyroScalarZ}
     * </ul>
     * 
     *
     * @param newGyroTrim Parameter to modify
     * @return Itself
     */
    public final Pigeon2Configuration withGyroTrim(GyroTrimConfigs newGyroTrim)
    {
        GyroTrim = newGyroTrim;
        return this;
    }
    
    /**
     * Modifies this configuration's Pigeon2Features parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs to enable/disable various features of the Pigeon2.
     * <p>
     * These configs allow the user to enable or disable various aspects
     * of the Pigeon2.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link Pigeon2FeaturesConfigs#EnableCompass}
     *   <li> {@link
     * Pigeon2FeaturesConfigs#DisableTemperatureCompensation}
     *   <li> {@link Pigeon2FeaturesConfigs#DisableNoMotionCalibration}
     * </ul>
     * 
     *
     * @param newPigeon2Features Parameter to modify
     * @return Itself
     */
    public final Pigeon2Configuration withPigeon2Features(Pigeon2FeaturesConfigs newPigeon2Features)
    {
        Pigeon2Features = newPigeon2Features;
        return this;
    }
    
    /**
     * Modifies this configuration's CustomParams parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     *
     * @param newCustomParams Parameter to modify
     * @return Itself
     */
    public final Pigeon2Configuration withCustomParams(CustomParamsConfigs newCustomParams)
    {
        CustomParams = newCustomParams;
        return this;
    }

    @Override
    public String toString() {
        String ss = "Pigeon2Configuration\n";
        ss += MountPose.toString();
        ss += GyroTrim.toString();
        ss += Pigeon2Features.toString();
        ss += CustomParams.toString();
        return ss;
    }

    /**
     * Get the serialized form of this configuration.
     *
     * @return Serialized form of this config group
     */
    public final String serialize() {
        String ss = "";
        ss += MountPose.serialize();
        ss += GyroTrim.serialize();
        ss += Pigeon2Features.serialize();
        ss += CustomParams.serialize();
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration.
     *
     * @return Return code of the deserialize method
     */
    public final StatusCode deserialize(String to_deserialize) {
        StatusCode err = StatusCode.OK;
        err = MountPose.deserialize(to_deserialize);
        err = GyroTrim.deserialize(to_deserialize);
        err = Pigeon2Features.deserialize(to_deserialize);
        err = CustomParams.deserialize(to_deserialize);
        return err;
    }

    @Override
    public Pigeon2Configuration clone() {
        var retval = new Pigeon2Configuration();
        retval.FutureProofConfigs = FutureProofConfigs;
        retval.MountPose = MountPose.clone();
        retval.GyroTrim = GyroTrim.clone();
        retval.Pigeon2Features = Pigeon2Features.clone();
        retval.CustomParams = CustomParams.clone();
        return retval;
    }
}
