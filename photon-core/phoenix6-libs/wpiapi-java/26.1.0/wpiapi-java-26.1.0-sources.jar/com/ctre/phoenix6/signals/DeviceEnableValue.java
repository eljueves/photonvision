/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether the device is enabled.
 */
public enum DeviceEnableValue
{
    Enabled(1),
    Disabled(0),;

    public final int value;

    DeviceEnableValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, DeviceEnableValue> _map = null;
    static
    {
        _map = new HashMap<Integer, DeviceEnableValue>();
        for (DeviceEnableValue type : DeviceEnableValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets DeviceEnableValue from specified value
     * @param value Value of DeviceEnableValue
     * @return DeviceEnableValue of specified value
     */
    public static DeviceEnableValue valueOf(int value)
    {
        DeviceEnableValue retval = _map.get(value);
        if (retval != null) return retval;
        return DeviceEnableValue.values()[0];
    }
}
