/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.jni;

public class StatusSignalJNI extends CtreJniWrapper implements Cloneable {
    public String network = ""; // don't let this be null
    public int deviceHash;
    public int spn;
    public int unitsKey;
    public double value;
    public double hwtimeStampSeconds;
    public double swtimeStampSeconds;
    public double ecutimeStampSeconds;
    public int statusCode;

    public native String JNI_GetUnits();

    public native int JNI_RefreshSignal(double timeoutSeconds);

    public native int JNI_WaitForSignal(double timeoutSeconds);

    public static native int JNI_WaitForAll(String network, double timeoutSeconds,
            StatusSignalJNI[] signals);

    public native int JNI_SetUpdateFrequency(double frequencyHz, double timeoutSeconds);
    public static native int JNI_SetUpdateFrequencyForAll(double frequencyHz, StatusSignalJNI[] signals, double timeoutSeconds);
    public native double JNI_GetAppliedUpdateFrequency();
    public static native int JNI_OptimizeUpdateFrequencies(String network, int deviceHash, double optimizedFreqHz, double timeoutSeconds);
    public static native int JNI_ResetUpdateFrequencies(String network, int deviceHash, double timeoutSeconds);

    @Override
    public StatusSignalJNI clone() {
        var retval = new StatusSignalJNI();
        retval.network = network;
        retval.deviceHash = deviceHash;
        retval.spn = spn;
        return retval;
    }
}
