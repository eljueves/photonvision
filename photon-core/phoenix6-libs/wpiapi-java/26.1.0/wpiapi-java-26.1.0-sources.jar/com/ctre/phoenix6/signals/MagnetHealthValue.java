/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Magnet health as measured by CANcoder.
 * <p>
 * Red indicates too close or too far, Orange is adequate but with reduced
 * accuracy, green is ideal. Invalid means the accuracy cannot be determined.
 */
public enum MagnetHealthValue
{
    /**
     * The magnet is too close or too far from the CANcoder.
     */
    Magnet_Red(1),
    /**
     * Magnet health is adequate but with reduced accuracy.
     */
    Magnet_Orange(2),
    /**
     * Magnet health is ideal.
     */
    Magnet_Green(3),
    /**
     * The accuracy cannot be determined.
     */
    Magnet_Invalid(0),;

    public final int value;

    MagnetHealthValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, MagnetHealthValue> _map = null;
    static
    {
        _map = new HashMap<Integer, MagnetHealthValue>();
        for (MagnetHealthValue type : MagnetHealthValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets MagnetHealthValue from specified value
     * @param value Value of MagnetHealthValue
     * @return MagnetHealthValue of specified value
     */
    public static MagnetHealthValue valueOf(int value)
    {
        MagnetHealthValue retval = _map.get(value);
        if (retval != null) return retval;
        return MagnetHealthValue.values()[0];
    }
}
