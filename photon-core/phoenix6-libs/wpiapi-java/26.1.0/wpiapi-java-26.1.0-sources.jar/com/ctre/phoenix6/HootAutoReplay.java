/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6;

import java.util.ArrayList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleSupplier;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import com.ctre.phoenix6.StatusSignal.SignalMeasurement;

import edu.wpi.first.units.Measure;
import edu.wpi.first.units.Unit;
import edu.wpi.first.util.function.FloatSupplier;
import edu.wpi.first.util.protobuf.Protobuf;
import edu.wpi.first.util.struct.Struct;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.RobotController;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.simulation.DriverStationSim;

/**
 * Class for handling automatic logging and replay of custom signal inputs.
 * Each subsystem typically creates a new instance of this class.
 * <p>
 * Note that all StatusSignals are automatically logged and replayed, so they
 * do not need to be registered with this class. Additionally, the {@link SignalLogger}
 * must be separately started at the start of the robot program.
 * <p>
 * "Inputs" are signals measured directly from devices that should be replayed
 * unmodified. By comparison, a processed signal, such as a signal indicating
 * that a mechanism has reached the target, is considered an "output". This
 * class should only be used with inputs.
 * <p>
 * Inputs are registered with a getter that returns a value to log and a setter
 * that updates the value in your robot program. For example, a {@code Vision}
 * class with a {@code Pose2d cameraPose} input would register the input using:
 * <pre>
 * private final HootAutoReplay autoReplay = new HootAutoReplay()
 *   .withStruct(
 *     "Vision/CameraPose", Pose2d.struct,
 *     () -> cameraPose, val -> cameraPose = val.value
 *   );
 * </pre>
 * <p>
 * After registering all relevant inputs, call {@link #update()} periodically
 * to perform the following:
 * <ul>
 *  <li> In normal/simulated robot operation, registered inputs will be
 *       fetched from your robot code using the provided getter, and then
 *       logged using the {@link SignalLogger}.
 *  <li> During Hoot Replay, registered inputs will be fetched from
 *       {@link HootReplay} and then updated in your robot code using the
 *       provided setter.
 * </ul>
 */
public class HootAutoReplay {
    private final ArrayList<Runnable> updates = new ArrayList<>();

    /**
     * Updates the state of the robot program by doing one of the following:
     * <ul>
     *  <li> In normal/simulated robot operation, registered signals will be
     *       fetched from your robot code using the provided getter, and then
     *       logged using the {@link SignalLogger}.
     *  <li> During Hoot Replay, registered signals will be fetched from
     *       {@link HootReplay} and then updated in your robot code using the
     *       provided setter.
     * </ul>
     * This should be called periodically, typically in the subsystem.
     */
    public final void update() {
        for (final var update : updates) {
            update.run();
        }
    }

    /**
     * Registers {@link Timer#getTimestamp()} time logging and playback with
     * this instance. This should only be applied to one instance in the robot
     * program.
     * <p>
     * The {@link #update()} of this HootAutoReplay instance must be run
     * at the start of robotPeriodic() before the CommandScheduler is run.
     *
     * @return this object
     */
    public HootAutoReplay withTimestampReplay() {
        class TimestampData {
            final Lock mtx = new ReentrantLock();
            double fpgaTimestamp;
            double ctreTimestamp;
        }
        final var data = new TimestampData();

        withDouble("RobotTimestamp", Timer::getTimestamp, val -> {
            try {
                data.mtx.lock();
                data.fpgaTimestamp = val.value;
                data.ctreTimestamp = val.timestamp;
            } finally {
                data.mtx.unlock();
            }
        });
        if (Utils.isReplay()) {
            RobotController.setTimeSource(() -> {
                try {
                    data.mtx.lock();
                    return (long)((data.fpgaTimestamp + Utils.getCurrentTimeSeconds() - data.ctreTimestamp) * 1e6);
                } finally {
                    data.mtx.unlock();
                }
            });
        }

        return this;
    }

    /**
     * Registers joystick logging and playback with this instance. This should
     * only be applied to one instance in the robot program.
     * <p>
     * To get joysticks to playback during Hoot Replay, "Turn off DS" must be
     * checked in the simulation GUI (under "DS" at the top of the window).
     * Additionally, the {@link #update()} of this HootAutoReplay instance must
     * be run at the start of robotPeriodic() before the CommandScheduler is run.
     *
     * @return this object
     */
    public HootAutoReplay withJoystickReplay() {
        for (int joy = 0; joy < DriverStation.kJoystickPorts; ++joy) {
            final int id = joy;
            final var joystick = "DS:joystick" + id + "/";

            class JoystickData {
                boolean[] buttons = new boolean[0];
                long[] povs = new long[0];
                float[] axes = new float[0];
                long[] axis_types = new long[0];
            }
            final var data = new JoystickData();

            withString(
                joystick + "name",
                () -> DriverStation.getJoystickName(id),
                val -> DriverStationSim.setJoystickName(id, val.value)
            );
            withInteger(
                joystick + "type",
                () -> DriverStation.getJoystickType(id),
                val -> DriverStationSim.setJoystickType(id, val.value.intValue())
            );
            withBoolean(
                joystick + "is_xbox",
                () -> DriverStation.getJoystickIsXbox(id),
                val -> DriverStationSim.setJoystickIsXbox(id, val.value)
            );

            withBooleanArray(
                joystick + "buttons",
                () -> {
                    final var buttonCount = DriverStation.getStickButtonCount(id);
                    if (buttonCount != data.buttons.length) {
                        data.buttons = new boolean[buttonCount];
                    }
                    for (int i = 0; i < data.buttons.length; ++i) {
                        data.buttons[i] = DriverStation.getStickButton(id, i + 1);
                    }
                    return data.buttons;
                },
                val -> {
                    DriverStationSim.setJoystickButtonCount(id, val.value.length);
                    for (int i = 0; i < val.value.length; ++i) {
                        DriverStationSim.setJoystickButton(id, i + 1, val.value[i]);
                    }
                }
            );

            withIntegerArray(
                joystick + "povs",
                () -> {
                    final var povCount = DriverStation.getStickPOVCount(id);
                    if (povCount != data.povs.length) {
                        data.povs = new long[povCount];
                    }
                    for (int i = 0; i < data.povs.length; ++i) {
                        data.povs[i] = DriverStation.getStickPOV(id, i);
                    }
                    return data.povs;
                },
                val -> {
                    DriverStationSim.setJoystickPOVCount(id, val.value.length);
                    for (int i = 0; i < val.value.length; ++i) {
                        DriverStationSim.setJoystickPOV(id, i, (int)val.value[i]);
                    }
                }
            );

            withFloatArray(
                joystick + "axes",
                () -> {
                    final var axisCount = DriverStation.getStickAxisCount(id);
                    if (axisCount != data.axes.length) {
                        data.axes = new float[axisCount];
                    }
                    for (int i = 0; i < data.axes.length; ++i) {
                        data.axes[i] = (float)DriverStation.getStickAxis(id, i);
                    }
                    return data.axes;
                },
                val -> {
                    DriverStationSim.setJoystickAxisCount(id, val.value.length);
                    for (int i = 0; i < val.value.length; ++i) {
                        DriverStationSim.setJoystickAxis(id, i, val.value[i]);
                    }
                }
            );

            withIntegerArray(
                joystick + "axis_types",
                () -> {
                    final var axisCount = DriverStation.getStickAxisCount(id);
                    if (axisCount != data.axis_types.length) {
                        data.axis_types = new long[axisCount];
                    }
                    for (int i = 0; i < data.axis_types.length; ++i) {
                        data.axis_types[i] = DriverStation.getJoystickAxisType(id, i);
                    }
                    return data.axis_types;
                },
                val -> {
                    DriverStationSim.setJoystickAxisCount(id, val.value.length);
                    for (int i = 0; i < val.value.length; ++i) {
                        DriverStationSim.setJoystickAxisType(id, i, (int)val.value[i]);
                    }
                    /* last one, so notify that joystick data has been updated */
                    if (DriverStationSim.getDsAttached()) {
                        DriverStationSim.notifyNewData();
                    }
                }
            );
        }

        return this;
    }

    /**
     * Registers the schema-serialized bytes as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param schemaName Name of the schema
     * @param type Type of the schema, such as struct or protobuf
     * @param schema Schema bytes to write
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withSchemaValue(
        String name, String schemaName,
        HootSchemaType type, byte[] schema,
        Supplier<byte[]> getter,
        Consumer<SignalMeasurement<byte[]>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getSchemaValue(name, type);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            if (!SignalLogger.hasSchema(schemaName, type)) {
                SignalLogger.addSchema(schemaName, type, schema);
            }
            updates.add(() ->
                SignalLogger.writeSchemaValue(name, schemaName, type, getter.get())
            );
        }
        return this;
    }

    /**
     * Registers the schema-serialized bytes as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param schemaName Name of the schema
     * @param type Type of the schema, such as struct or protobuf
     * @param schema Schema string to write
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withSchemaValue(
        String name, String schemaName,
        HootSchemaType type, String schema,
        Supplier<byte[]> getter,
        Consumer<SignalMeasurement<byte[]>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getSchemaValue(name, type);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            if (!SignalLogger.hasSchema(schemaName, type)) {
                SignalLogger.addSchema(schemaName, type, schema);
            }
            updates.add(() ->
                SignalLogger.writeSchemaValue(name, schemaName, type, getter.get())
            );
        }
        return this;
    }

    /**
     * Registers the WPILib Struct as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param struct Struct serialization implementation
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final <T> HootAutoReplay withStruct(
        String name, Struct<T> struct,
        Supplier<T> getter,
        Consumer<SignalMeasurement<T>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getStruct(name, struct);
                if (val.status.isOK()) {
                    val.value.ifPresent(v -> {
                        var data = new SignalMeasurement<T>();
                        data.name = val.name;
                        data.value = v;
                        data.timestamp = val.timestamp;
                        data.units = val.units;
                        data.status = val.status;
                        setter.accept(data);
                    });
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeStruct(name, struct, getter.get())
            );
        }
        return this;
    }

    /**
     * Registers the array of WPILib Structs as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param struct Struct serialization implementation
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final <T> HootAutoReplay withStructArray(
        String name, Struct<T> struct,
        Supplier<T[]> getter,
        Consumer<SignalMeasurement<T[]>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getStructArray(name, struct);
                if (val.status.isOK()) {
                    val.value.ifPresent(v -> {
                        var data = new SignalMeasurement<T[]>();
                        data.name = val.name;
                        data.value = v;
                        data.timestamp = val.timestamp;
                        data.units = val.units;
                        data.status = val.status;
                        setter.accept(data);
                    });
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeStructArray(name, struct, getter.get())
            );
        }
        return this;
    }

    /**
     * Registers the protobuf as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param proto Protobuf serialization implementation
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final <T> HootAutoReplay withProtobuf(
        String name, Protobuf<T, ?> proto,
        Supplier<T> getter,
        Consumer<SignalMeasurement<T>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getProtobuf(name, proto);
                if (val.status.isOK()) {
                    val.value.ifPresent(v -> {
                        var data = new SignalMeasurement<T>();
                        data.name = val.name;
                        data.value = v;
                        data.timestamp = val.timestamp;
                        data.units = val.units;
                        data.status = val.status;
                        setter.accept(data);
                    });
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeProtobuf(name, proto, getter.get())
            );
        }
        return this;
    }

    /**
     * Registers the raw data bytes as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withRaw(
        String name,
        Supplier<byte[]> getter,
        Consumer<SignalMeasurement<byte[]>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getRaw(name);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeRaw(name, getter.get())
            );
        }
        return this;
    }

    /**
     * Registers the boolean as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withBoolean(
        String name,
        BooleanSupplier getter,
        Consumer<SignalMeasurement<Boolean>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getBoolean(name);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeBoolean(name, getter.getAsBoolean())
            );
        }
        return this;
    }

    /**
     * Registers the integer as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withInteger(
        String name,
        LongSupplier getter,
        Consumer<SignalMeasurement<Long>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getInteger(name);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeInteger(name, getter.getAsLong())
            );
        }
        return this;
    }

    /**
     * Registers the float as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withFloat(
        String name,
        FloatSupplier getter,
        Consumer<SignalMeasurement<Float>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getFloat(name);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeFloat(name, getter.getAsFloat())
            );
        }
        return this;
    }

    /**
     * Registers the double as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withDouble(
        String name,
        DoubleSupplier getter,
        Consumer<SignalMeasurement<Double>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getDouble(name);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeDouble(name, getter.getAsDouble())
            );
        }
        return this;
    }

    /**
     * Registers the string as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withString(
        String name,
        Supplier<String> getter,
        Consumer<SignalMeasurement<String>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getString(name);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeString(name, getter.get())
            );
        }
        return this;
    }

    /**
     * Registers the unit value as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param units Units to use for logging the measure
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final <U extends Unit, MEAS extends Measure<U>>
    HootAutoReplay withValue(
        String name,
        U units,
        Supplier<MEAS> getter,
        Consumer<SignalMeasurement<MEAS>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                @SuppressWarnings("unchecked")
                final var val = (SignalMeasurement<MEAS>)HootReplay.getValue(name, units::of);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeValue(name, getter.get(), units)
            );
        }
        return this;
    }

    /**
     * Registers the array of booleans as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withBooleanArray(
        String name,
        Supplier<boolean[]> getter,
        Consumer<SignalMeasurement<boolean[]>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getBooleanArray(name);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeBooleanArray(name, getter.get())
            );
        }
        return this;
    }

    /**
     * Registers the array of integers as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withIntegerArray(
        String name,
        Supplier<long[]> getter,
        Consumer<SignalMeasurement<long[]>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getIntegerArray(name);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeIntegerArray(name, getter.get())
            );
        }
        return this;
    }

    /**
     * Registers the array of floats as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withFloatArray(
        String name,
        Supplier<float[]> getter,
        Consumer<SignalMeasurement<float[]>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getFloatArray(name);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeFloatArray(name, getter.get())
            );
        }
        return this;
    }

    /**
     * Registers the array of doubles as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withDoubleArray(
        String name,
        Supplier<double[]> getter,
        Consumer<SignalMeasurement<double[]>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getDoubleArray(name);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeDoubleArray(name, getter.get())
            );
        }
        return this;
    }

    /**
     * Registers the array of strings as a Hoot-Replayed input.
     *
     * @param name Name of the signal in the log
     * @param getter Function that returns the current value of the input
     * @param setter Function that sets the input to a new value
     * @return this object
     */
    public final HootAutoReplay withStringArray(
        String name,
        Supplier<String[]> getter,
        Consumer<SignalMeasurement<String[]>> setter
    ) {
        if (Utils.isReplay()) {
            updates.add(() -> {
                final var val = HootReplay.getStringArray(name);
                if (val.status.isOK()) {
                    setter.accept(val);
                }
            });
        } else {
            updates.add(() ->
                SignalLogger.writeStringArray(name, getter.get())
            );
        }
        return this;
    }
}
