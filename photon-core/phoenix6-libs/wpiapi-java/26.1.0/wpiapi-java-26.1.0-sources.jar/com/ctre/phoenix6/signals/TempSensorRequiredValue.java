/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether a temperature sensor should be required for motor control. This
 * configuration is ignored in FRC environments and defaults to Required.
 */
public enum TempSensorRequiredValue
{
    /**
     * Temperature sensor is required for motor control.
     */
    Required(0),
    /**
     * Temperature sensor is not required for motor control.
     */
    Not_Required(1),;

    public final int value;

    TempSensorRequiredValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, TempSensorRequiredValue> _map = null;
    static
    {
        _map = new HashMap<Integer, TempSensorRequiredValue>();
        for (TempSensorRequiredValue type : TempSensorRequiredValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets TempSensorRequiredValue from specified value
     * @param value Value of TempSensorRequiredValue
     * @return TempSensorRequiredValue of specified value
     */
    public static TempSensorRequiredValue valueOf(int value)
    {
        TempSensorRequiredValue retval = _map.get(value);
        if (retval != null) return retval;
        return TempSensorRequiredValue.values()[0];
    }
}
