/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.jni.ControlJNI;
import com.ctre.phoenix6.hardware.traits.*;

import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Request PID to target velocity with a differential position setpoint.
 * <p>
 * This control mode will set the motor's velocity setpoint to the velocity specified by the user. It will
 * also set the motor's differential position setpoint to the specified position.
 */
public final class DifferentialVelocityVoltage implements ControlRequest, Cloneable {
    /**
     * Average velocity to drive toward in rotations per second.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     */
    public double AverageVelocity;
    /**
     * Differential position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     */
    public double DifferentialPosition;
    /**
     * Set to true to use FOC commutation (requires Phoenix Pro), which increases
     * peak power by ~15% on supported devices (see {@link SupportsFOC}). Set to
     * false to use trapezoidal commutation.
     * <p>
     * FOC improves motor performance by leveraging torque (current) control. 
     * However, this may be inconvenient for applications that require specifying
     * duty cycle or voltage.  CTR-Electronics has developed a hybrid method that
     * combines the performances gains of FOC while still allowing applications to
     * provide duty cycle or voltage demand.  This not to be confused with simple
     * sinusoidal control or phase voltage control which lacks the performance
     * gains.
     */
    public boolean EnableFOC = true;
    /**
     * Select which gains are applied to the average controller by selecting the
     * slot.  Use the configuration api to set the gain values for the selected slot
     * before enabling this feature. Slot must be within [0,2].
     */
    public int AverageSlot = 0;
    /**
     * Select which gains are applied to the differential controller by selecting
     * the slot.  Use the configuration api to set the gain values for the selected
     * slot before enabling this feature. Slot must be within [0,2].
     */
    public int DifferentialSlot = 1;
    /**
     * Set to true to static-brake the rotor when output is zero (or within
     * deadband).  Set to false to use the NeutralMode configuration setting
     * (default). This flag exists to provide the fundamental behavior of this
     * control when output is zero, which is to provide 0V to the motor.
     */
    public boolean OverrideBrakeDurNeutral = false;
    /**
     * Set to true to force forward limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     */
    public boolean LimitForwardMotion = false;
    /**
     * Set to true to force reverse limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     */
    public boolean LimitReverseMotion = false;
    /**
     * Set to true to ignore hardware limit switches and the LimitForwardMotion and
     * LimitReverseMotion parameters, instead allowing motion.
     * <p>
     * This can be useful on mechanisms such as an intake/feeder, where a limit
     * switch stops motion while intaking but should be ignored when feeding to a
     * shooter.
     * <p>
     * The hardware limit faults and Forward/ReverseLimit signals will still report
     * the values of the limit switches regardless of this parameter.
     */
    public boolean IgnoreHardwareLimits = false;
    /**
     * Set to true to ignore software limits, instead allowing motion.
     * <p>
     * This can be useful when calibrating the zero point of a mechanism such as an
     * elevator.
     * <p>
     * The software limit faults will still report the values of the software limits
     * regardless of this parameter.
     */
    public boolean IgnoreSoftwareLimits = false;
    /**
     * Set to true to delay applying this control request until a timesync boundary
     * (requires Phoenix Pro and CANivore). This eliminates the impact of
     * nondeterministic network delays in exchange for a larger but deterministic
     * control latency.
     * <p>
     * This requires setting the ControlTimesyncFreqHz config in MotorOutputConfigs.
     * Additionally, when this is enabled, the UpdateFreqHz of this request should
     * be set to 0 Hz.
     */
    public boolean UseTimesync = false;

    /**
     * The frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     */
    public double UpdateFreqHz = 100;

    /**
     * Request PID to target velocity with a differential position setpoint.
     * <p>
     * This control mode will set the motor's velocity setpoint to the velocity
     * specified by the user. It will also set the motor's differential position
     * setpoint to the specified position.
     * 
     * @param AverageVelocity Average velocity to drive toward in rotations per
     *                        second.
     * @param DifferentialPosition Differential position to drive toward in
     *                             rotations.
     */
    public DifferentialVelocityVoltage(double AverageVelocity, double DifferentialPosition) {
        this.AverageVelocity = AverageVelocity;
        this.DifferentialPosition = DifferentialPosition;
    }

    /**
     * Request PID to target velocity with a differential position setpoint.
     * <p>
     * This control mode will set the motor's velocity setpoint to the velocity
     * specified by the user. It will also set the motor's differential position
     * setpoint to the specified position.
     * 
     * @param AverageVelocity Average velocity to drive toward in rotations per
     *                        second.
     * @param DifferentialPosition Differential position to drive toward in
     *                             rotations.
     */
    public DifferentialVelocityVoltage(AngularVelocity AverageVelocity, Angle DifferentialPosition) {
        this(AverageVelocity.in(RotationsPerSecond), DifferentialPosition.in(Rotations));
    }

    @Override
    public String getName() {
        return "DifferentialVelocityVoltage";
    }

    @Override
    public String toString() {
        String ss = "Control: DifferentialVelocityVoltage\n";
        ss += "    AverageVelocity: " + AverageVelocity + " rotations per second" + "\n";
        ss += "    DifferentialPosition: " + DifferentialPosition + " rotations" + "\n";
        ss += "    EnableFOC: " + EnableFOC + "\n";
        ss += "    AverageSlot: " + AverageSlot + "\n";
        ss += "    DifferentialSlot: " + DifferentialSlot + "\n";
        ss += "    OverrideBrakeDurNeutral: " + OverrideBrakeDurNeutral + "\n";
        ss += "    LimitForwardMotion: " + LimitForwardMotion + "\n";
        ss += "    LimitReverseMotion: " + LimitReverseMotion + "\n";
        ss += "    IgnoreHardwareLimits: " + IgnoreHardwareLimits + "\n";
        ss += "    IgnoreSoftwareLimits: " + IgnoreSoftwareLimits + "\n";
        ss += "    UseTimesync: " + UseTimesync + "\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlDifferentialVelocityVoltage(
                network, deviceHash, UpdateFreqHz, AverageVelocity, DifferentialPosition, EnableFOC, AverageSlot, DifferentialSlot, OverrideBrakeDurNeutral, LimitForwardMotion, LimitReverseMotion, IgnoreHardwareLimits, IgnoreSoftwareLimits, UseTimesync));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String, String>();
        controlInfo.put("Name", getName());
        controlInfo.put("AverageVelocity", String.valueOf(this.AverageVelocity));
        controlInfo.put("DifferentialPosition", String.valueOf(this.DifferentialPosition));
        controlInfo.put("EnableFOC", String.valueOf(this.EnableFOC));
        controlInfo.put("AverageSlot", String.valueOf(this.AverageSlot));
        controlInfo.put("DifferentialSlot", String.valueOf(this.DifferentialSlot));
        controlInfo.put("OverrideBrakeDurNeutral", String.valueOf(this.OverrideBrakeDurNeutral));
        controlInfo.put("LimitForwardMotion", String.valueOf(this.LimitForwardMotion));
        controlInfo.put("LimitReverseMotion", String.valueOf(this.LimitReverseMotion));
        controlInfo.put("IgnoreHardwareLimits", String.valueOf(this.IgnoreHardwareLimits));
        controlInfo.put("IgnoreSoftwareLimits", String.valueOf(this.IgnoreSoftwareLimits));
        controlInfo.put("UseTimesync", String.valueOf(this.UseTimesync));
        return controlInfo;
    }
    
    /**
     * Modifies this Control Request's AverageVelocity parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Average velocity to drive toward in rotations per second.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @param newAverageVelocity Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withAverageVelocity(double newAverageVelocity) {
        AverageVelocity = newAverageVelocity;
        return this;
    }
    
    /**
     * Modifies this Control Request's AverageVelocity parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Average velocity to drive toward in rotations per second.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @param newAverageVelocity Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withAverageVelocity(AngularVelocity newAverageVelocity) {
        AverageVelocity = newAverageVelocity.in(RotationsPerSecond);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's AverageVelocity parameter converted
     * to a unit type. If not using the Java units library, {@link #AverageVelocity}
     * can be accessed directly instead.
     * <p>
     * Average velocity to drive toward in rotations per second.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @return AverageVelocity
     */
    public AngularVelocity getAverageVelocityMeasure() {
        return RotationsPerSecond.of(AverageVelocity);
    }
    
    /**
     * Modifies this Control Request's DifferentialPosition parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Differential position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     *
     * @param newDifferentialPosition Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withDifferentialPosition(double newDifferentialPosition) {
        DifferentialPosition = newDifferentialPosition;
        return this;
    }
    
    /**
     * Modifies this Control Request's DifferentialPosition parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Differential position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     *
     * @param newDifferentialPosition Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withDifferentialPosition(Angle newDifferentialPosition) {
        DifferentialPosition = newDifferentialPosition.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's DifferentialPosition parameter converted
     * to a unit type. If not using the Java units library, {@link #DifferentialPosition}
     * can be accessed directly instead.
     * <p>
     * Differential position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     *
     * @return DifferentialPosition
     */
    public Angle getDifferentialPositionMeasure() {
        return Rotations.of(DifferentialPosition);
    }
    
    /**
     * Modifies this Control Request's EnableFOC parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to use FOC commutation (requires Phoenix Pro), which increases
     * peak power by ~15% on supported devices (see {@link SupportsFOC}). Set to
     * false to use trapezoidal commutation.
     * <p>
     * FOC improves motor performance by leveraging torque (current) control. 
     * However, this may be inconvenient for applications that require specifying
     * duty cycle or voltage.  CTR-Electronics has developed a hybrid method that
     * combines the performances gains of FOC while still allowing applications to
     * provide duty cycle or voltage demand.  This not to be confused with simple
     * sinusoidal control or phase voltage control which lacks the performance
     * gains.
     *
     * @param newEnableFOC Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withEnableFOC(boolean newEnableFOC) {
        EnableFOC = newEnableFOC;
        return this;
    }
    
    /**
     * Modifies this Control Request's AverageSlot parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Select which gains are applied to the average controller by selecting the
     * slot.  Use the configuration api to set the gain values for the selected slot
     * before enabling this feature. Slot must be within [0,2].
     *
     * @param newAverageSlot Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withAverageSlot(int newAverageSlot) {
        AverageSlot = newAverageSlot;
        return this;
    }
    
    /**
     * Modifies this Control Request's DifferentialSlot parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Select which gains are applied to the differential controller by selecting
     * the slot.  Use the configuration api to set the gain values for the selected
     * slot before enabling this feature. Slot must be within [0,2].
     *
     * @param newDifferentialSlot Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withDifferentialSlot(int newDifferentialSlot) {
        DifferentialSlot = newDifferentialSlot;
        return this;
    }
    
    /**
     * Modifies this Control Request's OverrideBrakeDurNeutral parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to static-brake the rotor when output is zero (or within
     * deadband).  Set to false to use the NeutralMode configuration setting
     * (default). This flag exists to provide the fundamental behavior of this
     * control when output is zero, which is to provide 0V to the motor.
     *
     * @param newOverrideBrakeDurNeutral Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withOverrideBrakeDurNeutral(boolean newOverrideBrakeDurNeutral) {
        OverrideBrakeDurNeutral = newOverrideBrakeDurNeutral;
        return this;
    }
    
    /**
     * Modifies this Control Request's LimitForwardMotion parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to force forward limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     *
     * @param newLimitForwardMotion Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withLimitForwardMotion(boolean newLimitForwardMotion) {
        LimitForwardMotion = newLimitForwardMotion;
        return this;
    }
    
    /**
     * Modifies this Control Request's LimitReverseMotion parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to force reverse limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     *
     * @param newLimitReverseMotion Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withLimitReverseMotion(boolean newLimitReverseMotion) {
        LimitReverseMotion = newLimitReverseMotion;
        return this;
    }
    
    /**
     * Modifies this Control Request's IgnoreHardwareLimits parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to ignore hardware limit switches and the LimitForwardMotion and
     * LimitReverseMotion parameters, instead allowing motion.
     * <p>
     * This can be useful on mechanisms such as an intake/feeder, where a limit
     * switch stops motion while intaking but should be ignored when feeding to a
     * shooter.
     * <p>
     * The hardware limit faults and Forward/ReverseLimit signals will still report
     * the values of the limit switches regardless of this parameter.
     *
     * @param newIgnoreHardwareLimits Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withIgnoreHardwareLimits(boolean newIgnoreHardwareLimits) {
        IgnoreHardwareLimits = newIgnoreHardwareLimits;
        return this;
    }
    
    /**
     * Modifies this Control Request's IgnoreSoftwareLimits parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to ignore software limits, instead allowing motion.
     * <p>
     * This can be useful when calibrating the zero point of a mechanism such as an
     * elevator.
     * <p>
     * The software limit faults will still report the values of the software limits
     * regardless of this parameter.
     *
     * @param newIgnoreSoftwareLimits Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withIgnoreSoftwareLimits(boolean newIgnoreSoftwareLimits) {
        IgnoreSoftwareLimits = newIgnoreSoftwareLimits;
        return this;
    }
    
    /**
     * Modifies this Control Request's UseTimesync parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to delay applying this control request until a timesync boundary
     * (requires Phoenix Pro and CANivore). This eliminates the impact of
     * nondeterministic network delays in exchange for a larger but deterministic
     * control latency.
     * <p>
     * This requires setting the ControlTimesyncFreqHz config in MotorOutputConfigs.
     * Additionally, when this is enabled, the UpdateFreqHz of this request should
     * be set to 0 Hz.
     *
     * @param newUseTimesync Parameter to modify
     * @return Itself
     */
    public DifferentialVelocityVoltage withUseTimesync(boolean newUseTimesync) {
        UseTimesync = newUseTimesync;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public DifferentialVelocityVoltage withUpdateFreqHz(double newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public DifferentialVelocityVoltage withUpdateFreqHz(Frequency newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz.in(Hertz);
        return this;
    }

    @Override
    public DifferentialVelocityVoltage clone() {
        try {
            return (DifferentialVelocityVoltage)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

