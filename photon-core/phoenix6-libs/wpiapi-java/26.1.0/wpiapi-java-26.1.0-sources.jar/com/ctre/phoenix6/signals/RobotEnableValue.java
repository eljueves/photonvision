/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether the robot is enabled.
 */
public enum RobotEnableValue
{
    Enabled(1),
    Disabled(0),;

    public final int value;

    RobotEnableValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, RobotEnableValue> _map = null;
    static
    {
        _map = new HashMap<Integer, RobotEnableValue>();
        for (RobotEnableValue type : RobotEnableValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets RobotEnableValue from specified value
     * @param value Value of RobotEnableValue
     * @return RobotEnableValue of specified value
     */
    public static RobotEnableValue valueOf(int value)
    {
        RobotEnableValue retval = _map.get(value);
        if (retval != null) return retval;
        return RobotEnableValue.values()[0];
    }
}
