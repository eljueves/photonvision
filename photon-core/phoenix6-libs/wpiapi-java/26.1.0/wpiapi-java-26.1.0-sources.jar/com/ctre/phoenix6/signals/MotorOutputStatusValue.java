/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Assess the status of the motor output with respect to load and supply.
 * <p>
 * This routine can be used to determine the general status of motor
 * commutation.
 */
public enum MotorOutputStatusValue
{
    /**
     * The status of motor output could not be determined.
     */
    Unknown(0),
    /**
     * Motor output is disabled.
     */
    Off(1),
    /**
     * The motor is in neutral-brake.
     */
    StaticBraking(2),
    /**
     * The motor is loaded in a typical fashion, drawing current from the supply,
     * and successfully turning the rotor in the direction of applied voltage.
     */
    Motoring(3),
    /**
     * The same as Motoring, except the rotor is being backdriven as the motor
     * output is not enough to defeat load forces.
     */
    DiscordantMotoring(4),
    /**
     * The motor is braking in such a way where motor current is traveling back to
     * the supply (typically a battery).
     */
    RegenBraking(5),;

    public final int value;

    MotorOutputStatusValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, MotorOutputStatusValue> _map = null;
    static
    {
        _map = new HashMap<Integer, MotorOutputStatusValue>();
        for (MotorOutputStatusValue type : MotorOutputStatusValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets MotorOutputStatusValue from specified value
     * @param value Value of MotorOutputStatusValue
     * @return MotorOutputStatusValue of specified value
     */
    public static MotorOutputStatusValue valueOf(int value)
    {
        MotorOutputStatusValue retval = _map.get(value);
        if (retval != null) return retval;
        return MotorOutputStatusValue.values()[0];
    }
}
