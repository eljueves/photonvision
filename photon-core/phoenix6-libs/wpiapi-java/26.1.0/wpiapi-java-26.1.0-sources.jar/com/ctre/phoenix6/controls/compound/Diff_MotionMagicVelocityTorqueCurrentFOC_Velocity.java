/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls.compound;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.*;
import com.ctre.phoenix6.controls.jni.ControlJNI;

import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @hidden
 * Requires Phoenix Pro and CANivore;
 * Differential control with Motion Magic® Velocity average target and velocity
 * difference target using torque current control.
 */
public final class Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity implements ControlRequest, Cloneable {
    /**
     * Average MotionMagicVelocityTorqueCurrentFOC request of the mechanism.
     */
    public MotionMagicVelocityTorqueCurrentFOC AverageRequest;
    /**
     * Differential VelocityTorqueCurrentFOC request of the mechanism.
     */
    public VelocityTorqueCurrentFOC DifferentialRequest;

    /**
     * The frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     */
    public double UpdateFreqHz = 100;

    /**
     * Requires Phoenix Pro and CANivore;
     * Differential control with Motion Magic® Velocity average target and velocity
     * difference target using torque current control.
     * 
     * @param AverageRequest Average MotionMagicVelocityTorqueCurrentFOC request of
     *                       the mechanism.
     * @param DifferentialRequest Differential VelocityTorqueCurrentFOC request of
     *                            the mechanism.
     */
    public Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity(MotionMagicVelocityTorqueCurrentFOC AverageRequest, VelocityTorqueCurrentFOC DifferentialRequest) {
        this.AverageRequest = AverageRequest;
        this.DifferentialRequest = DifferentialRequest;
    }

    @Override
    public String getName() {
        return "Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity";
    }

    @Override
    public String toString() {
        String ss = "Control: Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity\n";
        ss += "    AverageRequest:" + "\n";
        ss += "        Velocity: " + AverageRequest.Velocity + " rotations per second" + "\n";
        ss += "        Acceleration: " + AverageRequest.Acceleration + " rotations per second²" + "\n";
        ss += "        FeedForward: " + AverageRequest.FeedForward + " A" + "\n";
        ss += "        Slot: " + AverageRequest.Slot + "\n";
        ss += "        OverrideCoastDurNeutral: " + AverageRequest.OverrideCoastDurNeutral + "\n";
        ss += "        LimitForwardMotion: " + AverageRequest.LimitForwardMotion + "\n";
        ss += "        LimitReverseMotion: " + AverageRequest.LimitReverseMotion + "\n";
        ss += "        IgnoreHardwareLimits: " + AverageRequest.IgnoreHardwareLimits + "\n";
        ss += "        IgnoreSoftwareLimits: " + AverageRequest.IgnoreSoftwareLimits + "\n";
        ss += "        UseTimesync: " + AverageRequest.UseTimesync + "\n";
        ss += "    DifferentialRequest:" + "\n";
        ss += "        Velocity: " + DifferentialRequest.Velocity + " rotations per second" + "\n";
        ss += "        Acceleration: " + DifferentialRequest.Acceleration + " rotations per second²" + "\n";
        ss += "        FeedForward: " + DifferentialRequest.FeedForward + " A" + "\n";
        ss += "        Slot: " + DifferentialRequest.Slot + "\n";
        ss += "        OverrideCoastDurNeutral: " + DifferentialRequest.OverrideCoastDurNeutral + "\n";
        ss += "        LimitForwardMotion: " + DifferentialRequest.LimitForwardMotion + "\n";
        ss += "        LimitReverseMotion: " + DifferentialRequest.LimitReverseMotion + "\n";
        ss += "        IgnoreHardwareLimits: " + DifferentialRequest.IgnoreHardwareLimits + "\n";
        ss += "        IgnoreSoftwareLimits: " + DifferentialRequest.IgnoreSoftwareLimits + "\n";
        ss += "        UseTimesync: " + DifferentialRequest.UseTimesync + "\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlDiff_MotionMagicVelocityTorqueCurrentFOC_Velocity(
                network, deviceHash, UpdateFreqHz, AverageRequest.Velocity, AverageRequest.Acceleration, AverageRequest.FeedForward, AverageRequest.Slot, AverageRequest.OverrideCoastDurNeutral, AverageRequest.LimitForwardMotion, AverageRequest.LimitReverseMotion, AverageRequest.IgnoreHardwareLimits, AverageRequest.IgnoreSoftwareLimits, AverageRequest.UseTimesync, DifferentialRequest.Velocity, DifferentialRequest.Acceleration, DifferentialRequest.FeedForward, DifferentialRequest.Slot, DifferentialRequest.OverrideCoastDurNeutral, DifferentialRequest.LimitForwardMotion, DifferentialRequest.LimitReverseMotion, DifferentialRequest.IgnoreHardwareLimits, DifferentialRequest.IgnoreSoftwareLimits, DifferentialRequest.UseTimesync));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String, String>();
        controlInfo.put("Name", getName());
        controlInfo.put("AverageRequest", String.valueOf(this.AverageRequest));
        controlInfo.put("DifferentialRequest", String.valueOf(this.DifferentialRequest));
        return controlInfo;
    }
    
    /**
     * Modifies this Control Request's AverageRequest parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Average MotionMagicVelocityTorqueCurrentFOC request of the mechanism.
     *
     * @param newAverageRequest Parameter to modify
     * @return Itself
     */
    public Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity withAverageRequest(MotionMagicVelocityTorqueCurrentFOC newAverageRequest) {
        AverageRequest = newAverageRequest;
        return this;
    }
    
    /**
     * Modifies this Control Request's DifferentialRequest parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Differential VelocityTorqueCurrentFOC request of the mechanism.
     *
     * @param newDifferentialRequest Parameter to modify
     * @return Itself
     */
    public Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity withDifferentialRequest(VelocityTorqueCurrentFOC newDifferentialRequest) {
        DifferentialRequest = newDifferentialRequest;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity withUpdateFreqHz(double newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity withUpdateFreqHz(Frequency newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz.in(Hertz);
        return this;
    }

    @Override
    public Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity clone() {
        try {
            return (Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

