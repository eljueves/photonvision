/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The Color of LED1 when it's "Off".
 */
public enum Led1OffColorValue
{
    Off(0),
    Red(1),
    Green(2),
    Orange(3),
    Blue(4),
    Pink(5),
    Cyan(6),
    White(7),;

    public final int value;

    Led1OffColorValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, Led1OffColorValue> _map = null;
    static
    {
        _map = new HashMap<Integer, Led1OffColorValue>();
        for (Led1OffColorValue type : Led1OffColorValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets Led1OffColorValue from specified value
     * @param value Value of Led1OffColorValue
     * @return Led1OffColorValue of specified value
     */
    public static Led1OffColorValue valueOf(int value)
    {
        Led1OffColorValue retval = _map.get(value);
        if (retval != null) return retval;
        return Led1OffColorValue.values()[0];
    }
}
