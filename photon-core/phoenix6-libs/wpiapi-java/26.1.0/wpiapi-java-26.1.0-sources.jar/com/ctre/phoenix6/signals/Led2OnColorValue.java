/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The Color of LED2 when it's "On".
 */
public enum Led2OnColorValue
{
    Off(0),
    Red(1),
    Green(2),
    Orange(3),
    Blue(4),
    Pink(5),
    Cyan(6),
    White(7),;

    public final int value;

    Led2OnColorValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, Led2OnColorValue> _map = null;
    static
    {
        _map = new HashMap<Integer, Led2OnColorValue>();
        for (Led2OnColorValue type : Led2OnColorValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets Led2OnColorValue from specified value
     * @param value Value of Led2OnColorValue
     * @return Led2OnColorValue of specified value
     */
    public static Led2OnColorValue valueOf(int value)
    {
        Led2OnColorValue retval = _map.get(value);
        if (retval != null) return retval;
        return Led2OnColorValue.values()[0];
    }
}
