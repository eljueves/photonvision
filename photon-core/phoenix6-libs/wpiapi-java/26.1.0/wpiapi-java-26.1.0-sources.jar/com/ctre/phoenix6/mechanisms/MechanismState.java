/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.mechanisms;

/**
 * Possible states of a mechanism.
 */
public enum MechanismState {
    /**
     * The mechanism is running normally.
     */
    OK,
    /**
     * The mechanism is temporarily disabled due to an issue.
     */
    Disabled,
    /**
     * The mechanism is disabled and requires user action.
     */
    RequiresUserAction,
}
