/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Status of the temperature sensor of the external motor.
 */
public enum ExternalMotorTempStatusValue
{
    /**
     * Talon is collecting information on the sensor.
     */
    Collecting(0),
    /**
     * Temperature sensor appears to be disconnected.
     */
    Disconnected(1),
    /**
     * Temperature sensor is too hot to allow motor operation.
     */
    TooHot(2),
    /**
     * Temperature sensor is normal.
     */
    Normal(3),
    /**
     * Temperature sensor is present but is not used.  Most likely the motor
     * arrangement is brushed or disabled.
     */
    NotUsed(4),
    /**
     * Temperature sensor appears to be for the wrong motor arrangement, or signals
     * are shorted.
     */
    WrongMotorOrShorted(5),;

    public final int value;

    ExternalMotorTempStatusValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, ExternalMotorTempStatusValue> _map = null;
    static
    {
        _map = new HashMap<Integer, ExternalMotorTempStatusValue>();
        for (ExternalMotorTempStatusValue type : ExternalMotorTempStatusValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets ExternalMotorTempStatusValue from specified value
     * @param value Value of ExternalMotorTempStatusValue
     * @return ExternalMotorTempStatusValue of specified value
     */
    public static ExternalMotorTempStatusValue valueOf(int value)
    {
        ExternalMotorTempStatusValue retval = _map.get(value);
        if (retval != null) return retval;
        return ExternalMotorTempStatusValue.values()[0];
    }
}
