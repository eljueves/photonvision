/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

/**
 * Configs related to the CANdi™ branded device's quadrature interface
 * using both the S1IN and S2IN inputs
 * <p>
 * All the configs related to the quadrature interface for the CANdi™
 * branded device , including encoder edges per revolution and sensor
 * direction.
 */
public class QuadratureConfigs implements ParentConfiguration, Cloneable {
    /**
     * The number of quadrature edges in one rotation for the quadrature
     * sensor connected to the Talon data port.
     * <p>
     * This is the total number of transitions from high-to-low or
     * low-to-high across both channels per rotation of the sensor. This
     * is also equivalent to the Counts Per Revolution when using 4x
     * decoding.
     * <p>
     * For example, the SRX Mag Encoder has 4096 edges per rotation, and a
     * US Digital 1024 CPR (Cycles Per Revolution) quadrature encoder has
     * 4096 edges per rotation.
     * <p>
     * On the Talon FXS, this can be at most 2,000,000,000 / Peak RPM.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 1
     *   <li> <b>Maximum Value:</b> 1000000
     *   <li> <b>Default Value:</b> 4096
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int QuadratureEdgesPerRotation = 4096;
    /**
     * Direction of the quadrature sensor to determine positive rotation.
     * Invert this so that forward motion on the mechanism results in an
     * increase in quadrature position.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean SensorDirection = false;
    
    /**
     * Modifies this configuration's QuadratureEdgesPerRotation parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The number of quadrature edges in one rotation for the quadrature
     * sensor connected to the Talon data port.
     * <p>
     * This is the total number of transitions from high-to-low or
     * low-to-high across both channels per rotation of the sensor. This
     * is also equivalent to the Counts Per Revolution when using 4x
     * decoding.
     * <p>
     * For example, the SRX Mag Encoder has 4096 edges per rotation, and a
     * US Digital 1024 CPR (Cycles Per Revolution) quadrature encoder has
     * 4096 edges per rotation.
     * <p>
     * On the Talon FXS, this can be at most 2,000,000,000 / Peak RPM.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 1
     *   <li> <b>Maximum Value:</b> 1000000
     *   <li> <b>Default Value:</b> 4096
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newQuadratureEdgesPerRotation Parameter to modify
     * @return Itself
     */
    public final QuadratureConfigs withQuadratureEdgesPerRotation(int newQuadratureEdgesPerRotation)
    {
        QuadratureEdgesPerRotation = newQuadratureEdgesPerRotation;
        return this;
    }
    
    /**
     * Modifies this configuration's SensorDirection parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Direction of the quadrature sensor to determine positive rotation.
     * Invert this so that forward motion on the mechanism results in an
     * increase in quadrature position.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newSensorDirection Parameter to modify
     * @return Itself
     */
    public final QuadratureConfigs withSensorDirection(boolean newSensorDirection)
    {
        SensorDirection = newSensorDirection;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: Quadrature\n";
        ss += "    QuadratureEdgesPerRotation: " + QuadratureEdgesPerRotation + "\n";
        ss += "    SensorDirection: " + SensorDirection + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeint(SpnValue.Config_QuadratureEdgesPerRotation.value, QuadratureEdgesPerRotation);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_Quad_SensorDirection.value, SensorDirection);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        QuadratureEdgesPerRotation = ConfigJNI.Deserializeint(SpnValue.Config_QuadratureEdgesPerRotation.value, to_deserialize);
        SensorDirection = ConfigJNI.Deserializeboolean(SpnValue.Config_Quad_SensorDirection.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public QuadratureConfigs clone() {
        try {
            return (QuadratureConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

