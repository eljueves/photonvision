/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * What value the Signal 2 input (S2IN) needs to be for the CTR Electronics'
 * CANdi™ to detect as Closed.
 * <p>
 * Devices using the S2 input as a remote limit switch will treat the switch as
 * closed when the S2 input is this state.
 */
public enum S2CloseStateValue
{
    /**
     * The S2 input will be treated as closed when it is not floating.
     */
    CloseWhenNotFloating(0),
    /**
     * The S2 input will be treated as closed when it is floating.
     */
    CloseWhenFloating(1),
    /**
     * The S2 input will be treated as closed when it is not High.
     */
    CloseWhenNotHigh(2),
    /**
     * The S2 input will be treated as closed when it is High.
     */
    CloseWhenHigh(3),
    /**
     * The S2 input will be treated as closed when it is not Low.
     */
    CloseWhenNotLow(4),
    /**
     * The S2 input will be treated as closed when it is Low.
     */
    CloseWhenLow(5),;

    public final int value;

    S2CloseStateValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, S2CloseStateValue> _map = null;
    static
    {
        _map = new HashMap<Integer, S2CloseStateValue>();
        for (S2CloseStateValue type : S2CloseStateValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets S2CloseStateValue from specified value
     * @param value Value of S2CloseStateValue
     * @return S2CloseStateValue of specified value
     */
    public static S2CloseStateValue valueOf(int value)
    {
        S2CloseStateValue retval = _map.get(value);
        if (retval != null) return retval;
        return S2CloseStateValue.values()[0];
    }
}
