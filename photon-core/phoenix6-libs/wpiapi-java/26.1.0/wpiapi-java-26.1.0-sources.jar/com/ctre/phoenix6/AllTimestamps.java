/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6;

/**
 * A collection of timestamps for a received signal.
 */
public final class AllTimestamps implements Cloneable {
    private Timestamp systemTimestamp = new Timestamp();
    private Timestamp canivoreTimestamp = new Timestamp();
    private Timestamp deviceTimestamp = new Timestamp();

    void update(Timestamp newSystemTimestamp, Timestamp newCanivoreTimestamp, Timestamp newDeviceTimestamp) {
        systemTimestamp = newSystemTimestamp;
        canivoreTimestamp = newCanivoreTimestamp;
        deviceTimestamp = newDeviceTimestamp;
    }
    void update(
        double systemTimestampSeconds, Timestamp.TimestampSource systemTimestampSource, boolean systemTimestampValid,
        double canivoreTimestampSeconds, Timestamp.TimestampSource canivoreTimestampSource, boolean canivoreTimestampValid,
        double deviceTimestampSeconds, Timestamp.TimestampSource deviceTimestampSource, boolean deviceTimestampValid
    ) {
        this.systemTimestamp.update(systemTimestampSeconds, systemTimestampSource, systemTimestampValid);
        this.canivoreTimestamp.update(canivoreTimestampSeconds, canivoreTimestampSource, canivoreTimestampValid);
        this.deviceTimestamp.update(deviceTimestampSeconds, deviceTimestampSource, deviceTimestampValid);
    }

    /**
     * Get the most accurate timestamp available.
     * <p>
     * The timestamp sources from most to least accurate are:
     * <ul>
     *   <li> {@link Timestamp.TimestampSource#Device}
     *   <li> {@link Timestamp.TimestampSource#CANivore}
     *   <li> {@link Timestamp.TimestampSource#System}
     * </ul>
     * Note that some of these sources may not be available.
     *
     * @return The most accurate timestamp available
     */
    public Timestamp getBestTimestamp() {
        if (deviceTimestamp.isValid()) {
            return deviceTimestamp;
        }
        if (canivoreTimestamp.isValid()) {
            return canivoreTimestamp;
        }
        /* System timestamp is always available */
        return systemTimestamp;
    }

    /**
     * Get the timestamp as reported by the {@link Timestamp.TimestampSource#System} source.
     *
     * @return Timestamp as reported by the System
     */
    public Timestamp getSystemTimestamp() {
        return systemTimestamp;
    }
    /**
     * Get the timestamp as reported by the {@link Timestamp.TimestampSource#CANivore} source.
     *
     * @return Timestamp as reported by the CANivore
     */
    public Timestamp getCANivoreTimestamp() {
        return canivoreTimestamp;
    }
    /**
     * Get the timestamp as reported by the {@link Timestamp.TimestampSource#Device} source.
     *
     * @return Timestamp as reported by the Device
     */
    public Timestamp getDeviceTimestamp() {
        return deviceTimestamp;
    }

    @Override
    public AllTimestamps clone() {
        var toReturn = new AllTimestamps();
        toReturn.update(
            systemTimestamp.getTime(), systemTimestamp.getSource(), systemTimestamp.isValid(),
            canivoreTimestamp.getTime(), canivoreTimestamp.getSource(), canivoreTimestamp.isValid(),
            deviceTimestamp.getTime(), deviceTimestamp.getSource(), deviceTimestamp.isValid());
        return toReturn;
    }
}
