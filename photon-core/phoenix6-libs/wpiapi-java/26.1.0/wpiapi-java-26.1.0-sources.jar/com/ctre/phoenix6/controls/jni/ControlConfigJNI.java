/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls.jni;

import com.ctre.phoenix6.jni.CtreJniWrapper;

public class ControlConfigJNI extends CtreJniWrapper {
    public static native int JNI_RequestConfigApply(
            String canbus, int deviceHash, double timeoutSeconds, String serializedStr, boolean forceApply);
}
