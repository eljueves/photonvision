/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Gains for the specified slot.
 * <p>
 * If this slot is selected, these gains are used in closed loop
 * control requests.
 */
public class Slot0Configs implements ParentConfiguration, Cloneable {
    /**
     * Proportional gain.
     * <p>
     * The units for this gain is dependent on the control mode. Since
     * this gain is multiplied by error in the input, the units should be
     * defined as units of output per unit of input error. For example,
     * when controlling velocity using a duty cycle closed loop, the units
     * for the proportional gain will be duty cycle per rps of error, or
     * 1/rps.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public double kP = 0;
    /**
     * Integral gain.
     * <p>
     * The units for this gain is dependent on the control mode. Since
     * this gain is multiplied by error in the input integrated over time
     * (in units of seconds), the units should be defined as units of
     * output per unit of integrated input error. For example, when
     * controlling velocity using a duty cycle closed loop, integrating
     * velocity over time results in rps * s = rotations. Therefore, the
     * units for the integral gain will be duty cycle per rotation of
     * accumulated error, or 1/rot.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public double kI = 0;
    /**
     * Derivative gain.
     * <p>
     * The units for this gain is dependent on the control mode. Since
     * this gain is multiplied by the derivative of error in the input
     * with respect to time (in units of seconds), the units should be
     * defined as units of output per unit of the differentiated input
     * error. For example, when controlling velocity using a duty cycle
     * closed loop, the derivative of velocity with respect to time is rot
     * per sec², which is acceleration. Therefore, the units for the
     * derivative gain will be duty cycle per unit of acceleration error,
     * or 1/(rot per sec²).
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public double kD = 0;
    /**
     * Static feedforward gain.
     * <p>
     * This is added to the closed loop output. The unit for this constant
     * is dependent on the control mode, typically fractional duty cycle,
     * voltage, or torque current.
     * <p>
     * The sign is typically determined by reference velocity when using
     * position, velocity, and Motion Magic® closed loop modes. However,
     * when using position closed loop with zero velocity reference (no
     * motion profiling), the application can instead use the position
     * closed loop error by setting the Static Feedforward Sign
     * configuration parameter.  When doing so, we recommend the minimal
     * amount of kS, otherwise the motor output may dither when closed
     * loop error is near zero.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -128
     *   <li> <b>Maximum Value:</b> 127
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public double kS = 0;
    /**
     * Velocity feedforward gain.
     * <p>
     * The units for this gain is dependent on the control mode. Since
     * this gain is multiplied by the requested velocity, the units should
     * be defined as units of output per unit of requested input velocity.
     * For example, when controlling velocity using a duty cycle closed
     * loop, the units for the velocity feedfoward gain will be duty cycle
     * per requested rps, or 1/rps.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public double kV = 0;
    /**
     * Acceleration feedforward gain.
     * <p>
     * The units for this gain is dependent on the control mode. Since
     * this gain is multiplied by the requested acceleration, the units
     * should be defined as units of output per unit of requested input
     * acceleration. For example, when controlling velocity using a duty
     * cycle closed loop, the units for the acceleration feedfoward gain
     * will be duty cycle per requested rot per sec², or 1/(rot per sec²).
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public double kA = 0;
    /**
     * Gravity feedforward/feedback gain. The type of gravity compensation
     * is selected by {@link #GravityType}.
     * <p>
     * This is added to the closed loop output. The sign is determined by
     * the gravity type. The unit for this constant is dependent on the
     * control mode, typically fractional duty cycle, voltage, or torque
     * current.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -128
     *   <li> <b>Maximum Value:</b> 127
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public double kG = 0;
    /**
     * Gravity feedforward/feedback type.
     * <p>
     * This determines the type of the gravity feedforward/feedback.
     * <p>
     * Choose Elevator_Static for systems where the gravity feedforward is
     * constant, such as an elevator. The gravity feedforward output will
     * always have the same sign.
     * <p>
     * Choose Arm_Cosine for systems where the gravity feedback is
     * dependent on the angular position of the mechanism, such as an arm.
     * The gravity feedback output will vary depending on the mechanism
     * angular position. Note that the sensor offset and ratios must be
     * configured so that the sensor reports a position of 0 when the
     * mechanism is horizonal (parallel to the ground), and the reported
     * sensor position is 1:1 with the mechanism.
     * 
     */
    public GravityTypeValue GravityType = GravityTypeValue.Elevator_Static;
    /**
     * Static feedforward sign during position closed loop.
     * <p>
     * This determines the sign of the applied kS during position
     * closed-loop modes. The default behavior uses the velocity reference
     * sign. This works well with velocity closed loop, Motion Magic®
     * controls, and position closed loop when velocity reference is
     * specified (motion profiling).
     * <p>
     * However, when using position closed loop with zero velocity
     * reference (no motion profiling), the application may want to apply
     * static feedforward based on the sign of closed loop error instead.
     * When doing so, we recommend using the minimal amount of kS,
     * otherwise the motor output may dither when closed loop error is
     * near zero.
     * 
     */
    public StaticFeedforwardSignValue StaticFeedforwardSign = StaticFeedforwardSignValue.UseVelocitySign;
    /**
     * Gravity feedback position offset when using the Arm/Cosine gravity
     * type.
     * <p>
     * This is an offset applied to the position of the arm, within
     * (-0.25, 0.25) rot, before calculating the output of kG. This is
     * useful when the center of gravity of the arm is offset from the
     * actual zero point of the arm, such as when the arm and intake form
     * an L shape.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -0.25
     *   <li> <b>Maximum Value:</b> 0.25
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double GravityArmPositionOffset = 0;
    /**
     * The behavior of the gain scheduler on this slot. This specifies
     * which gains to use while within the configured
     * GainSchedErrorThreshold. The default is to continue using the
     * specified slot.
     * <p>
     * Gain scheduling will not take effect when running velocity
     * closed-loop controls.
     * 
     */
    public GainSchedBehaviorValue GainSchedBehavior = GainSchedBehaviorValue.Inactive;
    
    /**
     * Modifies this configuration's kP parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Proportional gain.
     * <p>
     * The units for this gain is dependent on the control mode. Since
     * this gain is multiplied by error in the input, the units should be
     * defined as units of output per unit of input error. For example,
     * when controlling velocity using a duty cycle closed loop, the units
     * for the proportional gain will be duty cycle per rps of error, or
     * 1/rps.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newKP Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withKP(double newKP)
    {
        kP = newKP;
        return this;
    }
    
    /**
     * Modifies this configuration's kI parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Integral gain.
     * <p>
     * The units for this gain is dependent on the control mode. Since
     * this gain is multiplied by error in the input integrated over time
     * (in units of seconds), the units should be defined as units of
     * output per unit of integrated input error. For example, when
     * controlling velocity using a duty cycle closed loop, integrating
     * velocity over time results in rps * s = rotations. Therefore, the
     * units for the integral gain will be duty cycle per rotation of
     * accumulated error, or 1/rot.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newKI Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withKI(double newKI)
    {
        kI = newKI;
        return this;
    }
    
    /**
     * Modifies this configuration's kD parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Derivative gain.
     * <p>
     * The units for this gain is dependent on the control mode. Since
     * this gain is multiplied by the derivative of error in the input
     * with respect to time (in units of seconds), the units should be
     * defined as units of output per unit of the differentiated input
     * error. For example, when controlling velocity using a duty cycle
     * closed loop, the derivative of velocity with respect to time is rot
     * per sec², which is acceleration. Therefore, the units for the
     * derivative gain will be duty cycle per unit of acceleration error,
     * or 1/(rot per sec²).
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newKD Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withKD(double newKD)
    {
        kD = newKD;
        return this;
    }
    
    /**
     * Modifies this configuration's kS parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Static feedforward gain.
     * <p>
     * This is added to the closed loop output. The unit for this constant
     * is dependent on the control mode, typically fractional duty cycle,
     * voltage, or torque current.
     * <p>
     * The sign is typically determined by reference velocity when using
     * position, velocity, and Motion Magic® closed loop modes. However,
     * when using position closed loop with zero velocity reference (no
     * motion profiling), the application can instead use the position
     * closed loop error by setting the Static Feedforward Sign
     * configuration parameter.  When doing so, we recommend the minimal
     * amount of kS, otherwise the motor output may dither when closed
     * loop error is near zero.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -128
     *   <li> <b>Maximum Value:</b> 127
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newKS Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withKS(double newKS)
    {
        kS = newKS;
        return this;
    }
    
    /**
     * Modifies this configuration's kV parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Velocity feedforward gain.
     * <p>
     * The units for this gain is dependent on the control mode. Since
     * this gain is multiplied by the requested velocity, the units should
     * be defined as units of output per unit of requested input velocity.
     * For example, when controlling velocity using a duty cycle closed
     * loop, the units for the velocity feedfoward gain will be duty cycle
     * per requested rps, or 1/rps.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newKV Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withKV(double newKV)
    {
        kV = newKV;
        return this;
    }
    
    /**
     * Modifies this configuration's kA parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Acceleration feedforward gain.
     * <p>
     * The units for this gain is dependent on the control mode. Since
     * this gain is multiplied by the requested acceleration, the units
     * should be defined as units of output per unit of requested input
     * acceleration. For example, when controlling velocity using a duty
     * cycle closed loop, the units for the acceleration feedfoward gain
     * will be duty cycle per requested rot per sec², or 1/(rot per sec²).
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newKA Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withKA(double newKA)
    {
        kA = newKA;
        return this;
    }
    
    /**
     * Modifies this configuration's kG parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Gravity feedforward/feedback gain. The type of gravity compensation
     * is selected by {@link #GravityType}.
     * <p>
     * This is added to the closed loop output. The sign is determined by
     * the gravity type. The unit for this constant is dependent on the
     * control mode, typically fractional duty cycle, voltage, or torque
     * current.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -128
     *   <li> <b>Maximum Value:</b> 127
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newKG Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withKG(double newKG)
    {
        kG = newKG;
        return this;
    }
    
    /**
     * Modifies this configuration's GravityType parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Gravity feedforward/feedback type.
     * <p>
     * This determines the type of the gravity feedforward/feedback.
     * <p>
     * Choose Elevator_Static for systems where the gravity feedforward is
     * constant, such as an elevator. The gravity feedforward output will
     * always have the same sign.
     * <p>
     * Choose Arm_Cosine for systems where the gravity feedback is
     * dependent on the angular position of the mechanism, such as an arm.
     * The gravity feedback output will vary depending on the mechanism
     * angular position. Note that the sensor offset and ratios must be
     * configured so that the sensor reports a position of 0 when the
     * mechanism is horizonal (parallel to the ground), and the reported
     * sensor position is 1:1 with the mechanism.
     * 
     *
     * @param newGravityType Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withGravityType(GravityTypeValue newGravityType)
    {
        GravityType = newGravityType;
        return this;
    }
    
    /**
     * Modifies this configuration's StaticFeedforwardSign parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Static feedforward sign during position closed loop.
     * <p>
     * This determines the sign of the applied kS during position
     * closed-loop modes. The default behavior uses the velocity reference
     * sign. This works well with velocity closed loop, Motion Magic®
     * controls, and position closed loop when velocity reference is
     * specified (motion profiling).
     * <p>
     * However, when using position closed loop with zero velocity
     * reference (no motion profiling), the application may want to apply
     * static feedforward based on the sign of closed loop error instead.
     * When doing so, we recommend using the minimal amount of kS,
     * otherwise the motor output may dither when closed loop error is
     * near zero.
     * 
     *
     * @param newStaticFeedforwardSign Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withStaticFeedforwardSign(StaticFeedforwardSignValue newStaticFeedforwardSign)
    {
        StaticFeedforwardSign = newStaticFeedforwardSign;
        return this;
    }
    
    /**
     * Modifies this configuration's GravityArmPositionOffset parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Gravity feedback position offset when using the Arm/Cosine gravity
     * type.
     * <p>
     * This is an offset applied to the position of the arm, within
     * (-0.25, 0.25) rot, before calculating the output of kG. This is
     * useful when the center of gravity of the arm is offset from the
     * actual zero point of the arm, such as when the arm and intake form
     * an L shape.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -0.25
     *   <li> <b>Maximum Value:</b> 0.25
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newGravityArmPositionOffset Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withGravityArmPositionOffset(double newGravityArmPositionOffset)
    {
        GravityArmPositionOffset = newGravityArmPositionOffset;
        return this;
    }
    
    /**
     * Modifies this configuration's GravityArmPositionOffset parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Gravity feedback position offset when using the Arm/Cosine gravity
     * type.
     * <p>
     * This is an offset applied to the position of the arm, within
     * (-0.25, 0.25) rot, before calculating the output of kG. This is
     * useful when the center of gravity of the arm is offset from the
     * actual zero point of the arm, such as when the arm and intake form
     * an L shape.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -0.25
     *   <li> <b>Maximum Value:</b> 0.25
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newGravityArmPositionOffset Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withGravityArmPositionOffset(Angle newGravityArmPositionOffset)
    {
        GravityArmPositionOffset = newGravityArmPositionOffset.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's GravityArmPositionOffset parameter converted
     * to a unit type. If not using the Java units library, {@link #GravityArmPositionOffset}
     * can be accessed directly instead.
     * <p>
     * Gravity feedback position offset when using the Arm/Cosine gravity
     * type.
     * <p>
     * This is an offset applied to the position of the arm, within
     * (-0.25, 0.25) rot, before calculating the output of kG. This is
     * useful when the center of gravity of the arm is offset from the
     * actual zero point of the arm, such as when the arm and intake form
     * an L shape.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -0.25
     *   <li> <b>Maximum Value:</b> 0.25
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return GravityArmPositionOffset
     */
    public final Angle getGravityArmPositionOffsetMeasure()
    {
        return Rotations.of(GravityArmPositionOffset);
    }
    
    /**
     * Modifies this configuration's GainSchedBehavior parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The behavior of the gain scheduler on this slot. This specifies
     * which gains to use while within the configured
     * GainSchedErrorThreshold. The default is to continue using the
     * specified slot.
     * <p>
     * Gain scheduling will not take effect when running velocity
     * closed-loop controls.
     * 
     *
     * @param newGainSchedBehavior Parameter to modify
     * @return Itself
     */
    public final Slot0Configs withGainSchedBehavior(GainSchedBehaviorValue newGainSchedBehavior)
    {
        GainSchedBehavior = newGainSchedBehavior;
        return this;
    }

    /**
     * Converts the provided value to an instance of this type.
     *
     * @param value The value to convert
     * @return Converted value
     */
    public static Slot0Configs from(SlotConfigs value)
    {
        return new Slot0Configs() {{
            kP = value.kP;
            kI = value.kI;
            kD = value.kD;
            kS = value.kS;
            kV = value.kV;
            kA = value.kA;
            kG = value.kG;
            GravityType = value.GravityType;
            StaticFeedforwardSign = value.StaticFeedforwardSign;
            GravityArmPositionOffset = value.GravityArmPositionOffset;
            GainSchedBehavior = value.GainSchedBehavior;
        }};
    }

    @Override
    public String toString() {
        String ss = "Config Group: Slot0\n";
        ss += "    kP: " + kP + "\n";
        ss += "    kI: " + kI + "\n";
        ss += "    kD: " + kD + "\n";
        ss += "    kS: " + kS + "\n";
        ss += "    kV: " + kV + "\n";
        ss += "    kA: " + kA + "\n";
        ss += "    kG: " + kG + "\n";
        ss += "    GravityType: " + GravityType + "\n";
        ss += "    StaticFeedforwardSign: " + StaticFeedforwardSign + "\n";
        ss += "    GravityArmPositionOffset: " + GravityArmPositionOffset + " rotations" + "\n";
        ss += "    GainSchedBehavior: " + GainSchedBehavior + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Slot0_kP.value, kP);
        ss += ConfigJNI.Serializedouble(SpnValue.Slot0_kI.value, kI);
        ss += ConfigJNI.Serializedouble(SpnValue.Slot0_kD.value, kD);
        ss += ConfigJNI.Serializedouble(SpnValue.Slot0_kS.value, kS);
        ss += ConfigJNI.Serializedouble(SpnValue.Slot0_kV.value, kV);
        ss += ConfigJNI.Serializedouble(SpnValue.Slot0_kA.value, kA);
        ss += ConfigJNI.Serializedouble(SpnValue.Slot0_kG.value, kG);
        ss += ConfigJNI.Serializeint(SpnValue.Slot0_kG_Type.value, GravityType.value);
        ss += ConfigJNI.Serializeint(SpnValue.Slot0_kS_Sign.value, StaticFeedforwardSign.value);
        ss += ConfigJNI.Serializedouble(SpnValue.Slot0_kG_PosOffset.value, GravityArmPositionOffset);
        ss += ConfigJNI.Serializeint(SpnValue.Slot0_GainSchedBehavior.value, GainSchedBehavior.value);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        kP = ConfigJNI.Deserializedouble(SpnValue.Slot0_kP.value, to_deserialize);
        kI = ConfigJNI.Deserializedouble(SpnValue.Slot0_kI.value, to_deserialize);
        kD = ConfigJNI.Deserializedouble(SpnValue.Slot0_kD.value, to_deserialize);
        kS = ConfigJNI.Deserializedouble(SpnValue.Slot0_kS.value, to_deserialize);
        kV = ConfigJNI.Deserializedouble(SpnValue.Slot0_kV.value, to_deserialize);
        kA = ConfigJNI.Deserializedouble(SpnValue.Slot0_kA.value, to_deserialize);
        kG = ConfigJNI.Deserializedouble(SpnValue.Slot0_kG.value, to_deserialize);
        GravityType = GravityTypeValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Slot0_kG_Type.value, to_deserialize));
        StaticFeedforwardSign = StaticFeedforwardSignValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Slot0_kS_Sign.value, to_deserialize));
        GravityArmPositionOffset = ConfigJNI.Deserializedouble(SpnValue.Slot0_kG_PosOffset.value, to_deserialize);
        GainSchedBehavior = GainSchedBehaviorValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Slot0_GainSchedBehavior.value, to_deserialize));
        return  StatusCode.OK;
    }

    @Override
    public Slot0Configs clone() {
        try {
            return (Slot0Configs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

