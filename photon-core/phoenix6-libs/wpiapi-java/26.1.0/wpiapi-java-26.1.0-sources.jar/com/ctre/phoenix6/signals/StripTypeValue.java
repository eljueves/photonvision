/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The type of LEDs that are being controlled.
 */
public enum StripTypeValue
{
    /**
     * LEDs that are controlled by Green-Red-Blue values.
     */
    GRB(0),
    /**
     * LEDs that are controlled by Red-Green-Blue values.
     */
    RGB(1),
    /**
     * LEDs that are controlled by Blue-Red-Green values.
     */
    BRG(2),
    /**
     * LEDs that are controlled by Green-Red-Blue-White values.
     */
    GRBW(6),
    /**
     * LEDs that are controlled by Red-Green-Blue-White values.
     */
    RGBW(7),
    /**
     * LEDs that are controlled by Blue-Red-Green-White values.
     */
    BRGW(8),;

    public final int value;

    StripTypeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, StripTypeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, StripTypeValue>();
        for (StripTypeValue type : StripTypeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets StripTypeValue from specified value
     * @param value Value of StripTypeValue
     * @return StripTypeValue of specified value
     */
    public static StripTypeValue valueOf(int value)
    {
        StripTypeValue retval = _map.get(value);
        if (retval != null) return retval;
        return StripTypeValue.values()[0];
    }
}
