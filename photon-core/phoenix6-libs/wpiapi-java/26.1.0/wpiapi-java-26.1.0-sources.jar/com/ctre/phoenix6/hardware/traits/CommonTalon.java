/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.traits;



/**
 * Contains everything common between Talon motor controllers.
 */
public interface CommonTalon extends HasTalonControls, HasTalonSignals
{




}

