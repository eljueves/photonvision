/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware;

import java.util.ArrayList;

import com.ctre.phoenix6.CANBus;
import com.ctre.phoenix6.Utils;
import com.ctre.phoenix6.hardware.core.CoreCANdle;
import com.ctre.phoenix6.jni.PlatformJNI;
import com.ctre.phoenix6.sim.DeviceType;
import com.ctre.phoenix6.wpiutils.AutoFeedEnable;
import com.ctre.phoenix6.wpiutils.CallbackHelper;
import com.ctre.phoenix6.wpiutils.ReplayAutoEnable;

import edu.wpi.first.hal.HAL;
import edu.wpi.first.hal.HAL.SimPeriodicBeforeCallback;
import edu.wpi.first.hal.HALValue;
import edu.wpi.first.hal.SimDevice;
import edu.wpi.first.hal.SimDevice.Direction;
import edu.wpi.first.hal.SimDouble;
import edu.wpi.first.hal.simulation.SimDeviceDataJNI;
import edu.wpi.first.util.sendable.Sendable;
import edu.wpi.first.util.sendable.SendableBuilder;
import edu.wpi.first.util.sendable.SendableRegistry;
import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.wpilibj.simulation.CallbackStore;
import edu.wpi.first.wpilibj.simulation.SimDeviceSim;

/**
 * WPILib-integrated version of {@link CoreCANdle}.
 */
public class CANdle extends CoreCANdle implements Sendable, AutoCloseable {
    /**
     * The StatusSignal getters are copies so that calls
     * to the WPI interface do not update any references
     */
    private static final DeviceType kSimDeviceType = DeviceType.P6_CANdleType;

    private SimDevice m_simCANdle;
    private SimDouble m_simSupplyVoltage;
    private SimDouble m_simFiveVRail;
    private SimDouble m_simOutputCurrent;
    private SimDouble m_simTemperature;
    private SimDouble m_simVBatModulation;

    // returned registered callbacks
    private final ArrayList<CallbackStore> m_simValueChangedCallbacks = new ArrayList<CallbackStore>();
    private SimPeriodicBeforeCallback m_simPeriodicBeforeCallback = null;

    /**
     * Constructs a new CANdle object.
     * <p>
     * Constructs the device using the default CAN bus for the system
     * (see {@link CANBus#CANBus()}).
     *
     * @param deviceId ID of the device, as configured in Phoenix Tuner
     */
    public CANdle(int deviceId) {
        this(deviceId, new CANBus());
    }

    /**
     * Constructs a new CANdle object.
     *
     * @param deviceId ID of the device, as configured in Phoenix Tuner
     * @param canbus   Name of the CAN bus this device is on. Possible CAN bus
     *                 strings are:
     *                 <ul>
     *                   <li>"rio" for the native roboRIO CAN bus
     *                   <li>CANivore name or serial number
     *                   <li>SocketCAN interface (non-FRC Linux only)
     *                   <li>"*" for any CANivore seen by the program
     *                   <li>empty string (default) to select the default for the
     *                       system:
     *                   <ul>
     *                     <li>"rio" on roboRIO
     *                     <li>"can0" on Linux
     *                     <li>"*" on Windows
     *                   </ul>
     *                 </ul>
     *
     * @deprecated Constructing devices with a CAN bus string is deprecated for removal
     * in the 2027 season. Construct devices using a {@link CANBus} instance instead.
     */
    @Deprecated(since = "2026", forRemoval = true)
    public CANdle(int deviceId, String canbus) {
        this(deviceId, new CANBus(canbus));
    }

    /**
     * Constructs a new CANdle object.
     *
     * @param deviceId ID of the device, as configured in Phoenix Tuner
     * @param canbus   The CAN bus this device is on
     */
    @SuppressWarnings("this-escape")
    public CANdle(int deviceId, CANBus canbus) {
        super(deviceId, canbus);
        SendableRegistry.addLW(this, "CANdle (v6) ", deviceId);

        if (RobotBase.isSimulation()) {
            /* run in both swsim and hwsim */
            AutoFeedEnable.getInstance().start();
        }
        if (Utils.isReplay()) {
            ReplayAutoEnable.getInstance().start();
        }

        m_simCANdle = SimDevice.create("CAN:CANdle (v6)", deviceId);

        if (m_simCANdle != null) {
            m_simPeriodicBeforeCallback = HAL.registerSimPeriodicBeforeCallback(this::onPeriodic);

            m_simSupplyVoltage = m_simCANdle.createDouble("supplyVoltage", Direction.kInput, 12.0);
            m_simFiveVRail = m_simCANdle.createDouble("fiveVRail", Direction.kInput, 5.0);
            m_simOutputCurrent = m_simCANdle.createDouble("outputCurrent", Direction.kInput, 0.0);
            m_simTemperature = m_simCANdle.createDouble("temperature", Direction.kInput, 25.0);

            m_simVBatModulation = m_simCANdle.createDouble("vbatModulation", Direction.kOutput, 0);

            final SimDeviceSim sim = new SimDeviceSim("CAN:CANdle (v6)");
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simSupplyVoltage, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simFiveVRail, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simOutputCurrent, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simTemperature, this::onValueChanged, true)
            );
        }
    }

    // ----- Auto-Closable ----- //
    @Override
    public void close() {
        SendableRegistry.remove(this);
        if (m_simPeriodicBeforeCallback != null) {
            m_simPeriodicBeforeCallback.close();
            m_simPeriodicBeforeCallback = null;
        }
        if (m_simCANdle != null) {
            m_simCANdle.close();
            m_simCANdle = null;
        }

        for (var callback : m_simValueChangedCallbacks) {
            callback.close();
        }
        m_simValueChangedCallbacks.clear();

        AutoFeedEnable.getInstance().stop();
    }

    // ----- Callbacks for Sim ----- //
    private void onValueChanged(String name, int handle, int direction, HALValue value) {
        String deviceName = SimDeviceDataJNI.getSimDeviceName(SimDeviceDataJNI.getSimValueDeviceHandle(handle));
        String physType = deviceName + ":" + name;
        PlatformJNI.JNI_SimSetPhysicsInput(
            kSimDeviceType.value, getDeviceID(),
            physType, CallbackHelper.getRawValue(value)
        );
    }

    private void onPeriodic() {
        double value = 0;
        int err = 0;

        final int deviceID = getDeviceID();

        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "SupplyVoltage");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simSupplyVoltage.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "FiveVRail");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simFiveVRail.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "OutputCurrent");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simOutputCurrent.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "Temperature");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simTemperature.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "VBatModulation");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simVBatModulation.set(value);
        }
    }

    // ----- Sendable ----- //
    @Override
    public void initSendable(SendableBuilder builder) {
        builder.setSmartDashboardType("CANdle");
    }
}
