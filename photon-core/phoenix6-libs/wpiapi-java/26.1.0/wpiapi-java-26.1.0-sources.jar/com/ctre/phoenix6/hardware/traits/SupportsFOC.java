/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.traits;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.*;
import com.ctre.phoenix6.controls.compound.*;

/**
 * Requires Phoenix Pro; Contains all FOC-exclusive control functions available
 * for devices that support FOC.
 */
public interface SupportsFOC extends CommonDevice
{
    
    
    /**
     * Request a specified motor current (field oriented control).
     * <p>
     * This control request will drive the motor to the requested motor
     * (stator) current value.  This leverages field oriented control
     * (FOC), which means greater peak power than what is documented. 
     * This scales to torque based on Motor's kT constant.
     * <ul>
     *   <li> <b>TorqueCurrentFOC Parameters:</b> 
     *   <ul>
     *     <li> <b>Output:</b> Amount of motor current in Amperes
     *     <li> <b>MaxAbsDutyCycle:</b> The maximum absolute motor output that can
     *                                  be applied, which effectively limits the
     *                                  velocity. For example, 0.50 means no more
     *                                  than 50% output in either direction.  This
     *                                  is useful for preventing the motor from
     *                                  spinning to its terminal velocity when there
     *                                  is no external torque applied unto the
     *                                  rotor.  Note this is absolute maximum, so
     *                                  the value should be between zero and one.
     *     <li> <b>Deadband:</b> Deadband in Amperes.  If torque request is within
     *                           deadband, the bridge output is neutral. If deadband
     *                           is set to zero then there is effectively no
     *                           deadband. Note if deadband is zero, a free spinning
     *                           motor will spin for quite a while as the firmware
     *                           attempts to hold the motor's bemf. If user expects
     *                           motor to cease spinning quickly with a demand of
     *                           zero, we recommend a deadband of one Ampere. This
     *                           value will be converted to an integral value of
     *                           amps.
     *     <li> <b>OverrideCoastDurNeutral:</b> Set to true to coast the rotor when
     *                                          output is zero (or within deadband).
     *                                           Set to false to use the NeutralMode
     *                                          configuration setting (default).
     *                                          This flag exists to provide the
     *                                          fundamental behavior of this control
     *                                          when output is zero, which is to
     *                                          provide 0A (zero torque).
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(TorqueCurrentFOC request);
    
    /**
     * Request PID to target position with torque current feedforward.
     * <p>
     * This control mode will set the motor's position setpoint to the
     * position specified by the user. In addition, it will apply an
     * additional torque current as an arbitrary feedforward value.
     * <ul>
     *   <li> <b>PositionTorqueCurrentFOC Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>Velocity:</b> Velocity to drive toward in rotations per second.
     *                           This is typically used for motion profiles
     *                           generated by the robot program.
     *     <li> <b>FeedForward:</b> Feedforward to apply in torque current in
     *                              Amperes. This is added to the output of the
     *                              onboard feedforward terms.
     *                              <p>
     *                              User can use motor's kT to scale Newton-meter to
     *                              Amperes.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideCoastDurNeutral:</b> Set to true to coast the rotor when
     *                                          output is zero (or within deadband).
     *                                           Set to false to use the NeutralMode
     *                                          configuration setting (default).
     *                                          This flag exists to provide the
     *                                          fundamental behavior of this control
     *                                          when output is zero, which is to
     *                                          provide 0A (zero torque).
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(PositionTorqueCurrentFOC request);
    
    /**
     * Request PID to target velocity with torque current feedforward.
     * <p>
     * This control mode will set the motor's velocity setpoint to the
     * velocity specified by the user. In addition, it will apply an
     * additional torque current as an arbitrary feedforward value.
     * <ul>
     *   <li> <b>VelocityTorqueCurrentFOC Parameters:</b> 
     *   <ul>
     *     <li> <b>Velocity:</b> Velocity to drive toward in rotations per second.
     *     <li> <b>Acceleration:</b> Acceleration to drive toward in rotations per
     *                               second squared. This is typically used for
     *                               motion profiles generated by the robot program.
     *     <li> <b>FeedForward:</b> Feedforward to apply in torque current in
     *                              Amperes. This is added to the output of the
     *                              onboard feedforward terms.
     *                              <p>
     *                              User can use motor's kT to scale Newton-meter to
     *                              Amperes.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideCoastDurNeutral:</b> Set to true to coast the rotor when
     *                                          output is zero (or within deadband).
     *                                           Set to false to use the NeutralMode
     *                                          configuration setting (default).
     *                                          This flag exists to provide the
     *                                          fundamental behavior of this control
     *                                          when output is zero, which is to
     *                                          provide 0A (zero torque).
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(VelocityTorqueCurrentFOC request);
    
    /**
     * Requests Motion Magic® to target a final position using a motion
     * profile.  Users can optionally provide a torque current
     * feedforward.
     * <p>
     * Motion Magic® produces a motion profile in real-time while
     * attempting to honor the Cruise Velocity, Acceleration, and
     * (optional) Jerk specified via the Motion Magic® configuration
     * values.  This control mode does not use the Expo_kV or Expo_kA
     * configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is based on
     * torque current, so relevant closed-loop gains will use Amperes for
     * the numerator.
     * <ul>
     *   <li> <b>MotionMagicTorqueCurrentFOC Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>FeedForward:</b> Feedforward to apply in torque current in
     *                              Amperes. This is added to the output of the
     *                              onboard feedforward terms.
     *                              <p>
     *                              User can use motor's kT to scale Newton-meter to
     *                              Amperes.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideCoastDurNeutral:</b> Set to true to coast the rotor when
     *                                          output is zero (or within deadband).
     *                                           Set to false to use the NeutralMode
     *                                          configuration setting (default).
     *                                          This flag exists to provide the
     *                                          fundamental behavior of this control
     *                                          when output is zero, which is to
     *                                          provide 0A (zero torque).
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(MotionMagicTorqueCurrentFOC request);
    
    /**
     * Requests Motion Magic® to target a final velocity using a motion
     * profile.  This allows smooth transitions between velocity set
     * points.  Users can optionally provide a torque feedforward.
     * <p>
     * Motion Magic® Velocity produces a motion profile in real-time while
     * attempting to honor the specified Acceleration and (optional) Jerk.
     *  This control mode does not use the CruiseVelocity, Expo_kV, or
     * Expo_kA configs.
     * <p>
     * If the specified acceleration is zero, the Acceleration under
     * Motion Magic® configuration parameter is used instead.  This allows
     * for runtime adjustment of acceleration for advanced users.  Jerk is
     * also specified in the Motion Magic® persistent configuration
     * values.  If Jerk is set to zero, Motion Magic® will produce a
     * trapezoidal acceleration profile.
     * <p>
     * Target velocity can also be changed on-the-fly and Motion Magic®
     * will do its best to adjust the profile.  This control mode is based
     * on torque current, so relevant closed-loop gains will use Amperes
     * for the numerator.
     * <ul>
     *   <li> <b>MotionMagicVelocityTorqueCurrentFOC Parameters:</b> 
     *   <ul>
     *     <li> <b>Velocity:</b> Target velocity to drive toward in rotations per
     *                           second.  This can be changed on-the fly.
     *     <li> <b>Acceleration:</b> This is the absolute Acceleration to use
     *                               generating the profile.  If this parameter is
     *                               zero, the Acceleration persistent configuration
     *                               parameter is used instead. Acceleration is in
     *                               rotations per second squared.  If nonzero, the
     *                               signage does not matter as the absolute value
     *                               is used.
     *     <li> <b>FeedForward:</b> Feedforward to apply in torque current in
     *                              Amperes. This is added to the output of the
     *                              onboard feedforward terms.
     *                              <p>
     *                              User can use motor's kT to scale Newton-meter to
     *                              Amperes.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideCoastDurNeutral:</b> Set to true to coast the rotor when
     *                                          output is zero (or within deadband).
     *                                           Set to false to use the NeutralMode
     *                                          configuration setting (default).
     *                                          This flag exists to provide the
     *                                          fundamental behavior of this control
     *                                          when output is zero, which is to
     *                                          provide 0A (zero torque).
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(MotionMagicVelocityTorqueCurrentFOC request);
    
    /**
     * Requests Motion Magic® to target a final position using an
     * exponential motion profile.  Users can optionally provide a torque
     * current feedforward.
     * <p>
     * Motion Magic® Expo produces a motion profile in real-time while
     * attempting to honor the Cruise Velocity (optional) and the
     * mechanism kV and kA, specified via the Motion Magic® configuration
     * values.  Note that unlike the slot gains, the Expo_kV and Expo_kA
     * configs are always in output units of Volts.
     * <p>
     * Setting Cruise Velocity to 0 will allow the profile to run to the
     * max possible velocity based on Expo_kV.  This control mode does not
     * use the Acceleration or Jerk configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile.  This control mode is based on
     * torque current, so relevant closed-loop gains will use Amperes for
     * the numerator.
     * <ul>
     *   <li> <b>MotionMagicExpoTorqueCurrentFOC Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>FeedForward:</b> Feedforward to apply in torque current in
     *                              Amperes. This is added to the output of the
     *                              onboard feedforward terms.
     *                              <p>
     *                              User can use motor's kT to scale Newton-meter to
     *                              Amperes.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideCoastDurNeutral:</b> Set to true to coast the rotor when
     *                                          output is zero (or within deadband).
     *                                           Set to false to use the NeutralMode
     *                                          configuration setting (default).
     *                                          This flag exists to provide the
     *                                          fundamental behavior of this control
     *                                          when output is zero, which is to
     *                                          provide 0A (zero torque).
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(MotionMagicExpoTorqueCurrentFOC request);
    
    /**
     * Requests Motion Magic® to target a final position using a motion
     * profile.  This dynamic request allows runtime changes to Cruise
     * Velocity, Acceleration, and (optional) Jerk.  Users can optionally
     * provide a torque current feedforward.
     * <p>
     * Motion Magic® produces a motion profile in real-time while
     * attempting to honor the specified Cruise Velocity, Acceleration,
     * and (optional) Jerk.  This control mode does not use the Expo_kV or
     * Expo_kA configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile. This control mode is based on
     * torque current, so relevant closed-loop gains will use Amperes for
     * the numerator.
     * <ul>
     *   <li> <b>DynamicMotionMagicTorqueCurrentFOC Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>Velocity:</b> Cruise velocity for profiling.  The signage does
     *                           not matter as the device will use the absolute
     *                           value for profile generation.
     *     <li> <b>Acceleration:</b> Acceleration for profiling.  The signage does
     *                               not matter as the device will use the absolute
     *                               value for profile generation.
     *     <li> <b>Jerk:</b> Jerk for profiling.  The signage does not matter as the
     *                       device will use the absolute value for profile
     *                       generation.
     *                       <p>
     *                       Jerk is optional; if this is set to zero, then Motion
     *                       Magic® will not apply a Jerk limit.
     *     <li> <b>FeedForward:</b> Feedforward to apply in torque current in
     *                              Amperes. This is added to the output of the
     *                              onboard feedforward terms.
     *                              <p>
     *                              User can use motor's kT to scale Newton-meter to
     *                              Amperes.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideCoastDurNeutral:</b> Set to true to coast the rotor when
     *                                          output is zero (or within deadband).
     *                                           Set to false to use the NeutralMode
     *                                          configuration setting (default).
     *                                          This flag exists to provide the
     *                                          fundamental behavior of this control
     *                                          when output is zero, which is to
     *                                          provide 0A (zero torque).
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DynamicMotionMagicTorqueCurrentFOC request);
    
    /**
     * Requests Motion Magic® Expo to target a final position using an
     * exponential motion profile.  This dynamic request allows runtime
     * changes to the profile kV, kA, and (optional) Cruise Velocity. 
     * Users can optionally provide a torque current feedforward.
     * <p>
     * Motion Magic® Expo produces a motion profile in real-time while
     * attempting to honor the specified Cruise Velocity (optional) and
     * the mechanism kV and kA.  Note that unlike the slot gains, the
     * Expo_kV and Expo_kA parameters are always in output units of Volts.
     * <p>
     * Setting the Cruise Velocity to 0 will allow the profile to run to
     * the max possible velocity based on Expo_kV.  This control mode does
     * not use the Acceleration or Jerk configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do
     * its best to adjust the profile. This control mode is based on
     * torque current, so relevant closed-loop gains will use Amperes for
     * the numerator.
     * <ul>
     *   <li> <b>DynamicMotionMagicExpoTorqueCurrentFOC Parameters:</b> 
     *   <ul>
     *     <li> <b>Position:</b> Position to drive toward in rotations.
     *     <li> <b>kV:</b> Mechanism kV for profiling.  Unlike the kV slot gain,
     *                     this is always in units of V/rps.
     *                     <p>
     *                     This represents the amount of voltage necessary to hold a
     *                     velocity.  In terms of the Motion Magic® Expo profile, a
     *                     higher kV results in a slower maximum velocity.
     *     <li> <b>kA:</b> Mechanism kA for profiling.  Unlike the kA slot gain,
     *                     this is always in units of V/rps².
     *                     <p>
     *                     This represents the amount of voltage necessary to
     *                     achieve an acceleration.  In terms of the Motion Magic®
     *                     Expo profile, a higher kA results in a slower
     *                     acceleration.
     *     <li> <b>Velocity:</b> Cruise velocity for profiling.  The signage does
     *                           not matter as the device will use the absolute
     *                           value for profile generation.  Setting this to 0
     *                           will allow the profile to run to the max possible
     *                           velocity based on Expo_kV.
     *     <li> <b>FeedForward:</b> Feedforward to apply in torque current in
     *                              Amperes. This is added to the output of the
     *                              onboard feedforward terms.
     *                              <p>
     *                              User can use motor's kT to scale Newton-meter to
     *                              Amperes.
     *     <li> <b>Slot:</b> Select which gains are applied by selecting the slot. 
     *                       Use the configuration api to set the gain values for
     *                       the selected slot before enabling this feature. Slot
     *                       must be within [0,2].
     *     <li> <b>OverrideCoastDurNeutral:</b> Set to true to coast the rotor when
     *                                          output is zero (or within deadband).
     *                                           Set to false to use the NeutralMode
     *                                          configuration setting (default).
     *                                          This flag exists to provide the
     *                                          fundamental behavior of this control
     *                                          when output is zero, which is to
     *                                          provide 0A (zero torque).
     *     <li> <b>LimitForwardMotion:</b> Set to true to force forward limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>LimitReverseMotion:</b> Set to true to force reverse limiting. 
     *                                     This allows users to use other limit
     *                                     switch sensors connected to robot
     *                                     controller.  This also allows use of
     *                                     active sensors that require external
     *                                     power.
     *     <li> <b>IgnoreHardwareLimits:</b> Set to true to ignore hardware limit
     *                                       switches and the LimitForwardMotion and
     *                                       LimitReverseMotion parameters, instead
     *                                       allowing motion.
     *                                       <p>
     *                                       This can be useful on mechanisms such
     *                                       as an intake/feeder, where a limit
     *                                       switch stops motion while intaking but
     *                                       should be ignored when feeding to a
     *                                       shooter.
     *                                       <p>
     *                                       The hardware limit faults and
     *                                       Forward/ReverseLimit signals will still
     *                                       report the values of the limit switches
     *                                       regardless of this parameter.
     *     <li> <b>IgnoreSoftwareLimits:</b> Set to true to ignore software limits,
     *                                       instead allowing motion.
     *                                       <p>
     *                                       This can be useful when calibrating the
     *                                       zero point of a mechanism such as an
     *                                       elevator.
     *                                       <p>
     *                                       The software limit faults will still
     *                                       report the values of the software
     *                                       limits regardless of this parameter.
     *     <li> <b>UseTimesync:</b> Set to true to delay applying this control
     *                              request until a timesync boundary (requires
     *                              Phoenix Pro and CANivore). This eliminates the
     *                              impact of nondeterministic network delays in
     *                              exchange for a larger but deterministic control
     *                              latency.
     *                              <p>
     *                              This requires setting the ControlTimesyncFreqHz
     *                              config in MotorOutputConfigs. Additionally, when
     *                              this is enabled, the UpdateFreqHz of this
     *                              request should be set to 0 Hz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(DynamicMotionMagicExpoTorqueCurrentFOC request);
    
    /**
     * Differential control with torque current average target and
     * position difference target.
     * <ul>
     *   <li> <b>Diff_TorqueCurrentFOC_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average TorqueCurrentFOC request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_TorqueCurrentFOC_Position request);
    
    /**
     * Differential control with position average target and position
     * difference target using torque current control.
     * <ul>
     *   <li> <b>Diff_PositionTorqueCurrentFOC_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average PositionTorqueCurrentFOC request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_PositionTorqueCurrentFOC_Position request);
    
    /**
     * Differential control with velocity average target and position
     * difference target using torque current control.
     * <ul>
     *   <li> <b>Diff_VelocityTorqueCurrentFOC_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VelocityTorqueCurrentFOC request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VelocityTorqueCurrentFOC_Position request);
    
    /**
     * Differential control with Motion Magic® average target and position
     * difference target using torque current control.
     * <ul>
     *   <li> <b>Diff_MotionMagicTorqueCurrentFOC_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicTorqueCurrentFOC request
     *                                 of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicTorqueCurrentFOC_Position request);
    
    /**
     * Differential control with Motion Magic® Expo average target and
     * position difference target using torque current control.
     * <ul>
     *   <li> <b>Diff_MotionMagicExpoTorqueCurrentFOC_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicExpoTorqueCurrentFOC
     *                                 request of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicExpoTorqueCurrentFOC_Position request);
    
    /**
     * Differential control with Motion Magic® Velocity average target and
     * position difference target using torque current control.
     * <ul>
     *   <li> <b>Diff_MotionMagicVelocityTorqueCurrentFOC_Position Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVelocityTorqueCurrentFOC
     *                                 request of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential PositionTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVelocityTorqueCurrentFOC_Position request);
    
    /**
     * Differential control with torque current average target and
     * velocity difference target.
     * <ul>
     *   <li> <b>Diff_TorqueCurrentFOC_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average TorqueCurrentFOC request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_TorqueCurrentFOC_Velocity request);
    
    /**
     * Differential control with position average target and velocity
     * difference target using torque current control.
     * <ul>
     *   <li> <b>Diff_PositionTorqueCurrentFOC_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average PositionTorqueCurrentFOC request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_PositionTorqueCurrentFOC_Velocity request);
    
    /**
     * Differential control with velocity average target and velocity
     * difference target using torque current control.
     * <ul>
     *   <li> <b>Diff_VelocityTorqueCurrentFOC_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VelocityTorqueCurrentFOC request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VelocityTorqueCurrentFOC_Velocity request);
    
    /**
     * Differential control with Motion Magic® average target and velocity
     * difference target using torque current control.
     * <ul>
     *   <li> <b>Diff_MotionMagicTorqueCurrentFOC_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicTorqueCurrentFOC request
     *                                 of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicTorqueCurrentFOC_Velocity request);
    
    /**
     * Differential control with Motion Magic® Expo average target and
     * velocity difference target using torque current control.
     * <ul>
     *   <li> <b>Diff_MotionMagicExpoTorqueCurrentFOC_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicExpoTorqueCurrentFOC
     *                                 request of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicExpoTorqueCurrentFOC_Velocity request);
    
    /**
     * Differential control with Motion Magic® Velocity average target and
     * velocity difference target using torque current control.
     * <ul>
     *   <li> <b>Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVelocityTorqueCurrentFOC
     *                                 request of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential VelocityTorqueCurrentFOC
     *                                      request of the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity request);
    
    /**
     * Differential control with torque current average target and torque
     * current difference target.
     * <ul>
     *   <li> <b>Diff_TorqueCurrentFOC_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average TorqueCurrentFOC request of the
     *                                 mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential TorqueCurrentFOC request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_TorqueCurrentFOC_Open request);
    
    /**
     * Differential control with position average target and torque
     * current difference target.
     * <ul>
     *   <li> <b>Diff_PositionTorqueCurrentFOC_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average PositionTorqueCurrentFOC request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential TorqueCurrentFOC request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_PositionTorqueCurrentFOC_Open request);
    
    /**
     * Differential control with velocity average target and torque
     * current difference target.
     * <ul>
     *   <li> <b>Diff_VelocityTorqueCurrentFOC_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average VelocityTorqueCurrentFOC request of
     *                                 the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential TorqueCurrentFOC request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_VelocityTorqueCurrentFOC_Open request);
    
    /**
     * Differential control with Motion Magic® average target and torque
     * current difference target.
     * <ul>
     *   <li> <b>Diff_MotionMagicTorqueCurrentFOC_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicTorqueCurrentFOC request
     *                                 of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential TorqueCurrentFOC request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicTorqueCurrentFOC_Open request);
    
    /**
     * Differential control with Motion Magic® Expo average target and
     * torque current difference target.
     * <ul>
     *   <li> <b>Diff_MotionMagicExpoTorqueCurrentFOC_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicExpoTorqueCurrentFOC
     *                                 request of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential TorqueCurrentFOC request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicExpoTorqueCurrentFOC_Open request);
    
    /**
     * Differential control with Motion Magic® Velocity average target and
     * torque current difference target.
     * <ul>
     *   <li> <b>Diff_MotionMagicVelocityTorqueCurrentFOC_Open Parameters:</b> 
     *   <ul>
     *     <li> <b>AverageRequest:</b> Average MotionMagicVelocityTorqueCurrentFOC
     *                                 request of the mechanism.
     *     <li> <b>DifferentialRequest:</b> Differential TorqueCurrentFOC request of
     *                                      the mechanism.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(Diff_MotionMagicVelocityTorqueCurrentFOC_Open request);

    /**
     * Control device with generic control request object.
     * <p>
     * User must make sure the specified object is castable to a valid control request,
     * otherwise this function will fail at run-time and return the NotSupported StatusCode
     *
     * @param request Control object to request of the device
     * @return Status Code of the request, 0 is OK
     */
    StatusCode setControl(ControlRequest request);
    
}

