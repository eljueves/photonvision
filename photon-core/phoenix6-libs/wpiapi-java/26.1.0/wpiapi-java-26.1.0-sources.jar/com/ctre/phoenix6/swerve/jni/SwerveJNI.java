/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.swerve.jni;

import java.util.function.IntSupplier;

import com.ctre.phoenix6.jni.CtreJniWrapper;

public class SwerveJNI extends CtreJniWrapper implements Cloneable {
    public static class ModuleState {
        public double speed = 0;
        public double angle = 0;
    }
    public static class ModulePosition {
        public double distance = 0;
        public double angle = 0;
    }
    public static class DriveState implements Cloneable {
        /** The current pose of the robot */
        public double PoseX;
        public double PoseY;
        public double PoseTheta;
        /** The current velocity of the robot */
        public double SpeedsVx;
        public double SpeedsVy;
        public double SpeedsOmega;
        /** The current module states */
        public ModuleState[] ModuleStates;
        /** The target module states */
        public ModuleState[] ModuleTargets;
        /** The current module positions */
        public ModulePosition[] ModulePositions;
        /** The raw heading of the robot, unaffected by vision updates and odometry resets */
        public double RawHeading;
        /** The timestamp of the state capture, in seconds */
        public double Timestamp;
        /** The measured odometry update period, in seconds */
        public double OdometryPeriod;
        /** Number of successful data acquisitions */
        public int SuccessfulDaqs;
        /** Number of failed data acquisitions */
        public int FailedDaqs;

        @Override
        public DriveState clone() {
            final DriveState toReturn = new DriveState();

            toReturn.ModuleStates = new ModuleState[ModuleStates.length];
            for (int i = 0; i < ModuleStates.length; ++i) {
                toReturn.ModuleStates[i] = new ModuleState();
            }
            toReturn.ModuleTargets = new ModuleState[ModuleTargets.length];
            for (int i = 0; i < ModuleTargets.length; ++i) {
                toReturn.ModuleTargets[i] = new ModuleState();
            }
            toReturn.ModulePositions = new ModulePosition[ModulePositions.length];
            for (int i = 0; i < ModulePositions.length; ++i) {
                toReturn.ModulePositions[i] = new ModulePosition();
            }

            return toReturn;
        }
    }
    public static class ControlParams {
        /* Max speed in m/s */
        public double kMaxSpeedMps;
        /* Operator forward direction in radians */
        public double operatorForwardDirection;
        /* Current chassis speeds of the robot */
        public double currentChassisSpeedVx;
        public double currentChassisSpeedVy;
        public double currentChassisSpeedOmega;
        /* Current pose of the robot */
        public double currentPoseX;
        public double currentPoseY;
        public double currentPoseTheta;
        /* Current time */
        public double timestamp;
        /* Update rate */
        public double updatePeriod;
    }
    public static class ModuleApplyParams {
        /* Speed and direction the module should target */
        public ModuleState state = new ModuleState();
        /* Robot-relative wheel force feedforward to apply in the X direction */
        public double wheelForceFeedforwardX = 0.0;
        /* Robot-relative wheel force feedforward to apply in the Y direction */
        public double wheelForceFeedforwardY = 0.0;
        /* The type of control request to use for the drive motor */
        public int driveRequest = 0;
        /* The type of control request to use for the steer motor */
        public int steerRequest = 0;
        /* The update period of the module request */
        public double updatePeriod = 0.0;
        /* Whether to use FOC for Voltage-based control */
        public boolean enableFOC = true;
    }

    public DriveState driveState = new DriveState();
    public ControlParams controlParams = new ControlParams();

    public ModuleApplyParams moduleApplyParams = new ModuleApplyParams();
    public ModuleState moduleState = new ModuleState();
    public ModulePosition modulePosition = new ModulePosition();

    @Override
    public SwerveJNI clone() {
        SwerveJNI toReturn = new SwerveJNI();
        toReturn.driveState = driveState.clone();
        return toReturn;
    }

    public static native int JNI_CreateDrivetrain(long drivetrainConstants, long moduleConstants, int numModules);
    public static native int JNI_CreateDrivetrainWithFreq(long drivetrainConstants, double odometryUpdateFreqHz, long moduleConstants, int numModules);
    public static native int JNI_CreateDrivetrainWithStddev(long drivetrainConstants, double odometryUpdateFreqHz, double[] odometryStandardDeviation,
            double[] visionStandardDeviation, long moduleConstants, int numModules);
    public static native void JNI_DestroyDrivetrain(int id);

    public static native boolean JNI_IsOnCANFD(int id);
    public static native double JNI_GetOdometryFrequency(int id);
    public static native boolean JNI_IsOdometryValid(int id);
    public native long JNI_SetControl(int id, IntSupplier request);
    public static native void JNI_DestroyControl(long handle);
    public native void JNI_GetState(int id);
    public native long JNI_RegisterTelemetry(int id, Runnable telemetryFunc);
    public static native void JNI_DestroyTelemetry(long handle);
    public static native int JNI_ConfigNeutralMode(int id, int neutralMode);
    public static native int JNI_ConfigNeutralModeWithTimeout(int id, int neutralMode, double timeoutSeconds);
    public static native void JNI_TareEverything(int id);
    public static native void JNI_SeedFieldCentric(int id, double rotationRad);
    public static native void JNI_ResetPose(int id, double xMeters, double yMeters, double rotationRad);
    public static native void JNI_ResetTranslation(int id, double xMeters, double yMeters);
    public static native void JNI_ResetRotation(int id, double rotationRad);
    public static native void JNI_SetOperatorPerspectiveForward(int id, double rotationRad);
    public static native double JNI_GetOperatorForwardDirection(int id);
    public static native void JNI_AddVisionMeasurement(int id, double xMeters, double yMeters, double rotationRad, double timestampSeconds);
    public static native void JNI_AddVisionMeasurementWithStdDev(int id, double xMeters, double yMeters, double rotationRad,
            double timestampSeconds, double[] visionMeasurementStdDevs);
    public static native void JNI_SetVisionMeasurementStdDevs(int id, double[] visionMeasurementStdDevs);
    public static native void JNI_SetStateStdDevs(int id, double[] stateStdDevs);
    public static native double[] JNI_SamplePoseAt(int id, double timestampSeconds);

    public static native void JNI_Odom_Start(int id);
    public static native void JNI_Odom_Stop(int id);
    public static native void JNI_Odom_SetThreadPriority(int id, int priority);

    public native void JNI_Module_Apply(int id, int idx);
    public native void JNI_Module_GetPosition(int id, int idx, boolean refresh);
    public native void JNI_Module_GetCachedPosition(int id, int idx);
    public native void JNI_Module_GetCurrentState(int id, int idx);
    public native void JNI_Module_GetTargetState(int id, int idx);
    public static native void JNI_Module_ResetPosition(int id, int idx);

    public static native long JNI_CreateDrivetrainConstants(
        String canbusName,
        int pigeon2Id);
    public static native long JNI_CreateModuleConstantsArr(long numModules);
    public static native void JNI_SetModuleConstants(
        long constantsArr,
        long moduleIdx,
        int steerMotorId,
        int driveMotorId,
        int encoderId,
        double encoderOffset_tr,
        double locationX_m,
        double locationY_m,
        boolean driveMotorInverted,
        boolean steerMotorInverted,
        boolean encoderInverted,
        double driveMotorGearRatio,
        double steerMotorGearRatio,
        double couplingGearRatio,
        double wheelRadius_m,
        int steerMotorClosedLoopOutput,
        int driveMotorClosedLoopOutput,
        double slipCurrent_A,
        double speedAt12Volts_mps,
        int driveMotorType,
        int steerMotorType,
        int feedbackSource,
        double steerInertia_kg_sq_m,
        double driveInertia_kg_sq_m,
        double steerFrictionVoltage_V,
        double driveFrictionVoltage_V);
    public static native void JNI_DestroyConstants(long constants);

    public static native void JNI_SetControl_Idle(
        int id);
    public static native int JNI_Request_Apply_Idle(
        int id);
    public static native void JNI_SetControl_SwerveDriveBrake(
        int id,
        int driveRequestType,
        int steerRequestType);
    public static native int JNI_Request_Apply_SwerveDriveBrake(
        int id,
        int driveRequestType,
        int steerRequestType);
    public static native void JNI_SetControl_FieldCentric(
        int id,
        double velocityX_mps,
        double velocityY_mps,
        double rotationalRate_rad_per_s,
        double deadband_mps,
        double rotationalDeadband_rad_per_s,
        double centerOfRotationX,
        double centerOfRotationY,
        int driveRequestType,
        int steerRequestType,
        boolean desaturateWheelSpeeds,
        int forwardPerspective);
    public static native int JNI_Request_Apply_FieldCentric(
        int id,
        double velocityX_mps,
        double velocityY_mps,
        double rotationalRate_rad_per_s,
        double deadband_mps,
        double rotationalDeadband_rad_per_s,
        double centerOfRotationX,
        double centerOfRotationY,
        int driveRequestType,
        int steerRequestType,
        boolean desaturateWheelSpeeds,
        int forwardPerspective);
    public static native void JNI_SetControl_RobotCentric(
        int id,
        double velocityX_mps,
        double velocityY_mps,
        double rotationalRate_rad_per_s,
        double deadband_mps,
        double rotationalDeadband_rad_per_s,
        double centerOfRotationX,
        double centerOfRotationY,
        int driveRequestType,
        int steerRequestType,
        boolean desaturateWheelSpeeds);
    public static native int JNI_Request_Apply_RobotCentric(
        int id,
        double velocityX_mps,
        double velocityY_mps,
        double rotationalRate_rad_per_s,
        double deadband_mps,
        double rotationalDeadband_rad_per_s,
        double centerOfRotationX,
        double centerOfRotationY,
        int driveRequestType,
        int steerRequestType,
        boolean desaturateWheelSpeeds);
    public static native void JNI_SetControl_PointWheelsAt(
        int id,
        double moduleDirection,
        int driveRequestType,
        int steerRequestType);
    public static native int JNI_Request_Apply_PointWheelsAt(
        int id,
        double moduleDirection,
        int driveRequestType,
        int steerRequestType);
    public static native void JNI_SetControl_ApplyRobotSpeeds(
        int id,
        double speedsVx,
        double speedsVy,
        double speedsOmega,
        double[] wheelForceFeedforwardsX_N,
        double[] wheelForceFeedforwardsY_N,
        double centerOfRotationX,
        double centerOfRotationY,
        int driveRequestType,
        int steerRequestType,
        boolean desaturateWheelSpeeds);
    public static native int JNI_Request_Apply_ApplyRobotSpeeds(
        int id,
        double speedsVx,
        double speedsVy,
        double speedsOmega,
        double[] wheelForceFeedforwardsX_N,
        double[] wheelForceFeedforwardsY_N,
        double centerOfRotationX,
        double centerOfRotationY,
        int driveRequestType,
        int steerRequestType,
        boolean desaturateWheelSpeeds);
    public static native void JNI_SetControl_ApplyFieldSpeeds(
        int id,
        double speedsVx,
        double speedsVy,
        double speedsOmega,
        double[] wheelForceFeedforwardsX_N,
        double[] wheelForceFeedforwardsY_N,
        double centerOfRotationX,
        double centerOfRotationY,
        int driveRequestType,
        int steerRequestType,
        boolean desaturateWheelSpeeds,
        int forwardPerspective);
    public static native int JNI_Request_Apply_ApplyFieldSpeeds(
        int id,
        double speedsVx,
        double speedsVy,
        double speedsOmega,
        double[] wheelForceFeedforwardsX_N,
        double[] wheelForceFeedforwardsY_N,
        double centerOfRotationX,
        double centerOfRotationY,
        int driveRequestType,
        int steerRequestType,
        boolean desaturateWheelSpeeds,
        int forwardPerspective);
}
