/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs that affect the closed-loop control of this motor
 * controller.
 * <p>
 * Closed-loop ramp rates for the various control types.
 */
public class ClosedLoopRampsConfigs implements ParentConfiguration, Cloneable {
    /**
     * If non-zero, this determines how much time to ramp from 0% output
     * to 100% during the closed-loop DutyCycle control modes.
     * <p>
     * If the goal is to limit acceleration, it is more useful to ramp the
     * closed-loop setpoint instead of the output. This can be achieved
     * using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     */
    public double DutyCycleClosedLoopRampPeriod = 0;
    /**
     * If non-zero, this determines how much time to ramp from 0V output
     * to 12V during the closed-loop Voltage control modes.
     * <p>
     * If the goal is to limit acceleration, it is more useful to ramp the
     * closed-loop setpoint instead of the output. This can be achieved
     * using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     */
    public double VoltageClosedLoopRampPeriod = 0;
    /**
     * If non-zero, this determines how much time to ramp from 0A output
     * to 300A during the closed-loop TorqueCurrent control modes.
     * <p>
     * Since TorqueCurrent is directly proportional to acceleration, this
     * ramp limits jerk instead of acceleration.
     * <p>
     * If the goal is to limit acceleration or jerk, it is more useful to
     * ramp the closed-loop setpoint instead of the output. This can be
     * achieved using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 10
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     */
    public double TorqueClosedLoopRampPeriod = 0;
    
    /**
     * Modifies this configuration's DutyCycleClosedLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0% output
     * to 100% during the closed-loop DutyCycle control modes.
     * <p>
     * If the goal is to limit acceleration, it is more useful to ramp the
     * closed-loop setpoint instead of the output. This can be achieved
     * using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newDutyCycleClosedLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final ClosedLoopRampsConfigs withDutyCycleClosedLoopRampPeriod(double newDutyCycleClosedLoopRampPeriod)
    {
        DutyCycleClosedLoopRampPeriod = newDutyCycleClosedLoopRampPeriod;
        return this;
    }
    
    /**
     * Modifies this configuration's DutyCycleClosedLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0% output
     * to 100% during the closed-loop DutyCycle control modes.
     * <p>
     * If the goal is to limit acceleration, it is more useful to ramp the
     * closed-loop setpoint instead of the output. This can be achieved
     * using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newDutyCycleClosedLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final ClosedLoopRampsConfigs withDutyCycleClosedLoopRampPeriod(Time newDutyCycleClosedLoopRampPeriod)
    {
        DutyCycleClosedLoopRampPeriod = newDutyCycleClosedLoopRampPeriod.in(Seconds);
        return this;
    }
    
    /**
     * Helper method to get this configuration's DutyCycleClosedLoopRampPeriod parameter converted
     * to a unit type. If not using the Java units library, {@link #DutyCycleClosedLoopRampPeriod}
     * can be accessed directly instead.
     * <p>
     * If non-zero, this determines how much time to ramp from 0% output
     * to 100% during the closed-loop DutyCycle control modes.
     * <p>
     * If the goal is to limit acceleration, it is more useful to ramp the
     * closed-loop setpoint instead of the output. This can be achieved
     * using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @return DutyCycleClosedLoopRampPeriod
     */
    public final Time getDutyCycleClosedLoopRampPeriodMeasure()
    {
        return Seconds.of(DutyCycleClosedLoopRampPeriod);
    }
    
    /**
     * Modifies this configuration's VoltageClosedLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0V output
     * to 12V during the closed-loop Voltage control modes.
     * <p>
     * If the goal is to limit acceleration, it is more useful to ramp the
     * closed-loop setpoint instead of the output. This can be achieved
     * using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newVoltageClosedLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final ClosedLoopRampsConfigs withVoltageClosedLoopRampPeriod(double newVoltageClosedLoopRampPeriod)
    {
        VoltageClosedLoopRampPeriod = newVoltageClosedLoopRampPeriod;
        return this;
    }
    
    /**
     * Modifies this configuration's VoltageClosedLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0V output
     * to 12V during the closed-loop Voltage control modes.
     * <p>
     * If the goal is to limit acceleration, it is more useful to ramp the
     * closed-loop setpoint instead of the output. This can be achieved
     * using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newVoltageClosedLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final ClosedLoopRampsConfigs withVoltageClosedLoopRampPeriod(Time newVoltageClosedLoopRampPeriod)
    {
        VoltageClosedLoopRampPeriod = newVoltageClosedLoopRampPeriod.in(Seconds);
        return this;
    }
    
    /**
     * Helper method to get this configuration's VoltageClosedLoopRampPeriod parameter converted
     * to a unit type. If not using the Java units library, {@link #VoltageClosedLoopRampPeriod}
     * can be accessed directly instead.
     * <p>
     * If non-zero, this determines how much time to ramp from 0V output
     * to 12V during the closed-loop Voltage control modes.
     * <p>
     * If the goal is to limit acceleration, it is more useful to ramp the
     * closed-loop setpoint instead of the output. This can be achieved
     * using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @return VoltageClosedLoopRampPeriod
     */
    public final Time getVoltageClosedLoopRampPeriodMeasure()
    {
        return Seconds.of(VoltageClosedLoopRampPeriod);
    }
    
    /**
     * Modifies this configuration's TorqueClosedLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0A output
     * to 300A during the closed-loop TorqueCurrent control modes.
     * <p>
     * Since TorqueCurrent is directly proportional to acceleration, this
     * ramp limits jerk instead of acceleration.
     * <p>
     * If the goal is to limit acceleration or jerk, it is more useful to
     * ramp the closed-loop setpoint instead of the output. This can be
     * achieved using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 10
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newTorqueClosedLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final ClosedLoopRampsConfigs withTorqueClosedLoopRampPeriod(double newTorqueClosedLoopRampPeriod)
    {
        TorqueClosedLoopRampPeriod = newTorqueClosedLoopRampPeriod;
        return this;
    }
    
    /**
     * Modifies this configuration's TorqueClosedLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0A output
     * to 300A during the closed-loop TorqueCurrent control modes.
     * <p>
     * Since TorqueCurrent is directly proportional to acceleration, this
     * ramp limits jerk instead of acceleration.
     * <p>
     * If the goal is to limit acceleration or jerk, it is more useful to
     * ramp the closed-loop setpoint instead of the output. This can be
     * achieved using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 10
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newTorqueClosedLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final ClosedLoopRampsConfigs withTorqueClosedLoopRampPeriod(Time newTorqueClosedLoopRampPeriod)
    {
        TorqueClosedLoopRampPeriod = newTorqueClosedLoopRampPeriod.in(Seconds);
        return this;
    }
    
    /**
     * Helper method to get this configuration's TorqueClosedLoopRampPeriod parameter converted
     * to a unit type. If not using the Java units library, {@link #TorqueClosedLoopRampPeriod}
     * can be accessed directly instead.
     * <p>
     * If non-zero, this determines how much time to ramp from 0A output
     * to 300A during the closed-loop TorqueCurrent control modes.
     * <p>
     * Since TorqueCurrent is directly proportional to acceleration, this
     * ramp limits jerk instead of acceleration.
     * <p>
     * If the goal is to limit acceleration or jerk, it is more useful to
     * ramp the closed-loop setpoint instead of the output. This can be
     * achieved using Motion Magic® controls.
     * <p>
     * The acceleration and current draw of the motor can also be better
     * restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 10
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @return TorqueClosedLoopRampPeriod
     */
    public final Time getTorqueClosedLoopRampPeriodMeasure()
    {
        return Seconds.of(TorqueClosedLoopRampPeriod);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: ClosedLoopRamps\n";
        ss += "    DutyCycleClosedLoopRampPeriod: " + DutyCycleClosedLoopRampPeriod + " seconds" + "\n";
        ss += "    VoltageClosedLoopRampPeriod: " + VoltageClosedLoopRampPeriod + " seconds" + "\n";
        ss += "    TorqueClosedLoopRampPeriod: " + TorqueClosedLoopRampPeriod + " seconds" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_DutyCycleClosedLoopRampPeriod.value, DutyCycleClosedLoopRampPeriod);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_VoltageClosedLoopRampPeriod.value, VoltageClosedLoopRampPeriod);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_TorqueClosedLoopRampPeriod.value, TorqueClosedLoopRampPeriod);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        DutyCycleClosedLoopRampPeriod = ConfigJNI.Deserializedouble(SpnValue.Config_DutyCycleClosedLoopRampPeriod.value, to_deserialize);
        VoltageClosedLoopRampPeriod = ConfigJNI.Deserializedouble(SpnValue.Config_VoltageClosedLoopRampPeriod.value, to_deserialize);
        TorqueClosedLoopRampPeriod = ConfigJNI.Deserializedouble(SpnValue.Config_TorqueClosedLoopRampPeriod.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public ClosedLoopRampsConfigs clone() {
        try {
            return (ClosedLoopRampsConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

