/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether the device is Season Pass licensed.
 */
public enum Licensing_IsSeasonPassedValue
{
    NotLicensed(0),
    Licensed(1),;

    public final int value;

    Licensing_IsSeasonPassedValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, Licensing_IsSeasonPassedValue> _map = null;
    static
    {
        _map = new HashMap<Integer, Licensing_IsSeasonPassedValue>();
        for (Licensing_IsSeasonPassedValue type : Licensing_IsSeasonPassedValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets Licensing_IsSeasonPassedValue from specified value
     * @param value Value of Licensing_IsSeasonPassedValue
     * @return Licensing_IsSeasonPassedValue of specified value
     */
    public static Licensing_IsSeasonPassedValue valueOf(int value)
    {
        Licensing_IsSeasonPassedValue retval = _map.get(value);
        if (retval != null) return retval;
        return Licensing_IsSeasonPassedValue.values()[0];
    }
}
