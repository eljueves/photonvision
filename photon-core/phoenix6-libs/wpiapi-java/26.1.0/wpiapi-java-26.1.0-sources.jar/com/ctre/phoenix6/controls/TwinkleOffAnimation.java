/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.jni.ControlJNI;
import com.ctre.phoenix6.hardware.traits.*;
import com.ctre.phoenix6.signals.*;

import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Animation that randomly turns on LEDs until it reaches the maximum count, and
 * then turns them all off.
 * <p>
 * 
 */
public final class TwinkleOffAnimation implements ControlRequest, Cloneable {
    /**
     * The index of the first LED this animation controls (inclusive). Indices 0-7
     * control the onboard LEDs, and 8-399 control an attached LED strip.
     */
    public int LEDStartIndex;
    /**
     * The index of the last LED this animation controls (inclusive). Indices 0-7
     * control the onboard LEDs, and 8-399 control an attached LED strip.
     */
    public int LEDEndIndex;
    /**
     * The slot of this animation, within [0, 7]. Each slot on the CANdle can store
     * and run one animation.
     */
    public int Slot = 0;
    /**
     * The color to use in the animation.
     */
    public RGBWColor Color = new RGBWColor();
    /**
     * The max proportion of LEDs that can be on, in the range [0.1, 1.0].
     */
    public double MaxLEDsOnProportion = 1.0;
    /**
     * The frame rate of the animation, from [2, 1000] Hz. This determines the speed
     * of the animation.
     * <p>
     * A frame is defined as a transition in the state of the LEDs, turning one LED
     * on or all LEDs off.
     * 
     * <ul>
     *   <li> Units: Hz
     * </ul>
     * 
     */
    public double FrameRate = 25;

    /**
     * The frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     */
    public double UpdateFreqHz = 20;

    /**
     * Animation that randomly turns on LEDs until it reaches the maximum count, and
     * then turns them all off.
     * <p>
     * 
     * 
     * @param LEDStartIndex The index of the first LED this animation controls
     *                      (inclusive). Indices 0-7 control the onboard LEDs, and
     *                      8-399 control an attached LED strip.
     * @param LEDEndIndex The index of the last LED this animation controls
     *                    (inclusive). Indices 0-7 control the onboard LEDs, and
     *                    8-399 control an attached LED strip.
     */
    public TwinkleOffAnimation(int LEDStartIndex, int LEDEndIndex) {
        this.LEDStartIndex = LEDStartIndex;
        this.LEDEndIndex = LEDEndIndex;
    }

    @Override
    public String getName() {
        return "TwinkleOffAnimation";
    }

    @Override
    public String toString() {
        String ss = "Control: TwinkleOffAnimation\n";
        ss += "    LEDStartIndex: " + LEDStartIndex + "\n";
        ss += "    LEDEndIndex: " + LEDEndIndex + "\n";
        ss += "    Slot: " + Slot + "\n";
        ss += "    Color: " + Color + "\n";
        ss += "    MaxLEDsOnProportion: " + MaxLEDsOnProportion + "\n";
        ss += "    FrameRate: " + FrameRate + " Hz" + "\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlTwinkleOffAnimation(
                network, deviceHash, UpdateFreqHz, LEDStartIndex, LEDEndIndex, Slot, Color.Red, Color.Green, Color.Blue, Color.White, MaxLEDsOnProportion, FrameRate));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String, String>();
        controlInfo.put("Name", getName());
        controlInfo.put("LEDStartIndex", String.valueOf(this.LEDStartIndex));
        controlInfo.put("LEDEndIndex", String.valueOf(this.LEDEndIndex));
        controlInfo.put("Slot", String.valueOf(this.Slot));
        controlInfo.put("Color", String.valueOf(this.Color));
        controlInfo.put("MaxLEDsOnProportion", String.valueOf(this.MaxLEDsOnProportion));
        controlInfo.put("FrameRate", String.valueOf(this.FrameRate));
        return controlInfo;
    }
    
    /**
     * Modifies this Control Request's LEDStartIndex parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * The index of the first LED this animation controls (inclusive). Indices 0-7
     * control the onboard LEDs, and 8-399 control an attached LED strip.
     *
     * @param newLEDStartIndex Parameter to modify
     * @return Itself
     */
    public TwinkleOffAnimation withLEDStartIndex(int newLEDStartIndex) {
        LEDStartIndex = newLEDStartIndex;
        return this;
    }
    
    /**
     * Modifies this Control Request's LEDEndIndex parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * The index of the last LED this animation controls (inclusive). Indices 0-7
     * control the onboard LEDs, and 8-399 control an attached LED strip.
     *
     * @param newLEDEndIndex Parameter to modify
     * @return Itself
     */
    public TwinkleOffAnimation withLEDEndIndex(int newLEDEndIndex) {
        LEDEndIndex = newLEDEndIndex;
        return this;
    }
    
    /**
     * Modifies this Control Request's Slot parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * The slot of this animation, within [0, 7]. Each slot on the CANdle can store
     * and run one animation.
     *
     * @param newSlot Parameter to modify
     * @return Itself
     */
    public TwinkleOffAnimation withSlot(int newSlot) {
        Slot = newSlot;
        return this;
    }
    
    /**
     * Modifies this Control Request's Color parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * The color to use in the animation.
     *
     * @param newColor Parameter to modify
     * @return Itself
     */
    public TwinkleOffAnimation withColor(RGBWColor newColor) {
        Color = newColor;
        return this;
    }
    
    /**
     * Modifies this Control Request's MaxLEDsOnProportion parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * The max proportion of LEDs that can be on, in the range [0.1, 1.0].
     *
     * @param newMaxLEDsOnProportion Parameter to modify
     * @return Itself
     */
    public TwinkleOffAnimation withMaxLEDsOnProportion(double newMaxLEDsOnProportion) {
        MaxLEDsOnProportion = newMaxLEDsOnProportion;
        return this;
    }
    
    /**
     * Modifies this Control Request's FrameRate parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * The frame rate of the animation, from [2, 1000] Hz. This determines the speed
     * of the animation.
     * <p>
     * A frame is defined as a transition in the state of the LEDs, turning one LED
     * on or all LEDs off.
     * 
     * <ul>
     *   <li> Units: Hz
     * </ul>
     * 
     *
     * @param newFrameRate Parameter to modify
     * @return Itself
     */
    public TwinkleOffAnimation withFrameRate(double newFrameRate) {
        FrameRate = newFrameRate;
        return this;
    }
    
    /**
     * Modifies this Control Request's FrameRate parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * The frame rate of the animation, from [2, 1000] Hz. This determines the speed
     * of the animation.
     * <p>
     * A frame is defined as a transition in the state of the LEDs, turning one LED
     * on or all LEDs off.
     * 
     * <ul>
     *   <li> Units: Hz
     * </ul>
     * 
     *
     * @param newFrameRate Parameter to modify
     * @return Itself
     */
    public TwinkleOffAnimation withFrameRate(Frequency newFrameRate) {
        FrameRate = newFrameRate.in(Hertz);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's FrameRate parameter converted
     * to a unit type. If not using the Java units library, {@link #FrameRate}
     * can be accessed directly instead.
     * <p>
     * The frame rate of the animation, from [2, 1000] Hz. This determines the speed
     * of the animation.
     * <p>
     * A frame is defined as a transition in the state of the LEDs, turning one LED
     * on or all LEDs off.
     * 
     * <ul>
     *   <li> Units: Hz
     * </ul>
     * 
     *
     * @return FrameRate
     */
    public Frequency getFrameRateMeasure() {
        return Hertz.of(FrameRate);
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public TwinkleOffAnimation withUpdateFreqHz(double newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public TwinkleOffAnimation withUpdateFreqHz(Frequency newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz.in(Hertz);
        return this;
    }

    @Override
    public TwinkleOffAnimation clone() {
        try {
            return (TwinkleOffAnimation)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

