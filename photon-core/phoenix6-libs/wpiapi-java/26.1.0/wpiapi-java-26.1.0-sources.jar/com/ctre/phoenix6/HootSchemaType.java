/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6;

/**
 * Supported schema types for a hoot user signal.
 */
public enum HootSchemaType {
    /**
     * Serialize using the WPILib Struct format.
     */
    Struct(1),
    /**
     * Serialize using the Protobuf format.
     */
    Protobuf(2);

    public final int value;

    HootSchemaType(int value) {
        this.value = value;
    }
}
