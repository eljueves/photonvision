/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs that affect the ToF Field of View
 * <p>
 * Includes range and center configs
 */
public class FovParamsConfigs implements ParentConfiguration, Cloneable {
    /**
     * Specifies the target center of the Field of View in the X
     * direction.
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -11.8
     *   <li> <b>Maximum Value:</b> 11.8
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     */
    public double FOVCenterX = 0;
    /**
     * Specifies the target center of the Field of View in the Y
     * direction.
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -11.8
     *   <li> <b>Maximum Value:</b> 11.8
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     */
    public double FOVCenterY = 0;
    /**
     * Specifies the target range of the Field of View in the X direction.
     * This is the full range of the FOV.
     * <p>
     * The magnitude of this is capped to abs(27 - 2*FOVCenterX).
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 6.75
     *   <li> <b>Maximum Value:</b> 27
     *   <li> <b>Default Value:</b> 27
     *   <li> <b>Units:</b> deg
     * </ul>
     */
    public double FOVRangeX = 27;
    /**
     * Specifies the target range of the Field of View in the Y direction.
     * This is the full range of the FOV.
     * <p>
     * The magnitude of this is capped to abs(27 - 2*FOVCenterY).
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 6.75
     *   <li> <b>Maximum Value:</b> 27
     *   <li> <b>Default Value:</b> 27
     *   <li> <b>Units:</b> deg
     * </ul>
     */
    public double FOVRangeY = 27;
    
    /**
     * Modifies this configuration's FOVCenterX parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Specifies the target center of the Field of View in the X
     * direction.
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -11.8
     *   <li> <b>Maximum Value:</b> 11.8
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newFOVCenterX Parameter to modify
     * @return Itself
     */
    public final FovParamsConfigs withFOVCenterX(double newFOVCenterX)
    {
        FOVCenterX = newFOVCenterX;
        return this;
    }
    
    /**
     * Modifies this configuration's FOVCenterX parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Specifies the target center of the Field of View in the X
     * direction.
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -11.8
     *   <li> <b>Maximum Value:</b> 11.8
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newFOVCenterX Parameter to modify
     * @return Itself
     */
    public final FovParamsConfigs withFOVCenterX(Angle newFOVCenterX)
    {
        FOVCenterX = newFOVCenterX.in(Degrees);
        return this;
    }
    
    /**
     * Helper method to get this configuration's FOVCenterX parameter converted
     * to a unit type. If not using the Java units library, {@link #FOVCenterX}
     * can be accessed directly instead.
     * <p>
     * Specifies the target center of the Field of View in the X
     * direction.
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -11.8
     *   <li> <b>Maximum Value:</b> 11.8
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @return FOVCenterX
     */
    public final Angle getFOVCenterXMeasure()
    {
        return Degrees.of(FOVCenterX);
    }
    
    /**
     * Modifies this configuration's FOVCenterY parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Specifies the target center of the Field of View in the Y
     * direction.
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -11.8
     *   <li> <b>Maximum Value:</b> 11.8
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newFOVCenterY Parameter to modify
     * @return Itself
     */
    public final FovParamsConfigs withFOVCenterY(double newFOVCenterY)
    {
        FOVCenterY = newFOVCenterY;
        return this;
    }
    
    /**
     * Modifies this configuration's FOVCenterY parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Specifies the target center of the Field of View in the Y
     * direction.
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -11.8
     *   <li> <b>Maximum Value:</b> 11.8
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newFOVCenterY Parameter to modify
     * @return Itself
     */
    public final FovParamsConfigs withFOVCenterY(Angle newFOVCenterY)
    {
        FOVCenterY = newFOVCenterY.in(Degrees);
        return this;
    }
    
    /**
     * Helper method to get this configuration's FOVCenterY parameter converted
     * to a unit type. If not using the Java units library, {@link #FOVCenterY}
     * can be accessed directly instead.
     * <p>
     * Specifies the target center of the Field of View in the Y
     * direction.
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -11.8
     *   <li> <b>Maximum Value:</b> 11.8
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @return FOVCenterY
     */
    public final Angle getFOVCenterYMeasure()
    {
        return Degrees.of(FOVCenterY);
    }
    
    /**
     * Modifies this configuration's FOVRangeX parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Specifies the target range of the Field of View in the X direction.
     * This is the full range of the FOV.
     * <p>
     * The magnitude of this is capped to abs(27 - 2*FOVCenterX).
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 6.75
     *   <li> <b>Maximum Value:</b> 27
     *   <li> <b>Default Value:</b> 27
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newFOVRangeX Parameter to modify
     * @return Itself
     */
    public final FovParamsConfigs withFOVRangeX(double newFOVRangeX)
    {
        FOVRangeX = newFOVRangeX;
        return this;
    }
    
    /**
     * Modifies this configuration's FOVRangeX parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Specifies the target range of the Field of View in the X direction.
     * This is the full range of the FOV.
     * <p>
     * The magnitude of this is capped to abs(27 - 2*FOVCenterX).
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 6.75
     *   <li> <b>Maximum Value:</b> 27
     *   <li> <b>Default Value:</b> 27
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newFOVRangeX Parameter to modify
     * @return Itself
     */
    public final FovParamsConfigs withFOVRangeX(Angle newFOVRangeX)
    {
        FOVRangeX = newFOVRangeX.in(Degrees);
        return this;
    }
    
    /**
     * Helper method to get this configuration's FOVRangeX parameter converted
     * to a unit type. If not using the Java units library, {@link #FOVRangeX}
     * can be accessed directly instead.
     * <p>
     * Specifies the target range of the Field of View in the X direction.
     * This is the full range of the FOV.
     * <p>
     * The magnitude of this is capped to abs(27 - 2*FOVCenterX).
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 6.75
     *   <li> <b>Maximum Value:</b> 27
     *   <li> <b>Default Value:</b> 27
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @return FOVRangeX
     */
    public final Angle getFOVRangeXMeasure()
    {
        return Degrees.of(FOVRangeX);
    }
    
    /**
     * Modifies this configuration's FOVRangeY parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Specifies the target range of the Field of View in the Y direction.
     * This is the full range of the FOV.
     * <p>
     * The magnitude of this is capped to abs(27 - 2*FOVCenterY).
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 6.75
     *   <li> <b>Maximum Value:</b> 27
     *   <li> <b>Default Value:</b> 27
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newFOVRangeY Parameter to modify
     * @return Itself
     */
    public final FovParamsConfigs withFOVRangeY(double newFOVRangeY)
    {
        FOVRangeY = newFOVRangeY;
        return this;
    }
    
    /**
     * Modifies this configuration's FOVRangeY parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Specifies the target range of the Field of View in the Y direction.
     * This is the full range of the FOV.
     * <p>
     * The magnitude of this is capped to abs(27 - 2*FOVCenterY).
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 6.75
     *   <li> <b>Maximum Value:</b> 27
     *   <li> <b>Default Value:</b> 27
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @param newFOVRangeY Parameter to modify
     * @return Itself
     */
    public final FovParamsConfigs withFOVRangeY(Angle newFOVRangeY)
    {
        FOVRangeY = newFOVRangeY.in(Degrees);
        return this;
    }
    
    /**
     * Helper method to get this configuration's FOVRangeY parameter converted
     * to a unit type. If not using the Java units library, {@link #FOVRangeY}
     * can be accessed directly instead.
     * <p>
     * Specifies the target range of the Field of View in the Y direction.
     * This is the full range of the FOV.
     * <p>
     * The magnitude of this is capped to abs(27 - 2*FOVCenterY).
     * <p>
     * The exact value may be different for different CANrange devices due
     * to imperfections in the sensing silicon.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 6.75
     *   <li> <b>Maximum Value:</b> 27
     *   <li> <b>Default Value:</b> 27
     *   <li> <b>Units:</b> deg
     * </ul>
     *
     * @return FOVRangeY
     */
    public final Angle getFOVRangeYMeasure()
    {
        return Degrees.of(FOVRangeY);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: FovParams\n";
        ss += "    FOVCenterX: " + FOVCenterX + " deg" + "\n";
        ss += "    FOVCenterY: " + FOVCenterY + " deg" + "\n";
        ss += "    FOVRangeX: " + FOVRangeX + " deg" + "\n";
        ss += "    FOVRangeY: " + FOVRangeY + " deg" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.CANrange_FOVCenterX.value, FOVCenterX);
        ss += ConfigJNI.Serializedouble(SpnValue.CANrange_FOVCenterY.value, FOVCenterY);
        ss += ConfigJNI.Serializedouble(SpnValue.CANrange_FOVRangeX.value, FOVRangeX);
        ss += ConfigJNI.Serializedouble(SpnValue.CANrange_FOVRangeY.value, FOVRangeY);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        FOVCenterX = ConfigJNI.Deserializedouble(SpnValue.CANrange_FOVCenterX.value, to_deserialize);
        FOVCenterY = ConfigJNI.Deserializedouble(SpnValue.CANrange_FOVCenterY.value, to_deserialize);
        FOVRangeX = ConfigJNI.Deserializedouble(SpnValue.CANrange_FOVRangeX.value, to_deserialize);
        FOVRangeY = ConfigJNI.Deserializedouble(SpnValue.CANrange_FOVRangeY.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public FovParamsConfigs clone() {
        try {
            return (FovParamsConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

