/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.jni.ControlJNI;
import com.ctre.phoenix6.hardware.traits.*;

import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Requires Phoenix Pro and CANivore;
 * Requests Motion Magic® to target a final position using a motion profile. 
 * This dynamic request allows runtime changes to Cruise Velocity, Acceleration,
 * and (optional) Jerk.  Users can optionally provide a voltage feedforward.
 * <p>
 * Motion Magic® produces a motion profile in real-time while attempting to honor the specified Cruise
 * Velocity, Acceleration, and (optional) Jerk.  This control mode does not use the Expo_kV or Expo_kA
 * configs.
 * <p>
 * Target position can be changed on-the-fly and Motion Magic® will do its best to adjust the profile.  This
 * control mode is voltage-based, so relevant closed-loop gains will use Volts for the numerator.
 */
public final class DynamicMotionMagicVoltage implements ControlRequest, Cloneable {
    /**
     * Position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     */
    public double Position;
    /**
     * Cruise velocity for profiling.  The signage does not matter as the device
     * will use the absolute value for profile generation.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     */
    public double Velocity;
    /**
     * Acceleration for profiling.  The signage does not matter as the device will
     * use the absolute value for profile generation.
     * 
     * <ul>
     *   <li> Units: rotations per second²
     * </ul>
     * 
     */
    public double Acceleration;
    /**
     * Jerk for profiling.  The signage does not matter as the device will use the
     * absolute value for profile generation.
     * <p>
     * Jerk is optional; if this is set to zero, then Motion Magic® will not apply a
     * Jerk limit.
     * 
     * <ul>
     *   <li> Units: rotations per second³
     * </ul>
     * 
     */
    public double Jerk = 0.0;
    /**
     * Set to true to use FOC commutation (requires Phoenix Pro), which increases
     * peak power by ~15% on supported devices (see {@link SupportsFOC}). Set to
     * false to use trapezoidal commutation.
     * <p>
     * FOC improves motor performance by leveraging torque (current) control. 
     * However, this may be inconvenient for applications that require specifying
     * duty cycle or voltage.  CTR-Electronics has developed a hybrid method that
     * combines the performances gains of FOC while still allowing applications to
     * provide duty cycle or voltage demand.  This not to be confused with simple
     * sinusoidal control or phase voltage control which lacks the performance
     * gains.
     */
    public boolean EnableFOC = true;
    /**
     * Feedforward to apply in volts. This is added to the output of the onboard
     * feedforward terms.
     * 
     * <ul>
     *   <li> Units: Volts
     * </ul>
     * 
     */
    public double FeedForward = 0.0;
    /**
     * Select which gains are applied by selecting the slot.  Use the configuration
     * api to set the gain values for the selected slot before enabling this
     * feature. Slot must be within [0,2].
     */
    public int Slot = 0;
    /**
     * Set to true to static-brake the rotor when output is zero (or within
     * deadband).  Set to false to use the NeutralMode configuration setting
     * (default). This flag exists to provide the fundamental behavior of this
     * control when output is zero, which is to provide 0V to the motor.
     */
    public boolean OverrideBrakeDurNeutral = false;
    /**
     * Set to true to force forward limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     */
    public boolean LimitForwardMotion = false;
    /**
     * Set to true to force reverse limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     */
    public boolean LimitReverseMotion = false;
    /**
     * Set to true to ignore hardware limit switches and the LimitForwardMotion and
     * LimitReverseMotion parameters, instead allowing motion.
     * <p>
     * This can be useful on mechanisms such as an intake/feeder, where a limit
     * switch stops motion while intaking but should be ignored when feeding to a
     * shooter.
     * <p>
     * The hardware limit faults and Forward/ReverseLimit signals will still report
     * the values of the limit switches regardless of this parameter.
     */
    public boolean IgnoreHardwareLimits = false;
    /**
     * Set to true to ignore software limits, instead allowing motion.
     * <p>
     * This can be useful when calibrating the zero point of a mechanism such as an
     * elevator.
     * <p>
     * The software limit faults will still report the values of the software limits
     * regardless of this parameter.
     */
    public boolean IgnoreSoftwareLimits = false;
    /**
     * Set to true to delay applying this control request until a timesync boundary
     * (requires Phoenix Pro and CANivore). This eliminates the impact of
     * nondeterministic network delays in exchange for a larger but deterministic
     * control latency.
     * <p>
     * This requires setting the ControlTimesyncFreqHz config in MotorOutputConfigs.
     * Additionally, when this is enabled, the UpdateFreqHz of this request should
     * be set to 0 Hz.
     */
    public boolean UseTimesync = false;

    /**
     * The frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     */
    public double UpdateFreqHz = 100;

    /**
     * Requires Phoenix Pro and CANivore;
     * Requests Motion Magic® to target a final position using a motion profile. 
     * This dynamic request allows runtime changes to Cruise Velocity, Acceleration,
     * and (optional) Jerk.  Users can optionally provide a voltage feedforward.
     * <p>
     * Motion Magic® produces a motion profile in real-time while attempting to
     * honor the specified Cruise Velocity, Acceleration, and (optional) Jerk.  This
     * control mode does not use the Expo_kV or Expo_kA configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do its best
     * to adjust the profile.  This control mode is voltage-based, so relevant
     * closed-loop gains will use Volts for the numerator.
     * 
     * @param Position Position to drive toward in rotations.
     * @param Velocity Cruise velocity for profiling.  The signage does not matter
     *                 as the device will use the absolute value for profile
     *                 generation.
     * @param Acceleration Acceleration for profiling.  The signage does not matter
     *                     as the device will use the absolute value for profile
     *                     generation.
     */
    public DynamicMotionMagicVoltage(double Position, double Velocity, double Acceleration) {
        this.Position = Position;
        this.Velocity = Velocity;
        this.Acceleration = Acceleration;
    }

    /**
     * Requires Phoenix Pro and CANivore;
     * Requests Motion Magic® to target a final position using a motion profile. 
     * This dynamic request allows runtime changes to Cruise Velocity, Acceleration,
     * and (optional) Jerk.  Users can optionally provide a voltage feedforward.
     * <p>
     * Motion Magic® produces a motion profile in real-time while attempting to
     * honor the specified Cruise Velocity, Acceleration, and (optional) Jerk.  This
     * control mode does not use the Expo_kV or Expo_kA configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do its best
     * to adjust the profile.  This control mode is voltage-based, so relevant
     * closed-loop gains will use Volts for the numerator.
     * 
     * @param Position Position to drive toward in rotations.
     * @param Velocity Cruise velocity for profiling.  The signage does not matter
     *                 as the device will use the absolute value for profile
     *                 generation.
     * @param Acceleration Acceleration for profiling.  The signage does not matter
     *                     as the device will use the absolute value for profile
     *                     generation.
     */
    public DynamicMotionMagicVoltage(Angle Position, AngularVelocity Velocity, AngularAcceleration Acceleration) {
        this(Position.in(Rotations), Velocity.in(RotationsPerSecond), Acceleration.in(RotationsPerSecondPerSecond));
    }

    @Override
    public String getName() {
        return "DynamicMotionMagicVoltage";
    }

    @Override
    public String toString() {
        String ss = "Control: DynamicMotionMagicVoltage\n";
        ss += "    Position: " + Position + " rotations" + "\n";
        ss += "    Velocity: " + Velocity + " rotations per second" + "\n";
        ss += "    Acceleration: " + Acceleration + " rotations per second²" + "\n";
        ss += "    Jerk: " + Jerk + " rotations per second³" + "\n";
        ss += "    EnableFOC: " + EnableFOC + "\n";
        ss += "    FeedForward: " + FeedForward + " Volts" + "\n";
        ss += "    Slot: " + Slot + "\n";
        ss += "    OverrideBrakeDurNeutral: " + OverrideBrakeDurNeutral + "\n";
        ss += "    LimitForwardMotion: " + LimitForwardMotion + "\n";
        ss += "    LimitReverseMotion: " + LimitReverseMotion + "\n";
        ss += "    IgnoreHardwareLimits: " + IgnoreHardwareLimits + "\n";
        ss += "    IgnoreSoftwareLimits: " + IgnoreSoftwareLimits + "\n";
        ss += "    UseTimesync: " + UseTimesync + "\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlDynamicMotionMagicVoltage(
                network, deviceHash, UpdateFreqHz, Position, Velocity, Acceleration, Jerk, EnableFOC, FeedForward, Slot, OverrideBrakeDurNeutral, LimitForwardMotion, LimitReverseMotion, IgnoreHardwareLimits, IgnoreSoftwareLimits, UseTimesync));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String, String>();
        controlInfo.put("Name", getName());
        controlInfo.put("Position", String.valueOf(this.Position));
        controlInfo.put("Velocity", String.valueOf(this.Velocity));
        controlInfo.put("Acceleration", String.valueOf(this.Acceleration));
        controlInfo.put("Jerk", String.valueOf(this.Jerk));
        controlInfo.put("EnableFOC", String.valueOf(this.EnableFOC));
        controlInfo.put("FeedForward", String.valueOf(this.FeedForward));
        controlInfo.put("Slot", String.valueOf(this.Slot));
        controlInfo.put("OverrideBrakeDurNeutral", String.valueOf(this.OverrideBrakeDurNeutral));
        controlInfo.put("LimitForwardMotion", String.valueOf(this.LimitForwardMotion));
        controlInfo.put("LimitReverseMotion", String.valueOf(this.LimitReverseMotion));
        controlInfo.put("IgnoreHardwareLimits", String.valueOf(this.IgnoreHardwareLimits));
        controlInfo.put("IgnoreSoftwareLimits", String.valueOf(this.IgnoreSoftwareLimits));
        controlInfo.put("UseTimesync", String.valueOf(this.UseTimesync));
        return controlInfo;
    }
    
    /**
     * Modifies this Control Request's Position parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     *
     * @param newPosition Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withPosition(double newPosition) {
        Position = newPosition;
        return this;
    }
    
    /**
     * Modifies this Control Request's Position parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     *
     * @param newPosition Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withPosition(Angle newPosition) {
        Position = newPosition.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's Position parameter converted
     * to a unit type. If not using the Java units library, {@link #Position}
     * can be accessed directly instead.
     * <p>
     * Position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     *
     * @return Position
     */
    public Angle getPositionMeasure() {
        return Rotations.of(Position);
    }
    
    /**
     * Modifies this Control Request's Velocity parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Cruise velocity for profiling.  The signage does not matter as the device
     * will use the absolute value for profile generation.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @param newVelocity Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withVelocity(double newVelocity) {
        Velocity = newVelocity;
        return this;
    }
    
    /**
     * Modifies this Control Request's Velocity parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Cruise velocity for profiling.  The signage does not matter as the device
     * will use the absolute value for profile generation.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @param newVelocity Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withVelocity(AngularVelocity newVelocity) {
        Velocity = newVelocity.in(RotationsPerSecond);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's Velocity parameter converted
     * to a unit type. If not using the Java units library, {@link #Velocity}
     * can be accessed directly instead.
     * <p>
     * Cruise velocity for profiling.  The signage does not matter as the device
     * will use the absolute value for profile generation.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @return Velocity
     */
    public AngularVelocity getVelocityMeasure() {
        return RotationsPerSecond.of(Velocity);
    }
    
    /**
     * Modifies this Control Request's Acceleration parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Acceleration for profiling.  The signage does not matter as the device will
     * use the absolute value for profile generation.
     * 
     * <ul>
     *   <li> Units: rotations per second²
     * </ul>
     * 
     *
     * @param newAcceleration Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withAcceleration(double newAcceleration) {
        Acceleration = newAcceleration;
        return this;
    }
    
    /**
     * Modifies this Control Request's Acceleration parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Acceleration for profiling.  The signage does not matter as the device will
     * use the absolute value for profile generation.
     * 
     * <ul>
     *   <li> Units: rotations per second²
     * </ul>
     * 
     *
     * @param newAcceleration Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withAcceleration(AngularAcceleration newAcceleration) {
        Acceleration = newAcceleration.in(RotationsPerSecondPerSecond);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's Acceleration parameter converted
     * to a unit type. If not using the Java units library, {@link #Acceleration}
     * can be accessed directly instead.
     * <p>
     * Acceleration for profiling.  The signage does not matter as the device will
     * use the absolute value for profile generation.
     * 
     * <ul>
     *   <li> Units: rotations per second²
     * </ul>
     * 
     *
     * @return Acceleration
     */
    public AngularAcceleration getAccelerationMeasure() {
        return RotationsPerSecondPerSecond.of(Acceleration);
    }
    
    /**
     * Modifies this Control Request's Jerk parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Jerk for profiling.  The signage does not matter as the device will use the
     * absolute value for profile generation.
     * <p>
     * Jerk is optional; if this is set to zero, then Motion Magic® will not apply a
     * Jerk limit.
     * 
     * <ul>
     *   <li> Units: rotations per second³
     * </ul>
     * 
     *
     * @param newJerk Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withJerk(double newJerk) {
        Jerk = newJerk;
        return this;
    }
    
    /**
     * Modifies this Control Request's Jerk parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Jerk for profiling.  The signage does not matter as the device will use the
     * absolute value for profile generation.
     * <p>
     * Jerk is optional; if this is set to zero, then Motion Magic® will not apply a
     * Jerk limit.
     * 
     * <ul>
     *   <li> Units: rotations per second³
     * </ul>
     * 
     *
     * @param newJerk Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withJerk(Velocity<AngularAccelerationUnit> newJerk) {
        Jerk = newJerk.in(RotationsPerSecondPerSecond.per(Second));
        return this;
    }
    
    /**
     * Helper method to get this Control Request's Jerk parameter converted
     * to a unit type. If not using the Java units library, {@link #Jerk}
     * can be accessed directly instead.
     * <p>
     * Jerk for profiling.  The signage does not matter as the device will use the
     * absolute value for profile generation.
     * <p>
     * Jerk is optional; if this is set to zero, then Motion Magic® will not apply a
     * Jerk limit.
     * 
     * <ul>
     *   <li> Units: rotations per second³
     * </ul>
     * 
     *
     * @return Jerk
     */
    public Velocity<AngularAccelerationUnit> getJerkMeasure() {
        return RotationsPerSecondPerSecond.per(Second).of(Jerk);
    }
    
    /**
     * Modifies this Control Request's EnableFOC parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to use FOC commutation (requires Phoenix Pro), which increases
     * peak power by ~15% on supported devices (see {@link SupportsFOC}). Set to
     * false to use trapezoidal commutation.
     * <p>
     * FOC improves motor performance by leveraging torque (current) control. 
     * However, this may be inconvenient for applications that require specifying
     * duty cycle or voltage.  CTR-Electronics has developed a hybrid method that
     * combines the performances gains of FOC while still allowing applications to
     * provide duty cycle or voltage demand.  This not to be confused with simple
     * sinusoidal control or phase voltage control which lacks the performance
     * gains.
     *
     * @param newEnableFOC Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withEnableFOC(boolean newEnableFOC) {
        EnableFOC = newEnableFOC;
        return this;
    }
    
    /**
     * Modifies this Control Request's FeedForward parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Feedforward to apply in volts. This is added to the output of the onboard
     * feedforward terms.
     * 
     * <ul>
     *   <li> Units: Volts
     * </ul>
     * 
     *
     * @param newFeedForward Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withFeedForward(double newFeedForward) {
        FeedForward = newFeedForward;
        return this;
    }
    
    /**
     * Modifies this Control Request's FeedForward parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Feedforward to apply in volts. This is added to the output of the onboard
     * feedforward terms.
     * 
     * <ul>
     *   <li> Units: Volts
     * </ul>
     * 
     *
     * @param newFeedForward Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withFeedForward(Voltage newFeedForward) {
        FeedForward = newFeedForward.in(Volts);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's FeedForward parameter converted
     * to a unit type. If not using the Java units library, {@link #FeedForward}
     * can be accessed directly instead.
     * <p>
     * Feedforward to apply in volts. This is added to the output of the onboard
     * feedforward terms.
     * 
     * <ul>
     *   <li> Units: Volts
     * </ul>
     * 
     *
     * @return FeedForward
     */
    public Voltage getFeedForwardMeasure() {
        return Volts.of(FeedForward);
    }
    
    /**
     * Modifies this Control Request's Slot parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Select which gains are applied by selecting the slot.  Use the configuration
     * api to set the gain values for the selected slot before enabling this
     * feature. Slot must be within [0,2].
     *
     * @param newSlot Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withSlot(int newSlot) {
        Slot = newSlot;
        return this;
    }
    
    /**
     * Modifies this Control Request's OverrideBrakeDurNeutral parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to static-brake the rotor when output is zero (or within
     * deadband).  Set to false to use the NeutralMode configuration setting
     * (default). This flag exists to provide the fundamental behavior of this
     * control when output is zero, which is to provide 0V to the motor.
     *
     * @param newOverrideBrakeDurNeutral Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withOverrideBrakeDurNeutral(boolean newOverrideBrakeDurNeutral) {
        OverrideBrakeDurNeutral = newOverrideBrakeDurNeutral;
        return this;
    }
    
    /**
     * Modifies this Control Request's LimitForwardMotion parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to force forward limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     *
     * @param newLimitForwardMotion Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withLimitForwardMotion(boolean newLimitForwardMotion) {
        LimitForwardMotion = newLimitForwardMotion;
        return this;
    }
    
    /**
     * Modifies this Control Request's LimitReverseMotion parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to force reverse limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     *
     * @param newLimitReverseMotion Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withLimitReverseMotion(boolean newLimitReverseMotion) {
        LimitReverseMotion = newLimitReverseMotion;
        return this;
    }
    
    /**
     * Modifies this Control Request's IgnoreHardwareLimits parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to ignore hardware limit switches and the LimitForwardMotion and
     * LimitReverseMotion parameters, instead allowing motion.
     * <p>
     * This can be useful on mechanisms such as an intake/feeder, where a limit
     * switch stops motion while intaking but should be ignored when feeding to a
     * shooter.
     * <p>
     * The hardware limit faults and Forward/ReverseLimit signals will still report
     * the values of the limit switches regardless of this parameter.
     *
     * @param newIgnoreHardwareLimits Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withIgnoreHardwareLimits(boolean newIgnoreHardwareLimits) {
        IgnoreHardwareLimits = newIgnoreHardwareLimits;
        return this;
    }
    
    /**
     * Modifies this Control Request's IgnoreSoftwareLimits parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to ignore software limits, instead allowing motion.
     * <p>
     * This can be useful when calibrating the zero point of a mechanism such as an
     * elevator.
     * <p>
     * The software limit faults will still report the values of the software limits
     * regardless of this parameter.
     *
     * @param newIgnoreSoftwareLimits Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withIgnoreSoftwareLimits(boolean newIgnoreSoftwareLimits) {
        IgnoreSoftwareLimits = newIgnoreSoftwareLimits;
        return this;
    }
    
    /**
     * Modifies this Control Request's UseTimesync parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to delay applying this control request until a timesync boundary
     * (requires Phoenix Pro and CANivore). This eliminates the impact of
     * nondeterministic network delays in exchange for a larger but deterministic
     * control latency.
     * <p>
     * This requires setting the ControlTimesyncFreqHz config in MotorOutputConfigs.
     * Additionally, when this is enabled, the UpdateFreqHz of this request should
     * be set to 0 Hz.
     *
     * @param newUseTimesync Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicVoltage withUseTimesync(boolean newUseTimesync) {
        UseTimesync = newUseTimesync;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public DynamicMotionMagicVoltage withUpdateFreqHz(double newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public DynamicMotionMagicVoltage withUpdateFreqHz(Frequency newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz.in(Hertz);
        return this;
    }

    @Override
    public DynamicMotionMagicVoltage clone() {
        try {
            return (DynamicMotionMagicVoltage)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

