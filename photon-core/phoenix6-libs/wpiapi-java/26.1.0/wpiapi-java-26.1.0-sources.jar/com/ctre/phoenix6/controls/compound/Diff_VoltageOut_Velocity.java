/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls.compound;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.*;
import com.ctre.phoenix6.controls.jni.ControlJNI;

import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @hidden
 * Requires Phoenix Pro and CANivore;
 * Differential control with voltage average target and velocity difference
 * target.
 */
public final class Diff_VoltageOut_Velocity implements ControlRequest, Cloneable {
    /**
     * Average VoltageOut request of the mechanism.
     */
    public VoltageOut AverageRequest;
    /**
     * Differential VelocityVoltage request of the mechanism.
     */
    public VelocityVoltage DifferentialRequest;

    /**
     * The frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     */
    public double UpdateFreqHz = 100;

    /**
     * Requires Phoenix Pro and CANivore;
     * Differential control with voltage average target and velocity difference
     * target.
     * 
     * @param AverageRequest Average VoltageOut request of the mechanism.
     * @param DifferentialRequest Differential VelocityVoltage request of the
     *                            mechanism.
     */
    public Diff_VoltageOut_Velocity(VoltageOut AverageRequest, VelocityVoltage DifferentialRequest) {
        this.AverageRequest = AverageRequest;
        this.DifferentialRequest = DifferentialRequest;
    }

    @Override
    public String getName() {
        return "Diff_VoltageOut_Velocity";
    }

    @Override
    public String toString() {
        String ss = "Control: Diff_VoltageOut_Velocity\n";
        ss += "    AverageRequest:" + "\n";
        ss += "        Output: " + AverageRequest.Output + " Volts" + "\n";
        ss += "        EnableFOC: " + AverageRequest.EnableFOC + "\n";
        ss += "        OverrideBrakeDurNeutral: " + AverageRequest.OverrideBrakeDurNeutral + "\n";
        ss += "        LimitForwardMotion: " + AverageRequest.LimitForwardMotion + "\n";
        ss += "        LimitReverseMotion: " + AverageRequest.LimitReverseMotion + "\n";
        ss += "        IgnoreHardwareLimits: " + AverageRequest.IgnoreHardwareLimits + "\n";
        ss += "        IgnoreSoftwareLimits: " + AverageRequest.IgnoreSoftwareLimits + "\n";
        ss += "        UseTimesync: " + AverageRequest.UseTimesync + "\n";
        ss += "    DifferentialRequest:" + "\n";
        ss += "        Velocity: " + DifferentialRequest.Velocity + " rotations per second" + "\n";
        ss += "        Acceleration: " + DifferentialRequest.Acceleration + " rotations per second²" + "\n";
        ss += "        EnableFOC: " + DifferentialRequest.EnableFOC + "\n";
        ss += "        FeedForward: " + DifferentialRequest.FeedForward + " Volts" + "\n";
        ss += "        Slot: " + DifferentialRequest.Slot + "\n";
        ss += "        OverrideBrakeDurNeutral: " + DifferentialRequest.OverrideBrakeDurNeutral + "\n";
        ss += "        LimitForwardMotion: " + DifferentialRequest.LimitForwardMotion + "\n";
        ss += "        LimitReverseMotion: " + DifferentialRequest.LimitReverseMotion + "\n";
        ss += "        IgnoreHardwareLimits: " + DifferentialRequest.IgnoreHardwareLimits + "\n";
        ss += "        IgnoreSoftwareLimits: " + DifferentialRequest.IgnoreSoftwareLimits + "\n";
        ss += "        UseTimesync: " + DifferentialRequest.UseTimesync + "\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlDiff_VoltageOut_Velocity(
                network, deviceHash, UpdateFreqHz, AverageRequest.Output, AverageRequest.EnableFOC, AverageRequest.OverrideBrakeDurNeutral, AverageRequest.LimitForwardMotion, AverageRequest.LimitReverseMotion, AverageRequest.IgnoreHardwareLimits, AverageRequest.IgnoreSoftwareLimits, AverageRequest.UseTimesync, DifferentialRequest.Velocity, DifferentialRequest.Acceleration, DifferentialRequest.EnableFOC, DifferentialRequest.FeedForward, DifferentialRequest.Slot, DifferentialRequest.OverrideBrakeDurNeutral, DifferentialRequest.LimitForwardMotion, DifferentialRequest.LimitReverseMotion, DifferentialRequest.IgnoreHardwareLimits, DifferentialRequest.IgnoreSoftwareLimits, DifferentialRequest.UseTimesync));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String, String>();
        controlInfo.put("Name", getName());
        controlInfo.put("AverageRequest", String.valueOf(this.AverageRequest));
        controlInfo.put("DifferentialRequest", String.valueOf(this.DifferentialRequest));
        return controlInfo;
    }
    
    /**
     * Modifies this Control Request's AverageRequest parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Average VoltageOut request of the mechanism.
     *
     * @param newAverageRequest Parameter to modify
     * @return Itself
     */
    public Diff_VoltageOut_Velocity withAverageRequest(VoltageOut newAverageRequest) {
        AverageRequest = newAverageRequest;
        return this;
    }
    
    /**
     * Modifies this Control Request's DifferentialRequest parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Differential VelocityVoltage request of the mechanism.
     *
     * @param newDifferentialRequest Parameter to modify
     * @return Itself
     */
    public Diff_VoltageOut_Velocity withDifferentialRequest(VelocityVoltage newDifferentialRequest) {
        DifferentialRequest = newDifferentialRequest;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public Diff_VoltageOut_Velocity withUpdateFreqHz(double newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public Diff_VoltageOut_Velocity withUpdateFreqHz(Frequency newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz.in(Hertz);
        return this;
    }

    @Override
    public Diff_VoltageOut_Velocity clone() {
        try {
            return (Diff_VoltageOut_Velocity)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

