/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware;

import com.ctre.phoenix6.CANBus;
import com.ctre.phoenix6.hardware.jni.HardwareJNI;

public final class DeviceIdentifier {
    CANBus network;
    String model;
    String tostring = null;
    int deviceID;
    int deviceHash;

    public DeviceIdentifier() {
        this.network = new CANBus();
        this.model = "";
        this.deviceID = 0;
        this.deviceHash = 0;
    }

    public DeviceIdentifier(int deviceID, String model, CANBus canbus) {
        this.network = canbus;
        this.model = model;
        this.deviceID = deviceID;
        this.deviceHash = HardwareJNI.getDeviceHash(deviceID, model, canbus.getName());
    }

    public CANBus getNetwork() {
        return network;
    }

    public String getModel() {
        return model;
    }

    public int getDeviceId() {
        return deviceID;
    }

    public int getDeviceHash() {
        return deviceHash;
    }

    public String toString() {
        if (tostring == null)
        {
            tostring = model + " " + deviceID + " (\"" + network.getName() + "\")";
        }
        return tostring;
    }
}
