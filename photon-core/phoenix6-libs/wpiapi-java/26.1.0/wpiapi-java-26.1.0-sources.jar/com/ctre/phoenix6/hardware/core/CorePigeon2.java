/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.core;

import com.ctre.phoenix6.hardware.ParentDevice;
import com.ctre.phoenix6.controls.*;
import com.ctre.phoenix6.configs.*;
import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.jni.PlatformJNI;
import com.ctre.phoenix6.sim.DeviceType;
import com.ctre.phoenix6.sim.Pigeon2SimState;
import com.ctre.phoenix6.*;
import com.ctre.phoenix6.spns.*;
import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Class description for the Pigeon 2 IMU sensor that measures orientation.
 * 
 * <pre>
 * // Constants used in Pigeon2 construction
 * final int kPigeon2Id = 0;
 * final CANBus kPigeon2CANbus = new CANBus("canivore");
 * 
 * // Construct the Pigeon 2
 * final Pigeon2 pigeon = new Pigeon2(kPigeon2Id, kPigeon2CANbus);
 * 
 * // Configure the Pigeon2 for basic use
 * Pigeon2Configuration configs = new Pigeon2Configuration();
 * // This Pigeon is mounted X-up, so we should mount-pose with Pitch at 90 degrees
 * configs.MountPose.MountPoseYaw = 0;
 * configs.MountPose.MountPosePitch = 90;
 * configs.MountPose.MountPoseRoll = 0;
 * // This Pigeon has no need to trim the gyro
 * configs.GyroTrim.GyroScalarX = 0;
 * configs.GyroTrim.GyroScalarY = 0;
 * configs.GyroTrim.GyroScalarZ = 0;
 * // We want the thermal comp and no-motion cal enabled, with the compass disabled for best behavior
 * configs.Pigeon2Features.DisableNoMotionCalibration = false;
 * configs.Pigeon2Features.DisableTemperatureCompensation = false;
 * configs.Pigeon2Features.EnableCompass = false;
 * 
 * // Write these configs to the Pigeon2
 * pigeon.getConfigurator().apply(configs);
 * 
 * // Set the yaw to 0 degrees for initial use
 * pigeon.setYaw(0);
 * 
 * // Get Yaw Pitch Roll StatusSignals
 * var yaw = pigeon.getYaw();
 * var pitch = pigeon.getPitch();
 * var roll = pigeon.getRoll();
 * 
 * // Refresh and print these values
 * System.out.println("Yaw is " + yaw.refresh().toString());
 * System.out.println("Pitch is " + pitch.refresh().toString());
 * System.out.println("Roll is " + roll.refresh().toString());
 * </pre>
 */
public class CorePigeon2 extends ParentDevice
{
    private Pigeon2Configurator _configurator;

    /**
     * Constructs a new Pigeon 2 sensor object.
     * <p>
     * Constructs the device using the default CAN bus for the system
     * (see {@link CANBus#CANBus()}).
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     */
    public CorePigeon2(int deviceId)
    {
        this(deviceId, new CANBus());
    }

    /**
     * Constructs a new Pigeon 2 sensor object.
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     * @param canbus      Name of the CAN bus this device is on. Possible CAN bus strings are:
     *                    <ul>
     *                      <li>"rio" for the native roboRIO CAN bus
     *                      <li>CANivore name or serial number
     *                      <li>SocketCAN interface (non-FRC Linux only)
     *                      <li>"*" for any CANivore seen by the program
     *                      <li>empty string (default) to select the default for the system:
     *                      <ul>
     *                        <li>"rio" on roboRIO
     *                        <li>"can0" on Linux
     *                        <li>"*" on Windows
     *                      </ul>
     *                    </ul>
     *
     * @deprecated Constructing devices with a CAN bus string is deprecated for removal
     * in the 2027 season. Construct devices using a {@link CANBus} instance instead.
     */
    @Deprecated(since = "2026", forRemoval = true)
    public CorePigeon2(int deviceId, String canbus)
    {
        this(deviceId, new CANBus(canbus));
    }

    /**
     * Constructs a new Pigeon 2 sensor object.
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     * @param canbus      The CAN bus this device is on
     */
    public CorePigeon2(int deviceId, CANBus canbus)
    {
        super(deviceId, "pigeon 2", canbus);
        _configurator = new Pigeon2Configurator(this.deviceIdentifier);
        PlatformJNI.JNI_SimCreate(DeviceType.P6_Pigeon2Type.value, deviceId);
    }

    /**
     * Gets the configurator to use with this device's configs
     *
     * @return Configurator for this object
     */
    public final Pigeon2Configurator getConfigurator()
    {
        return this._configurator;
    }


    private Pigeon2SimState _simState = null;
    /**
     * Get the simulation state for this device.
     * <p>
     * This function reuses an allocated simulation state
     * object, so it is safe to call this function multiple
     * times in a robot loop.
     *
     * @return Simulation state
     */
    public final Pigeon2SimState getSimState() {
        if (_simState == null)
            _simState = new Pigeon2SimState(this);
        return _simState;
    }


        
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMajor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMajor()
    {
        return getVersionMajor(true);
    }
    
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMajor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMajor(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Major.value, "VersionMajor", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMinor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMinor()
    {
        return getVersionMinor(true);
    }
    
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMinor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMinor(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Minor.value, "VersionMinor", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBugfix Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBugfix()
    {
        return getVersionBugfix(true);
    }
    
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBugfix Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBugfix(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Bugfix.value, "VersionBugfix", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBuild Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBuild()
    {
        return getVersionBuild(true);
    }
    
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBuild Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBuild(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Build.value, "VersionBuild", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Version Status Signal Object
     */
    public final StatusSignal<Integer> getVersion()
    {
        return getVersion(true);
    }
    
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Version Status Signal Object
     */
    public final StatusSignal<Integer> getVersion(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Full.value, "Version", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return FaultField Status Signal Object
     */
    public final StatusSignal<Integer> getFaultField()
    {
        return getFaultField(true);
    }
    
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return FaultField Status Signal Object
     */
    public final StatusSignal<Integer> getFaultField(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.AllFaults.value, "FaultField", Integer.class, val -> (int)val, true, refresh);
        return retval;
    }
        
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFaultField Status Signal Object
     */
    public final StatusSignal<Integer> getStickyFaultField()
    {
        return getStickyFaultField(true);
    }
    
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFaultField Status Signal Object
     */
    public final StatusSignal<Integer> getStickyFaultField(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.AllStickyFaults.value, "StickyFaultField", Integer.class, val -> (int)val, true, refresh);
        return retval;
    }
        
    /**
     * Current reported yaw of the Pigeon2.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -368640.0
     *   <li> <b>Maximum Value:</b> 368639.99725341797
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Yaw Status Signal Object
     */
    public final StatusSignal<Angle> getYaw()
    {
        return getYaw(true);
    }
    
    /**
     * Current reported yaw of the Pigeon2.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -368640.0
     *   <li> <b>Maximum Value:</b> 368639.99725341797
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Yaw Status Signal Object
     */
    public final StatusSignal<Angle> getYaw(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2Yaw.value, "Yaw", Angle.class, val -> Degrees.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Current reported pitch of the Pigeon2.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -90.0
     *   <li> <b>Maximum Value:</b> 89.9560546875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Pitch Status Signal Object
     */
    public final StatusSignal<Angle> getPitch()
    {
        return getPitch(true);
    }
    
    /**
     * Current reported pitch of the Pigeon2.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -90.0
     *   <li> <b>Maximum Value:</b> 89.9560546875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Pitch Status Signal Object
     */
    public final StatusSignal<Angle> getPitch(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2Pitch.value, "Pitch", Angle.class, val -> Degrees.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Current reported roll of the Pigeon2.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -180.0
     *   <li> <b>Maximum Value:</b> 179.9560546875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Roll Status Signal Object
     */
    public final StatusSignal<Angle> getRoll()
    {
        return getRoll(true);
    }
    
    /**
     * Current reported roll of the Pigeon2.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -180.0
     *   <li> <b>Maximum Value:</b> 179.9560546875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Roll Status Signal Object
     */
    public final StatusSignal<Angle> getRoll(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2Roll.value, "Roll", Angle.class, val -> Degrees.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The W component of the reported Quaternion.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0001220852154804
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 50.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return QuatW Status Signal Object
     */
    public final StatusSignal<Double> getQuatW()
    {
        return getQuatW(true);
    }
    
    /**
     * The W component of the reported Quaternion.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0001220852154804
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 50.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return QuatW Status Signal Object
     */
    public final StatusSignal<Double> getQuatW(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2QuatW.value, "QuatW", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The X component of the reported Quaternion.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0001220852154804
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 50.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return QuatX Status Signal Object
     */
    public final StatusSignal<Double> getQuatX()
    {
        return getQuatX(true);
    }
    
    /**
     * The X component of the reported Quaternion.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0001220852154804
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 50.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return QuatX Status Signal Object
     */
    public final StatusSignal<Double> getQuatX(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2QuatX.value, "QuatX", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The Y component of the reported Quaternion.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0001220852154804
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 50.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return QuatY Status Signal Object
     */
    public final StatusSignal<Double> getQuatY()
    {
        return getQuatY(true);
    }
    
    /**
     * The Y component of the reported Quaternion.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0001220852154804
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 50.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return QuatY Status Signal Object
     */
    public final StatusSignal<Double> getQuatY(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2QuatY.value, "QuatY", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The Z component of the reported Quaternion.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0001220852154804
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 50.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return QuatZ Status Signal Object
     */
    public final StatusSignal<Double> getQuatZ()
    {
        return getQuatZ(true);
    }
    
    /**
     * The Z component of the reported Quaternion.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0001220852154804
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 50.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return QuatZ Status Signal Object
     */
    public final StatusSignal<Double> getQuatZ(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2QuatZ.value, "QuatZ", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The X component of the gravity vector.
     * <p>
     * This is the X component of the reported gravity-vector. The gravity
     * vector is not the acceleration experienced by the Pigeon2, rather
     * it is where the Pigeon2 believes "Down" is. This can be used for
     * mechanisms that are linearly related to gravity, such as an arm
     * pivoting about a point, as the contribution of gravity to the arm
     * is directly proportional to the contribution of gravity about one
     * of these primary axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.000030518509476
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return GravityVectorX Status Signal Object
     */
    public final StatusSignal<Double> getGravityVectorX()
    {
        return getGravityVectorX(true);
    }
    
    /**
     * The X component of the gravity vector.
     * <p>
     * This is the X component of the reported gravity-vector. The gravity
     * vector is not the acceleration experienced by the Pigeon2, rather
     * it is where the Pigeon2 believes "Down" is. This can be used for
     * mechanisms that are linearly related to gravity, such as an arm
     * pivoting about a point, as the contribution of gravity to the arm
     * is directly proportional to the contribution of gravity about one
     * of these primary axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.000030518509476
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return GravityVectorX Status Signal Object
     */
    public final StatusSignal<Double> getGravityVectorX(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2GravityVectorX.value, "GravityVectorX", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The Y component of the gravity vector.
     * <p>
     * This is the X component of the reported gravity-vector. The gravity
     * vector is not the acceleration experienced by the Pigeon2, rather
     * it is where the Pigeon2 believes "Down" is. This can be used for
     * mechanisms that are linearly related to gravity, such as an arm
     * pivoting about a point, as the contribution of gravity to the arm
     * is directly proportional to the contribution of gravity about one
     * of these primary axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.000030518509476
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return GravityVectorY Status Signal Object
     */
    public final StatusSignal<Double> getGravityVectorY()
    {
        return getGravityVectorY(true);
    }
    
    /**
     * The Y component of the gravity vector.
     * <p>
     * This is the X component of the reported gravity-vector. The gravity
     * vector is not the acceleration experienced by the Pigeon2, rather
     * it is where the Pigeon2 believes "Down" is. This can be used for
     * mechanisms that are linearly related to gravity, such as an arm
     * pivoting about a point, as the contribution of gravity to the arm
     * is directly proportional to the contribution of gravity about one
     * of these primary axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.000030518509476
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return GravityVectorY Status Signal Object
     */
    public final StatusSignal<Double> getGravityVectorY(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2GravityVectorY.value, "GravityVectorY", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The Z component of the gravity vector.
     * <p>
     * This is the Z component of the reported gravity-vector. The gravity
     * vector is not the acceleration experienced by the Pigeon2, rather
     * it is where the Pigeon2 believes "Down" is. This can be used for
     * mechanisms that are linearly related to gravity, such as an arm
     * pivoting about a point, as the contribution of gravity to the arm
     * is directly proportional to the contribution of gravity about one
     * of these primary axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.000030518509476
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return GravityVectorZ Status Signal Object
     */
    public final StatusSignal<Double> getGravityVectorZ()
    {
        return getGravityVectorZ(true);
    }
    
    /**
     * The Z component of the gravity vector.
     * <p>
     * This is the Z component of the reported gravity-vector. The gravity
     * vector is not the acceleration experienced by the Pigeon2, rather
     * it is where the Pigeon2 believes "Down" is. This can be used for
     * mechanisms that are linearly related to gravity, such as an arm
     * pivoting about a point, as the contribution of gravity to the arm
     * is directly proportional to the contribution of gravity about one
     * of these primary axis.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.000030518509476
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return GravityVectorZ Status Signal Object
     */
    public final StatusSignal<Double> getGravityVectorZ(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2GravityVectorZ.value, "GravityVectorZ", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * Temperature of the Pigeon 2.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -128.0
     *   <li> <b>Maximum Value:</b> 127.99609375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Temperature Status Signal Object
     */
    public final StatusSignal<Temperature> getTemperature()
    {
        return getTemperature(true);
    }
    
    /**
     * Temperature of the Pigeon 2.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -128.0
     *   <li> <b>Maximum Value:</b> 127.99609375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Temperature Status Signal Object
     */
    public final StatusSignal<Temperature> getTemperature(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2Temperature.value, "Temperature", Temperature.class, val -> Celsius.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Whether the no-motion calibration feature is enabled.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> 0
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return NoMotionEnabled Status Signal Object
     */
    public final StatusSignal<Boolean> getNoMotionEnabled()
    {
        return getNoMotionEnabled(true);
    }
    
    /**
     * Whether the no-motion calibration feature is enabled.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> 0
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return NoMotionEnabled Status Signal Object
     */
    public final StatusSignal<Boolean> getNoMotionEnabled(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2NoMotionCalEnabled.value, "NoMotionEnabled", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * The number of times a no-motion event occurred, wraps at 15.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 15
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return NoMotionCount Status Signal Object
     */
    public final StatusSignal<Double> getNoMotionCount()
    {
        return getNoMotionCount(true);
    }
    
    /**
     * The number of times a no-motion event occurred, wraps at 15.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 15
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return NoMotionCount Status Signal Object
     */
    public final StatusSignal<Double> getNoMotionCount(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2NoMotionCount.value, "NoMotionCount", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * Whether the temperature-compensation feature is disabled.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> 0
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return TemperatureCompensationDisabled Status Signal Object
     */
    public final StatusSignal<Boolean> getTemperatureCompensationDisabled()
    {
        return getTemperatureCompensationDisabled(true);
    }
    
    /**
     * Whether the temperature-compensation feature is disabled.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> 0
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return TemperatureCompensationDisabled Status Signal Object
     */
    public final StatusSignal<Boolean> getTemperatureCompensationDisabled(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2TempCompDisabled.value, "TemperatureCompensationDisabled", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * How long the Pigeon 2's been up in seconds, caps at 255 seconds.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> s
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return UpTime Status Signal Object
     */
    public final StatusSignal<Time> getUpTime()
    {
        return getUpTime(true);
    }
    
    /**
     * How long the Pigeon 2's been up in seconds, caps at 255 seconds.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> s
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return UpTime Status Signal Object
     */
    public final StatusSignal<Time> getUpTime(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2UpTime.value, "UpTime", Time.class, val -> Seconds.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The accumulated gyro about the X axis without any sensor fusing.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -23040.0
     *   <li> <b>Maximum Value:</b> 23039.9560546875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AccumGyroX Status Signal Object
     */
    public final StatusSignal<Angle> getAccumGyroX()
    {
        return getAccumGyroX(true);
    }
    
    /**
     * The accumulated gyro about the X axis without any sensor fusing.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -23040.0
     *   <li> <b>Maximum Value:</b> 23039.9560546875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AccumGyroX Status Signal Object
     */
    public final StatusSignal<Angle> getAccumGyroX(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AccumGyroX.value, "AccumGyroX", Angle.class, val -> Degrees.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The accumulated gyro about the Y axis without any sensor fusing.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -23040.0
     *   <li> <b>Maximum Value:</b> 23039.9560546875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AccumGyroY Status Signal Object
     */
    public final StatusSignal<Angle> getAccumGyroY()
    {
        return getAccumGyroY(true);
    }
    
    /**
     * The accumulated gyro about the Y axis without any sensor fusing.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -23040.0
     *   <li> <b>Maximum Value:</b> 23039.9560546875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AccumGyroY Status Signal Object
     */
    public final StatusSignal<Angle> getAccumGyroY(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AccumGyroY.value, "AccumGyroY", Angle.class, val -> Degrees.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The accumulated gyro about the Z axis without any sensor fusing.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -23040.0
     *   <li> <b>Maximum Value:</b> 23039.9560546875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AccumGyroZ Status Signal Object
     */
    public final StatusSignal<Angle> getAccumGyroZ()
    {
        return getAccumGyroZ(true);
    }
    
    /**
     * The accumulated gyro about the Z axis without any sensor fusing.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -23040.0
     *   <li> <b>Maximum Value:</b> 23039.9560546875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> deg
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AccumGyroZ Status Signal Object
     */
    public final StatusSignal<Angle> getAccumGyroZ(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AccumGyroZ.value, "AccumGyroZ", Angle.class, val -> Degrees.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The angular velocity (ω) of the Pigeon 2 about the X axis with
     * respect to the world frame.  This value is mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2048.0
     *   <li> <b>Maximum Value:</b> 2047.99609375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AngularVelocityXWorld Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityXWorld()
    {
        return getAngularVelocityXWorld(true);
    }
    
    /**
     * The angular velocity (ω) of the Pigeon 2 about the X axis with
     * respect to the world frame.  This value is mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2048.0
     *   <li> <b>Maximum Value:</b> 2047.99609375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AngularVelocityXWorld Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityXWorld(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AngularVelocityXWorld.value, "AngularVelocityXWorld", AngularVelocity.class, val -> DegreesPerSecond.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The angular velocity (ω) of the Pigeon 2 about the Y axis with
     * respect to the world frame.  This value is mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2048.0
     *   <li> <b>Maximum Value:</b> 2047.99609375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AngularVelocityYWorld Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityYWorld()
    {
        return getAngularVelocityYWorld(true);
    }
    
    /**
     * The angular velocity (ω) of the Pigeon 2 about the Y axis with
     * respect to the world frame.  This value is mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2048.0
     *   <li> <b>Maximum Value:</b> 2047.99609375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AngularVelocityYWorld Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityYWorld(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AngularVelocityYWorld.value, "AngularVelocityYWorld", AngularVelocity.class, val -> DegreesPerSecond.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The angular velocity (ω) of the Pigeon 2 about the Z axis with
     * respect to the world frame.  This value is mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2048.0
     *   <li> <b>Maximum Value:</b> 2047.99609375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AngularVelocityZWorld Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityZWorld()
    {
        return getAngularVelocityZWorld(true);
    }
    
    /**
     * The angular velocity (ω) of the Pigeon 2 about the Z axis with
     * respect to the world frame.  This value is mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2048.0
     *   <li> <b>Maximum Value:</b> 2047.99609375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AngularVelocityZWorld Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityZWorld(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AngularVelocityZWorld.value, "AngularVelocityZWorld", AngularVelocity.class, val -> DegreesPerSecond.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The acceleration measured by Pigeon2 in the X direction.
     * <p>
     * This value includes the acceleration due to gravity. If this is
     * undesirable, get the gravity vector and subtract out the
     * contribution in this direction.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2.0
     *   <li> <b>Maximum Value:</b> 1.99993896484375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> g
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AccelerationX Status Signal Object
     */
    public final StatusSignal<LinearAcceleration> getAccelerationX()
    {
        return getAccelerationX(true);
    }
    
    /**
     * The acceleration measured by Pigeon2 in the X direction.
     * <p>
     * This value includes the acceleration due to gravity. If this is
     * undesirable, get the gravity vector and subtract out the
     * contribution in this direction.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2.0
     *   <li> <b>Maximum Value:</b> 1.99993896484375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> g
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AccelerationX Status Signal Object
     */
    public final StatusSignal<LinearAcceleration> getAccelerationX(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AccelerationX.value, "AccelerationX", LinearAcceleration.class, val -> Gs.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The acceleration measured by Pigeon2 in the Y direction.
     * <p>
     * This value includes the acceleration due to gravity. If this is
     * undesirable, get the gravity vector and subtract out the
     * contribution in this direction.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2.0
     *   <li> <b>Maximum Value:</b> 1.99993896484375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> g
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AccelerationY Status Signal Object
     */
    public final StatusSignal<LinearAcceleration> getAccelerationY()
    {
        return getAccelerationY(true);
    }
    
    /**
     * The acceleration measured by Pigeon2 in the Y direction.
     * <p>
     * This value includes the acceleration due to gravity. If this is
     * undesirable, get the gravity vector and subtract out the
     * contribution in this direction.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2.0
     *   <li> <b>Maximum Value:</b> 1.99993896484375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> g
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AccelerationY Status Signal Object
     */
    public final StatusSignal<LinearAcceleration> getAccelerationY(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AccelerationY.value, "AccelerationY", LinearAcceleration.class, val -> Gs.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The acceleration measured by Pigeon2 in the Z direction.
     * <p>
     * This value includes the acceleration due to gravity. If this is
     * undesirable, get the gravity vector and subtract out the
     * contribution in this direction.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2.0
     *   <li> <b>Maximum Value:</b> 1.99993896484375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> g
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AccelerationZ Status Signal Object
     */
    public final StatusSignal<LinearAcceleration> getAccelerationZ()
    {
        return getAccelerationZ(true);
    }
    
    /**
     * The acceleration measured by Pigeon2 in the Z direction.
     * <p>
     * This value includes the acceleration due to gravity. If this is
     * undesirable, get the gravity vector and subtract out the
     * contribution in this direction.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2.0
     *   <li> <b>Maximum Value:</b> 1.99993896484375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> g
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AccelerationZ Status Signal Object
     */
    public final StatusSignal<LinearAcceleration> getAccelerationZ(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AccelerationZ.value, "AccelerationZ", LinearAcceleration.class, val -> Gs.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Measured supply voltage to the Pigeon2.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 31.99951171875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return SupplyVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getSupplyVoltage()
    {
        return getSupplyVoltage(true);
    }
    
    /**
     * Measured supply voltage to the Pigeon2.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 31.99951171875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return SupplyVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getSupplyVoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2_SupplyVoltage.value, "SupplyVoltage", Voltage.class, val -> Volts.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The angular velocity (ω) of the Pigeon 2 about the device's X axis.
     * <p>
     * This value is not mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1998.048780487805
     *   <li> <b>Maximum Value:</b> 1997.987804878049
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AngularVelocityXDevice Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityXDevice()
    {
        return getAngularVelocityXDevice(true);
    }
    
    /**
     * The angular velocity (ω) of the Pigeon 2 about the device's X axis.
     * <p>
     * This value is not mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1998.048780487805
     *   <li> <b>Maximum Value:</b> 1997.987804878049
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AngularVelocityXDevice Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityXDevice(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AngularVelocityX.value, "AngularVelocityXDevice", AngularVelocity.class, val -> DegreesPerSecond.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The angular velocity (ω) of the Pigeon 2 about the device's Y axis.
     * <p>
     * This value is not mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1998.048780487805
     *   <li> <b>Maximum Value:</b> 1997.987804878049
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AngularVelocityYDevice Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityYDevice()
    {
        return getAngularVelocityYDevice(true);
    }
    
    /**
     * The angular velocity (ω) of the Pigeon 2 about the device's Y axis.
     * <p>
     * This value is not mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1998.048780487805
     *   <li> <b>Maximum Value:</b> 1997.987804878049
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AngularVelocityYDevice Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityYDevice(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AngularVelocityY.value, "AngularVelocityYDevice", AngularVelocity.class, val -> DegreesPerSecond.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The angular velocity (ω) of the Pigeon 2 about the device's Z axis.
     * <p>
     * This value is not mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1998.048780487805
     *   <li> <b>Maximum Value:</b> 1997.987804878049
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AngularVelocityZDevice Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityZDevice()
    {
        return getAngularVelocityZDevice(true);
    }
    
    /**
     * The angular velocity (ω) of the Pigeon 2 about the device's Z axis.
     * <p>
     * This value is not mount-calibrated.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1998.048780487805
     *   <li> <b>Maximum Value:</b> 1997.987804878049
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> dps
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AngularVelocityZDevice Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAngularVelocityZDevice(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2AngularVelocityZ.value, "AngularVelocityZDevice", AngularVelocity.class, val -> DegreesPerSecond.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The biased magnitude of the magnetic field measured by the Pigeon 2
     * in the X direction. This is only valid after performing a
     * magnetometer calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MagneticFieldX Status Signal Object
     */
    public final StatusSignal<Double> getMagneticFieldX()
    {
        return getMagneticFieldX(true);
    }
    
    /**
     * The biased magnitude of the magnetic field measured by the Pigeon 2
     * in the X direction. This is only valid after performing a
     * magnetometer calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MagneticFieldX Status Signal Object
     */
    public final StatusSignal<Double> getMagneticFieldX(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2MagneticFieldX.value, "MagneticFieldX", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The biased magnitude of the magnetic field measured by the Pigeon 2
     * in the Y direction. This is only valid after performing a
     * magnetometer calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MagneticFieldY Status Signal Object
     */
    public final StatusSignal<Double> getMagneticFieldY()
    {
        return getMagneticFieldY(true);
    }
    
    /**
     * The biased magnitude of the magnetic field measured by the Pigeon 2
     * in the Y direction. This is only valid after performing a
     * magnetometer calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MagneticFieldY Status Signal Object
     */
    public final StatusSignal<Double> getMagneticFieldY(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2MagneticFieldY.value, "MagneticFieldY", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The biased magnitude of the magnetic field measured by the Pigeon 2
     * in the Z direction. This is only valid after performing a
     * magnetometer calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MagneticFieldZ Status Signal Object
     */
    public final StatusSignal<Double> getMagneticFieldZ()
    {
        return getMagneticFieldZ(true);
    }
    
    /**
     * The biased magnitude of the magnetic field measured by the Pigeon 2
     * in the Z direction. This is only valid after performing a
     * magnetometer calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MagneticFieldZ Status Signal Object
     */
    public final StatusSignal<Double> getMagneticFieldZ(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2MagneticFieldZ.value, "MagneticFieldZ", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The raw magnitude of the magnetic field measured by the Pigeon 2 in
     * the X direction. This is only valid after performing a magnetometer
     * calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RawMagneticFieldX Status Signal Object
     */
    public final StatusSignal<Double> getRawMagneticFieldX()
    {
        return getRawMagneticFieldX(true);
    }
    
    /**
     * The raw magnitude of the magnetic field measured by the Pigeon 2 in
     * the X direction. This is only valid after performing a magnetometer
     * calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RawMagneticFieldX Status Signal Object
     */
    public final StatusSignal<Double> getRawMagneticFieldX(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2RawMagneticFieldX.value, "RawMagneticFieldX", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The raw magnitude of the magnetic field measured by the Pigeon 2 in
     * the Y direction. This is only valid after performing a magnetometer
     * calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RawMagneticFieldY Status Signal Object
     */
    public final StatusSignal<Double> getRawMagneticFieldY()
    {
        return getRawMagneticFieldY(true);
    }
    
    /**
     * The raw magnitude of the magnetic field measured by the Pigeon 2 in
     * the Y direction. This is only valid after performing a magnetometer
     * calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RawMagneticFieldY Status Signal Object
     */
    public final StatusSignal<Double> getRawMagneticFieldY(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2RawMagneticFieldY.value, "RawMagneticFieldY", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The raw magnitude of the magnetic field measured by the Pigeon 2 in
     * the Z direction. This is only valid after performing a magnetometer
     * calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RawMagneticFieldZ Status Signal Object
     */
    public final StatusSignal<Double> getRawMagneticFieldZ()
    {
        return getRawMagneticFieldZ(true);
    }
    
    /**
     * The raw magnitude of the magnetic field measured by the Pigeon 2 in
     * the Z direction. This is only valid after performing a magnetometer
     * calibration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -19660.8
     *   <li> <b>Maximum Value:</b> 19660.2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> uT
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RawMagneticFieldZ Status Signal Object
     */
    public final StatusSignal<Double> getRawMagneticFieldZ(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Pigeon2RawMagneticFieldZ.value, "RawMagneticFieldZ", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return IsProLicensed Status Signal Object
     */
    public final StatusSignal<Boolean> getIsProLicensed()
    {
        return getIsProLicensed(true);
    }
    
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return IsProLicensed Status Signal Object
     */
    public final StatusSignal<Boolean> getIsProLicensed(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_IsProLicensed.value, "IsProLicensed", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Hardware()
    {
        return getFault_Hardware(true);
    }
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Hardware(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_Hardware.value, "Fault_Hardware", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Hardware()
    {
        return getStickyFault_Hardware(true);
    }
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Hardware(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_Hardware.value, "StickyFault_Hardware", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Undervoltage()
    {
        return getFault_Undervoltage(true);
    }
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Undervoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_Undervoltage.value, "Fault_Undervoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Undervoltage()
    {
        return getStickyFault_Undervoltage(true);
    }
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Undervoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_Undervoltage.value, "StickyFault_Undervoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootDuringEnable()
    {
        return getFault_BootDuringEnable(true);
    }
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootDuringEnable(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_BootDuringEnable.value, "Fault_BootDuringEnable", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootDuringEnable()
    {
        return getStickyFault_BootDuringEnable(true);
    }
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootDuringEnable(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_BootDuringEnable.value, "StickyFault_BootDuringEnable", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_UnlicensedFeatureInUse()
    {
        return getFault_UnlicensedFeatureInUse(true);
    }
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_UnlicensedFeatureInUse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_UnlicensedFeatureInUse.value, "Fault_UnlicensedFeatureInUse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse()
    {
        return getStickyFault_UnlicensedFeatureInUse(true);
    }
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_UnlicensedFeatureInUse.value, "StickyFault_UnlicensedFeatureInUse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Bootup checks failed: Accelerometer
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BootupAccelerometer Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootupAccelerometer()
    {
        return getFault_BootupAccelerometer(true);
    }
    
    /**
     * Bootup checks failed: Accelerometer
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BootupAccelerometer Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootupAccelerometer(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_PIGEON2_BootupAccel.value, "Fault_BootupAccelerometer", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Bootup checks failed: Accelerometer
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BootupAccelerometer Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootupAccelerometer()
    {
        return getStickyFault_BootupAccelerometer(true);
    }
    
    /**
     * Bootup checks failed: Accelerometer
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BootupAccelerometer Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootupAccelerometer(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_PIGEON2_BootupAccel.value, "StickyFault_BootupAccelerometer", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Bootup checks failed: Gyroscope
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BootupGyroscope Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootupGyroscope()
    {
        return getFault_BootupGyroscope(true);
    }
    
    /**
     * Bootup checks failed: Gyroscope
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BootupGyroscope Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootupGyroscope(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_PIGEON2_BootupGyros.value, "Fault_BootupGyroscope", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Bootup checks failed: Gyroscope
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BootupGyroscope Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootupGyroscope()
    {
        return getStickyFault_BootupGyroscope(true);
    }
    
    /**
     * Bootup checks failed: Gyroscope
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BootupGyroscope Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootupGyroscope(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_PIGEON2_BootupGyros.value, "StickyFault_BootupGyroscope", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Bootup checks failed: Magnetometer
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BootupMagnetometer Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootupMagnetometer()
    {
        return getFault_BootupMagnetometer(true);
    }
    
    /**
     * Bootup checks failed: Magnetometer
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BootupMagnetometer Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootupMagnetometer(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_PIGEON2_BootupMagne.value, "Fault_BootupMagnetometer", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Bootup checks failed: Magnetometer
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BootupMagnetometer Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootupMagnetometer()
    {
        return getStickyFault_BootupMagnetometer(true);
    }
    
    /**
     * Bootup checks failed: Magnetometer
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BootupMagnetometer Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootupMagnetometer(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_PIGEON2_BootupMagne.value, "StickyFault_BootupMagnetometer", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Motion Detected during bootup.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BootIntoMotion Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootIntoMotion()
    {
        return getFault_BootIntoMotion(true);
    }
    
    /**
     * Motion Detected during bootup.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BootIntoMotion Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootIntoMotion(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_PIGEON2_BootIntoMotion.value, "Fault_BootIntoMotion", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Motion Detected during bootup.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BootIntoMotion Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootIntoMotion()
    {
        return getStickyFault_BootIntoMotion(true);
    }
    
    /**
     * Motion Detected during bootup.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BootIntoMotion Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootIntoMotion(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_PIGEON2_BootIntoMotion.value, "StickyFault_BootIntoMotion", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Motion stack data acquisition was slower than expected
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_DataAcquiredLate Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_DataAcquiredLate()
    {
        return getFault_DataAcquiredLate(true);
    }
    
    /**
     * Motion stack data acquisition was slower than expected
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_DataAcquiredLate Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_DataAcquiredLate(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_PIGEON2_DataAcquiredLate.value, "Fault_DataAcquiredLate", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Motion stack data acquisition was slower than expected
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_DataAcquiredLate Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_DataAcquiredLate()
    {
        return getStickyFault_DataAcquiredLate(true);
    }
    
    /**
     * Motion stack data acquisition was slower than expected
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_DataAcquiredLate Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_DataAcquiredLate(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_PIGEON2_DataAcquiredLate.value, "StickyFault_DataAcquiredLate", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Motion stack loop time was slower than expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_LoopTimeSlow Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_LoopTimeSlow()
    {
        return getFault_LoopTimeSlow(true);
    }
    
    /**
     * Motion stack loop time was slower than expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_LoopTimeSlow Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_LoopTimeSlow(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_PIGEON2_LoopTimeSlow.value, "Fault_LoopTimeSlow", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Motion stack loop time was slower than expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_LoopTimeSlow Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_LoopTimeSlow()
    {
        return getStickyFault_LoopTimeSlow(true);
    }
    
    /**
     * Motion stack loop time was slower than expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_LoopTimeSlow Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_LoopTimeSlow(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_PIGEON2_LoopTimeSlow.value, "StickyFault_LoopTimeSlow", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Magnetometer values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_SaturatedMagnetometer Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_SaturatedMagnetometer()
    {
        return getFault_SaturatedMagnetometer(true);
    }
    
    /**
     * Magnetometer values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_SaturatedMagnetometer Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_SaturatedMagnetometer(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_PIGEON2_SaturatedMagne.value, "Fault_SaturatedMagnetometer", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Magnetometer values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_SaturatedMagnetometer Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_SaturatedMagnetometer()
    {
        return getStickyFault_SaturatedMagnetometer(true);
    }
    
    /**
     * Magnetometer values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_SaturatedMagnetometer Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_SaturatedMagnetometer(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_PIGEON2_SaturatedMagne.value, "StickyFault_SaturatedMagnetometer", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Accelerometer values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_SaturatedAccelerometer Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_SaturatedAccelerometer()
    {
        return getFault_SaturatedAccelerometer(true);
    }
    
    /**
     * Accelerometer values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_SaturatedAccelerometer Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_SaturatedAccelerometer(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_PIGEON2_SaturatedAccel.value, "Fault_SaturatedAccelerometer", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Accelerometer values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_SaturatedAccelerometer Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_SaturatedAccelerometer()
    {
        return getStickyFault_SaturatedAccelerometer(true);
    }
    
    /**
     * Accelerometer values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_SaturatedAccelerometer Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_SaturatedAccelerometer(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_PIGEON2_SaturatedAccel.value, "StickyFault_SaturatedAccelerometer", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Gyroscope values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_SaturatedGyroscope Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_SaturatedGyroscope()
    {
        return getFault_SaturatedGyroscope(true);
    }
    
    /**
     * Gyroscope values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_SaturatedGyroscope Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_SaturatedGyroscope(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_PIGEON2_SaturatedGyros.value, "Fault_SaturatedGyroscope", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Gyroscope values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_SaturatedGyroscope Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_SaturatedGyroscope()
    {
        return getStickyFault_SaturatedGyroscope(true);
    }
    
    /**
     * Gyroscope values are saturated
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_SaturatedGyroscope Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_SaturatedGyroscope(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_PIGEON2_SaturatedGyros.value, "StickyFault_SaturatedGyroscope", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }

    

    /**
     * Control device with generic control request object.
     * <p>
     * User must make sure the specified object is castable to a valid control request,
     * otherwise this function will fail at run-time and return the NotSupported StatusCode
     *
     * @param request Control object to request of the device
     * @return Status Code of the request, 0 is OK
     */
    public final StatusCode setControl(ControlRequest request)
    {
        
        return StatusCode.NotSupported;
    }

    
    /**
     * The yaw to set the Pigeon2 to right now.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @param newValue Value to set to. Units are in deg.
     * @return StatusCode of the set command
     */
    public final StatusCode setYaw(double newValue) {
        return setYaw(newValue, 0.100);
    }
    /**
     * The yaw to set the Pigeon2 to right now.
     * 
     * @param newValue Value to set to. Units are in deg.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setYaw(double newValue, double timeoutSeconds) {
        return getConfigurator().setYaw(newValue, timeoutSeconds);
    }
    
    /**
     * The yaw to set the Pigeon2 to right now.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @param newValue Value to set to. Units are in deg.
     * @return StatusCode of the set command
     */
    public final StatusCode setYaw(Angle newValue) {
        return setYaw(newValue.in(Degrees));
    }
    /**
     * The yaw to set the Pigeon2 to right now.
     * 
     * @param newValue Value to set to. Units are in deg.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setYaw(Angle newValue, double timeoutSeconds) {
        return setYaw(newValue.in(Degrees), timeoutSeconds);
    }
    
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults() {
        return clearStickyFaults(0.100);
    }
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults(double timeoutSeconds) {
        return getConfigurator().clearStickyFaults(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware() {
        return clearStickyFault_Hardware(0.100);
    }
    /**
     * Clear sticky fault: Hardware fault occurred
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Hardware(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage() {
        return clearStickyFault_Undervoltage(0.100);
    }
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Undervoltage(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable() {
        return clearStickyFault_BootDuringEnable(0.100);
    }
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_BootDuringEnable(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse() {
        return clearStickyFault_UnlicensedFeatureInUse(0.100);
    }
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_UnlicensedFeatureInUse(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Bootup checks failed: Accelerometer
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupAccelerometer() {
        return clearStickyFault_BootupAccelerometer(0.100);
    }
    /**
     * Clear sticky fault: Bootup checks failed: Accelerometer
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupAccelerometer(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_BootupAccelerometer(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Bootup checks failed: Gyroscope
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupGyroscope() {
        return clearStickyFault_BootupGyroscope(0.100);
    }
    /**
     * Clear sticky fault: Bootup checks failed: Gyroscope
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupGyroscope(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_BootupGyroscope(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Bootup checks failed: Magnetometer
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupMagnetometer() {
        return clearStickyFault_BootupMagnetometer(0.100);
    }
    /**
     * Clear sticky fault: Bootup checks failed: Magnetometer
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootupMagnetometer(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_BootupMagnetometer(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Motion Detected during bootup.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootIntoMotion() {
        return clearStickyFault_BootIntoMotion(0.100);
    }
    /**
     * Clear sticky fault: Motion Detected during bootup.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootIntoMotion(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_BootIntoMotion(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Motion stack data acquisition was slower than
     * expected
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_DataAcquiredLate() {
        return clearStickyFault_DataAcquiredLate(0.100);
    }
    /**
     * Clear sticky fault: Motion stack data acquisition was slower than
     * expected
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_DataAcquiredLate(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_DataAcquiredLate(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Motion stack loop time was slower than
     * expected.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_LoopTimeSlow() {
        return clearStickyFault_LoopTimeSlow(0.100);
    }
    /**
     * Clear sticky fault: Motion stack loop time was slower than
     * expected.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_LoopTimeSlow(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_LoopTimeSlow(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Magnetometer values are saturated
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedMagnetometer() {
        return clearStickyFault_SaturatedMagnetometer(0.100);
    }
    /**
     * Clear sticky fault: Magnetometer values are saturated
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedMagnetometer(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_SaturatedMagnetometer(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Accelerometer values are saturated
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedAccelerometer() {
        return clearStickyFault_SaturatedAccelerometer(0.100);
    }
    /**
     * Clear sticky fault: Accelerometer values are saturated
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedAccelerometer(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_SaturatedAccelerometer(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Gyroscope values are saturated
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedGyroscope() {
        return clearStickyFault_SaturatedGyroscope(0.100);
    }
    /**
     * Clear sticky fault: Gyroscope values are saturated
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SaturatedGyroscope(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_SaturatedGyroscope(timeoutSeconds);
    }
}

