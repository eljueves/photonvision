/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;

/**
 * Class description for the Talon FX integrated motor controller.
 *
 * This handles applying and refreshing the configurations for the {@link com.ctre.phoenix6.hardware.TalonFX}.
 */
public class TalonFXConfiguration implements ParentConfiguration, Cloneable {
    /**
     * True if we should factory default newer unsupported configs,
     * false to leave newer unsupported configs alone.
     * <p>
     * This flag addresses a corner case where the device may have
     * firmware with newer configs that didn't exist when this
     * version of the API was built. If this occurs and this
     * flag is true, unsupported new configs will be factory
     * defaulted to avoid unexpected behavior.
     * <p>
     * This is also the behavior in Phoenix 5, so this flag
     * is defaulted to true to match.
     */
    public boolean FutureProofConfigs = true;

    
    /**
     * Configs that directly affect motor output.
     * <p>
     * Includes motor invert, neutral mode, and other features related to
     * motor output.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link MotorOutputConfigs#Inverted}
     *   <li> {@link MotorOutputConfigs#NeutralMode}
     *   <li> {@link MotorOutputConfigs#DutyCycleNeutralDeadband}
     *   <li> {@link MotorOutputConfigs#PeakForwardDutyCycle}
     *   <li> {@link MotorOutputConfigs#PeakReverseDutyCycle}
     *   <li> {@link MotorOutputConfigs#ControlTimesyncFreqHz}
     * </ul>
     * 
     */
    public MotorOutputConfigs MotorOutput = new MotorOutputConfigs();
    
    /**
     * Configs that directly affect current limiting features.
     * <p>
     * Contains the supply/stator current limit thresholds and whether to
     * enable them.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimit}
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimitEnable}
     *   <li> {@link CurrentLimitsConfigs#SupplyCurrentLimit}
     *   <li> {@link CurrentLimitsConfigs#SupplyCurrentLimitEnable}
     *   <li> {@link CurrentLimitsConfigs#SupplyCurrentLowerLimit}
     *   <li> {@link CurrentLimitsConfigs#SupplyCurrentLowerTime}
     * </ul>
     * 
     */
    public CurrentLimitsConfigs CurrentLimits = new CurrentLimitsConfigs();
    
    /**
     * Configs that affect Voltage control types.
     * <p>
     * Includes peak output voltages and other configs affecting voltage
     * measurements.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link VoltageConfigs#SupplyVoltageTimeConstant}
     *   <li> {@link VoltageConfigs#PeakForwardVoltage}
     *   <li> {@link VoltageConfigs#PeakReverseVoltage}
     * </ul>
     * 
     */
    public VoltageConfigs Voltage = new VoltageConfigs();
    
    /**
     * Configs that affect Torque Current control types.
     * <p>
     * Includes the maximum and minimum applied torque output and the
     * neutral deadband used during TorqueCurrentFOC requests.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link TorqueCurrentConfigs#PeakForwardTorqueCurrent}
     *   <li> {@link TorqueCurrentConfigs#PeakReverseTorqueCurrent}
     *   <li> {@link TorqueCurrentConfigs#TorqueNeutralDeadband}
     * </ul>
     * 
     */
    public TorqueCurrentConfigs TorqueCurrent = new TorqueCurrentConfigs();
    
    /**
     * Configs that affect the feedback of this motor controller.
     * <p>
     * Includes feedback sensor source, any offsets for the feedback
     * sensor, and various ratios to describe the relationship between the
     * sensor and the mechanism for closed looping.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link FeedbackConfigs#FeedbackRotorOffset}
     *   <li> {@link FeedbackConfigs#SensorToMechanismRatio}
     *   <li> {@link FeedbackConfigs#RotorToSensorRatio}
     *   <li> {@link FeedbackConfigs#FeedbackSensorSource}
     *   <li> {@link FeedbackConfigs#FeedbackRemoteSensorID}
     *   <li> {@link FeedbackConfigs#VelocityFilterTimeConstant}
     * </ul>
     * 
     */
    public FeedbackConfigs Feedback = new FeedbackConfigs();
    
    /**
     * Configs related to sensors used for differential control of a
     * mechanism.
     * <p>
     * Includes the differential sensor sources and IDs.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link DifferentialSensorsConfigs#DifferentialSensorSource}
     *   <li> {@link
     * DifferentialSensorsConfigs#DifferentialTalonFXSensorID}
     *   <li> {@link
     * DifferentialSensorsConfigs#DifferentialRemoteSensorID}
     *   <li> {@link DifferentialSensorsConfigs#SensorToDifferentialRatio}
     * </ul>
     * 
     */
    public DifferentialSensorsConfigs DifferentialSensors = new DifferentialSensorsConfigs();
    
    /**
     * Configs related to constants used for differential control of a
     * mechanism.
     * <p>
     * Includes the differential peak outputs.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link
     * DifferentialConstantsConfigs#PeakDifferentialDutyCycle}
     *   <li> {@link DifferentialConstantsConfigs#PeakDifferentialVoltage}
     *   <li> {@link
     * DifferentialConstantsConfigs#PeakDifferentialTorqueCurrent}
     * </ul>
     * 
     */
    public DifferentialConstantsConfigs DifferentialConstants = new DifferentialConstantsConfigs();
    
    /**
     * Configs that affect the open-loop control of this motor controller.
     * <p>
     * Open-loop ramp rates for the various control types.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link OpenLoopRampsConfigs#DutyCycleOpenLoopRampPeriod}
     *   <li> {@link OpenLoopRampsConfigs#VoltageOpenLoopRampPeriod}
     *   <li> {@link OpenLoopRampsConfigs#TorqueOpenLoopRampPeriod}
     * </ul>
     * 
     */
    public OpenLoopRampsConfigs OpenLoopRamps = new OpenLoopRampsConfigs();
    
    /**
     * Configs that affect the closed-loop control of this motor
     * controller.
     * <p>
     * Closed-loop ramp rates for the various control types.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link ClosedLoopRampsConfigs#DutyCycleClosedLoopRampPeriod}
     *   <li> {@link ClosedLoopRampsConfigs#VoltageClosedLoopRampPeriod}
     *   <li> {@link ClosedLoopRampsConfigs#TorqueClosedLoopRampPeriod}
     * </ul>
     * 
     */
    public ClosedLoopRampsConfigs ClosedLoopRamps = new ClosedLoopRampsConfigs();
    
    /**
     * Configs that change how the motor controller behaves under
     * different limit switch states.
     * <p>
     * Includes configs such as enabling limit switches, configuring the
     * remote sensor ID, the source, and the position to set on limit.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link HardwareLimitSwitchConfigs#ForwardLimitType}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ForwardLimitAutosetPositionEnable}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ForwardLimitAutosetPositionValue}
     *   <li> {@link HardwareLimitSwitchConfigs#ForwardLimitEnable}
     *   <li> {@link HardwareLimitSwitchConfigs#ForwardLimitSource}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ForwardLimitRemoteSensorID}
     *   <li> {@link HardwareLimitSwitchConfigs#ReverseLimitType}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ReverseLimitAutosetPositionEnable}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ReverseLimitAutosetPositionValue}
     *   <li> {@link HardwareLimitSwitchConfigs#ReverseLimitEnable}
     *   <li> {@link HardwareLimitSwitchConfigs#ReverseLimitSource}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ReverseLimitRemoteSensorID}
     * </ul>
     * 
     */
    public HardwareLimitSwitchConfigs HardwareLimitSwitch = new HardwareLimitSwitchConfigs();
    
    /**
     * Configs that affect audible components of the device.
     * <p>
     * Includes configuration for the beep on boot.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link AudioConfigs#BeepOnBoot}
     *   <li> {@link AudioConfigs#BeepOnConfig}
     *   <li> {@link AudioConfigs#AllowMusicDurDisable}
     * </ul>
     * 
     */
    public AudioConfigs Audio = new AudioConfigs();
    
    /**
     * Configs that affect how software-limit switches behave.
     * <p>
     * Includes enabling software-limit switches and the threshold at
     * which they are tripped.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link SoftwareLimitSwitchConfigs#ForwardSoftLimitEnable}
     *   <li> {@link SoftwareLimitSwitchConfigs#ReverseSoftLimitEnable}
     *   <li> {@link SoftwareLimitSwitchConfigs#ForwardSoftLimitThreshold}
     *   <li> {@link SoftwareLimitSwitchConfigs#ReverseSoftLimitThreshold}
     * </ul>
     * 
     */
    public SoftwareLimitSwitchConfigs SoftwareLimitSwitch = new SoftwareLimitSwitchConfigs();
    
    /**
     * Configs for Motion Magic®.
     * <p>
     * Includes Velocity, Acceleration, Jerk, and Expo parameters.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link MotionMagicConfigs#MotionMagicCruiseVelocity}
     *   <li> {@link MotionMagicConfigs#MotionMagicAcceleration}
     *   <li> {@link MotionMagicConfigs#MotionMagicJerk}
     *   <li> {@link MotionMagicConfigs#MotionMagicExpo_kV}
     *   <li> {@link MotionMagicConfigs#MotionMagicExpo_kA}
     * </ul>
     * 
     */
    public MotionMagicConfigs MotionMagic = new MotionMagicConfigs();
    
    /**
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     */
    public CustomParamsConfigs CustomParams = new CustomParamsConfigs();
    
    /**
     * Configs that affect general behavior during closed-looping.
     * <p>
     * Includes Continuous Wrap features.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link ClosedLoopGeneralConfigs#ContinuousWrap}
     *   <li> {@link ClosedLoopGeneralConfigs#DifferentialContinuousWrap}
     *   <li> {@link ClosedLoopGeneralConfigs#GainSchedErrorThreshold}
     *   <li> {@link ClosedLoopGeneralConfigs#GainSchedKpBehavior}
     * </ul>
     * 
     */
    public ClosedLoopGeneralConfigs ClosedLoopGeneral = new ClosedLoopGeneralConfigs();
    
    /**
     * Gains for the specified slot.
     * <p>
     * If this slot is selected, these gains are used in closed loop
     * control requests.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link Slot0Configs#kP}
     *   <li> {@link Slot0Configs#kI}
     *   <li> {@link Slot0Configs#kD}
     *   <li> {@link Slot0Configs#kS}
     *   <li> {@link Slot0Configs#kV}
     *   <li> {@link Slot0Configs#kA}
     *   <li> {@link Slot0Configs#kG}
     *   <li> {@link Slot0Configs#GravityType}
     *   <li> {@link Slot0Configs#StaticFeedforwardSign}
     *   <li> {@link Slot0Configs#GravityArmPositionOffset}
     *   <li> {@link Slot0Configs#GainSchedBehavior}
     * </ul>
     * 
     */
    public Slot0Configs Slot0 = new Slot0Configs();
    
    /**
     * Gains for the specified slot.
     * <p>
     * If this slot is selected, these gains are used in closed loop
     * control requests.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link Slot1Configs#kP}
     *   <li> {@link Slot1Configs#kI}
     *   <li> {@link Slot1Configs#kD}
     *   <li> {@link Slot1Configs#kS}
     *   <li> {@link Slot1Configs#kV}
     *   <li> {@link Slot1Configs#kA}
     *   <li> {@link Slot1Configs#kG}
     *   <li> {@link Slot1Configs#GravityType}
     *   <li> {@link Slot1Configs#StaticFeedforwardSign}
     *   <li> {@link Slot1Configs#GravityArmPositionOffset}
     *   <li> {@link Slot1Configs#GainSchedBehavior}
     * </ul>
     * 
     */
    public Slot1Configs Slot1 = new Slot1Configs();
    
    /**
     * Gains for the specified slot.
     * <p>
     * If this slot is selected, these gains are used in closed loop
     * control requests.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link Slot2Configs#kP}
     *   <li> {@link Slot2Configs#kI}
     *   <li> {@link Slot2Configs#kD}
     *   <li> {@link Slot2Configs#kS}
     *   <li> {@link Slot2Configs#kV}
     *   <li> {@link Slot2Configs#kA}
     *   <li> {@link Slot2Configs#kG}
     *   <li> {@link Slot2Configs#GravityType}
     *   <li> {@link Slot2Configs#StaticFeedforwardSign}
     *   <li> {@link Slot2Configs#GravityArmPositionOffset}
     *   <li> {@link Slot2Configs#GainSchedBehavior}
     * </ul>
     * 
     */
    public Slot2Configs Slot2 = new Slot2Configs();
    
    /**
     * Modifies this configuration's MotorOutput parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that directly affect motor output.
     * <p>
     * Includes motor invert, neutral mode, and other features related to
     * motor output.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link MotorOutputConfigs#Inverted}
     *   <li> {@link MotorOutputConfigs#NeutralMode}
     *   <li> {@link MotorOutputConfigs#DutyCycleNeutralDeadband}
     *   <li> {@link MotorOutputConfigs#PeakForwardDutyCycle}
     *   <li> {@link MotorOutputConfigs#PeakReverseDutyCycle}
     *   <li> {@link MotorOutputConfigs#ControlTimesyncFreqHz}
     * </ul>
     * 
     *
     * @param newMotorOutput Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withMotorOutput(MotorOutputConfigs newMotorOutput)
    {
        MotorOutput = newMotorOutput;
        return this;
    }
    
    /**
     * Modifies this configuration's CurrentLimits parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that directly affect current limiting features.
     * <p>
     * Contains the supply/stator current limit thresholds and whether to
     * enable them.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimit}
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimitEnable}
     *   <li> {@link CurrentLimitsConfigs#SupplyCurrentLimit}
     *   <li> {@link CurrentLimitsConfigs#SupplyCurrentLimitEnable}
     *   <li> {@link CurrentLimitsConfigs#SupplyCurrentLowerLimit}
     *   <li> {@link CurrentLimitsConfigs#SupplyCurrentLowerTime}
     * </ul>
     * 
     *
     * @param newCurrentLimits Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withCurrentLimits(CurrentLimitsConfigs newCurrentLimits)
    {
        CurrentLimits = newCurrentLimits;
        return this;
    }
    
    /**
     * Modifies this configuration's Voltage parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect Voltage control types.
     * <p>
     * Includes peak output voltages and other configs affecting voltage
     * measurements.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link VoltageConfigs#SupplyVoltageTimeConstant}
     *   <li> {@link VoltageConfigs#PeakForwardVoltage}
     *   <li> {@link VoltageConfigs#PeakReverseVoltage}
     * </ul>
     * 
     *
     * @param newVoltage Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withVoltage(VoltageConfigs newVoltage)
    {
        Voltage = newVoltage;
        return this;
    }
    
    /**
     * Modifies this configuration's TorqueCurrent parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect Torque Current control types.
     * <p>
     * Includes the maximum and minimum applied torque output and the
     * neutral deadband used during TorqueCurrentFOC requests.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link TorqueCurrentConfigs#PeakForwardTorqueCurrent}
     *   <li> {@link TorqueCurrentConfigs#PeakReverseTorqueCurrent}
     *   <li> {@link TorqueCurrentConfigs#TorqueNeutralDeadband}
     * </ul>
     * 
     *
     * @param newTorqueCurrent Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withTorqueCurrent(TorqueCurrentConfigs newTorqueCurrent)
    {
        TorqueCurrent = newTorqueCurrent;
        return this;
    }
    
    /**
     * Modifies this configuration's Feedback parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect the feedback of this motor controller.
     * <p>
     * Includes feedback sensor source, any offsets for the feedback
     * sensor, and various ratios to describe the relationship between the
     * sensor and the mechanism for closed looping.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link FeedbackConfigs#FeedbackRotorOffset}
     *   <li> {@link FeedbackConfigs#SensorToMechanismRatio}
     *   <li> {@link FeedbackConfigs#RotorToSensorRatio}
     *   <li> {@link FeedbackConfigs#FeedbackSensorSource}
     *   <li> {@link FeedbackConfigs#FeedbackRemoteSensorID}
     *   <li> {@link FeedbackConfigs#VelocityFilterTimeConstant}
     * </ul>
     * 
     *
     * @param newFeedback Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withFeedback(FeedbackConfigs newFeedback)
    {
        Feedback = newFeedback;
        return this;
    }
    
    /**
     * Modifies this configuration's DifferentialSensors parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs related to sensors used for differential control of a
     * mechanism.
     * <p>
     * Includes the differential sensor sources and IDs.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link DifferentialSensorsConfigs#DifferentialSensorSource}
     *   <li> {@link
     * DifferentialSensorsConfigs#DifferentialTalonFXSensorID}
     *   <li> {@link
     * DifferentialSensorsConfigs#DifferentialRemoteSensorID}
     *   <li> {@link DifferentialSensorsConfigs#SensorToDifferentialRatio}
     * </ul>
     * 
     *
     * @param newDifferentialSensors Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withDifferentialSensors(DifferentialSensorsConfigs newDifferentialSensors)
    {
        DifferentialSensors = newDifferentialSensors;
        return this;
    }
    
    /**
     * Modifies this configuration's DifferentialConstants parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs related to constants used for differential control of a
     * mechanism.
     * <p>
     * Includes the differential peak outputs.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link
     * DifferentialConstantsConfigs#PeakDifferentialDutyCycle}
     *   <li> {@link DifferentialConstantsConfigs#PeakDifferentialVoltage}
     *   <li> {@link
     * DifferentialConstantsConfigs#PeakDifferentialTorqueCurrent}
     * </ul>
     * 
     *
     * @param newDifferentialConstants Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withDifferentialConstants(DifferentialConstantsConfigs newDifferentialConstants)
    {
        DifferentialConstants = newDifferentialConstants;
        return this;
    }
    
    /**
     * Modifies this configuration's OpenLoopRamps parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect the open-loop control of this motor controller.
     * <p>
     * Open-loop ramp rates for the various control types.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link OpenLoopRampsConfigs#DutyCycleOpenLoopRampPeriod}
     *   <li> {@link OpenLoopRampsConfigs#VoltageOpenLoopRampPeriod}
     *   <li> {@link OpenLoopRampsConfigs#TorqueOpenLoopRampPeriod}
     * </ul>
     * 
     *
     * @param newOpenLoopRamps Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withOpenLoopRamps(OpenLoopRampsConfigs newOpenLoopRamps)
    {
        OpenLoopRamps = newOpenLoopRamps;
        return this;
    }
    
    /**
     * Modifies this configuration's ClosedLoopRamps parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect the closed-loop control of this motor
     * controller.
     * <p>
     * Closed-loop ramp rates for the various control types.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link ClosedLoopRampsConfigs#DutyCycleClosedLoopRampPeriod}
     *   <li> {@link ClosedLoopRampsConfigs#VoltageClosedLoopRampPeriod}
     *   <li> {@link ClosedLoopRampsConfigs#TorqueClosedLoopRampPeriod}
     * </ul>
     * 
     *
     * @param newClosedLoopRamps Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withClosedLoopRamps(ClosedLoopRampsConfigs newClosedLoopRamps)
    {
        ClosedLoopRamps = newClosedLoopRamps;
        return this;
    }
    
    /**
     * Modifies this configuration's HardwareLimitSwitch parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that change how the motor controller behaves under
     * different limit switch states.
     * <p>
     * Includes configs such as enabling limit switches, configuring the
     * remote sensor ID, the source, and the position to set on limit.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link HardwareLimitSwitchConfigs#ForwardLimitType}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ForwardLimitAutosetPositionEnable}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ForwardLimitAutosetPositionValue}
     *   <li> {@link HardwareLimitSwitchConfigs#ForwardLimitEnable}
     *   <li> {@link HardwareLimitSwitchConfigs#ForwardLimitSource}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ForwardLimitRemoteSensorID}
     *   <li> {@link HardwareLimitSwitchConfigs#ReverseLimitType}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ReverseLimitAutosetPositionEnable}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ReverseLimitAutosetPositionValue}
     *   <li> {@link HardwareLimitSwitchConfigs#ReverseLimitEnable}
     *   <li> {@link HardwareLimitSwitchConfigs#ReverseLimitSource}
     *   <li> {@link
     * HardwareLimitSwitchConfigs#ReverseLimitRemoteSensorID}
     * </ul>
     * 
     *
     * @param newHardwareLimitSwitch Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withHardwareLimitSwitch(HardwareLimitSwitchConfigs newHardwareLimitSwitch)
    {
        HardwareLimitSwitch = newHardwareLimitSwitch;
        return this;
    }
    
    /**
     * Modifies this configuration's Audio parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect audible components of the device.
     * <p>
     * Includes configuration for the beep on boot.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link AudioConfigs#BeepOnBoot}
     *   <li> {@link AudioConfigs#BeepOnConfig}
     *   <li> {@link AudioConfigs#AllowMusicDurDisable}
     * </ul>
     * 
     *
     * @param newAudio Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withAudio(AudioConfigs newAudio)
    {
        Audio = newAudio;
        return this;
    }
    
    /**
     * Modifies this configuration's SoftwareLimitSwitch parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect how software-limit switches behave.
     * <p>
     * Includes enabling software-limit switches and the threshold at
     * which they are tripped.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link SoftwareLimitSwitchConfigs#ForwardSoftLimitEnable}
     *   <li> {@link SoftwareLimitSwitchConfigs#ReverseSoftLimitEnable}
     *   <li> {@link SoftwareLimitSwitchConfigs#ForwardSoftLimitThreshold}
     *   <li> {@link SoftwareLimitSwitchConfigs#ReverseSoftLimitThreshold}
     * </ul>
     * 
     *
     * @param newSoftwareLimitSwitch Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withSoftwareLimitSwitch(SoftwareLimitSwitchConfigs newSoftwareLimitSwitch)
    {
        SoftwareLimitSwitch = newSoftwareLimitSwitch;
        return this;
    }
    
    /**
     * Modifies this configuration's MotionMagic parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs for Motion Magic®.
     * <p>
     * Includes Velocity, Acceleration, Jerk, and Expo parameters.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link MotionMagicConfigs#MotionMagicCruiseVelocity}
     *   <li> {@link MotionMagicConfigs#MotionMagicAcceleration}
     *   <li> {@link MotionMagicConfigs#MotionMagicJerk}
     *   <li> {@link MotionMagicConfigs#MotionMagicExpo_kV}
     *   <li> {@link MotionMagicConfigs#MotionMagicExpo_kA}
     * </ul>
     * 
     *
     * @param newMotionMagic Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withMotionMagic(MotionMagicConfigs newMotionMagic)
    {
        MotionMagic = newMotionMagic;
        return this;
    }
    
    /**
     * Modifies this configuration's CustomParams parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     *
     * @param newCustomParams Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withCustomParams(CustomParamsConfigs newCustomParams)
    {
        CustomParams = newCustomParams;
        return this;
    }
    
    /**
     * Modifies this configuration's ClosedLoopGeneral parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect general behavior during closed-looping.
     * <p>
     * Includes Continuous Wrap features.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link ClosedLoopGeneralConfigs#ContinuousWrap}
     *   <li> {@link ClosedLoopGeneralConfigs#DifferentialContinuousWrap}
     *   <li> {@link ClosedLoopGeneralConfigs#GainSchedErrorThreshold}
     *   <li> {@link ClosedLoopGeneralConfigs#GainSchedKpBehavior}
     * </ul>
     * 
     *
     * @param newClosedLoopGeneral Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withClosedLoopGeneral(ClosedLoopGeneralConfigs newClosedLoopGeneral)
    {
        ClosedLoopGeneral = newClosedLoopGeneral;
        return this;
    }
    
    /**
     * Modifies this configuration's Slot0 parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Gains for the specified slot.
     * <p>
     * If this slot is selected, these gains are used in closed loop
     * control requests.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link Slot0Configs#kP}
     *   <li> {@link Slot0Configs#kI}
     *   <li> {@link Slot0Configs#kD}
     *   <li> {@link Slot0Configs#kS}
     *   <li> {@link Slot0Configs#kV}
     *   <li> {@link Slot0Configs#kA}
     *   <li> {@link Slot0Configs#kG}
     *   <li> {@link Slot0Configs#GravityType}
     *   <li> {@link Slot0Configs#StaticFeedforwardSign}
     *   <li> {@link Slot0Configs#GravityArmPositionOffset}
     *   <li> {@link Slot0Configs#GainSchedBehavior}
     * </ul>
     * 
     *
     * @param newSlot0 Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withSlot0(Slot0Configs newSlot0)
    {
        Slot0 = newSlot0;
        return this;
    }
    
    /**
     * Modifies this configuration's Slot1 parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Gains for the specified slot.
     * <p>
     * If this slot is selected, these gains are used in closed loop
     * control requests.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link Slot1Configs#kP}
     *   <li> {@link Slot1Configs#kI}
     *   <li> {@link Slot1Configs#kD}
     *   <li> {@link Slot1Configs#kS}
     *   <li> {@link Slot1Configs#kV}
     *   <li> {@link Slot1Configs#kA}
     *   <li> {@link Slot1Configs#kG}
     *   <li> {@link Slot1Configs#GravityType}
     *   <li> {@link Slot1Configs#StaticFeedforwardSign}
     *   <li> {@link Slot1Configs#GravityArmPositionOffset}
     *   <li> {@link Slot1Configs#GainSchedBehavior}
     * </ul>
     * 
     *
     * @param newSlot1 Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withSlot1(Slot1Configs newSlot1)
    {
        Slot1 = newSlot1;
        return this;
    }
    
    /**
     * Modifies this configuration's Slot2 parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Gains for the specified slot.
     * <p>
     * If this slot is selected, these gains are used in closed loop
     * control requests.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link Slot2Configs#kP}
     *   <li> {@link Slot2Configs#kI}
     *   <li> {@link Slot2Configs#kD}
     *   <li> {@link Slot2Configs#kS}
     *   <li> {@link Slot2Configs#kV}
     *   <li> {@link Slot2Configs#kA}
     *   <li> {@link Slot2Configs#kG}
     *   <li> {@link Slot2Configs#GravityType}
     *   <li> {@link Slot2Configs#StaticFeedforwardSign}
     *   <li> {@link Slot2Configs#GravityArmPositionOffset}
     *   <li> {@link Slot2Configs#GainSchedBehavior}
     * </ul>
     * 
     *
     * @param newSlot2 Parameter to modify
     * @return Itself
     */
    public final TalonFXConfiguration withSlot2(Slot2Configs newSlot2)
    {
        Slot2 = newSlot2;
        return this;
    }

    @Override
    public String toString() {
        String ss = "TalonFXConfiguration\n";
        ss += MotorOutput.toString();
        ss += CurrentLimits.toString();
        ss += Voltage.toString();
        ss += TorqueCurrent.toString();
        ss += Feedback.toString();
        ss += DifferentialSensors.toString();
        ss += DifferentialConstants.toString();
        ss += OpenLoopRamps.toString();
        ss += ClosedLoopRamps.toString();
        ss += HardwareLimitSwitch.toString();
        ss += Audio.toString();
        ss += SoftwareLimitSwitch.toString();
        ss += MotionMagic.toString();
        ss += CustomParams.toString();
        ss += ClosedLoopGeneral.toString();
        ss += Slot0.toString();
        ss += Slot1.toString();
        ss += Slot2.toString();
        return ss;
    }

    /**
     * Get the serialized form of this configuration.
     *
     * @return Serialized form of this config group
     */
    public final String serialize() {
        String ss = "";
        ss += MotorOutput.serialize();
        ss += CurrentLimits.serialize();
        ss += Voltage.serialize();
        ss += TorqueCurrent.serialize();
        ss += Feedback.serialize();
        ss += DifferentialSensors.serialize();
        ss += DifferentialConstants.serialize();
        ss += OpenLoopRamps.serialize();
        ss += ClosedLoopRamps.serialize();
        ss += HardwareLimitSwitch.serialize();
        ss += Audio.serialize();
        ss += SoftwareLimitSwitch.serialize();
        ss += MotionMagic.serialize();
        ss += CustomParams.serialize();
        ss += ClosedLoopGeneral.serialize();
        ss += Slot0.serialize();
        ss += Slot1.serialize();
        ss += Slot2.serialize();
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration.
     *
     * @return Return code of the deserialize method
     */
    public final StatusCode deserialize(String to_deserialize) {
        StatusCode err = StatusCode.OK;
        err = MotorOutput.deserialize(to_deserialize);
        err = CurrentLimits.deserialize(to_deserialize);
        err = Voltage.deserialize(to_deserialize);
        err = TorqueCurrent.deserialize(to_deserialize);
        err = Feedback.deserialize(to_deserialize);
        err = DifferentialSensors.deserialize(to_deserialize);
        err = DifferentialConstants.deserialize(to_deserialize);
        err = OpenLoopRamps.deserialize(to_deserialize);
        err = ClosedLoopRamps.deserialize(to_deserialize);
        err = HardwareLimitSwitch.deserialize(to_deserialize);
        err = Audio.deserialize(to_deserialize);
        err = SoftwareLimitSwitch.deserialize(to_deserialize);
        err = MotionMagic.deserialize(to_deserialize);
        err = CustomParams.deserialize(to_deserialize);
        err = ClosedLoopGeneral.deserialize(to_deserialize);
        err = Slot0.deserialize(to_deserialize);
        err = Slot1.deserialize(to_deserialize);
        err = Slot2.deserialize(to_deserialize);
        return err;
    }

    @Override
    public TalonFXConfiguration clone() {
        var retval = new TalonFXConfiguration();
        retval.FutureProofConfigs = FutureProofConfigs;
        retval.MotorOutput = MotorOutput.clone();
        retval.CurrentLimits = CurrentLimits.clone();
        retval.Voltage = Voltage.clone();
        retval.TorqueCurrent = TorqueCurrent.clone();
        retval.Feedback = Feedback.clone();
        retval.DifferentialSensors = DifferentialSensors.clone();
        retval.DifferentialConstants = DifferentialConstants.clone();
        retval.OpenLoopRamps = OpenLoopRamps.clone();
        retval.ClosedLoopRamps = ClosedLoopRamps.clone();
        retval.HardwareLimitSwitch = HardwareLimitSwitch.clone();
        retval.Audio = Audio.clone();
        retval.SoftwareLimitSwitch = SoftwareLimitSwitch.clone();
        retval.MotionMagic = MotionMagic.clone();
        retval.CustomParams = CustomParams.clone();
        retval.ClosedLoopGeneral = ClosedLoopGeneral.clone();
        retval.Slot0 = Slot0.clone();
        retval.Slot1 = Slot1.clone();
        retval.Slot2 = Slot2.clone();
        return retval;
    }
}
