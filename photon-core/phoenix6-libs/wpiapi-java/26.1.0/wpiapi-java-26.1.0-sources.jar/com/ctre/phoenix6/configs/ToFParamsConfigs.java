/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs that affect the ToF sensor
 * <p>
 * Includes Update mode and frequency
 */
public class ToFParamsConfigs implements ParentConfiguration, Cloneable {
    /**
     * Update mode of the CANrange. The CANrange supports short-range and
     * long-range detection at various update frequencies.
     * 
     */
    public UpdateModeValue UpdateMode = UpdateModeValue.ShortRange100Hz;
    /**
     * Rate at which the CANrange will take measurements. A lower
     * frequency may provide more stable readings but will reduce the data
     * rate of the sensor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 5
     *   <li> <b>Maximum Value:</b> 50
     *   <li> <b>Default Value:</b> 50
     *   <li> <b>Units:</b> Hz
     * </ul>
     */
    public double UpdateFrequency = 50;
    
    /**
     * Modifies this configuration's UpdateMode parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Update mode of the CANrange. The CANrange supports short-range and
     * long-range detection at various update frequencies.
     * 
     *
     * @param newUpdateMode Parameter to modify
     * @return Itself
     */
    public final ToFParamsConfigs withUpdateMode(UpdateModeValue newUpdateMode)
    {
        UpdateMode = newUpdateMode;
        return this;
    }
    
    /**
     * Modifies this configuration's UpdateFrequency parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Rate at which the CANrange will take measurements. A lower
     * frequency may provide more stable readings but will reduce the data
     * rate of the sensor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 5
     *   <li> <b>Maximum Value:</b> 50
     *   <li> <b>Default Value:</b> 50
     *   <li> <b>Units:</b> Hz
     * </ul>
     *
     * @param newUpdateFrequency Parameter to modify
     * @return Itself
     */
    public final ToFParamsConfigs withUpdateFrequency(double newUpdateFrequency)
    {
        UpdateFrequency = newUpdateFrequency;
        return this;
    }
    
    /**
     * Modifies this configuration's UpdateFrequency parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Rate at which the CANrange will take measurements. A lower
     * frequency may provide more stable readings but will reduce the data
     * rate of the sensor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 5
     *   <li> <b>Maximum Value:</b> 50
     *   <li> <b>Default Value:</b> 50
     *   <li> <b>Units:</b> Hz
     * </ul>
     *
     * @param newUpdateFrequency Parameter to modify
     * @return Itself
     */
    public final ToFParamsConfigs withUpdateFrequency(Frequency newUpdateFrequency)
    {
        UpdateFrequency = newUpdateFrequency.in(Hertz);
        return this;
    }
    
    /**
     * Helper method to get this configuration's UpdateFrequency parameter converted
     * to a unit type. If not using the Java units library, {@link #UpdateFrequency}
     * can be accessed directly instead.
     * <p>
     * Rate at which the CANrange will take measurements. A lower
     * frequency may provide more stable readings but will reduce the data
     * rate of the sensor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 5
     *   <li> <b>Maximum Value:</b> 50
     *   <li> <b>Default Value:</b> 50
     *   <li> <b>Units:</b> Hz
     * </ul>
     *
     * @return UpdateFrequency
     */
    public final Frequency getUpdateFrequencyMeasure()
    {
        return Hertz.of(UpdateFrequency);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: ToFParams\n";
        ss += "    UpdateMode: " + UpdateMode + "\n";
        ss += "    UpdateFrequency: " + UpdateFrequency + " Hz" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeint(SpnValue.CANrange_UpdateMode.value, UpdateMode.value);
        ss += ConfigJNI.Serializedouble(SpnValue.CANrange_UpdateFreq.value, UpdateFrequency);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        UpdateMode = UpdateModeValue.valueOf(ConfigJNI.Deserializeint(SpnValue.CANrange_UpdateMode.value, to_deserialize));
        UpdateFrequency = ConfigJNI.Deserializedouble(SpnValue.CANrange_UpdateFreq.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public ToFParamsConfigs clone() {
        try {
            return (ToFParamsConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

