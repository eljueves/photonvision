/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware;

import java.util.ArrayList;

import com.ctre.phoenix6.CANBus;
import com.ctre.phoenix6.Utils;
import com.ctre.phoenix6.hardware.core.CoreCANdi;
import com.ctre.phoenix6.jni.PlatformJNI;
import com.ctre.phoenix6.sim.DeviceType;
import com.ctre.phoenix6.wpiutils.AutoFeedEnable;
import com.ctre.phoenix6.wpiutils.CallbackHelper;
import com.ctre.phoenix6.wpiutils.ReplayAutoEnable;

import edu.wpi.first.hal.HAL;
import edu.wpi.first.hal.HAL.SimPeriodicBeforeCallback;
import edu.wpi.first.hal.HALValue;
import edu.wpi.first.hal.SimDevice;
import edu.wpi.first.hal.SimDevice.Direction;
import edu.wpi.first.hal.SimBoolean;
import edu.wpi.first.hal.SimDouble;
import edu.wpi.first.hal.SimEnum;
import edu.wpi.first.hal.simulation.SimDeviceDataJNI;
import edu.wpi.first.util.sendable.Sendable;
import edu.wpi.first.util.sendable.SendableBuilder;
import edu.wpi.first.util.sendable.SendableRegistry;
import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.wpilibj.simulation.CallbackStore;
import edu.wpi.first.wpilibj.simulation.SimDeviceSim;

/**
 * WPILib-integrated version of {@link CoreCANdi}.
 */
public class CANdi extends CoreCANdi implements Sendable, AutoCloseable {
    /**
     * The StatusSignal getters are copies so that calls
     * to the WPI interface do not update any references
     */
    private static final DeviceType kSimDeviceType = DeviceType.P6_CANdiType;

    private SimDevice m_simCANdi;
    private SimDouble m_simSupplyVoltage;
    private SimDouble m_simRequestedOutputCurrent;
    private SimDouble m_simOutputCurrent;

    private SimDevice m_simPwm1;
    private SimDouble m_simPwm1Position;
    private SimBoolean m_simPwm1Connected;
    private SimDouble m_simPwm1Velocity;
    private SimDouble m_simPwm1RiseRise;
    private SimDouble m_simPwm1RiseFall;

    private SimDevice m_simPwm2;
    private SimDouble m_simPwm2Position;
    private SimBoolean m_simPwm2Connected;
    private SimDouble m_simPwm2Velocity;
    private SimDouble m_simPwm2RiseRise;
    private SimDouble m_simPwm2RiseFall;

    private SimDevice m_simQuadrature;
    private SimDouble m_simQuadPos;
    private SimDouble m_simQuadRawPos;
    private SimDouble m_simQuadVel;

    private SimDevice m_simS1DIO;
    private SimBoolean m_simS1Closed;
    private SimEnum m_simS1State;

    private SimDevice m_simS2DIO;
    private SimBoolean m_simS2Closed;
    private SimEnum m_simS2State;

    // returned registered callbacks
    private final ArrayList<CallbackStore> m_simValueChangedCallbacks = new ArrayList<CallbackStore>();
    private SimPeriodicBeforeCallback m_simPeriodicBeforeCallback = null;

    /**
     * Constructs a new CANdi object.
     * <p>
     * Constructs the device using the default CAN bus for the system
     * (see {@link CANBus#CANBus()}).
     *
     * @param deviceId ID of the device, as configured in Phoenix Tuner
     */
    public CANdi(int deviceId) {
        this(deviceId, new CANBus());
    }

    /**
     * Constructs a new CANdi object.
     *
     * @param deviceId ID of the device, as configured in Phoenix Tuner
     * @param canbus   Name of the CAN bus this device is on. Possible CAN bus
     *                 strings are:
     *                 <ul>
     *                   <li>"rio" for the native roboRIO CAN bus
     *                   <li>CANivore name or serial number
     *                   <li>SocketCAN interface (non-FRC Linux only)
     *                   <li>"*" for any CANivore seen by the program
     *                   <li>empty string (default) to select the default for the
     *                       system:
     *                   <ul>
     *                     <li>"rio" on roboRIO
     *                     <li>"can0" on Linux
     *                     <li>"*" on Windows
     *                   </ul>
     *                 </ul>
     *
     * @deprecated Constructing devices with a CAN bus string is deprecated for removal
     * in the 2027 season. Construct devices using a {@link CANBus} instance instead.
     */
    @Deprecated(since = "2026", forRemoval = true)
    public CANdi(int deviceId, String canbus) {
        this(deviceId, new CANBus(canbus));
    }

    /**
     * Constructs a new CANdi object.
     *
     * @param deviceId ID of the device, as configured in Phoenix Tuner
     * @param canbus   The CAN bus this device is on
     */
    @SuppressWarnings("this-escape")
    public CANdi(int deviceId, CANBus canbus) {
        super(deviceId, canbus);
        SendableRegistry.addLW(this, "CANdi (v6) ", deviceId);

        if (RobotBase.isSimulation()) {
            /* run in both swsim and hwsim */
            AutoFeedEnable.getInstance().start();
        }
        if (Utils.isReplay()) {
            ReplayAutoEnable.getInstance().start();
        }

        m_simCANdi = SimDevice.create("CAN:CANdi (v6)", deviceId);

        final String base = "CANdi (v6)[" + deviceId + "]/";
        m_simPwm1 = SimDevice.create("CANDutyCycle:" + base + "PWM1");
        m_simPwm2 = SimDevice.create("CANDutyCycle:" + base + "PWM2");
        m_simQuadrature = SimDevice.create("CANEncoder:" + base + "Quadrature");
        m_simS1DIO = SimDevice.create("CANDIO:" + base + "S1");
        m_simS2DIO = SimDevice.create("CANDIO:" + base + "S2");

        final String[] StateEnums = new String[]{"Floating", "Low", "High"};

        if (m_simCANdi != null) {
            m_simPeriodicBeforeCallback = HAL.registerSimPeriodicBeforeCallback(this::onPeriodic);

            m_simSupplyVoltage = m_simCANdi.createDouble("supplyVoltage", Direction.kInput, 12.0);
            m_simRequestedOutputCurrent = m_simCANdi.createDouble("requestedOutputCurrent", Direction.kInput, 0);
            m_simOutputCurrent = m_simCANdi.createDouble("outputCurrent", Direction.kOutput, 0);

            final SimDeviceSim sim = new SimDeviceSim("CAN:CANdi (v6)");
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simSupplyVoltage, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simRequestedOutputCurrent, this::onValueChanged, true)
            );
        }
        if (m_simPwm1 != null) {
            m_simPwm1Position = m_simPwm1.createDouble("position", Direction.kInput, 0);
            m_simPwm1Connected = m_simPwm1.createBoolean("connected", Direction.kInput, true);
            m_simPwm1Velocity = m_simPwm1.createDouble("velocity", Direction.kInput, 0);
            m_simPwm1RiseRise = m_simPwm1.createDouble("riseToRise", Direction.kInput, 0.004);
            m_simPwm1RiseFall = m_simPwm1.createDouble("riseToFall", Direction.kInput, 0);

            final SimDeviceSim sim = new SimDeviceSim("CANDutyCycle:" + base + "PWM1");
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simPwm1Position, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simPwm1Connected, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simPwm1Velocity, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simPwm1RiseRise, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simPwm1RiseFall, this::onValueChanged, true)
            );
        }
        if (m_simPwm2 != null) {
            m_simPwm2Position = m_simPwm2.createDouble("position", Direction.kInput, 0);
            m_simPwm2Connected = m_simPwm2.createBoolean("connected", Direction.kInput, true);
            m_simPwm2Velocity = m_simPwm2.createDouble("velocity", Direction.kInput, 0);
            m_simPwm2RiseRise = m_simPwm2.createDouble("riseToRise", Direction.kInput, 0.004);
            m_simPwm2RiseFall = m_simPwm2.createDouble("riseToFall", Direction.kInput, 0);

            final SimDeviceSim sim = new SimDeviceSim("CANDutyCycle:" + base + "PWM2");
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simPwm2Position, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simPwm2Connected, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simPwm2Velocity, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simPwm2RiseRise, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simPwm2RiseFall, this::onValueChanged, true)
            );
        }
        if (m_simQuadrature != null) {
            m_simQuadrature.createBoolean("init", Direction.kOutput, true);

            m_simQuadPos = m_simQuadrature.createDouble("position", Direction.kOutput, 0);

            m_simQuadRawPos = m_simQuadrature.createDouble("rawPositionInput", Direction.kInput, 0);
            m_simQuadVel = m_simQuadrature.createDouble("velocity", Direction.kInput, 0);

            final SimDeviceSim sim = new SimDeviceSim("CANEncoder:" + base + "Quadrature");
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simQuadRawPos, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simQuadVel, this::onValueChanged, true)
            );
        }
        if (m_simS1DIO != null) {
            m_simS1DIO.createBoolean("init", Direction.kOutput, true);
            m_simS1DIO.createBoolean("input", Direction.kOutput, true);
            m_simS1Closed = m_simS1DIO.createBoolean("value", Direction.kOutput, false);
            m_simS1State = m_simS1DIO.createEnum("state", Direction.kInput, StateEnums, 0);

            final SimDeviceSim sim = new SimDeviceSim("CANDIO:" + base + "S1");
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simS1State, this::onValueChanged, true)
            );
        }
        if (m_simS2DIO != null) {
            m_simS2DIO.createBoolean("init", Direction.kOutput, true);
            m_simS2DIO.createBoolean("input", Direction.kOutput, true);
            m_simS2Closed = m_simS2DIO.createBoolean("value", Direction.kOutput, false);
            m_simS2State = m_simS2DIO.createEnum("state", Direction.kInput, StateEnums, 0);

            final SimDeviceSim sim = new SimDeviceSim("CANDIO:" + base + "S2");
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simS2State, this::onValueChanged, true)
            );
        }
    }

    // ----- Auto-Closable ----- //
    @Override
    public void close() {
        SendableRegistry.remove(this);
        if (m_simPeriodicBeforeCallback != null) {
            m_simPeriodicBeforeCallback.close();
            m_simPeriodicBeforeCallback = null;
        }
        if (m_simCANdi != null) {
            m_simCANdi.close();
            m_simCANdi = null;
        }
        if (m_simPwm1 != null) {
            m_simPwm1.close();
            m_simPwm1 = null;
        }
        if (m_simPwm2 != null) {
            m_simPwm2.close();
            m_simPwm2 = null;
        }
        if (m_simQuadrature != null) {
            m_simQuadrature.close();
            m_simQuadrature = null;
        }
        if (m_simS1DIO != null) {
            m_simS1DIO.close();
            m_simS1DIO = null;
        }
        if (m_simS2DIO != null) {
            m_simS2DIO.close();
            m_simS2DIO = null;
        }

        for (var callback : m_simValueChangedCallbacks) {
            callback.close();
        }
        m_simValueChangedCallbacks.clear();

        AutoFeedEnable.getInstance().stop();
    }

    // ----- Callbacks for Sim ----- //
    private void onValueChanged(String name, int handle, int direction, HALValue value) {
        String deviceName = SimDeviceDataJNI.getSimDeviceName(SimDeviceDataJNI.getSimValueDeviceHandle(handle));
        String physType = deviceName + ":" + name;
        PlatformJNI.JNI_SimSetPhysicsInput(
            kSimDeviceType.value, getDeviceID(),
            physType, CallbackHelper.getRawValue(value)
        );
    }

    private void onPeriodic() {
        double value = 0;
        int err = 0;

        final int deviceID = getDeviceID();

        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "SupplyVoltage");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simSupplyVoltage.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "RequestedOutputCurrent");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simRequestedOutputCurrent.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "OutputCurrent");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simOutputCurrent.set(value);
        }

        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "PWM1Position");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simPwm1Position.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "PWM1Connected");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simPwm1Connected.set((int)value != 0);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "PWM1Velocity");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simPwm1Velocity.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "PWM1RiseToRise");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simPwm1RiseRise.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "PWM1RiseToFall");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simPwm1RiseFall.set(value);
        }
        
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "PWM2Position");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simPwm2Position.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "PWM2Connected");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simPwm2Connected.set((int)value != 0);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "PWM2Velocity");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simPwm2Velocity.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "PWM2RiseToRise");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simPwm2RiseRise.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "PWM2RiseToFall");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simPwm2RiseFall.set(value);
        }

        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "QuadraturePosition");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simQuadPos.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "RawQuadraturePosition");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simQuadRawPos.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "QuadratureVelocity");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simQuadVel.set(value);
        }

        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "S1State");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simS1State.set((int)value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "S1Closed");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simS1Closed.set((int)value != 0);
        }

        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "S2State");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simS2State.set((int)value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "S2Closed");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simS2Closed.set((int)value != 0);
        }
    }

    // ----- Sendable ----- //
    @Override
    public void initSendable(SendableBuilder builder) {
        builder.setSmartDashboardType("CANdi");
    }
}
