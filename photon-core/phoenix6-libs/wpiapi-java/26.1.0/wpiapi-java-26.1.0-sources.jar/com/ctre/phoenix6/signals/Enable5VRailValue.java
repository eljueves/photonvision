/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether the 5V rail is enabled. Disabling the 5V rail will also turn off the
 * onboard LEDs.
 */
public enum Enable5VRailValue
{
    /**
     * The 5V rail is enabled, allowing for LED control.
     */
    Enabled(0),
    /**
     * The 5V rail is disabled. This will also turn off the onboard LEDs.
     */
    Disabled(1),;

    public final int value;

    Enable5VRailValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, Enable5VRailValue> _map = null;
    static
    {
        _map = new HashMap<Integer, Enable5VRailValue>();
        for (Enable5VRailValue type : Enable5VRailValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets Enable5VRailValue from specified value
     * @param value Value of Enable5VRailValue
     * @return Enable5VRailValue of specified value
     */
    public static Enable5VRailValue valueOf(int value)
    {
        Enable5VRailValue retval = _map.get(value);
        if (retval != null) return retval;
        return Enable5VRailValue.values()[0];
    }
}
