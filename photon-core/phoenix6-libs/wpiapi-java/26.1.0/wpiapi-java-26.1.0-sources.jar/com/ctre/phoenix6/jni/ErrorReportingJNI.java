/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.jni;

public class ErrorReportingJNI extends CtreJniWrapper {
    /**
     * Report error to driver station
     *
     * @param errorCode Value of the error
     * @param location  Where the StatusCode was generated
     */
    public static native void reportStatusCode(int errorCode, String location);
}
