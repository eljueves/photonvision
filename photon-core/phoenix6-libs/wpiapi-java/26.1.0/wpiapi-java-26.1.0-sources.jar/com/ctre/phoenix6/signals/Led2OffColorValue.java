/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The Color of LED2 when it's "Off".
 */
public enum Led2OffColorValue
{
    Off(0),
    Red(1),
    Green(2),
    Orange(3),
    Blue(4),
    Pink(5),
    Cyan(6),
    White(7),;

    public final int value;

    Led2OffColorValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, Led2OffColorValue> _map = null;
    static
    {
        _map = new HashMap<Integer, Led2OffColorValue>();
        for (Led2OffColorValue type : Led2OffColorValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets Led2OffColorValue from specified value
     * @param value Value of Led2OffColorValue
     * @return Led2OffColorValue of specified value
     */
    public static Led2OffColorValue valueOf(int value)
    {
        Led2OffColorValue retval = _map.get(value);
        if (retval != null) return retval;
        return Led2OffColorValue.values()[0];
    }
}
