/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The active control mode of the motor controller.
 */
public enum ControlModeValue
{
    DisabledOutput(0),
    NeutralOut(1),
    StaticBrake(2),
    DutyCycleOut(3),
    PositionDutyCycle(4),
    VelocityDutyCycle(5),
    MotionMagicDutyCycle(6),
    DutyCycleFOC(7),
    PositionDutyCycleFOC(8),
    VelocityDutyCycleFOC(9),
    MotionMagicDutyCycleFOC(10),
    VoltageOut(11),
    PositionVoltage(12),
    VelocityVoltage(13),
    MotionMagicVoltage(14),
    VoltageFOC(15),
    PositionVoltageFOC(16),
    VelocityVoltageFOC(17),
    MotionMagicVoltageFOC(18),
    TorqueCurrentFOC(19),
    PositionTorqueCurrentFOC(20),
    VelocityTorqueCurrentFOC(21),
    MotionMagicTorqueCurrentFOC(22),
    Follower(23),
    Reserved(24),
    CoastOut(25),
    UnauthorizedDevice(26),
    MusicTone(27),
    MotionMagicVelocityDutyCycle(28),
    MotionMagicVelocityDutyCycleFOC(29),
    MotionMagicVelocityVoltage(30),
    MotionMagicVelocityVoltageFOC(31),
    MotionMagicVelocityTorqueCurrentFOC(32),
    MotionMagicExpoDutyCycle(33),
    MotionMagicExpoDutyCycleFOC(34),
    MotionMagicExpoVoltage(35),
    MotionMagicExpoVoltageFOC(36),
    MotionMagicExpoTorqueCurrentFOC(37),;

    public final int value;

    ControlModeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, ControlModeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, ControlModeValue>();
        for (ControlModeValue type : ControlModeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets ControlModeValue from specified value
     * @param value Value of ControlModeValue
     * @return ControlModeValue of specified value
     */
    public static ControlModeValue valueOf(int value)
    {
        ControlModeValue retval = _map.get(value);
        if (retval != null) return retval;
        return ControlModeValue.values()[0];
    }
}
