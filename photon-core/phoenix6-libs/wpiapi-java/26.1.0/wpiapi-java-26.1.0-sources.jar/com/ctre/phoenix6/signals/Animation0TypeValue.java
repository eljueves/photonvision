/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The type of animation running in slot 0 of the CANdle.
 */
public enum Animation0TypeValue
{
    /**
     * No animation.
     */
    Empty(0),
    /**
     * Color flow animation.
     */
    ColorFlow(1),
    /**
     * Fire animation.
     */
    Fire(2),
    /**
     * Larson animation.
     */
    Larson(3),
    /**
     * Rainbow animation.
     */
    Rainbow(4),
    /**
     * RGB Fade animation.
     */
    RgbFade(5),
    /**
     * Single fade animation.
     */
    SingleFade(6),
    /**
     * Strobe animation.
     */
    Strobe(7),
    /**
     * Twinkle animation.
     */
    Twinkle(8),
    /**
     * Twinkle off animation.
     */
    TwinkleOff(9),;

    public final int value;

    Animation0TypeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, Animation0TypeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, Animation0TypeValue>();
        for (Animation0TypeValue type : Animation0TypeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets Animation0TypeValue from specified value
     * @param value Value of Animation0TypeValue
     * @return Animation0TypeValue of specified value
     */
    public static Animation0TypeValue valueOf(int value)
    {
        Animation0TypeValue retval = _map.get(value);
        if (retval != null) return retval;
        return Animation0TypeValue.values()[0];
    }
}
