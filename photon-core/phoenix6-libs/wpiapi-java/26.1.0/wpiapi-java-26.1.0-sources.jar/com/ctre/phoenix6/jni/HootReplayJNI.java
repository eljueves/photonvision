/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.jni;

public class HootReplayJNI extends CtreJniWrapper {
    public double timestampSec;
    public String units;
    public Object data;

    public static native int JNI_LoadFile(String filepath);
    public static native void JNI_CloseFile();
    public static native boolean JNI_IsFileLoaded();

    public static native int JNI_Play();
    public static native int JNI_Pause();
    public static native int JNI_Stop();
    public static native boolean JNI_IsPlaying(double timeoutSeconds);
    public static native boolean JNI_IsFinished();

    public static native void JNI_SetSpeed(double speed);
    public static native int JNI_StepTiming(double stepTimeSeconds);

    public native int JNI_GetSchemaValue(String name, int type);
    public native int JNI_GetRaw(String name);
    public native int JNI_GetBoolean(String name);
    public native int JNI_GetInteger(String name);
    public native int JNI_GetFloat(String name);
    public native int JNI_GetDouble(String name);
    public native int JNI_GetString(String name);
    public native int JNI_GetBooleanArray(String name);
    public native int JNI_GetIntegerArray(String name);
    public native int JNI_GetFloatArray(String name);
    public native int JNI_GetDoubleArray(String name);
    public native int JNI_GetStringArray(String name);
}
