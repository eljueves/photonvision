/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.Utils;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.hardware.DeviceIdentifier;
import com.ctre.phoenix6.jni.ErrorReportingJNI;

public class ParentConfigurator {
    /**
     * The default maximum amount of time to wait for a config.
     */
    public double DefaultTimeoutSeconds = 0.100;

    private final DeviceIdentifier deviceIdentifier;
    private final Lock _lock = new ReentrantLock();

    private final ConfigJNI jni = new ConfigJNI();

    private final double _creationTime = Utils.getCurrentTimeSeconds();
    private double _lastConfigTime = _creationTime;
    private double _freqConfigStart = 0.0;

    protected ParentConfigurator(DeviceIdentifier deviceIdentifier) {
        this.deviceIdentifier = deviceIdentifier;
    }

    protected final void reportIfFrequent() {
        var currentTime = Utils.getCurrentTimeSeconds();
        var lastConfigTime = _lastConfigTime;
        _lastConfigTime = currentTime;

        if (currentTime - _creationTime < 5.0) {
            /* this was constructed recently, do not warn */
            return;
        }

        if (currentTime - lastConfigTime < 1.0) {
            /* we should not see multiple configs within a second */
            if (_freqConfigStart == 0.0) {
                /* this is the first frequent config, capture the time we started seeing them */
                _freqConfigStart = lastConfigTime;
            }
        } else {
            /* this is not a frequent config, reset the start time */
            _freqConfigStart = 0.0;
        }

        if (_freqConfigStart > 0.0 && currentTime - _freqConfigStart > 3.0) {
            /* we've been seeing frequent config calls continuously for a few seconds, warn user */
            String location = this.deviceIdentifier.toString() + " Config";
            ErrorReportingJNI.reportStatusCode(StatusCode.FrequentConfigCalls.value, location);
        }
    }

    protected final StatusCode setConfigsPrivate(String serialString, double timeoutSeconds, boolean futureProofConfigs,
            boolean overrideIfDuplicate) {
        StatusCode status;
        _lock.lock();
        /* make sure we always unlock */
        try {
            jni.serializedString = serialString;
            status = StatusCode.valueOf(
                jni.SetConfigs(
                    deviceIdentifier.getNetwork().getName(),
                    deviceIdentifier.getDeviceHash(),
                    timeoutSeconds,
                    futureProofConfigs,
                    overrideIfDuplicate));

            reportIfFrequent();
        } finally {
            _lock.unlock();
        }

        if (!status.isOK() && status != StatusCode.TimeoutCannotBeZero) {
            String location = this.deviceIdentifier.toString() + " Apply Config";
            ErrorReportingJNI.reportStatusCode(status.value, location);
        }
        return status;
    }

    protected final StatusCode getConfigsPrivate(StringBuilder serialString, double timeoutSeconds) {
        StatusCode status;
        _lock.lock();
        /* make sure we always unlock */
        try {
            status = StatusCode.valueOf(
                jni.GetConfigs(
                    deviceIdentifier.getNetwork().getName(),
                    deviceIdentifier.getDeviceHash(),
                    timeoutSeconds));
            serialString.append(jni.serializedString);

            reportIfFrequent();
        } finally {
            _lock.unlock();
        }

        if (!status.isOK()) {
            String location = this.deviceIdentifier.toString() + " Refresh Config";
            ErrorReportingJNI.reportStatusCode(status.value, location);
        }
        return status;
    }
}
