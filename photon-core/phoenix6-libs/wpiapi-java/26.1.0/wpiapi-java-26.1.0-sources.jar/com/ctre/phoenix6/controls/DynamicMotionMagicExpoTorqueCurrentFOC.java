/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.jni.ControlJNI;
import com.ctre.phoenix6.hardware.traits.*;

import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Requires Phoenix Pro and CANivore;
 * Requests Motion Magic® Expo to target a final position using an exponential
 * motion profile.  This dynamic request allows runtime changes to the profile
 * kV, kA, and (optional) Cruise Velocity.  Users can optionally provide a
 * torque current feedforward.
 * <p>
 * Motion Magic® Expo produces a motion profile in real-time while attempting to honor the specified Cruise
 * Velocity (optional) and the mechanism kV and kA.  Note that unlike the slot gains, the Expo_kV and Expo_kA
 * parameters are always in output units of Volts.
 * <p>
 * Setting the Cruise Velocity to 0 will allow the profile to run to the max possible velocity based on
 * Expo_kV.  This control mode does not use the Acceleration or Jerk configs.
 * <p>
 * Target position can be changed on-the-fly and Motion Magic® will do its best to adjust the profile. This
 * control mode is based on torque current, so relevant closed-loop gains will use Amperes for the numerator.
 */
public final class DynamicMotionMagicExpoTorqueCurrentFOC implements ControlRequest, Cloneable {
    /**
     * Position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     */
    public double Position;
    /**
     * Mechanism kV for profiling.  Unlike the kV slot gain, this is always in units
     * of V/rps.
     * <p>
     * This represents the amount of voltage necessary to hold a velocity.  In terms
     * of the Motion Magic® Expo profile, a higher kV results in a slower maximum
     * velocity.
     * 
     * <ul>
     *   <li> Units: V/rps
     * </ul>
     * 
     */
    public double kV;
    /**
     * Mechanism kA for profiling.  Unlike the kA slot gain, this is always in units
     * of V/rps².
     * <p>
     * This represents the amount of voltage necessary to achieve an acceleration. 
     * In terms of the Motion Magic® Expo profile, a higher kA results in a slower
     * acceleration.
     * 
     * <ul>
     *   <li> Units: V/rps²
     * </ul>
     * 
     */
    public double kA;
    /**
     * Cruise velocity for profiling.  The signage does not matter as the device
     * will use the absolute value for profile generation.  Setting this to 0 will
     * allow the profile to run to the max possible velocity based on Expo_kV.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     */
    public double Velocity = 0;
    /**
     * Feedforward to apply in torque current in Amperes. This is added to the
     * output of the onboard feedforward terms.
     * <p>
     * User can use motor's kT to scale Newton-meter to Amperes.
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     */
    public double FeedForward = 0.0;
    /**
     * Select which gains are applied by selecting the slot.  Use the configuration
     * api to set the gain values for the selected slot before enabling this
     * feature. Slot must be within [0,2].
     */
    public int Slot = 0;
    /**
     * Set to true to coast the rotor when output is zero (or within deadband).  Set
     * to false to use the NeutralMode configuration setting (default). This flag
     * exists to provide the fundamental behavior of this control when output is
     * zero, which is to provide 0A (zero torque).
     */
    public boolean OverrideCoastDurNeutral = false;
    /**
     * Set to true to force forward limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     */
    public boolean LimitForwardMotion = false;
    /**
     * Set to true to force reverse limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     */
    public boolean LimitReverseMotion = false;
    /**
     * Set to true to ignore hardware limit switches and the LimitForwardMotion and
     * LimitReverseMotion parameters, instead allowing motion.
     * <p>
     * This can be useful on mechanisms such as an intake/feeder, where a limit
     * switch stops motion while intaking but should be ignored when feeding to a
     * shooter.
     * <p>
     * The hardware limit faults and Forward/ReverseLimit signals will still report
     * the values of the limit switches regardless of this parameter.
     */
    public boolean IgnoreHardwareLimits = false;
    /**
     * Set to true to ignore software limits, instead allowing motion.
     * <p>
     * This can be useful when calibrating the zero point of a mechanism such as an
     * elevator.
     * <p>
     * The software limit faults will still report the values of the software limits
     * regardless of this parameter.
     */
    public boolean IgnoreSoftwareLimits = false;
    /**
     * Set to true to delay applying this control request until a timesync boundary
     * (requires Phoenix Pro and CANivore). This eliminates the impact of
     * nondeterministic network delays in exchange for a larger but deterministic
     * control latency.
     * <p>
     * This requires setting the ControlTimesyncFreqHz config in MotorOutputConfigs.
     * Additionally, when this is enabled, the UpdateFreqHz of this request should
     * be set to 0 Hz.
     */
    public boolean UseTimesync = false;

    /**
     * The frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     */
    public double UpdateFreqHz = 100;

    /**
     * Requires Phoenix Pro and CANivore;
     * Requests Motion Magic® Expo to target a final position using an exponential
     * motion profile.  This dynamic request allows runtime changes to the profile
     * kV, kA, and (optional) Cruise Velocity.  Users can optionally provide a
     * torque current feedforward.
     * <p>
     * Motion Magic® Expo produces a motion profile in real-time while attempting to
     * honor the specified Cruise Velocity (optional) and the mechanism kV and kA. 
     * Note that unlike the slot gains, the Expo_kV and Expo_kA parameters are
     * always in output units of Volts.
     * <p>
     * Setting the Cruise Velocity to 0 will allow the profile to run to the max
     * possible velocity based on Expo_kV.  This control mode does not use the
     * Acceleration or Jerk configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do its best
     * to adjust the profile. This control mode is based on torque current, so
     * relevant closed-loop gains will use Amperes for the numerator.
     * 
     * @param Position Position to drive toward in rotations.
     * @param kV Mechanism kV for profiling.  Unlike the kV slot gain, this is
     *           always in units of V/rps.
     *           <p>
     *           This represents the amount of voltage necessary to hold a velocity.
     *            In terms of the Motion Magic® Expo profile, a higher kV results in
     *           a slower maximum velocity.
     * @param kA Mechanism kA for profiling.  Unlike the kA slot gain, this is
     *           always in units of V/rps².
     *           <p>
     *           This represents the amount of voltage necessary to achieve an
     *           acceleration.  In terms of the Motion Magic® Expo profile, a higher
     *           kA results in a slower acceleration.
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC(double Position, double kV, double kA) {
        this.Position = Position;
        this.kV = kV;
        this.kA = kA;
    }

    /**
     * Requires Phoenix Pro and CANivore;
     * Requests Motion Magic® Expo to target a final position using an exponential
     * motion profile.  This dynamic request allows runtime changes to the profile
     * kV, kA, and (optional) Cruise Velocity.  Users can optionally provide a
     * torque current feedforward.
     * <p>
     * Motion Magic® Expo produces a motion profile in real-time while attempting to
     * honor the specified Cruise Velocity (optional) and the mechanism kV and kA. 
     * Note that unlike the slot gains, the Expo_kV and Expo_kA parameters are
     * always in output units of Volts.
     * <p>
     * Setting the Cruise Velocity to 0 will allow the profile to run to the max
     * possible velocity based on Expo_kV.  This control mode does not use the
     * Acceleration or Jerk configs.
     * <p>
     * Target position can be changed on-the-fly and Motion Magic® will do its best
     * to adjust the profile. This control mode is based on torque current, so
     * relevant closed-loop gains will use Amperes for the numerator.
     * 
     * @param Position Position to drive toward in rotations.
     * @param kV Mechanism kV for profiling.  Unlike the kV slot gain, this is
     *           always in units of V/rps.
     *           <p>
     *           This represents the amount of voltage necessary to hold a velocity.
     *            In terms of the Motion Magic® Expo profile, a higher kV results in
     *           a slower maximum velocity.
     * @param kA Mechanism kA for profiling.  Unlike the kA slot gain, this is
     *           always in units of V/rps².
     *           <p>
     *           This represents the amount of voltage necessary to achieve an
     *           acceleration.  In terms of the Motion Magic® Expo profile, a higher
     *           kA results in a slower acceleration.
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC(Angle Position, Per<VoltageUnit, AngularVelocityUnit> kV, Per<VoltageUnit, AngularAccelerationUnit> kA) {
        this(Position.in(Rotations), kV.in(Volts.per(RotationsPerSecond)), kA.in(Volts.per(RotationsPerSecondPerSecond)));
    }

    @Override
    public String getName() {
        return "DynamicMotionMagicExpoTorqueCurrentFOC";
    }

    @Override
    public String toString() {
        String ss = "Control: DynamicMotionMagicExpoTorqueCurrentFOC\n";
        ss += "    Position: " + Position + " rotations" + "\n";
        ss += "    kV: " + kV + " V/rps" + "\n";
        ss += "    kA: " + kA + " V/rps²" + "\n";
        ss += "    Velocity: " + Velocity + " rotations per second" + "\n";
        ss += "    FeedForward: " + FeedForward + " A" + "\n";
        ss += "    Slot: " + Slot + "\n";
        ss += "    OverrideCoastDurNeutral: " + OverrideCoastDurNeutral + "\n";
        ss += "    LimitForwardMotion: " + LimitForwardMotion + "\n";
        ss += "    LimitReverseMotion: " + LimitReverseMotion + "\n";
        ss += "    IgnoreHardwareLimits: " + IgnoreHardwareLimits + "\n";
        ss += "    IgnoreSoftwareLimits: " + IgnoreSoftwareLimits + "\n";
        ss += "    UseTimesync: " + UseTimesync + "\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlDynamicMotionMagicExpoTorqueCurrentFOC(
                network, deviceHash, UpdateFreqHz, Position, kV, kA, Velocity, FeedForward, Slot, OverrideCoastDurNeutral, LimitForwardMotion, LimitReverseMotion, IgnoreHardwareLimits, IgnoreSoftwareLimits, UseTimesync));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String, String>();
        controlInfo.put("Name", getName());
        controlInfo.put("Position", String.valueOf(this.Position));
        controlInfo.put("kV", String.valueOf(this.kV));
        controlInfo.put("kA", String.valueOf(this.kA));
        controlInfo.put("Velocity", String.valueOf(this.Velocity));
        controlInfo.put("FeedForward", String.valueOf(this.FeedForward));
        controlInfo.put("Slot", String.valueOf(this.Slot));
        controlInfo.put("OverrideCoastDurNeutral", String.valueOf(this.OverrideCoastDurNeutral));
        controlInfo.put("LimitForwardMotion", String.valueOf(this.LimitForwardMotion));
        controlInfo.put("LimitReverseMotion", String.valueOf(this.LimitReverseMotion));
        controlInfo.put("IgnoreHardwareLimits", String.valueOf(this.IgnoreHardwareLimits));
        controlInfo.put("IgnoreSoftwareLimits", String.valueOf(this.IgnoreSoftwareLimits));
        controlInfo.put("UseTimesync", String.valueOf(this.UseTimesync));
        return controlInfo;
    }
    
    /**
     * Modifies this Control Request's Position parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     *
     * @param newPosition Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withPosition(double newPosition) {
        Position = newPosition;
        return this;
    }
    
    /**
     * Modifies this Control Request's Position parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     *
     * @param newPosition Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withPosition(Angle newPosition) {
        Position = newPosition.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's Position parameter converted
     * to a unit type. If not using the Java units library, {@link #Position}
     * can be accessed directly instead.
     * <p>
     * Position to drive toward in rotations.
     * 
     * <ul>
     *   <li> Units: rotations
     * </ul>
     * 
     *
     * @return Position
     */
    public Angle getPositionMeasure() {
        return Rotations.of(Position);
    }
    
    /**
     * Modifies this Control Request's kV parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Mechanism kV for profiling.  Unlike the kV slot gain, this is always in units
     * of V/rps.
     * <p>
     * This represents the amount of voltage necessary to hold a velocity.  In terms
     * of the Motion Magic® Expo profile, a higher kV results in a slower maximum
     * velocity.
     * 
     * <ul>
     *   <li> Units: V/rps
     * </ul>
     * 
     *
     * @param newKV Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withKV(double newKV) {
        kV = newKV;
        return this;
    }
    
    /**
     * Modifies this Control Request's kV parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Mechanism kV for profiling.  Unlike the kV slot gain, this is always in units
     * of V/rps.
     * <p>
     * This represents the amount of voltage necessary to hold a velocity.  In terms
     * of the Motion Magic® Expo profile, a higher kV results in a slower maximum
     * velocity.
     * 
     * <ul>
     *   <li> Units: V/rps
     * </ul>
     * 
     *
     * @param newKV Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withKV(Per<VoltageUnit, AngularVelocityUnit> newKV) {
        kV = newKV.in(Volts.per(RotationsPerSecond));
        return this;
    }
    
    /**
     * Helper method to get this Control Request's kV parameter converted
     * to a unit type. If not using the Java units library, {@link #kV}
     * can be accessed directly instead.
     * <p>
     * Mechanism kV for profiling.  Unlike the kV slot gain, this is always in units
     * of V/rps.
     * <p>
     * This represents the amount of voltage necessary to hold a velocity.  In terms
     * of the Motion Magic® Expo profile, a higher kV results in a slower maximum
     * velocity.
     * 
     * <ul>
     *   <li> Units: V/rps
     * </ul>
     * 
     *
     * @return kV
     */
    public Per<VoltageUnit, AngularVelocityUnit> getKVMeasure() {
        return Volts.per(RotationsPerSecond).ofNative(kV);
    }
    
    /**
     * Modifies this Control Request's kA parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Mechanism kA for profiling.  Unlike the kA slot gain, this is always in units
     * of V/rps².
     * <p>
     * This represents the amount of voltage necessary to achieve an acceleration. 
     * In terms of the Motion Magic® Expo profile, a higher kA results in a slower
     * acceleration.
     * 
     * <ul>
     *   <li> Units: V/rps²
     * </ul>
     * 
     *
     * @param newKA Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withKA(double newKA) {
        kA = newKA;
        return this;
    }
    
    /**
     * Modifies this Control Request's kA parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Mechanism kA for profiling.  Unlike the kA slot gain, this is always in units
     * of V/rps².
     * <p>
     * This represents the amount of voltage necessary to achieve an acceleration. 
     * In terms of the Motion Magic® Expo profile, a higher kA results in a slower
     * acceleration.
     * 
     * <ul>
     *   <li> Units: V/rps²
     * </ul>
     * 
     *
     * @param newKA Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withKA(Per<VoltageUnit, AngularAccelerationUnit> newKA) {
        kA = newKA.in(Volts.per(RotationsPerSecondPerSecond));
        return this;
    }
    
    /**
     * Helper method to get this Control Request's kA parameter converted
     * to a unit type. If not using the Java units library, {@link #kA}
     * can be accessed directly instead.
     * <p>
     * Mechanism kA for profiling.  Unlike the kA slot gain, this is always in units
     * of V/rps².
     * <p>
     * This represents the amount of voltage necessary to achieve an acceleration. 
     * In terms of the Motion Magic® Expo profile, a higher kA results in a slower
     * acceleration.
     * 
     * <ul>
     *   <li> Units: V/rps²
     * </ul>
     * 
     *
     * @return kA
     */
    public Per<VoltageUnit, AngularAccelerationUnit> getKAMeasure() {
        return Volts.per(RotationsPerSecondPerSecond).ofNative(kA);
    }
    
    /**
     * Modifies this Control Request's Velocity parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Cruise velocity for profiling.  The signage does not matter as the device
     * will use the absolute value for profile generation.  Setting this to 0 will
     * allow the profile to run to the max possible velocity based on Expo_kV.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @param newVelocity Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withVelocity(double newVelocity) {
        Velocity = newVelocity;
        return this;
    }
    
    /**
     * Modifies this Control Request's Velocity parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Cruise velocity for profiling.  The signage does not matter as the device
     * will use the absolute value for profile generation.  Setting this to 0 will
     * allow the profile to run to the max possible velocity based on Expo_kV.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @param newVelocity Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withVelocity(AngularVelocity newVelocity) {
        Velocity = newVelocity.in(RotationsPerSecond);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's Velocity parameter converted
     * to a unit type. If not using the Java units library, {@link #Velocity}
     * can be accessed directly instead.
     * <p>
     * Cruise velocity for profiling.  The signage does not matter as the device
     * will use the absolute value for profile generation.  Setting this to 0 will
     * allow the profile to run to the max possible velocity based on Expo_kV.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @return Velocity
     */
    public AngularVelocity getVelocityMeasure() {
        return RotationsPerSecond.of(Velocity);
    }
    
    /**
     * Modifies this Control Request's FeedForward parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Feedforward to apply in torque current in Amperes. This is added to the
     * output of the onboard feedforward terms.
     * <p>
     * User can use motor's kT to scale Newton-meter to Amperes.
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     *
     * @param newFeedForward Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withFeedForward(double newFeedForward) {
        FeedForward = newFeedForward;
        return this;
    }
    
    /**
     * Modifies this Control Request's FeedForward parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Feedforward to apply in torque current in Amperes. This is added to the
     * output of the onboard feedforward terms.
     * <p>
     * User can use motor's kT to scale Newton-meter to Amperes.
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     *
     * @param newFeedForward Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withFeedForward(Current newFeedForward) {
        FeedForward = newFeedForward.in(Amps);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's FeedForward parameter converted
     * to a unit type. If not using the Java units library, {@link #FeedForward}
     * can be accessed directly instead.
     * <p>
     * Feedforward to apply in torque current in Amperes. This is added to the
     * output of the onboard feedforward terms.
     * <p>
     * User can use motor's kT to scale Newton-meter to Amperes.
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     *
     * @return FeedForward
     */
    public Current getFeedForwardMeasure() {
        return Amps.of(FeedForward);
    }
    
    /**
     * Modifies this Control Request's Slot parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Select which gains are applied by selecting the slot.  Use the configuration
     * api to set the gain values for the selected slot before enabling this
     * feature. Slot must be within [0,2].
     *
     * @param newSlot Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withSlot(int newSlot) {
        Slot = newSlot;
        return this;
    }
    
    /**
     * Modifies this Control Request's OverrideCoastDurNeutral parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to coast the rotor when output is zero (or within deadband).  Set
     * to false to use the NeutralMode configuration setting (default). This flag
     * exists to provide the fundamental behavior of this control when output is
     * zero, which is to provide 0A (zero torque).
     *
     * @param newOverrideCoastDurNeutral Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withOverrideCoastDurNeutral(boolean newOverrideCoastDurNeutral) {
        OverrideCoastDurNeutral = newOverrideCoastDurNeutral;
        return this;
    }
    
    /**
     * Modifies this Control Request's LimitForwardMotion parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to force forward limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     *
     * @param newLimitForwardMotion Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withLimitForwardMotion(boolean newLimitForwardMotion) {
        LimitForwardMotion = newLimitForwardMotion;
        return this;
    }
    
    /**
     * Modifies this Control Request's LimitReverseMotion parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to force reverse limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     *
     * @param newLimitReverseMotion Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withLimitReverseMotion(boolean newLimitReverseMotion) {
        LimitReverseMotion = newLimitReverseMotion;
        return this;
    }
    
    /**
     * Modifies this Control Request's IgnoreHardwareLimits parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to ignore hardware limit switches and the LimitForwardMotion and
     * LimitReverseMotion parameters, instead allowing motion.
     * <p>
     * This can be useful on mechanisms such as an intake/feeder, where a limit
     * switch stops motion while intaking but should be ignored when feeding to a
     * shooter.
     * <p>
     * The hardware limit faults and Forward/ReverseLimit signals will still report
     * the values of the limit switches regardless of this parameter.
     *
     * @param newIgnoreHardwareLimits Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withIgnoreHardwareLimits(boolean newIgnoreHardwareLimits) {
        IgnoreHardwareLimits = newIgnoreHardwareLimits;
        return this;
    }
    
    /**
     * Modifies this Control Request's IgnoreSoftwareLimits parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to ignore software limits, instead allowing motion.
     * <p>
     * This can be useful when calibrating the zero point of a mechanism such as an
     * elevator.
     * <p>
     * The software limit faults will still report the values of the software limits
     * regardless of this parameter.
     *
     * @param newIgnoreSoftwareLimits Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withIgnoreSoftwareLimits(boolean newIgnoreSoftwareLimits) {
        IgnoreSoftwareLimits = newIgnoreSoftwareLimits;
        return this;
    }
    
    /**
     * Modifies this Control Request's UseTimesync parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to delay applying this control request until a timesync boundary
     * (requires Phoenix Pro and CANivore). This eliminates the impact of
     * nondeterministic network delays in exchange for a larger but deterministic
     * control latency.
     * <p>
     * This requires setting the ControlTimesyncFreqHz config in MotorOutputConfigs.
     * Additionally, when this is enabled, the UpdateFreqHz of this request should
     * be set to 0 Hz.
     *
     * @param newUseTimesync Parameter to modify
     * @return Itself
     */
    public DynamicMotionMagicExpoTorqueCurrentFOC withUseTimesync(boolean newUseTimesync) {
        UseTimesync = newUseTimesync;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public DynamicMotionMagicExpoTorqueCurrentFOC withUpdateFreqHz(double newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public DynamicMotionMagicExpoTorqueCurrentFOC withUpdateFreqHz(Frequency newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz.in(Hertz);
        return this;
    }

    @Override
    public DynamicMotionMagicExpoTorqueCurrentFOC clone() {
        try {
            return (DynamicMotionMagicExpoTorqueCurrentFOC)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

