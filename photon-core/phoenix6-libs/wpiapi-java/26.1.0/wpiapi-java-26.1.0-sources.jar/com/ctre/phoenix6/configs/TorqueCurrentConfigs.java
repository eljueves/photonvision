/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs that affect Torque Current control types.
 * <p>
 * Includes the maximum and minimum applied torque output and the
 * neutral deadband used during TorqueCurrentFOC requests.
 */
public class TorqueCurrentConfigs implements ParentConfiguration, Cloneable {
    /**
     * Maximum (forward) output during torque current based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -800
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> 800
     *   <li> <b>Units:</b> A
     * </ul>
     */
    public double PeakForwardTorqueCurrent = 800;
    /**
     * Minimum (reverse) output during torque current based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -800
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> -800
     *   <li> <b>Units:</b> A
     * </ul>
     */
    public double PeakReverseTorqueCurrent = -800;
    /**
     * Configures the output deadband during torque current based control
     * modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 25
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> A
     * </ul>
     */
    public double TorqueNeutralDeadband = 0.0;
    
    /**
     * Modifies this configuration's PeakForwardTorqueCurrent parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Maximum (forward) output during torque current based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -800
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> 800
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newPeakForwardTorqueCurrent Parameter to modify
     * @return Itself
     */
    public final TorqueCurrentConfigs withPeakForwardTorqueCurrent(double newPeakForwardTorqueCurrent)
    {
        PeakForwardTorqueCurrent = newPeakForwardTorqueCurrent;
        return this;
    }
    
    /**
     * Modifies this configuration's PeakForwardTorqueCurrent parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Maximum (forward) output during torque current based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -800
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> 800
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newPeakForwardTorqueCurrent Parameter to modify
     * @return Itself
     */
    public final TorqueCurrentConfigs withPeakForwardTorqueCurrent(Current newPeakForwardTorqueCurrent)
    {
        PeakForwardTorqueCurrent = newPeakForwardTorqueCurrent.in(Amps);
        return this;
    }
    
    /**
     * Helper method to get this configuration's PeakForwardTorqueCurrent parameter converted
     * to a unit type. If not using the Java units library, {@link #PeakForwardTorqueCurrent}
     * can be accessed directly instead.
     * <p>
     * Maximum (forward) output during torque current based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -800
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> 800
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @return PeakForwardTorqueCurrent
     */
    public final Current getPeakForwardTorqueCurrentMeasure()
    {
        return Amps.of(PeakForwardTorqueCurrent);
    }
    
    /**
     * Modifies this configuration's PeakReverseTorqueCurrent parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Minimum (reverse) output during torque current based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -800
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> -800
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newPeakReverseTorqueCurrent Parameter to modify
     * @return Itself
     */
    public final TorqueCurrentConfigs withPeakReverseTorqueCurrent(double newPeakReverseTorqueCurrent)
    {
        PeakReverseTorqueCurrent = newPeakReverseTorqueCurrent;
        return this;
    }
    
    /**
     * Modifies this configuration's PeakReverseTorqueCurrent parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Minimum (reverse) output during torque current based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -800
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> -800
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newPeakReverseTorqueCurrent Parameter to modify
     * @return Itself
     */
    public final TorqueCurrentConfigs withPeakReverseTorqueCurrent(Current newPeakReverseTorqueCurrent)
    {
        PeakReverseTorqueCurrent = newPeakReverseTorqueCurrent.in(Amps);
        return this;
    }
    
    /**
     * Helper method to get this configuration's PeakReverseTorqueCurrent parameter converted
     * to a unit type. If not using the Java units library, {@link #PeakReverseTorqueCurrent}
     * can be accessed directly instead.
     * <p>
     * Minimum (reverse) output during torque current based control modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -800
     *   <li> <b>Maximum Value:</b> 800
     *   <li> <b>Default Value:</b> -800
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @return PeakReverseTorqueCurrent
     */
    public final Current getPeakReverseTorqueCurrentMeasure()
    {
        return Amps.of(PeakReverseTorqueCurrent);
    }
    
    /**
     * Modifies this configuration's TorqueNeutralDeadband parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configures the output deadband during torque current based control
     * modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 25
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newTorqueNeutralDeadband Parameter to modify
     * @return Itself
     */
    public final TorqueCurrentConfigs withTorqueNeutralDeadband(double newTorqueNeutralDeadband)
    {
        TorqueNeutralDeadband = newTorqueNeutralDeadband;
        return this;
    }
    
    /**
     * Modifies this configuration's TorqueNeutralDeadband parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configures the output deadband during torque current based control
     * modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 25
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newTorqueNeutralDeadband Parameter to modify
     * @return Itself
     */
    public final TorqueCurrentConfigs withTorqueNeutralDeadband(Current newTorqueNeutralDeadband)
    {
        TorqueNeutralDeadband = newTorqueNeutralDeadband.in(Amps);
        return this;
    }
    
    /**
     * Helper method to get this configuration's TorqueNeutralDeadband parameter converted
     * to a unit type. If not using the Java units library, {@link #TorqueNeutralDeadband}
     * can be accessed directly instead.
     * <p>
     * Configures the output deadband during torque current based control
     * modes.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 25
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @return TorqueNeutralDeadband
     */
    public final Current getTorqueNeutralDeadbandMeasure()
    {
        return Amps.of(TorqueNeutralDeadband);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: TorqueCurrent\n";
        ss += "    PeakForwardTorqueCurrent: " + PeakForwardTorqueCurrent + " A" + "\n";
        ss += "    PeakReverseTorqueCurrent: " + PeakReverseTorqueCurrent + " A" + "\n";
        ss += "    TorqueNeutralDeadband: " + TorqueNeutralDeadband + " A" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_PeakForTorqCurr.value, PeakForwardTorqueCurrent);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_PeakRevTorqCurr.value, PeakReverseTorqueCurrent);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_TorqueNeutralDB.value, TorqueNeutralDeadband);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        PeakForwardTorqueCurrent = ConfigJNI.Deserializedouble(SpnValue.Config_PeakForTorqCurr.value, to_deserialize);
        PeakReverseTorqueCurrent = ConfigJNI.Deserializedouble(SpnValue.Config_PeakRevTorqCurr.value, to_deserialize);
        TorqueNeutralDeadband = ConfigJNI.Deserializedouble(SpnValue.Config_TorqueNeutralDB.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public TorqueCurrentConfigs clone() {
        try {
            return (TorqueCurrentConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

