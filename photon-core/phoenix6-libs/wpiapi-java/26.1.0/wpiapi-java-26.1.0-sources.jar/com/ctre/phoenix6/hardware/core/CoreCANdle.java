/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.core;

import com.ctre.phoenix6.hardware.ParentDevice;
import com.ctre.phoenix6.controls.*;
import com.ctre.phoenix6.configs.*;
import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.jni.PlatformJNI;
import com.ctre.phoenix6.sim.DeviceType;
import com.ctre.phoenix6.sim.CANdleSimState;
import com.ctre.phoenix6.*;
import com.ctre.phoenix6.spns.*;
import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Class for CTR Electronics' CANdle® branded device, a device that controls
 * LEDs over the CAN bus.
 * 
 * <pre>
 * // Constants used in CANdle construction
 * final int kCANdleId = 0;
 * final CANBus kCANdleCANbus = new CANBus("canivore");
 * 
 * // Colors used in the animations
 * static final RGBWColor kGreen = new RgbwColor(0, 217, 0);
 * 
 * // Construct the CANdle and control requests
 * final CANdle candle = new CANdle(kCANdleId, kCANdleCANbus);
 * // Green fade on LEDs 0-7, Rainbow on 8-67
 * final SingleFadeAnimation singleFade = new SingleFadeAnimation(0, 7);
 * final RainbowAnimation rainbow = new RainbowAnimation(8, 67);
 * 
 * // Configure the CANdle for basic use
 * CANdleConfiguration configs = new CANdleConfiguration();
 * // Set the LED strip type and brightness
 * configs.LED.StripType = StripTypeValue.GRB;
 * configs.LED.BrightnessScalar = 0.5;
 * // Disable status LED when being controlled
 * configs.CANdleFeatures.StatusLedWhenActive = StatusLedWhenActiveValue.Disabled;
 * 
 * // Write these configs to the CANdle
 * candle.getConfigurator().apply(configs);
 * 
 * // Run the two animations at the same time using animation slots
 * candle.setControl(rgbFade.withSlot(0).withColor(kGreen));
 * candle.setControl(rainbow.withSlot(1));
 * </pre>
 */
public class CoreCANdle extends ParentDevice
{
    private CANdleConfigurator _configurator;

    /**
     * Constructs a new CANdle object.
     * <p>
     * Constructs the device using the default CAN bus for the system
     * (see {@link CANBus#CANBus()}).
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     */
    public CoreCANdle(int deviceId)
    {
        this(deviceId, new CANBus());
    }

    /**
     * Constructs a new CANdle object.
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     * @param canbus      Name of the CAN bus this device is on. Possible CAN bus strings are:
     *                    <ul>
     *                      <li>"rio" for the native roboRIO CAN bus
     *                      <li>CANivore name or serial number
     *                      <li>SocketCAN interface (non-FRC Linux only)
     *                      <li>"*" for any CANivore seen by the program
     *                      <li>empty string (default) to select the default for the system:
     *                      <ul>
     *                        <li>"rio" on roboRIO
     *                        <li>"can0" on Linux
     *                        <li>"*" on Windows
     *                      </ul>
     *                    </ul>
     *
     * @deprecated Constructing devices with a CAN bus string is deprecated for removal
     * in the 2027 season. Construct devices using a {@link CANBus} instance instead.
     */
    @Deprecated(since = "2026", forRemoval = true)
    public CoreCANdle(int deviceId, String canbus)
    {
        this(deviceId, new CANBus(canbus));
    }

    /**
     * Constructs a new CANdle object.
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     * @param canbus      The CAN bus this device is on
     */
    public CoreCANdle(int deviceId, CANBus canbus)
    {
        super(deviceId, "candle", canbus);
        _configurator = new CANdleConfigurator(this.deviceIdentifier);
        PlatformJNI.JNI_SimCreate(DeviceType.P6_CANdleType.value, deviceId);
    }

    /**
     * Gets the configurator to use with this device's configs
     *
     * @return Configurator for this object
     */
    public final CANdleConfigurator getConfigurator()
    {
        return this._configurator;
    }


    private CANdleSimState _simState = null;
    /**
     * Get the simulation state for this device.
     * <p>
     * This function reuses an allocated simulation state
     * object, so it is safe to call this function multiple
     * times in a robot loop.
     *
     * @return Simulation state
     */
    public final CANdleSimState getSimState() {
        if (_simState == null)
            _simState = new CANdleSimState(this);
        return _simState;
    }


        
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMajor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMajor()
    {
        return getVersionMajor(true);
    }
    
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMajor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMajor(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Major.value, "VersionMajor", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMinor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMinor()
    {
        return getVersionMinor(true);
    }
    
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMinor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMinor(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Minor.value, "VersionMinor", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBugfix Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBugfix()
    {
        return getVersionBugfix(true);
    }
    
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBugfix Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBugfix(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Bugfix.value, "VersionBugfix", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBuild Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBuild()
    {
        return getVersionBuild(true);
    }
    
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBuild Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBuild(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Build.value, "VersionBuild", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Version Status Signal Object
     */
    public final StatusSignal<Integer> getVersion()
    {
        return getVersion(true);
    }
    
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Version Status Signal Object
     */
    public final StatusSignal<Integer> getVersion(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Full.value, "Version", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return FaultField Status Signal Object
     */
    public final StatusSignal<Integer> getFaultField()
    {
        return getFaultField(true);
    }
    
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return FaultField Status Signal Object
     */
    public final StatusSignal<Integer> getFaultField(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.AllFaults.value, "FaultField", Integer.class, val -> (int)val, true, refresh);
        return retval;
    }
        
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFaultField Status Signal Object
     */
    public final StatusSignal<Integer> getStickyFaultField()
    {
        return getStickyFaultField(true);
    }
    
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFaultField Status Signal Object
     */
    public final StatusSignal<Integer> getStickyFaultField(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.AllStickyFaults.value, "StickyFaultField", Integer.class, val -> (int)val, true, refresh);
        return retval;
    }
        
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return IsProLicensed Status Signal Object
     */
    public final StatusSignal<Boolean> getIsProLicensed()
    {
        return getIsProLicensed(true);
    }
    
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return IsProLicensed Status Signal Object
     */
    public final StatusSignal<Boolean> getIsProLicensed(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_IsProLicensed.value, "IsProLicensed", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Measured supply voltage to the CANdle.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 32.767
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return SupplyVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getSupplyVoltage()
    {
        return getSupplyVoltage(true);
    }
    
    /**
     * Measured supply voltage to the CANdle.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 32.767
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return SupplyVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getSupplyVoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdle_General_SupplyVoltage.value, "SupplyVoltage", Voltage.class, val -> Volts.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The measured voltage of the 5V rail line.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 10.23
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return FiveVRailVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getFiveVRailVoltage()
    {
        return getFiveVRailVoltage(true);
    }
    
    /**
     * The measured voltage of the 5V rail line.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 10.23
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return FiveVRailVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getFiveVRailVoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdle_General_FiveVRailVoltage.value, "FiveVRailVoltage", Voltage.class, val -> Volts.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The measured output current. This includes both VBat and 5V output
     * current.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 10.23
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return OutputCurrent Status Signal Object
     */
    public final StatusSignal<Current> getOutputCurrent()
    {
        return getOutputCurrent(true);
    }
    
    /**
     * The measured output current. This includes both VBat and 5V output
     * current.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 10.23
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return OutputCurrent Status Signal Object
     */
    public final StatusSignal<Current> getOutputCurrent(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdle_General_OutputCurrent.value, "OutputCurrent", Current.class, val -> Amps.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The temperature that the CANdle measures itself to be at.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -128
     *   <li> <b>Maximum Value:</b> 127
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DeviceTemp Status Signal Object
     */
    public final StatusSignal<Temperature> getDeviceTemp()
    {
        return getDeviceTemp(true);
    }
    
    /**
     * The temperature that the CANdle measures itself to be at.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -128
     *   <li> <b>Maximum Value:</b> 127
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DeviceTemp Status Signal Object
     */
    public final StatusSignal<Temperature> getDeviceTemp(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdle_General_DeviceTemp.value, "DeviceTemp", Temperature.class, val -> Celsius.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The applied VBat modulation duty cycle.
     * <p>
     * This signal will report 1.0 if the VBatOutputMode is configured to
     * be always on, and 0.0 if configured to be always off. Otherwise,
     * this will report the applied modulation from the last
     * ModulateVBatOut request.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> frac
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VBatModulation Status Signal Object
     */
    public final StatusSignal<Double> getVBatModulation()
    {
        return getVBatModulation(true);
    }
    
    /**
     * The applied VBat modulation duty cycle.
     * <p>
     * This signal will report 1.0 if the VBatOutputMode is configured to
     * be always on, and 0.0 if configured to be always off. Otherwise,
     * this will report the applied modulation from the last
     * ModulateVBatOut request.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> frac
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VBatModulation Status Signal Object
     */
    public final StatusSignal<Double> getVBatModulation(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdle_General_VBatModulation.value, "VBatModulation", Double.class, val -> val, true, refresh);
        return retval;
    }
        
    /**
     * The maximum number of simultaneous animations supported by the
     * current version of CANdle firmware.
     * <p>
     * Any control request using an animation slot greater than or equal
     * to this signal will be ignored.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 31
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MaxSimultaneousAnimationCount Status Signal Object
     */
    public final StatusSignal<Integer> getMaxSimultaneousAnimationCount()
    {
        return getMaxSimultaneousAnimationCount(true);
    }
    
    /**
     * The maximum number of simultaneous animations supported by the
     * current version of CANdle firmware.
     * <p>
     * Any control request using an animation slot greater than or equal
     * to this signal will be ignored.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 31
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 10.0 Hz
     *   <li> <b>CAN FD:</b> 10.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MaxSimultaneousAnimationCount Status Signal Object
     */
    public final StatusSignal<Integer> getMaxSimultaneousAnimationCount(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdle_General_MaxSimulAnimCount.value, "MaxSimultaneousAnimationCount", Integer.class, val -> (int)val, true, refresh);
        return retval;
    }
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Hardware()
    {
        return getFault_Hardware(true);
    }
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Hardware(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_Hardware.value, "Fault_Hardware", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Hardware()
    {
        return getStickyFault_Hardware(true);
    }
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Hardware(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_Hardware.value, "StickyFault_Hardware", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Undervoltage()
    {
        return getFault_Undervoltage(true);
    }
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Undervoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_Undervoltage.value, "Fault_Undervoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Undervoltage()
    {
        return getStickyFault_Undervoltage(true);
    }
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Undervoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_Undervoltage.value, "StickyFault_Undervoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootDuringEnable()
    {
        return getFault_BootDuringEnable(true);
    }
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootDuringEnable(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_BootDuringEnable.value, "Fault_BootDuringEnable", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootDuringEnable()
    {
        return getStickyFault_BootDuringEnable(true);
    }
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootDuringEnable(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_BootDuringEnable.value, "StickyFault_BootDuringEnable", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_UnlicensedFeatureInUse()
    {
        return getFault_UnlicensedFeatureInUse(true);
    }
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_UnlicensedFeatureInUse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_UnlicensedFeatureInUse.value, "Fault_UnlicensedFeatureInUse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse()
    {
        return getStickyFault_UnlicensedFeatureInUse(true);
    }
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_UnlicensedFeatureInUse.value, "StickyFault_UnlicensedFeatureInUse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage is too high (above 30 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Overvoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Overvoltage()
    {
        return getFault_Overvoltage(true);
    }
    
    /**
     * Device supply voltage is too high (above 30 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Overvoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Overvoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_CANDLE_OVERVOLTAGE.value, "Fault_Overvoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage is too high (above 30 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Overvoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Overvoltage()
    {
        return getStickyFault_Overvoltage(true);
    }
    
    /**
     * Device supply voltage is too high (above 30 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Overvoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Overvoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_CANDLE_OVERVOLTAGE.value, "StickyFault_Overvoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device 5V line is too high (above 6 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_5VTooHigh Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_5VTooHigh()
    {
        return getFault_5VTooHigh(true);
    }
    
    /**
     * Device 5V line is too high (above 6 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_5VTooHigh Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_5VTooHigh(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_CANDLE_5V_TOO_HIGH.value, "Fault_5VTooHigh", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device 5V line is too high (above 6 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_5VTooHigh Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_5VTooHigh()
    {
        return getStickyFault_5VTooHigh(true);
    }
    
    /**
     * Device 5V line is too high (above 6 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_5VTooHigh Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_5VTooHigh(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_CANDLE_5V_TOO_HIGH.value, "StickyFault_5VTooHigh", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device 5V line is too low (below 4 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_5VTooLow Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_5VTooLow()
    {
        return getFault_5VTooLow(true);
    }
    
    /**
     * Device 5V line is too low (below 4 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_5VTooLow Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_5VTooLow(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_CANDLE_5V_TOO_LOW.value, "Fault_5VTooLow", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device 5V line is too low (below 4 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_5VTooLow Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_5VTooLow()
    {
        return getStickyFault_5VTooLow(true);
    }
    
    /**
     * Device 5V line is too low (below 4 V).
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_5VTooLow Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_5VTooLow(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_CANDLE_5V_TOO_LOW.value, "StickyFault_5VTooLow", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device temperature exceeded limit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Thermal Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Thermal()
    {
        return getFault_Thermal(true);
    }
    
    /**
     * Device temperature exceeded limit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Thermal Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Thermal(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_CANDLE_THERMAL.value, "Fault_Thermal", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device temperature exceeded limit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Thermal Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Thermal()
    {
        return getStickyFault_Thermal(true);
    }
    
    /**
     * Device temperature exceeded limit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Thermal Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Thermal(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_CANDLE_THERMAL.value, "StickyFault_Thermal", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * CANdle output current exceeded the 6 A limit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_SoftwareFuse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_SoftwareFuse()
    {
        return getFault_SoftwareFuse(true);
    }
    
    /**
     * CANdle output current exceeded the 6 A limit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_SoftwareFuse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_SoftwareFuse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_CANDLE_SOFTWARE_FUSE.value, "Fault_SoftwareFuse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * CANdle output current exceeded the 6 A limit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_SoftwareFuse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_SoftwareFuse()
    {
        return getStickyFault_SoftwareFuse(true);
    }
    
    /**
     * CANdle output current exceeded the 6 A limit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_SoftwareFuse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_SoftwareFuse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_CANDLE_SOFTWARE_FUSE.value, "StickyFault_SoftwareFuse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * CANdle has detected the output pin is shorted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_ShortCircuit Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_ShortCircuit()
    {
        return getFault_ShortCircuit(true);
    }
    
    /**
     * CANdle has detected the output pin is shorted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_ShortCircuit Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_ShortCircuit(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_CANDLE_SHORT_CIRCUIT.value, "Fault_ShortCircuit", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * CANdle has detected the output pin is shorted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_ShortCircuit Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_ShortCircuit()
    {
        return getStickyFault_ShortCircuit(true);
    }
    
    /**
     * CANdle has detected the output pin is shorted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_ShortCircuit Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_ShortCircuit(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_CANDLE_SHORT_CIRCUIT.value, "StickyFault_ShortCircuit", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }

    
    /**
     * Modulates the CANdle VBat output to the specified duty cycle. This
     * can be used to control a single-color LED strip.
     * <p>
     * Note that CANdleFeaturesConfigs.VBatOutputMode must be set to
     * VBatOutputModeValue.Modulated.
     * <p>
     * 
     * <ul>
     *   <li> <b>ModulateVBatOut Parameters:</b> 
     *   <ul>
     *     <li> <b>Output:</b> Proportion of VBat to output in fractional units
     *                         between 0.0 and 1.0.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(ModulateVBatOut request)
    {
        return setControlPrivate(request);
    }
    
    /**
     * Sets LEDs to a solid color.
     * <p>
     * 
     * <ul>
     *   <li> <b>SolidColor Parameters:</b> 
     *   <ul>
     *     <li> <b>LEDStartIndex:</b> The index of the first LED this animation
     *                                controls (inclusive). Indices 0-7 control the
     *                                onboard LEDs, and 8-399 control an attached
     *                                LED strip.
     *     <li> <b>LEDEndIndex:</b> The index of the last LED this animation
     *                              controls (inclusive). Indices 0-7 control the
     *                              onboard LEDs, and 8-399 control an attached LED
     *                              strip.
     *     <li> <b>Color:</b> The color to apply to the LEDs.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(SolidColor request)
    {
        return setControlPrivate(request);
    }
    
    /**
     * An empty animation, clearing any animation in the specified slot.
     * <p>
     * 
     * <ul>
     *   <li> <b>EmptyAnimation Parameters:</b> 
     *   <ul>
     *     <li> <b>Slot:</b> The slot of this animation, within [0, 7]. Each slot on
     *                       the CANdle can store and run one animation.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(EmptyAnimation request)
    {
        return setControlPrivate(request);
    }
    
    /**
     * Animation that gradually lights the entire LED strip one LED at a
     * time.
     * <p>
     * 
     * <ul>
     *   <li> <b>ColorFlowAnimation Parameters:</b> 
     *   <ul>
     *     <li> <b>LEDStartIndex:</b> The index of the first LED this animation
     *                                controls (inclusive). Indices 0-7 control the
     *                                onboard LEDs, and 8-399 control an attached
     *                                LED strip
     *                                <p>
     *                                If the start index is greater than the end
     *                                index, the direction will be reversed. The
     *                                direction can also be changed using the
     *                                Direction parameter.
     *     <li> <b>LEDEndIndex:</b> The index of the last LED this animation
     *                              controls (inclusive). Indices 0-7 control the
     *                              onboard LEDs, and 8-399 control an attached LED
     *                              strip.
     *                              <p>
     *                              If the end index is less than the start index,
     *                              the direction will be reversed. The direction
     *                              can also be changed using the Direction
     *                              parameter.
     *     <li> <b>Slot:</b> The slot of this animation, within [0, 7]. Each slot on
     *                       the CANdle can store and run one animation.
     *     <li> <b>Color:</b> The color to use in the animation.
     *     <li> <b>Direction:</b> The direction of the animation.
     *     <li> <b>FrameRate:</b> The frame rate of the animation, from [2, 1000]
     *                            Hz. This determines the speed of the animation.
     *                            <p>
     *                            A frame is defined as a transition in the state of
     *                            the LEDs, turning one on or off.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(ColorFlowAnimation request)
    {
        return setControlPrivate(request);
    }
    
    /**
     * Animation that looks similar to a flame flickering.
     * <p>
     * 
     * <ul>
     *   <li> <b>FireAnimation Parameters:</b> 
     *   <ul>
     *     <li> <b>LEDStartIndex:</b> The index of the first LED this animation
     *                                controls (inclusive). Indices 0-7 control the
     *                                onboard LEDs, and 8-399 control an attached
     *                                LED strip
     *                                <p>
     *                                If the start index is greater than the end
     *                                index, the direction will be reversed. The
     *                                direction can also be changed using the
     *                                Direction parameter.
     *     <li> <b>LEDEndIndex:</b> The index of the last LED this animation
     *                              controls (inclusive). Indices 0-7 control the
     *                              onboard LEDs, and 8-399 control an attached LED
     *                              strip.
     *                              <p>
     *                              If the end index is less than the start index,
     *                              the direction will be reversed. The direction
     *                              can also be changed using the Direction
     *                              parameter.
     *     <li> <b>Slot:</b> The slot of this animation, within [0, 7]. Each slot on
     *                       the CANdle can store and run one animation.
     *     <li> <b>Brightness:</b> The brightness of the animation, as a scalar from
     *                             0.0 to 1.0.
     *     <li> <b>Direction:</b> The direction of the animation.
     *     <li> <b>Sparking:</b> The proportion of time in which sparks reignite the
     *                           fire, as a scalar from 0.0 to 1.0.
     *     <li> <b>Cooling:</b> The rate at which the fire cools along the travel,
     *                          as a scalar from 0.0 to 1.0.
     *     <li> <b>FrameRate:</b> The frame rate of the animation, from [2, 1000]
     *                            Hz. This determines the speed of the animation.
     *                            <p>
     *                            A frame is defined as a transition in the state of
     *                            the LEDs, advancing the animation of the fire.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(FireAnimation request)
    {
        return setControlPrivate(request);
    }
    
    /**
     * Animation that bounces a pocket of light across the LED strip.
     * <p>
     * 
     * <ul>
     *   <li> <b>LarsonAnimation Parameters:</b> 
     *   <ul>
     *     <li> <b>LEDStartIndex:</b> The index of the first LED this animation
     *                                controls (inclusive). Indices 0-7 control the
     *                                onboard LEDs, and 8-399 control an attached
     *                                LED strip.
     *     <li> <b>LEDEndIndex:</b> The index of the last LED this animation
     *                              controls (inclusive). Indices 0-7 control the
     *                              onboard LEDs, and 8-399 control an attached LED
     *                              strip.
     *     <li> <b>Slot:</b> The slot of this animation, within [0, 7]. Each slot on
     *                       the CANdle can store and run one animation.
     *     <li> <b>Color:</b> The color to use in the animation.
     *     <li> <b>Size:</b> The number of LEDs in the pocket of light, up to 15.
     *     <li> <b>BounceMode:</b> The behavior of the pocket of light when it
     *                             reaches the end of the strip.
     *     <li> <b>FrameRate:</b> The frame rate of the animation, from [2, 1000]
     *                            Hz. This determines the speed of the animation.
     *                            <p>
     *                            A frame is defined as a transition in the state of
     *                            the LEDs, advancing the pocket of light by one
     *                            LED.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(LarsonAnimation request)
    {
        return setControlPrivate(request);
    }
    
    /**
     * Animation that creates a rainbow throughout all the LEDs.
     * <p>
     * 
     * <ul>
     *   <li> <b>RainbowAnimation Parameters:</b> 
     *   <ul>
     *     <li> <b>LEDStartIndex:</b> The index of the first LED this animation
     *                                controls (inclusive). Indices 0-7 control the
     *                                onboard LEDs, and 8-399 control an attached
     *                                LED strip
     *                                <p>
     *                                If the start index is greater than the end
     *                                index, the direction will be reversed. The
     *                                direction can also be changed using the
     *                                Direction parameter.
     *     <li> <b>LEDEndIndex:</b> The index of the last LED this animation
     *                              controls (inclusive). Indices 0-7 control the
     *                              onboard LEDs, and 8-399 control an attached LED
     *                              strip.
     *                              <p>
     *                              If the end index is less than the start index,
     *                              the direction will be reversed. The direction
     *                              can also be changed using the Direction
     *                              parameter.
     *     <li> <b>Slot:</b> The slot of this animation, within [0, 7]. Each slot on
     *                       the CANdle can store and run one animation.
     *     <li> <b>Brightness:</b> The brightness of the animation, as a scalar from
     *                             0.0 to 1.0.
     *     <li> <b>Direction:</b> The direction of the animation.
     *     <li> <b>FrameRate:</b> The frame rate of the animation, from [2, 1000]
     *                            Hz. This determines the speed of the animation.
     *                            <p>
     *                            A frame is defined as a transition in the state of
     *                            the LEDs, advancing the rainbow by about 3 degrees
     *                            of hue (out of 360 degrees).
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(RainbowAnimation request)
    {
        return setControlPrivate(request);
    }
    
    /**
     * Animation that fades all the LEDs of a strip simultaneously between
     * Red, Green, and Blue.
     * <p>
     * 
     * <ul>
     *   <li> <b>RgbFadeAnimation Parameters:</b> 
     *   <ul>
     *     <li> <b>LEDStartIndex:</b> The index of the first LED this animation
     *                                controls (inclusive). Indices 0-7 control the
     *                                onboard LEDs, and 8-399 control an attached
     *                                LED strip.
     *     <li> <b>LEDEndIndex:</b> The index of the last LED this animation
     *                              controls (inclusive). Indices 0-7 control the
     *                              onboard LEDs, and 8-399 control an attached LED
     *                              strip.
     *     <li> <b>Slot:</b> The slot of this animation, within [0, 7]. Each slot on
     *                       the CANdle can store and run one animation.
     *     <li> <b>Brightness:</b> The brightness of the animation, as a scalar from
     *                             0.0 to 1.0.
     *     <li> <b>FrameRate:</b> The frame rate of the animation, from [2, 1000]
     *                            Hz. This determines the speed of the animation.
     *                            <p>
     *                            A frame is defined as a transition in the state of
     *                            the LEDs, adjusting the brightness of the LEDs by
     *                            1%.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(RgbFadeAnimation request)
    {
        return setControlPrivate(request);
    }
    
    /**
     * Animation that fades into and out of a specified color.
     * <p>
     * 
     * <ul>
     *   <li> <b>SingleFadeAnimation Parameters:</b> 
     *   <ul>
     *     <li> <b>LEDStartIndex:</b> The index of the first LED this animation
     *                                controls (inclusive). Indices 0-7 control the
     *                                onboard LEDs, and 8-399 control an attached
     *                                LED strip.
     *     <li> <b>LEDEndIndex:</b> The index of the last LED this animation
     *                              controls (inclusive). Indices 0-7 control the
     *                              onboard LEDs, and 8-399 control an attached LED
     *                              strip.
     *     <li> <b>Slot:</b> The slot of this animation, within [0, 7]. Each slot on
     *                       the CANdle can store and run one animation.
     *     <li> <b>Color:</b> The color to use in the animation.
     *     <li> <b>FrameRate:</b> The frame rate of the animation, from [2, 1000]
     *                            Hz. This determines the speed of the animation.
     *                            <p>
     *                            A frame is defined as a transition in the state of
     *                            the LEDs, adjusting the brightness of the LEDs by
     *                            1%.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(SingleFadeAnimation request)
    {
        return setControlPrivate(request);
    }
    
    /**
     * Animation that strobes the LEDs a specified color.
     * <p>
     * 
     * <ul>
     *   <li> <b>StrobeAnimation Parameters:</b> 
     *   <ul>
     *     <li> <b>LEDStartIndex:</b> The index of the first LED this animation
     *                                controls (inclusive). Indices 0-7 control the
     *                                onboard LEDs, and 8-399 control an attached
     *                                LED strip.
     *     <li> <b>LEDEndIndex:</b> The index of the last LED this animation
     *                              controls (inclusive). Indices 0-7 control the
     *                              onboard LEDs, and 8-399 control an attached LED
     *                              strip.
     *     <li> <b>Slot:</b> The slot of this animation, within [0, 7]. Each slot on
     *                       the CANdle can store and run one animation.
     *     <li> <b>Color:</b> The color to use in the animation.
     *     <li> <b>FrameRate:</b> The frame rate of the animation, from [1, 500] Hz.
     *                            This determines the speed of the animation.
     *                            <p>
     *                            A frame is defined as a transition in the state of
     *                            the LEDs, turning all LEDs on or off.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(StrobeAnimation request)
    {
        return setControlPrivate(request);
    }
    
    /**
     * Animation that randomly turns LEDs on and off to a certain color.
     * <p>
     * 
     * <ul>
     *   <li> <b>TwinkleAnimation Parameters:</b> 
     *   <ul>
     *     <li> <b>LEDStartIndex:</b> The index of the first LED this animation
     *                                controls (inclusive). Indices 0-7 control the
     *                                onboard LEDs, and 8-399 control an attached
     *                                LED strip.
     *     <li> <b>LEDEndIndex:</b> The index of the last LED this animation
     *                              controls (inclusive). Indices 0-7 control the
     *                              onboard LEDs, and 8-399 control an attached LED
     *                              strip.
     *     <li> <b>Slot:</b> The slot of this animation, within [0, 7]. Each slot on
     *                       the CANdle can store and run one animation.
     *     <li> <b>Color:</b> The color to use in the animation.
     *     <li> <b>MaxLEDsOnProportion:</b> The max proportion of LEDs that can be
     *                                      on, in the range [0.1, 1.0].
     *     <li> <b>FrameRate:</b> The frame rate of the animation, from [2, 1000]
     *                            Hz. This determines the speed of the animation.
     *                            <p>
     *                            A frame is defined as a transition in the state of
     *                            the LEDs, turning one on or off.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(TwinkleAnimation request)
    {
        return setControlPrivate(request);
    }
    
    /**
     * Animation that randomly turns on LEDs until it reaches the maximum
     * count, and then turns them all off.
     * <p>
     * 
     * <ul>
     *   <li> <b>TwinkleOffAnimation Parameters:</b> 
     *   <ul>
     *     <li> <b>LEDStartIndex:</b> The index of the first LED this animation
     *                                controls (inclusive). Indices 0-7 control the
     *                                onboard LEDs, and 8-399 control an attached
     *                                LED strip.
     *     <li> <b>LEDEndIndex:</b> The index of the last LED this animation
     *                              controls (inclusive). Indices 0-7 control the
     *                              onboard LEDs, and 8-399 control an attached LED
     *                              strip.
     *     <li> <b>Slot:</b> The slot of this animation, within [0, 7]. Each slot on
     *                       the CANdle can store and run one animation.
     *     <li> <b>Color:</b> The color to use in the animation.
     *     <li> <b>MaxLEDsOnProportion:</b> The max proportion of LEDs that can be
     *                                      on, in the range [0.1, 1.0].
     *     <li> <b>FrameRate:</b> The frame rate of the animation, from [2, 1000]
     *                            Hz. This determines the speed of the animation.
     *                            <p>
     *                            A frame is defined as a transition in the state of
     *                            the LEDs, turning one LED on or all LEDs off.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    public final StatusCode setControl(TwinkleOffAnimation request)
    {
        return setControlPrivate(request);
    }

    /**
     * Control device with generic control request object.
     * <p>
     * User must make sure the specified object is castable to a valid control request,
     * otherwise this function will fail at run-time and return the NotSupported StatusCode
     *
     * @param request Control object to request of the device
     * @return Status Code of the request, 0 is OK
     */
    public final StatusCode setControl(ControlRequest request)
    {
        if (request instanceof ModulateVBatOut reqModulateVBatOut)
            return setControl(reqModulateVBatOut);
        if (request instanceof SolidColor reqSolidColor)
            return setControl(reqSolidColor);
        if (request instanceof EmptyAnimation reqEmptyAnimation)
            return setControl(reqEmptyAnimation);
        if (request instanceof ColorFlowAnimation reqColorFlowAnimation)
            return setControl(reqColorFlowAnimation);
        if (request instanceof FireAnimation reqFireAnimation)
            return setControl(reqFireAnimation);
        if (request instanceof LarsonAnimation reqLarsonAnimation)
            return setControl(reqLarsonAnimation);
        if (request instanceof RainbowAnimation reqRainbowAnimation)
            return setControl(reqRainbowAnimation);
        if (request instanceof RgbFadeAnimation reqRgbFadeAnimation)
            return setControl(reqRgbFadeAnimation);
        if (request instanceof SingleFadeAnimation reqSingleFadeAnimation)
            return setControl(reqSingleFadeAnimation);
        if (request instanceof StrobeAnimation reqStrobeAnimation)
            return setControl(reqStrobeAnimation);
        if (request instanceof TwinkleAnimation reqTwinkleAnimation)
            return setControl(reqTwinkleAnimation);
        if (request instanceof TwinkleOffAnimation reqTwinkleOffAnimation)
            return setControl(reqTwinkleOffAnimation);
        return StatusCode.NotSupported;
    }

    
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults() {
        return clearStickyFaults(0.100);
    }
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults(double timeoutSeconds) {
        return getConfigurator().clearStickyFaults(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware() {
        return clearStickyFault_Hardware(0.100);
    }
    /**
     * Clear sticky fault: Hardware fault occurred
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Hardware(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage() {
        return clearStickyFault_Undervoltage(0.100);
    }
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Undervoltage(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable() {
        return clearStickyFault_BootDuringEnable(0.100);
    }
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_BootDuringEnable(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse() {
        return clearStickyFault_UnlicensedFeatureInUse(0.100);
    }
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_UnlicensedFeatureInUse(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device supply voltage is too high (above 30 V).
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Overvoltage() {
        return clearStickyFault_Overvoltage(0.100);
    }
    /**
     * Clear sticky fault: Device supply voltage is too high (above 30 V).
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Overvoltage(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Overvoltage(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device 5V line is too high (above 6 V).
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_5VTooHigh() {
        return clearStickyFault_5VTooHigh(0.100);
    }
    /**
     * Clear sticky fault: Device 5V line is too high (above 6 V).
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_5VTooHigh(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_5VTooHigh(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device 5V line is too low (below 4 V).
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_5VTooLow() {
        return clearStickyFault_5VTooLow(0.100);
    }
    /**
     * Clear sticky fault: Device 5V line is too low (below 4 V).
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_5VTooLow(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_5VTooLow(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device temperature exceeded limit.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Thermal() {
        return clearStickyFault_Thermal(0.100);
    }
    /**
     * Clear sticky fault: Device temperature exceeded limit.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Thermal(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Thermal(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: CANdle output current exceeded the 6 A limit.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SoftwareFuse() {
        return clearStickyFault_SoftwareFuse(0.100);
    }
    /**
     * Clear sticky fault: CANdle output current exceeded the 6 A limit.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SoftwareFuse(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_SoftwareFuse(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: CANdle has detected the output pin is shorted.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ShortCircuit() {
        return clearStickyFault_ShortCircuit(0.100);
    }
    /**
     * Clear sticky fault: CANdle has detected the output pin is shorted.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ShortCircuit(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_ShortCircuit(timeoutSeconds);
    }
}

