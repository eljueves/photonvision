/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.spns;

import java.util.HashMap;

/** @hidden */
public enum SpnValue {
    TalonFX_System_State(615),
    Startup_ResetFlags(636),
    Version_Major(734),
    Version_Minor(735),
    Version_Bugfix(736),
    Version_Build(737),
    Version_Full(738),
    Licensing_IsProLicensed(751),
    Licensing_IsSeasonPassed(754),
    CustomParam0(823),
    CustomParam1(824),
    CANcoder_SensorDirection(828),
    FrcLock(830),
    RobotEnabled(831),
    LED1_OnColor(833),
    LED1_OffColor(834),
    LED2_OnColor(835),
    LED2_OffColor(836),
    AllFaults(844),
    AllStickyFaults(845),
    Pigeon2UseCompass(892),
    Pigeon2DisableTemperatureCompensation(927),
    Pigeon2DisableNoMotionCalibration(929),
    Pigeon2MountPoseYaw(934),
    Pigeon2MountPosePitch(935),
    Pigeon2MountPoseRoll(936),
    Pigeon2GyroScalarX(940),
    Pigeon2GyroScalarY(941),
    Pigeon2GyroScalarZ(942),
    Pigeon2Yaw(949),
    Pigeon2Pitch(950),
    Pigeon2Roll(951),
    Pigeon2QuatW(952),
    Pigeon2QuatX(953),
    Pigeon2QuatY(954),
    Pigeon2QuatZ(955),
    Pigeon2GravityVectorX(956),
    Pigeon2GravityVectorY(957),
    Pigeon2GravityVectorZ(958),
    Pigeon2Temperature(959),
    Pigeon2NoMotionCalEnabled(960),
    Pigeon2NoMotionCount(961),
    Pigeon2TempCompDisabled(962),
    Pigeon2UpTime(963),
    Pigeon2AccumGyroX(964),
    Pigeon2AccumGyroY(965),
    Pigeon2AccumGyroZ(966),
    Pigeon2AngularVelocityXWorld(967),
    Pigeon2AngularVelocityYWorld(968),
    Pigeon2AngularVelocityZWorld(969),
    Pigeon2AccelerationX(970),
    Pigeon2AccelerationY(971),
    Pigeon2AccelerationZ(972),
    Pigeon2_SupplyVoltage(973),
    Pigeon2AngularVelocityX(976),
    Pigeon2AngularVelocityY(977),
    Pigeon2AngularVelocityZ(978),
    Pigeon2MagneticFieldX(981),
    Pigeon2MagneticFieldY(982),
    Pigeon2MagneticFieldZ(983),
    Pigeon2RawMagneticFieldX(984),
    Pigeon2RawMagneticFieldY(985),
    Pigeon2RawMagneticFieldZ(986),
    CANCoder_MagnetOffset(987),
    TalonFX_SetSensorPosition(992),
    CANcoder_SetSensorPosition(994),
    Pigeon2_SetYaw(996),
    DeviceEnabled(1025),
    PRO_MotorOutput_MotorVoltage(1772),
    ForwardLimit(1773),
    ReverseLimit(1774),
    PRO_MotorOutput_RotorPolarity(1775),
    PRO_MotorOutput_DutyCycle(1776),
    PRO_MotorOutput_TorqueCurrent(1778),
    PRO_SupplyAndTemp_StatorCurrent(1779),
    PRO_SupplyAndTemp_SupplyCurrent(1780),
    PRO_SupplyAndTemp_SupplyVoltage(1781),
    PRO_SupplyAndTemp_DeviceTemp(1782),
    PRO_SupplyAndTemp_ProcessorTemp(1783),
    PRO_RotorPosAndVel_Velocity(1785),
    PRO_RotorPosAndVel_Position(1786),
    PRO_PosAndVel_Velocity(1789),
    PRO_PosAndVel_Position(1790),
    PRO_PosAndVel_Acceleration(1791),
    PRO_PIDStateEnables_IntegratedAccum_DC(1793),
    PRO_PIDStateEnables_IntegratedAccum_V(1794),
    PRO_PIDStateEnables_IntegratedAccum_A(1795),
    PRO_PIDStateEnables_FeedForward_DC(1796),
    PRO_PIDStateEnables_FeedForward_V(1797),
    PRO_PIDStateEnables_FeedForward_A(1798),
    TalonFX_ControlMode(1799),
    ExternalMotorTempStatus(1800),
    ExternalMotorTemp(1801),
    PRO_PIDStateEnables_MotionMagicAtTarget(1805),
    PRO_PIDStateEnables_IsMotionMagicRunning(1806),
    PRO_PIDStateEnables_RobotEnable(1807),
    PRO_PIDStateEnables_DeviceEnable(1808),
    PRO_PIDRefPIDErr_PIDRef_Position(1810),
    PRO_PIDRefPIDErr_PIDRef_Velocity(1811),
    PRO_PIDRefPIDErr_PIDErr_Position(1812),
    PRO_PIDRefPIDErr_PIDErr_Velocity(1813),
    PRO_PIDRefPIDErr_ClosedLoopMode(1814),
    PRO_PIDOutput_PIDOutputMode(1816),
    PRO_PIDOutput_ProportionalOutput_DC(1817),
    PRO_PIDOutput_ProportionalOutput_V(1818),
    PRO_PIDOutput_ProportionalOutput_A(1819),
    PRO_PIDOutput_DerivativeOutput_DC(1820),
    PRO_PIDOutput_DerivativeOutput_V(1821),
    PRO_PIDOutput_DerivativeOutput_A(1822),
    PRO_PIDOutput_Output_DC(1823),
    PRO_PIDOutput_Output_V(1824),
    PRO_PIDOutput_Output_A(1825),
    PRO_PIDOutput_Slot(1826),
    PRO_PIDRefSlopeECUTime_ReferenceSlope_Position(1827),
    PRO_PIDRefSlopeECUTime_ReferenceSlope_Velocity(1828),
    PRO_PIDRefSlopeECUTime_ClosedLoopMode(1829),
    TalonFX_MotorOutputStatus(1830),
    PRO_MotorOutput_PIDState_Diff_DutyCycle(1833),
    PRO_MotorOutput_PIDState_Diff_Voltage(1834),
    PRO_MotorOutput_PIDState_Diff_TorqueCurrent(1835),
    TalonFX_DifferentialControlMode(1838),
    PRO_MotorOutput_PIDState_Diff_IntegratedAccum_DC(1839),
    PRO_MotorOutput_PIDState_Diff_IntegratedAccum_V(1840),
    PRO_MotorOutput_PIDState_Diff_IntegratedAccum_A(1841),
    PRO_MotorOutput_PIDState_Diff_FeedForward_DC(1842),
    PRO_MotorOutput_PIDState_Diff_FeedForward_V(1843),
    PRO_MotorOutput_PIDState_Diff_FeedForward_A(1844),
    PRO_AvgPosAndVel_Velocity(1846),
    PRO_AvgPosAndVel_Position(1847),
    PRO_DiffPosAndVel_Velocity(1850),
    PRO_DiffPosAndVel_Position(1851),
    PRO_DiffPIDRefPIDErr_PIDRef_Position(1853),
    PRO_DiffPIDRefPIDErr_PIDRef_Velocity(1854),
    PRO_DiffPIDRefPIDErr_PIDErr_Position(1855),
    PRO_DiffPIDRefPIDErr_PIDErr_Velocity(1856),
    PRO_DiffPIDRefPIDErr_ClosedLoopMode(1857),
    PRO_DiffPIDOutput_PIDOutputMode(1859),
    PRO_DiffPIDOutput_ProportionalOutput_DC(1860),
    PRO_DiffPIDOutput_ProportionalOutput_V(1861),
    PRO_DiffPIDOutput_ProportionalOutput_A(1862),
    PRO_DiffPIDOutput_DerivativeOutput_DC(1863),
    PRO_DiffPIDOutput_DerivativeOutput_V(1864),
    PRO_DiffPIDOutput_DerivativeOutput_A(1865),
    PRO_DiffPIDOutput_Output_DC(1866),
    PRO_DiffPIDOutput_Output_V(1867),
    PRO_DiffPIDOutput_Output_A(1868),
    PRO_DiffPIDOutput_Slot(1869),
    PRO_DiffPIDRefSlopeECUTime_ReferenceSlope_Position(1870),
    PRO_DiffPIDRefSlopeECUTime_ReferenceSlope_Velocity(1871),
    PRO_DiffPIDRefSlopeECUTime_ClosedLoopMode(1872),
    TalonFX_MotorConstants_kT(1874),
    TalonFX_MotorConstants_kV(1875),
    TalonFX_MotorConstants_StallCurrent(1876),
    Slot0_kP(1877),
    Slot0_kI(1878),
    Slot0_kD(1879),
    Slot0_kS(1880),
    Slot0_kV(1881),
    Slot0_kA(1882),
    Slot0_kG(1883),
    Slot0_kG_Type(1884),
    Slot1_kP(1885),
    Slot1_kI(1886),
    Slot1_kD(1887),
    Slot1_kS(1888),
    Slot1_kV(1889),
    Slot1_kA(1890),
    Slot1_kG(1891),
    Slot1_kG_Type(1892),
    Slot2_kP(1893),
    Slot2_kI(1894),
    Slot2_kD(1895),
    Slot2_kS(1896),
    Slot2_kV(1897),
    Slot2_kA(1898),
    Slot2_kG(1899),
    Slot2_kG_Type(1900),
    Config_Inverted(1901),
    Config_SupplyVLowpassTau(1902),
    Config_BeepOnBoot(1903),
    Config_NeutralMode(1904),
    Config_DutyCycleNeutralDB(1905),
    Config_StatorCurrentLimit(1906),
    Config_StatorCurrLimitEn(1907),
    Config_SupplyCurrentLimit(1908),
    Config_SupplyCurrLimitEn(1909),
    Config_PeakForwardDC(1910),
    Config_PeakReverseDC(1911),
    Config_PeakForwardV(1912),
    Config_PeakReverseV(1913),
    Config_PeakForTorqCurr(1914),
    Config_PeakRevTorqCurr(1915),
    Config_TorqueNeutralDB(1916),
    Config_FeedbackRotorOffset(1917),
    Config_SensorToMechanismRatio(1918),
    Config_RotorToSensorRatio(1919),
    Config_FeedbackSensorSource(1920),
    Config_FeedbackRemoteSensorID(1921),
    Config_DutyCycleOpenLoopRampPeriod(1922),
    Config_VoltageOpenLoopRampPeriod(1923),
    Config_TorqueOpenLoopRampPeriod(1924),
    Config_DutyCycleClosedLoopRampPeriod(1925),
    Config_VoltageClosedLoopRampPeriod(1926),
    Config_TorqueClosedLoopRampPeriod(1927),
    Config_ForwardLimitType(1928),
    Config_ForwardLimitAutosetPosEnable(1929),
    Config_ForwardLimitAutosetPosValue(1930),
    Config_ForwardLimitEnable(1931),
    Config_ForwardLimitSource(1932),
    Config_ForwardLimitRemoteSensorID(1933),
    Config_ReverseLimitType(1934),
    Config_ReverseLimitAutosetPosEnable(1935),
    Config_ReverseLimitAutosetPosValue(1936),
    Config_ReverseLimitEnable(1937),
    Config_ReverseLimitSource(1938),
    Config_ReverseLimitRemoteSensorID(1939),
    Config_ForwardSoftLimitEnable(1940),
    Config_ReverseSoftLimitEnable(1941),
    Config_ForwardSoftLimitThreshold(1942),
    Config_ReverseSoftLimitThreshold(1943),
    Config_MotionMagicCruiseVelocity(1944),
    Config_MotionMagicAcceleration(1945),
    Config_MotionMagicJerk(1946),
    Config_MotionMagicExpo_kV(1947),
    Config_MotionMagicExpo_kA(1948),
    Config_PeakDiffDC(1949),
    Config_PeakDiffV(1950),
    Config_PeakDiffTorqCurr(1951),
    CANcoder_Velocity(1952),
    CANcoder_Position(1953),
    CANcoder_AbsPosition(1954),
    CANCoder_RawVel(1956),
    CANCoder_RawPos(1957),
    CANCoder_SupplyVoltage(1958),
    CANcoder_MagHealth(1959),
    SPN_ClearStickyFaults(1962),
    PRO_MotorOutput_BridgeType_Public(1963),
    Config_ContinuousWrap(1985),
    Config_DifferentialContinuousWrap(1986),
    Config_SupplyCurrentLowerLimit(1992),
    Config_SupplyCurrentLowerTime(1993),
    Config_DifferentialSensorSource(2007),
    Config_DifferentialTalonFXSensorID(2008),
    Config_DifferentialRemoteSensorID(2009),
    Config_SensorToDifferentialRatio(2010),
    Config_BeepOnConfig(2049),
    Config_AllowMusicDurDisable(2050),
    Compliancy_Version(2051),
    Version_IsProLicensed(2052),
    PRO_SupplyAndTemp_DeviceTemp2(2091),
    Slot0_kS_Sign(2114),
    Slot1_kS_Sign(2115),
    Slot2_kS_Sign(2116),
    TalonFX_ConnectedMotor(2117),
    CANrange_SupplyVoltage(2139),
    CANrange_Distance_Meters(2140),
    CANrange_MeasTime(2142),
    CANrange_SignalStrength(2143),
    CANrange_ProximityDetected(2144),
    CANrange_MeasState(2145),
    CANrange_AmbientSignal(2146),
    CANrange_DistanceStdDev(2147),
    CANrange_RealFOVCenterX(2150),
    CANrange_RealFOVCenterY(2151),
    CANrange_RealFOVRangeX(2152),
    CANrange_RealFOVRangeY(2153),
    CANrange_UpdateMode(2157),
    CANrange_UpdateFreq(2158),
    CANrange_ProximityThreshold(2160),
    CANrange_ProximityHysteresis(2161),
    CANrange_MinSigStrengthForValidMeas(2162),
    CANrange_FOVCenterX(2163),
    CANrange_FOVCenterY(2164),
    CANrange_FOVRangeX(2165),
    CANrange_FOVRangeY(2166),
    Config_ControlTimesyncFreq(2167),
    Config_VelocityFilterTimeConstant(2168),
    Config_AdvancedHallSupport(2365),
    Config_MotorType(2366),
    CANdi_Pin1State(2425),
    CANdi_Pin2State(2426),
    CANdi_QuadPosition(2427),
    CANdi_Pwm1_RiseToRise(2433),
    CANdi_Pwm1_Position(2434),
    CANdi_Pwm1_Velocity(2436),
    CANdi_Pwm2_RiseToRise(2437),
    CANdi_Pwm2_Position(2438),
    CANdi_Overcurrent(2440),
    CANdi_VSense(2441),
    CANdi_OutputCurrent(2442),
    CANdi_S1FloatState(2443),
    CANdi_S2FloatState(2444),
    Config_AbsoluteSensorOffset(2453),
    Config_ExternalFeedbackSensorSource(2454),
    Config_SensorPhase(2455),
    Config_QuadratureEdgesPerRotation(2456),
    Config_AbsoluteSensorDiscontinuityPoint(2457),
    CANdi_Pwm2_Velocity(2595),
    TalonFXS_5VRailVoltage(2597),
    TalonFXS_Gadgeteer_G3(2598),
    CANdi_QuadVelocity(2605),
    Config_PWM1_AbsoluteSensorOffset(2606),
    Config_PWM1_AbsoluteSensorDiscontinuityPoint(2607),
    Config_PWM1_SensorDirection(2608),
    Config_PWM2_AbsoluteSensorOffset(2610),
    Config_PWM2_AbsoluteSensorDiscontinuityPoint(2611),
    Config_PWM2_SensorDirection(2612),
    Config_Quad_SensorDirection(2614),
    CANdi_SetQuadPosition(2616),
    Config_S1_CloseState(2617),
    Config_S2_CloseState(2618),
    CANdi_S1Closed(2619),
    CANdi_S2Closed(2620),
    Config_BrushedMotorWiring(2626),
    PRO_GadgeteerQuad_RawQuadraturePosition(2633),
    PRO_GadgeteerQuad_RawQuadratureVelocity(2634),
    PRO_GadgeteerPwm_RawPwmPosition(2635),
    PRO_GadgeteerPwm_RawPwmVelocity(2636),
    CANdle_General_SupplyVoltage(2647),
    CANdle_General_FiveVRailVoltage(2648),
    CANdle_General_OutputCurrent(2649),
    CANdle_General_DeviceTemp(2650),
    CANdle_General_VBatModulation(2651),
    CANdle_General_MaxSimulAnimCount(2652),
    Config_LED_StripType(2653),
    Config_LED_BrightnessScalar(2654),
    Config_LED_LossOfSignalBehavior(2655),
    Config_CANdle_5VRail(2656),
    Config_CANdle_VBatOutputMode(2657),
    Config_CANdle_StatusLedWhenActive(2658),
    CANdle_Animation0_Type(2675),
    CANdle_Animation1_Type(2676),
    CANdle_Animation2_Type(2677),
    CANdle_Animation3_Type(2678),
    CANdle_Animation4_Type(2679),
    CANdle_Animation5_Type(2680),
    CANdle_Animation6_Type(2681),
    CANdle_Animation7_Type(2682),
    CANdle_AnimationDirection(2683),
    CANdle_LarsonBounceMode(2684),
    Slot0_kG_PosOffset(2685),
    Slot1_kG_PosOffset(2686),
    Slot2_kG_PosOffset(2687),
    Config_CustomMot_Kv(2688),
    Config_CustomMot_NumPolePairs(2689),
    Config_CustomMot_Thermistor_MaxTemp(2690),
    Config_CustomMot_Thermistor_Beta(2691),
    Config_CustomMot_Thermistor_R0(2692),
    Config_CustomMot_Hall_AB(2693),
    Config_CustomMot_Hall_AC(2694),
    Config_CustomMot_Hall_CCW_Select(2695),
    Config_CustomMot_Hall_Direction(2696),
    Config_TempSensorSelection(2697),
    Config_GainSchedErrorThreshold(2698),
    Config_GainSchedKpBehavior(2699),
    Slot0_GainSchedBehavior(2700),
    Slot1_GainSchedBehavior(2701),
    Slot2_GainSchedBehavior(2702),
    MotorAlignment(2703),
    Fault_Hardware(10001),
    StickyFault_Hardware(10002),
    ClearStickyFault_Hardware(10003),
    Fault_ProcTemp(10004),
    StickyFault_ProcTemp(10005),
    ClearStickyFault_ProcTemp(10006),
    Fault_DeviceTemp(10007),
    StickyFault_DeviceTemp(10008),
    ClearStickyFault_DeviceTemp(10009),
    Fault_Undervoltage(10010),
    StickyFault_Undervoltage(10011),
    ClearStickyFault_Undervoltage(10012),
    Fault_BootDuringEnable(10013),
    StickyFault_BootDuringEnable(10014),
    ClearStickyFault_BootDuringEnable(10015),
    Fault_UnlicensedFeatureInUse(10016),
    StickyFault_UnlicensedFeatureInUse(10017),
    ClearStickyFault_UnlicensedFeatureInUse(10018),
    Fault_PIGEON2_BootupAccel(10019),
    StickyFault_PIGEON2_BootupAccel(10020),
    ClearStickyFault_PIGEON2_BootupAccel(10021),
    Fault_PIGEON2_BootupGyros(10022),
    StickyFault_PIGEON2_BootupGyros(10023),
    ClearStickyFault_PIGEON2_BootupGyros(10024),
    Fault_PIGEON2_BootupMagne(10025),
    StickyFault_PIGEON2_BootupMagne(10026),
    ClearStickyFault_PIGEON2_BootupMagne(10027),
    Fault_PIGEON2_BootIntoMotion(10028),
    StickyFault_PIGEON2_BootIntoMotion(10029),
    ClearStickyFault_PIGEON2_BootIntoMotion(10030),
    Fault_PIGEON2_DataAcquiredLate(10031),
    StickyFault_PIGEON2_DataAcquiredLate(10032),
    ClearStickyFault_PIGEON2_DataAcquiredLate(10033),
    Fault_PIGEON2_LoopTimeSlow(10034),
    StickyFault_PIGEON2_LoopTimeSlow(10035),
    ClearStickyFault_PIGEON2_LoopTimeSlow(10036),
    Fault_PIGEON2_SaturatedMagne(10037),
    StickyFault_PIGEON2_SaturatedMagne(10038),
    ClearStickyFault_PIGEON2_SaturatedMagne(10039),
    Fault_PIGEON2_SaturatedAccel(10040),
    StickyFault_PIGEON2_SaturatedAccel(10041),
    ClearStickyFault_PIGEON2_SaturatedAccel(10042),
    Fault_PIGEON2_SaturatedGyros(10043),
    StickyFault_PIGEON2_SaturatedGyros(10044),
    ClearStickyFault_PIGEON2_SaturatedGyros(10045),
    Fault_CANCODER_BadMagnet(10046),
    StickyFault_CANCODER_BadMagnet(10047),
    ClearStickyFault_CANCODER_BadMagnet(10048),
    Fault_TALONFX_BridgeBrownout(10049),
    StickyFault_TALONFX_BridgeBrownout(10050),
    ClearStickyFault_TALONFX_BridgeBrownout(10051),
    Fault_TALONFX_RemoteSensorReset(10052),
    StickyFault_TALONFX_RemoteSensorReset(10053),
    ClearStickyFault_TALONFX_RemoteSensorReset(10054),
    Fault_TALONFX_MissingDifferentialFX(10055),
    StickyFault_TALONFX_MissingDifferentialFX(10056),
    ClearStickyFault_TALONFX_MissingDifferentialFX(10057),
    Fault_TALONFX_RemoteSensorPosOverflow(10058),
    StickyFault_TALONFX_RemoteSensorPosOverflow(10059),
    ClearStickyFault_TALONFX_RemoteSensorPosOverflow(10060),
    Fault_TALONFX_OverSupplyV(10061),
    StickyFault_TALONFX_OverSupplyV(10062),
    ClearStickyFault_TALONFX_OverSupplyV(10063),
    Fault_TALONFX_UnstableSupplyV(10064),
    StickyFault_TALONFX_UnstableSupplyV(10065),
    ClearStickyFault_TALONFX_UnstableSupplyV(10066),
    Fault_TALONFX_ReverseHardLimit(10067),
    StickyFault_TALONFX_ReverseHardLimit(10068),
    ClearStickyFault_TALONFX_ReverseHardLimit(10069),
    Fault_TALONFX_ForwardHardLimit(10070),
    StickyFault_TALONFX_ForwardHardLimit(10071),
    ClearStickyFault_TALONFX_ForwardHardLimit(10072),
    Fault_TALONFX_ReverseSoftLimit(10073),
    StickyFault_TALONFX_ReverseSoftLimit(10074),
    ClearStickyFault_TALONFX_ReverseSoftLimit(10075),
    Fault_TALONFX_ForwardSoftLimit(10076),
    StickyFault_TALONFX_ForwardSoftLimit(10077),
    ClearStickyFault_TALONFX_ForwardSoftLimit(10078),
    Fault_TALONFX_MissingRemSoftLim(10079),
    StickyFault_TALONFX_MissingRemSoftLim(10080),
    ClearStickyFault_TALONFX_MissingRemSoftLim(10081),
    Fault_TALONFX_MissingRemHardLim(10082),
    StickyFault_TALONFX_MissingRemHardLim(10083),
    ClearStickyFault_TALONFX_MissingRemHardLim(10084),
    Fault_TALONFX_MissingRemoteSensor(10085),
    StickyFault_TALONFX_MissingRemoteSensor(10086),
    ClearStickyFault_TALONFX_MissingRemoteSensor(10087),
    Fault_TALONFX_FusedSensorOutOfSync(10088),
    StickyFault_TALONFX_FusedSensorOutOfSync(10089),
    ClearStickyFault_TALONFX_FusedSensorOutOfSync(10090),
    Fault_TALONFX_StatorCurrLimit(10091),
    StickyFault_TALONFX_StatorCurrLimit(10092),
    ClearStickyFault_TALONFX_StatorCurrLimit(10093),
    Fault_TALONFX_SupplyCurrLimit(10094),
    StickyFault_TALONFX_SupplyCurrLimit(10095),
    ClearStickyFault_TALONFX_SupplyCurrLimit(10096),
    Fault_TALONFX_UsingFusedCCWhileUnlicensed(10097),
    StickyFault_TALONFX_UsingFusedCCWhileUnlicensed(10098),
    ClearStickyFault_TALONFX_UsingFusedCCWhileUnlicensed(10099),
    Fault_TALONFX_StaticBrakeDisabled(10100),
    StickyFault_TALONFX_StaticBrakeDisabled(10101),
    ClearStickyFault_TALONFX_StaticBrakeDisabled(10102),
    Fault_TALONFX_BridgeShort(10103),
    StickyFault_TALONFX_BridgeShort(10104),
    ClearStickyFault_TALONFX_BridgeShort(10105),
    Fault_TALONFX_HallSensorMissing(10106),
    StickyFault_TALONFX_HallSensorMissing(10107),
    ClearStickyFault_TALONFX_HallSensorMissing(10108),
    Fault_TALONFX_DriveDisabledHallSensor(10109),
    StickyFault_TALONFX_DriveDisabledHallSensor(10110),
    ClearStickyFault_TALONFX_DriveDisabledHallSensor(10111),
    Fault_TALONFX_MotorTempSensorMissing(10112),
    StickyFault_TALONFX_MotorTempSensorMissing(10113),
    ClearStickyFault_TALONFX_MotorTempSensorMissing(10114),
    Fault_TALONFX_MotorTempSensorTooHot(10115),
    StickyFault_TALONFX_MotorTempSensorTooHot(10116),
    ClearStickyFault_TALONFX_MotorTempSensorTooHot(10117),
    Fault_TALONFX_MotorArrangementNotSelected(10118),
    StickyFault_TALONFX_MotorArrangementNotSelected(10119),
    ClearStickyFault_TALONFX_MotorArrangementNotSelected(10120),
    Fault_TALONFX_5V(10121),
    StickyFault_TALONFX_5V(10122),
    Fault_CANDI_5V(10124),
    StickyFault_CANDI_5V(10125),
    ClearStickyFault_CANDI_5V(10126),
    Fault_CANDLE_OVERVOLTAGE(10127),
    StickyFault_CANDLE_OVERVOLTAGE(10128),
    ClearStickyFault_CANDLE_OVERVOLTAGE(10129),
    Fault_CANDLE_5V_TOO_HIGH(10130),
    StickyFault_CANDLE_5V_TOO_HIGH(10131),
    ClearStickyFault_CANDLE_5V_TOO_HIGH(10132),
    Fault_CANDLE_5V_TOO_LOW(10133),
    StickyFault_CANDLE_5V_TOO_LOW(10134),
    ClearStickyFault_CANDLE_5V_TOO_LOW(10135),
    Fault_CANDLE_THERMAL(10136),
    StickyFault_CANDLE_THERMAL(10137),
    ClearStickyFault_CANDLE_THERMAL(10138),
    Fault_CANDLE_SOFTWARE_FUSE(10139),
    StickyFault_CANDLE_SOFTWARE_FUSE(10140),
    ClearStickyFault_CANDLE_SOFTWARE_FUSE(10141),
    Fault_CANDLE_SHORT_CIRCUIT(10142),
    StickyFault_CANDLE_SHORT_CIRCUIT(10143),
    ClearStickyFault_CANDLE_SHORT_CIRCUIT(10144),;

    public final int value;

    SpnValue(int initValue) {
        this.value = initValue;
    }

    private static HashMap<Integer, SpnValue> _map = null;
    static {
        _map = new HashMap<Integer, SpnValue>();
        for (SpnValue type : SpnValue.values()) {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets SpnValue from specified value
     *
     * @param value Value of SpnValue
     * @return SpnValue of specified value
     */
    public static SpnValue valueOf(int value) {
        SpnValue retval = _map.get(value);
        if (retval != null)
            return retval;
        return SpnValue.values()[0];
    }

    public String toString() {
        switch (this) {
        case TalonFX_System_State: return "TalonFX_System_State";
        case Startup_ResetFlags: return "Startup_ResetFlags";
        case Version_Major: return "Version_Major";
        case Version_Minor: return "Version_Minor";
        case Version_Bugfix: return "Version_Bugfix";
        case Version_Build: return "Version_Build";
        case Version_Full: return "Version_Full";
        case Licensing_IsProLicensed: return "Licensing_IsProLicensed";
        case Licensing_IsSeasonPassed: return "Licensing_IsSeasonPassed";
        case CustomParam0: return "CustomParam0";
        case CustomParam1: return "CustomParam1";
        case CANcoder_SensorDirection: return "CANcoder_SensorDirection";
        case FrcLock: return "FrcLock";
        case RobotEnabled: return "RobotEnabled";
        case LED1_OnColor: return "LED1_OnColor";
        case LED1_OffColor: return "LED1_OffColor";
        case LED2_OnColor: return "LED2_OnColor";
        case LED2_OffColor: return "LED2_OffColor";
        case AllFaults: return "AllFaults";
        case AllStickyFaults: return "AllStickyFaults";
        case Pigeon2UseCompass: return "Pigeon2UseCompass";
        case Pigeon2DisableTemperatureCompensation: return "Pigeon2DisableTemperatureCompensation";
        case Pigeon2DisableNoMotionCalibration: return "Pigeon2DisableNoMotionCalibration";
        case Pigeon2MountPoseYaw: return "Pigeon2MountPoseYaw";
        case Pigeon2MountPosePitch: return "Pigeon2MountPosePitch";
        case Pigeon2MountPoseRoll: return "Pigeon2MountPoseRoll";
        case Pigeon2GyroScalarX: return "Pigeon2GyroScalarX";
        case Pigeon2GyroScalarY: return "Pigeon2GyroScalarY";
        case Pigeon2GyroScalarZ: return "Pigeon2GyroScalarZ";
        case Pigeon2Yaw: return "Pigeon2Yaw";
        case Pigeon2Pitch: return "Pigeon2Pitch";
        case Pigeon2Roll: return "Pigeon2Roll";
        case Pigeon2QuatW: return "Pigeon2QuatW";
        case Pigeon2QuatX: return "Pigeon2QuatX";
        case Pigeon2QuatY: return "Pigeon2QuatY";
        case Pigeon2QuatZ: return "Pigeon2QuatZ";
        case Pigeon2GravityVectorX: return "Pigeon2GravityVectorX";
        case Pigeon2GravityVectorY: return "Pigeon2GravityVectorY";
        case Pigeon2GravityVectorZ: return "Pigeon2GravityVectorZ";
        case Pigeon2Temperature: return "Pigeon2Temperature";
        case Pigeon2NoMotionCalEnabled: return "Pigeon2NoMotionCalEnabled";
        case Pigeon2NoMotionCount: return "Pigeon2NoMotionCount";
        case Pigeon2TempCompDisabled: return "Pigeon2TempCompDisabled";
        case Pigeon2UpTime: return "Pigeon2UpTime";
        case Pigeon2AccumGyroX: return "Pigeon2AccumGyroX";
        case Pigeon2AccumGyroY: return "Pigeon2AccumGyroY";
        case Pigeon2AccumGyroZ: return "Pigeon2AccumGyroZ";
        case Pigeon2AngularVelocityXWorld: return "Pigeon2AngularVelocityXWorld";
        case Pigeon2AngularVelocityYWorld: return "Pigeon2AngularVelocityYWorld";
        case Pigeon2AngularVelocityZWorld: return "Pigeon2AngularVelocityZWorld";
        case Pigeon2AccelerationX: return "Pigeon2AccelerationX";
        case Pigeon2AccelerationY: return "Pigeon2AccelerationY";
        case Pigeon2AccelerationZ: return "Pigeon2AccelerationZ";
        case Pigeon2_SupplyVoltage: return "Pigeon2_SupplyVoltage";
        case Pigeon2AngularVelocityX: return "Pigeon2AngularVelocityX";
        case Pigeon2AngularVelocityY: return "Pigeon2AngularVelocityY";
        case Pigeon2AngularVelocityZ: return "Pigeon2AngularVelocityZ";
        case Pigeon2MagneticFieldX: return "Pigeon2MagneticFieldX";
        case Pigeon2MagneticFieldY: return "Pigeon2MagneticFieldY";
        case Pigeon2MagneticFieldZ: return "Pigeon2MagneticFieldZ";
        case Pigeon2RawMagneticFieldX: return "Pigeon2RawMagneticFieldX";
        case Pigeon2RawMagneticFieldY: return "Pigeon2RawMagneticFieldY";
        case Pigeon2RawMagneticFieldZ: return "Pigeon2RawMagneticFieldZ";
        case CANCoder_MagnetOffset: return "CANCoder_MagnetOffset";
        case TalonFX_SetSensorPosition: return "TalonFX_SetSensorPosition";
        case CANcoder_SetSensorPosition: return "CANcoder_SetSensorPosition";
        case Pigeon2_SetYaw: return "Pigeon2_SetYaw";
        case DeviceEnabled: return "DeviceEnabled";
        case PRO_MotorOutput_MotorVoltage: return "PRO_MotorOutput_MotorVoltage";
        case ForwardLimit: return "ForwardLimit";
        case ReverseLimit: return "ReverseLimit";
        case PRO_MotorOutput_RotorPolarity: return "PRO_MotorOutput_RotorPolarity";
        case PRO_MotorOutput_DutyCycle: return "PRO_MotorOutput_DutyCycle";
        case PRO_MotorOutput_TorqueCurrent: return "PRO_MotorOutput_TorqueCurrent";
        case PRO_SupplyAndTemp_StatorCurrent: return "PRO_SupplyAndTemp_StatorCurrent";
        case PRO_SupplyAndTemp_SupplyCurrent: return "PRO_SupplyAndTemp_SupplyCurrent";
        case PRO_SupplyAndTemp_SupplyVoltage: return "PRO_SupplyAndTemp_SupplyVoltage";
        case PRO_SupplyAndTemp_DeviceTemp: return "PRO_SupplyAndTemp_DeviceTemp";
        case PRO_SupplyAndTemp_ProcessorTemp: return "PRO_SupplyAndTemp_ProcessorTemp";
        case PRO_RotorPosAndVel_Velocity: return "PRO_RotorPosAndVel_Velocity";
        case PRO_RotorPosAndVel_Position: return "PRO_RotorPosAndVel_Position";
        case PRO_PosAndVel_Velocity: return "PRO_PosAndVel_Velocity";
        case PRO_PosAndVel_Position: return "PRO_PosAndVel_Position";
        case PRO_PosAndVel_Acceleration: return "PRO_PosAndVel_Acceleration";
        case PRO_PIDStateEnables_IntegratedAccum_DC: return "PRO_PIDStateEnables_IntegratedAccum_DC";
        case PRO_PIDStateEnables_IntegratedAccum_V: return "PRO_PIDStateEnables_IntegratedAccum_V";
        case PRO_PIDStateEnables_IntegratedAccum_A: return "PRO_PIDStateEnables_IntegratedAccum_A";
        case PRO_PIDStateEnables_FeedForward_DC: return "PRO_PIDStateEnables_FeedForward_DC";
        case PRO_PIDStateEnables_FeedForward_V: return "PRO_PIDStateEnables_FeedForward_V";
        case PRO_PIDStateEnables_FeedForward_A: return "PRO_PIDStateEnables_FeedForward_A";
        case TalonFX_ControlMode: return "TalonFX_ControlMode";
        case ExternalMotorTempStatus: return "ExternalMotorTempStatus";
        case ExternalMotorTemp: return "ExternalMotorTemp";
        case PRO_PIDStateEnables_MotionMagicAtTarget: return "PRO_PIDStateEnables_MotionMagicAtTarget";
        case PRO_PIDStateEnables_IsMotionMagicRunning: return "PRO_PIDStateEnables_IsMotionMagicRunning";
        case PRO_PIDStateEnables_RobotEnable: return "PRO_PIDStateEnables_RobotEnable";
        case PRO_PIDStateEnables_DeviceEnable: return "PRO_PIDStateEnables_DeviceEnable";
        case PRO_PIDRefPIDErr_PIDRef_Position: return "PRO_PIDRefPIDErr_PIDRef_Position";
        case PRO_PIDRefPIDErr_PIDRef_Velocity: return "PRO_PIDRefPIDErr_PIDRef_Velocity";
        case PRO_PIDRefPIDErr_PIDErr_Position: return "PRO_PIDRefPIDErr_PIDErr_Position";
        case PRO_PIDRefPIDErr_PIDErr_Velocity: return "PRO_PIDRefPIDErr_PIDErr_Velocity";
        case PRO_PIDRefPIDErr_ClosedLoopMode: return "PRO_PIDRefPIDErr_ClosedLoopMode";
        case PRO_PIDOutput_PIDOutputMode: return "PRO_PIDOutput_PIDOutputMode";
        case PRO_PIDOutput_ProportionalOutput_DC: return "PRO_PIDOutput_ProportionalOutput_DC";
        case PRO_PIDOutput_ProportionalOutput_V: return "PRO_PIDOutput_ProportionalOutput_V";
        case PRO_PIDOutput_ProportionalOutput_A: return "PRO_PIDOutput_ProportionalOutput_A";
        case PRO_PIDOutput_DerivativeOutput_DC: return "PRO_PIDOutput_DerivativeOutput_DC";
        case PRO_PIDOutput_DerivativeOutput_V: return "PRO_PIDOutput_DerivativeOutput_V";
        case PRO_PIDOutput_DerivativeOutput_A: return "PRO_PIDOutput_DerivativeOutput_A";
        case PRO_PIDOutput_Output_DC: return "PRO_PIDOutput_Output_DC";
        case PRO_PIDOutput_Output_V: return "PRO_PIDOutput_Output_V";
        case PRO_PIDOutput_Output_A: return "PRO_PIDOutput_Output_A";
        case PRO_PIDOutput_Slot: return "PRO_PIDOutput_Slot";
        case PRO_PIDRefSlopeECUTime_ReferenceSlope_Position: return "PRO_PIDRefSlopeECUTime_ReferenceSlope_Position";
        case PRO_PIDRefSlopeECUTime_ReferenceSlope_Velocity: return "PRO_PIDRefSlopeECUTime_ReferenceSlope_Velocity";
        case PRO_PIDRefSlopeECUTime_ClosedLoopMode: return "PRO_PIDRefSlopeECUTime_ClosedLoopMode";
        case TalonFX_MotorOutputStatus: return "TalonFX_MotorOutputStatus";
        case PRO_MotorOutput_PIDState_Diff_DutyCycle: return "PRO_MotorOutput_PIDState_Diff_DutyCycle";
        case PRO_MotorOutput_PIDState_Diff_Voltage: return "PRO_MotorOutput_PIDState_Diff_Voltage";
        case PRO_MotorOutput_PIDState_Diff_TorqueCurrent: return "PRO_MotorOutput_PIDState_Diff_TorqueCurrent";
        case TalonFX_DifferentialControlMode: return "TalonFX_DifferentialControlMode";
        case PRO_MotorOutput_PIDState_Diff_IntegratedAccum_DC: return "PRO_MotorOutput_PIDState_Diff_IntegratedAccum_DC";
        case PRO_MotorOutput_PIDState_Diff_IntegratedAccum_V: return "PRO_MotorOutput_PIDState_Diff_IntegratedAccum_V";
        case PRO_MotorOutput_PIDState_Diff_IntegratedAccum_A: return "PRO_MotorOutput_PIDState_Diff_IntegratedAccum_A";
        case PRO_MotorOutput_PIDState_Diff_FeedForward_DC: return "PRO_MotorOutput_PIDState_Diff_FeedForward_DC";
        case PRO_MotorOutput_PIDState_Diff_FeedForward_V: return "PRO_MotorOutput_PIDState_Diff_FeedForward_V";
        case PRO_MotorOutput_PIDState_Diff_FeedForward_A: return "PRO_MotorOutput_PIDState_Diff_FeedForward_A";
        case PRO_AvgPosAndVel_Velocity: return "PRO_AvgPosAndVel_Velocity";
        case PRO_AvgPosAndVel_Position: return "PRO_AvgPosAndVel_Position";
        case PRO_DiffPosAndVel_Velocity: return "PRO_DiffPosAndVel_Velocity";
        case PRO_DiffPosAndVel_Position: return "PRO_DiffPosAndVel_Position";
        case PRO_DiffPIDRefPIDErr_PIDRef_Position: return "PRO_DiffPIDRefPIDErr_PIDRef_Position";
        case PRO_DiffPIDRefPIDErr_PIDRef_Velocity: return "PRO_DiffPIDRefPIDErr_PIDRef_Velocity";
        case PRO_DiffPIDRefPIDErr_PIDErr_Position: return "PRO_DiffPIDRefPIDErr_PIDErr_Position";
        case PRO_DiffPIDRefPIDErr_PIDErr_Velocity: return "PRO_DiffPIDRefPIDErr_PIDErr_Velocity";
        case PRO_DiffPIDRefPIDErr_ClosedLoopMode: return "PRO_DiffPIDRefPIDErr_ClosedLoopMode";
        case PRO_DiffPIDOutput_PIDOutputMode: return "PRO_DiffPIDOutput_PIDOutputMode";
        case PRO_DiffPIDOutput_ProportionalOutput_DC: return "PRO_DiffPIDOutput_ProportionalOutput_DC";
        case PRO_DiffPIDOutput_ProportionalOutput_V: return "PRO_DiffPIDOutput_ProportionalOutput_V";
        case PRO_DiffPIDOutput_ProportionalOutput_A: return "PRO_DiffPIDOutput_ProportionalOutput_A";
        case PRO_DiffPIDOutput_DerivativeOutput_DC: return "PRO_DiffPIDOutput_DerivativeOutput_DC";
        case PRO_DiffPIDOutput_DerivativeOutput_V: return "PRO_DiffPIDOutput_DerivativeOutput_V";
        case PRO_DiffPIDOutput_DerivativeOutput_A: return "PRO_DiffPIDOutput_DerivativeOutput_A";
        case PRO_DiffPIDOutput_Output_DC: return "PRO_DiffPIDOutput_Output_DC";
        case PRO_DiffPIDOutput_Output_V: return "PRO_DiffPIDOutput_Output_V";
        case PRO_DiffPIDOutput_Output_A: return "PRO_DiffPIDOutput_Output_A";
        case PRO_DiffPIDOutput_Slot: return "PRO_DiffPIDOutput_Slot";
        case PRO_DiffPIDRefSlopeECUTime_ReferenceSlope_Position: return "PRO_DiffPIDRefSlopeECUTime_ReferenceSlope_Position";
        case PRO_DiffPIDRefSlopeECUTime_ReferenceSlope_Velocity: return "PRO_DiffPIDRefSlopeECUTime_ReferenceSlope_Velocity";
        case PRO_DiffPIDRefSlopeECUTime_ClosedLoopMode: return "PRO_DiffPIDRefSlopeECUTime_ClosedLoopMode";
        case TalonFX_MotorConstants_kT: return "TalonFX_MotorConstants_kT";
        case TalonFX_MotorConstants_kV: return "TalonFX_MotorConstants_kV";
        case TalonFX_MotorConstants_StallCurrent: return "TalonFX_MotorConstants_StallCurrent";
        case Slot0_kP: return "Slot0_kP";
        case Slot0_kI: return "Slot0_kI";
        case Slot0_kD: return "Slot0_kD";
        case Slot0_kS: return "Slot0_kS";
        case Slot0_kV: return "Slot0_kV";
        case Slot0_kA: return "Slot0_kA";
        case Slot0_kG: return "Slot0_kG";
        case Slot0_kG_Type: return "Slot0_kG_Type";
        case Slot1_kP: return "Slot1_kP";
        case Slot1_kI: return "Slot1_kI";
        case Slot1_kD: return "Slot1_kD";
        case Slot1_kS: return "Slot1_kS";
        case Slot1_kV: return "Slot1_kV";
        case Slot1_kA: return "Slot1_kA";
        case Slot1_kG: return "Slot1_kG";
        case Slot1_kG_Type: return "Slot1_kG_Type";
        case Slot2_kP: return "Slot2_kP";
        case Slot2_kI: return "Slot2_kI";
        case Slot2_kD: return "Slot2_kD";
        case Slot2_kS: return "Slot2_kS";
        case Slot2_kV: return "Slot2_kV";
        case Slot2_kA: return "Slot2_kA";
        case Slot2_kG: return "Slot2_kG";
        case Slot2_kG_Type: return "Slot2_kG_Type";
        case Config_Inverted: return "Config_Inverted";
        case Config_SupplyVLowpassTau: return "Config_SupplyVLowpassTau";
        case Config_BeepOnBoot: return "Config_BeepOnBoot";
        case Config_NeutralMode: return "Config_NeutralMode";
        case Config_DutyCycleNeutralDB: return "Config_DutyCycleNeutralDB";
        case Config_StatorCurrentLimit: return "Config_StatorCurrentLimit";
        case Config_StatorCurrLimitEn: return "Config_StatorCurrLimitEn";
        case Config_SupplyCurrentLimit: return "Config_SupplyCurrentLimit";
        case Config_SupplyCurrLimitEn: return "Config_SupplyCurrLimitEn";
        case Config_PeakForwardDC: return "Config_PeakForwardDC";
        case Config_PeakReverseDC: return "Config_PeakReverseDC";
        case Config_PeakForwardV: return "Config_PeakForwardV";
        case Config_PeakReverseV: return "Config_PeakReverseV";
        case Config_PeakForTorqCurr: return "Config_PeakForTorqCurr";
        case Config_PeakRevTorqCurr: return "Config_PeakRevTorqCurr";
        case Config_TorqueNeutralDB: return "Config_TorqueNeutralDB";
        case Config_FeedbackRotorOffset: return "Config_FeedbackRotorOffset";
        case Config_SensorToMechanismRatio: return "Config_SensorToMechanismRatio";
        case Config_RotorToSensorRatio: return "Config_RotorToSensorRatio";
        case Config_FeedbackSensorSource: return "Config_FeedbackSensorSource";
        case Config_FeedbackRemoteSensorID: return "Config_FeedbackRemoteSensorID";
        case Config_DutyCycleOpenLoopRampPeriod: return "Config_DutyCycleOpenLoopRampPeriod";
        case Config_VoltageOpenLoopRampPeriod: return "Config_VoltageOpenLoopRampPeriod";
        case Config_TorqueOpenLoopRampPeriod: return "Config_TorqueOpenLoopRampPeriod";
        case Config_DutyCycleClosedLoopRampPeriod: return "Config_DutyCycleClosedLoopRampPeriod";
        case Config_VoltageClosedLoopRampPeriod: return "Config_VoltageClosedLoopRampPeriod";
        case Config_TorqueClosedLoopRampPeriod: return "Config_TorqueClosedLoopRampPeriod";
        case Config_ForwardLimitType: return "Config_ForwardLimitType";
        case Config_ForwardLimitAutosetPosEnable: return "Config_ForwardLimitAutosetPosEnable";
        case Config_ForwardLimitAutosetPosValue: return "Config_ForwardLimitAutosetPosValue";
        case Config_ForwardLimitEnable: return "Config_ForwardLimitEnable";
        case Config_ForwardLimitSource: return "Config_ForwardLimitSource";
        case Config_ForwardLimitRemoteSensorID: return "Config_ForwardLimitRemoteSensorID";
        case Config_ReverseLimitType: return "Config_ReverseLimitType";
        case Config_ReverseLimitAutosetPosEnable: return "Config_ReverseLimitAutosetPosEnable";
        case Config_ReverseLimitAutosetPosValue: return "Config_ReverseLimitAutosetPosValue";
        case Config_ReverseLimitEnable: return "Config_ReverseLimitEnable";
        case Config_ReverseLimitSource: return "Config_ReverseLimitSource";
        case Config_ReverseLimitRemoteSensorID: return "Config_ReverseLimitRemoteSensorID";
        case Config_ForwardSoftLimitEnable: return "Config_ForwardSoftLimitEnable";
        case Config_ReverseSoftLimitEnable: return "Config_ReverseSoftLimitEnable";
        case Config_ForwardSoftLimitThreshold: return "Config_ForwardSoftLimitThreshold";
        case Config_ReverseSoftLimitThreshold: return "Config_ReverseSoftLimitThreshold";
        case Config_MotionMagicCruiseVelocity: return "Config_MotionMagicCruiseVelocity";
        case Config_MotionMagicAcceleration: return "Config_MotionMagicAcceleration";
        case Config_MotionMagicJerk: return "Config_MotionMagicJerk";
        case Config_MotionMagicExpo_kV: return "Config_MotionMagicExpo_kV";
        case Config_MotionMagicExpo_kA: return "Config_MotionMagicExpo_kA";
        case Config_PeakDiffDC: return "Config_PeakDiffDC";
        case Config_PeakDiffV: return "Config_PeakDiffV";
        case Config_PeakDiffTorqCurr: return "Config_PeakDiffTorqCurr";
        case CANcoder_Velocity: return "CANcoder_Velocity";
        case CANcoder_Position: return "CANcoder_Position";
        case CANcoder_AbsPosition: return "CANcoder_AbsPosition";
        case CANCoder_RawVel: return "CANCoder_RawVel";
        case CANCoder_RawPos: return "CANCoder_RawPos";
        case CANCoder_SupplyVoltage: return "CANCoder_SupplyVoltage";
        case CANcoder_MagHealth: return "CANcoder_MagHealth";
        case SPN_ClearStickyFaults: return "SPN_ClearStickyFaults";
        case PRO_MotorOutput_BridgeType_Public: return "PRO_MotorOutput_BridgeType_Public";
        case Config_ContinuousWrap: return "Config_ContinuousWrap";
        case Config_DifferentialContinuousWrap: return "Config_DifferentialContinuousWrap";
        case Config_SupplyCurrentLowerLimit: return "Config_SupplyCurrentLowerLimit";
        case Config_SupplyCurrentLowerTime: return "Config_SupplyCurrentLowerTime";
        case Config_DifferentialSensorSource: return "Config_DifferentialSensorSource";
        case Config_DifferentialTalonFXSensorID: return "Config_DifferentialTalonFXSensorID";
        case Config_DifferentialRemoteSensorID: return "Config_DifferentialRemoteSensorID";
        case Config_SensorToDifferentialRatio: return "Config_SensorToDifferentialRatio";
        case Config_BeepOnConfig: return "Config_BeepOnConfig";
        case Config_AllowMusicDurDisable: return "Config_AllowMusicDurDisable";
        case Compliancy_Version: return "Compliancy_Version";
        case Version_IsProLicensed: return "Version_IsProLicensed";
        case PRO_SupplyAndTemp_DeviceTemp2: return "PRO_SupplyAndTemp_DeviceTemp2";
        case Slot0_kS_Sign: return "Slot0_kS_Sign";
        case Slot1_kS_Sign: return "Slot1_kS_Sign";
        case Slot2_kS_Sign: return "Slot2_kS_Sign";
        case TalonFX_ConnectedMotor: return "TalonFX_ConnectedMotor";
        case CANrange_SupplyVoltage: return "CANrange_SupplyVoltage";
        case CANrange_Distance_Meters: return "CANrange_Distance_Meters";
        case CANrange_MeasTime: return "CANrange_MeasTime";
        case CANrange_SignalStrength: return "CANrange_SignalStrength";
        case CANrange_ProximityDetected: return "CANrange_ProximityDetected";
        case CANrange_MeasState: return "CANrange_MeasState";
        case CANrange_AmbientSignal: return "CANrange_AmbientSignal";
        case CANrange_DistanceStdDev: return "CANrange_DistanceStdDev";
        case CANrange_RealFOVCenterX: return "CANrange_RealFOVCenterX";
        case CANrange_RealFOVCenterY: return "CANrange_RealFOVCenterY";
        case CANrange_RealFOVRangeX: return "CANrange_RealFOVRangeX";
        case CANrange_RealFOVRangeY: return "CANrange_RealFOVRangeY";
        case CANrange_UpdateMode: return "CANrange_UpdateMode";
        case CANrange_UpdateFreq: return "CANrange_UpdateFreq";
        case CANrange_ProximityThreshold: return "CANrange_ProximityThreshold";
        case CANrange_ProximityHysteresis: return "CANrange_ProximityHysteresis";
        case CANrange_MinSigStrengthForValidMeas: return "CANrange_MinSigStrengthForValidMeas";
        case CANrange_FOVCenterX: return "CANrange_FOVCenterX";
        case CANrange_FOVCenterY: return "CANrange_FOVCenterY";
        case CANrange_FOVRangeX: return "CANrange_FOVRangeX";
        case CANrange_FOVRangeY: return "CANrange_FOVRangeY";
        case Config_ControlTimesyncFreq: return "Config_ControlTimesyncFreq";
        case Config_VelocityFilterTimeConstant: return "Config_VelocityFilterTimeConstant";
        case Config_AdvancedHallSupport: return "Config_AdvancedHallSupport";
        case Config_MotorType: return "Config_MotorType";
        case CANdi_Pin1State: return "CANdi_Pin1State";
        case CANdi_Pin2State: return "CANdi_Pin2State";
        case CANdi_QuadPosition: return "CANdi_QuadPosition";
        case CANdi_Pwm1_RiseToRise: return "CANdi_Pwm1_RiseToRise";
        case CANdi_Pwm1_Position: return "CANdi_Pwm1_Position";
        case CANdi_Pwm1_Velocity: return "CANdi_Pwm1_Velocity";
        case CANdi_Pwm2_RiseToRise: return "CANdi_Pwm2_RiseToRise";
        case CANdi_Pwm2_Position: return "CANdi_Pwm2_Position";
        case CANdi_Overcurrent: return "CANdi_Overcurrent";
        case CANdi_VSense: return "CANdi_VSense";
        case CANdi_OutputCurrent: return "CANdi_OutputCurrent";
        case CANdi_S1FloatState: return "CANdi_S1FloatState";
        case CANdi_S2FloatState: return "CANdi_S2FloatState";
        case Config_AbsoluteSensorOffset: return "Config_AbsoluteSensorOffset";
        case Config_ExternalFeedbackSensorSource: return "Config_ExternalFeedbackSensorSource";
        case Config_SensorPhase: return "Config_SensorPhase";
        case Config_QuadratureEdgesPerRotation: return "Config_QuadratureEdgesPerRotation";
        case Config_AbsoluteSensorDiscontinuityPoint: return "Config_AbsoluteSensorDiscontinuityPoint";
        case CANdi_Pwm2_Velocity: return "CANdi_Pwm2_Velocity";
        case TalonFXS_5VRailVoltage: return "TalonFXS_5VRailVoltage";
        case TalonFXS_Gadgeteer_G3: return "TalonFXS_Gadgeteer_G3";
        case CANdi_QuadVelocity: return "CANdi_QuadVelocity";
        case Config_PWM1_AbsoluteSensorOffset: return "Config_PWM1_AbsoluteSensorOffset";
        case Config_PWM1_AbsoluteSensorDiscontinuityPoint: return "Config_PWM1_AbsoluteSensorDiscontinuityPoint";
        case Config_PWM1_SensorDirection: return "Config_PWM1_SensorDirection";
        case Config_PWM2_AbsoluteSensorOffset: return "Config_PWM2_AbsoluteSensorOffset";
        case Config_PWM2_AbsoluteSensorDiscontinuityPoint: return "Config_PWM2_AbsoluteSensorDiscontinuityPoint";
        case Config_PWM2_SensorDirection: return "Config_PWM2_SensorDirection";
        case Config_Quad_SensorDirection: return "Config_Quad_SensorDirection";
        case CANdi_SetQuadPosition: return "CANdi_SetQuadPosition";
        case Config_S1_CloseState: return "Config_S1_CloseState";
        case Config_S2_CloseState: return "Config_S2_CloseState";
        case CANdi_S1Closed: return "CANdi_S1Closed";
        case CANdi_S2Closed: return "CANdi_S2Closed";
        case Config_BrushedMotorWiring: return "Config_BrushedMotorWiring";
        case PRO_GadgeteerQuad_RawQuadraturePosition: return "PRO_GadgeteerQuad_RawQuadraturePosition";
        case PRO_GadgeteerQuad_RawQuadratureVelocity: return "PRO_GadgeteerQuad_RawQuadratureVelocity";
        case PRO_GadgeteerPwm_RawPwmPosition: return "PRO_GadgeteerPwm_RawPwmPosition";
        case PRO_GadgeteerPwm_RawPwmVelocity: return "PRO_GadgeteerPwm_RawPwmVelocity";
        case CANdle_General_SupplyVoltage: return "CANdle_General_SupplyVoltage";
        case CANdle_General_FiveVRailVoltage: return "CANdle_General_FiveVRailVoltage";
        case CANdle_General_OutputCurrent: return "CANdle_General_OutputCurrent";
        case CANdle_General_DeviceTemp: return "CANdle_General_DeviceTemp";
        case CANdle_General_VBatModulation: return "CANdle_General_VBatModulation";
        case CANdle_General_MaxSimulAnimCount: return "CANdle_General_MaxSimulAnimCount";
        case Config_LED_StripType: return "Config_LED_StripType";
        case Config_LED_BrightnessScalar: return "Config_LED_BrightnessScalar";
        case Config_LED_LossOfSignalBehavior: return "Config_LED_LossOfSignalBehavior";
        case Config_CANdle_5VRail: return "Config_CANdle_5VRail";
        case Config_CANdle_VBatOutputMode: return "Config_CANdle_VBatOutputMode";
        case Config_CANdle_StatusLedWhenActive: return "Config_CANdle_StatusLedWhenActive";
        case CANdle_Animation0_Type: return "CANdle_Animation0_Type";
        case CANdle_Animation1_Type: return "CANdle_Animation1_Type";
        case CANdle_Animation2_Type: return "CANdle_Animation2_Type";
        case CANdle_Animation3_Type: return "CANdle_Animation3_Type";
        case CANdle_Animation4_Type: return "CANdle_Animation4_Type";
        case CANdle_Animation5_Type: return "CANdle_Animation5_Type";
        case CANdle_Animation6_Type: return "CANdle_Animation6_Type";
        case CANdle_Animation7_Type: return "CANdle_Animation7_Type";
        case CANdle_AnimationDirection: return "CANdle_AnimationDirection";
        case CANdle_LarsonBounceMode: return "CANdle_LarsonBounceMode";
        case Slot0_kG_PosOffset: return "Slot0_kG_PosOffset";
        case Slot1_kG_PosOffset: return "Slot1_kG_PosOffset";
        case Slot2_kG_PosOffset: return "Slot2_kG_PosOffset";
        case Config_CustomMot_Kv: return "Config_CustomMot_Kv";
        case Config_CustomMot_NumPolePairs: return "Config_CustomMot_NumPolePairs";
        case Config_CustomMot_Thermistor_MaxTemp: return "Config_CustomMot_Thermistor_MaxTemp";
        case Config_CustomMot_Thermistor_Beta: return "Config_CustomMot_Thermistor_Beta";
        case Config_CustomMot_Thermistor_R0: return "Config_CustomMot_Thermistor_R0";
        case Config_CustomMot_Hall_AB: return "Config_CustomMot_Hall_AB";
        case Config_CustomMot_Hall_AC: return "Config_CustomMot_Hall_AC";
        case Config_CustomMot_Hall_CCW_Select: return "Config_CustomMot_Hall_CCW_Select";
        case Config_CustomMot_Hall_Direction: return "Config_CustomMot_Hall_Direction";
        case Config_TempSensorSelection: return "Config_TempSensorSelection";
        case Config_GainSchedErrorThreshold: return "Config_GainSchedErrorThreshold";
        case Config_GainSchedKpBehavior: return "Config_GainSchedKpBehavior";
        case Slot0_GainSchedBehavior: return "Slot0_GainSchedBehavior";
        case Slot1_GainSchedBehavior: return "Slot1_GainSchedBehavior";
        case Slot2_GainSchedBehavior: return "Slot2_GainSchedBehavior";
        case MotorAlignment: return "MotorAlignment";
        case Fault_Hardware: return "Fault_Hardware";
        case StickyFault_Hardware: return "StickyFault_Hardware";
        case ClearStickyFault_Hardware: return "ClearStickyFault_Hardware";
        case Fault_ProcTemp: return "Fault_ProcTemp";
        case StickyFault_ProcTemp: return "StickyFault_ProcTemp";
        case ClearStickyFault_ProcTemp: return "ClearStickyFault_ProcTemp";
        case Fault_DeviceTemp: return "Fault_DeviceTemp";
        case StickyFault_DeviceTemp: return "StickyFault_DeviceTemp";
        case ClearStickyFault_DeviceTemp: return "ClearStickyFault_DeviceTemp";
        case Fault_Undervoltage: return "Fault_Undervoltage";
        case StickyFault_Undervoltage: return "StickyFault_Undervoltage";
        case ClearStickyFault_Undervoltage: return "ClearStickyFault_Undervoltage";
        case Fault_BootDuringEnable: return "Fault_BootDuringEnable";
        case StickyFault_BootDuringEnable: return "StickyFault_BootDuringEnable";
        case ClearStickyFault_BootDuringEnable: return "ClearStickyFault_BootDuringEnable";
        case Fault_UnlicensedFeatureInUse: return "Fault_UnlicensedFeatureInUse";
        case StickyFault_UnlicensedFeatureInUse: return "StickyFault_UnlicensedFeatureInUse";
        case ClearStickyFault_UnlicensedFeatureInUse: return "ClearStickyFault_UnlicensedFeatureInUse";
        case Fault_PIGEON2_BootupAccel: return "Fault_PIGEON2_BootupAccel";
        case StickyFault_PIGEON2_BootupAccel: return "StickyFault_PIGEON2_BootupAccel";
        case ClearStickyFault_PIGEON2_BootupAccel: return "ClearStickyFault_PIGEON2_BootupAccel";
        case Fault_PIGEON2_BootupGyros: return "Fault_PIGEON2_BootupGyros";
        case StickyFault_PIGEON2_BootupGyros: return "StickyFault_PIGEON2_BootupGyros";
        case ClearStickyFault_PIGEON2_BootupGyros: return "ClearStickyFault_PIGEON2_BootupGyros";
        case Fault_PIGEON2_BootupMagne: return "Fault_PIGEON2_BootupMagne";
        case StickyFault_PIGEON2_BootupMagne: return "StickyFault_PIGEON2_BootupMagne";
        case ClearStickyFault_PIGEON2_BootupMagne: return "ClearStickyFault_PIGEON2_BootupMagne";
        case Fault_PIGEON2_BootIntoMotion: return "Fault_PIGEON2_BootIntoMotion";
        case StickyFault_PIGEON2_BootIntoMotion: return "StickyFault_PIGEON2_BootIntoMotion";
        case ClearStickyFault_PIGEON2_BootIntoMotion: return "ClearStickyFault_PIGEON2_BootIntoMotion";
        case Fault_PIGEON2_DataAcquiredLate: return "Fault_PIGEON2_DataAcquiredLate";
        case StickyFault_PIGEON2_DataAcquiredLate: return "StickyFault_PIGEON2_DataAcquiredLate";
        case ClearStickyFault_PIGEON2_DataAcquiredLate: return "ClearStickyFault_PIGEON2_DataAcquiredLate";
        case Fault_PIGEON2_LoopTimeSlow: return "Fault_PIGEON2_LoopTimeSlow";
        case StickyFault_PIGEON2_LoopTimeSlow: return "StickyFault_PIGEON2_LoopTimeSlow";
        case ClearStickyFault_PIGEON2_LoopTimeSlow: return "ClearStickyFault_PIGEON2_LoopTimeSlow";
        case Fault_PIGEON2_SaturatedMagne: return "Fault_PIGEON2_SaturatedMagne";
        case StickyFault_PIGEON2_SaturatedMagne: return "StickyFault_PIGEON2_SaturatedMagne";
        case ClearStickyFault_PIGEON2_SaturatedMagne: return "ClearStickyFault_PIGEON2_SaturatedMagne";
        case Fault_PIGEON2_SaturatedAccel: return "Fault_PIGEON2_SaturatedAccel";
        case StickyFault_PIGEON2_SaturatedAccel: return "StickyFault_PIGEON2_SaturatedAccel";
        case ClearStickyFault_PIGEON2_SaturatedAccel: return "ClearStickyFault_PIGEON2_SaturatedAccel";
        case Fault_PIGEON2_SaturatedGyros: return "Fault_PIGEON2_SaturatedGyros";
        case StickyFault_PIGEON2_SaturatedGyros: return "StickyFault_PIGEON2_SaturatedGyros";
        case ClearStickyFault_PIGEON2_SaturatedGyros: return "ClearStickyFault_PIGEON2_SaturatedGyros";
        case Fault_CANCODER_BadMagnet: return "Fault_CANCODER_BadMagnet";
        case StickyFault_CANCODER_BadMagnet: return "StickyFault_CANCODER_BadMagnet";
        case ClearStickyFault_CANCODER_BadMagnet: return "ClearStickyFault_CANCODER_BadMagnet";
        case Fault_TALONFX_BridgeBrownout: return "Fault_TALONFX_BridgeBrownout";
        case StickyFault_TALONFX_BridgeBrownout: return "StickyFault_TALONFX_BridgeBrownout";
        case ClearStickyFault_TALONFX_BridgeBrownout: return "ClearStickyFault_TALONFX_BridgeBrownout";
        case Fault_TALONFX_RemoteSensorReset: return "Fault_TALONFX_RemoteSensorReset";
        case StickyFault_TALONFX_RemoteSensorReset: return "StickyFault_TALONFX_RemoteSensorReset";
        case ClearStickyFault_TALONFX_RemoteSensorReset: return "ClearStickyFault_TALONFX_RemoteSensorReset";
        case Fault_TALONFX_MissingDifferentialFX: return "Fault_TALONFX_MissingDifferentialFX";
        case StickyFault_TALONFX_MissingDifferentialFX: return "StickyFault_TALONFX_MissingDifferentialFX";
        case ClearStickyFault_TALONFX_MissingDifferentialFX: return "ClearStickyFault_TALONFX_MissingDifferentialFX";
        case Fault_TALONFX_RemoteSensorPosOverflow: return "Fault_TALONFX_RemoteSensorPosOverflow";
        case StickyFault_TALONFX_RemoteSensorPosOverflow: return "StickyFault_TALONFX_RemoteSensorPosOverflow";
        case ClearStickyFault_TALONFX_RemoteSensorPosOverflow: return "ClearStickyFault_TALONFX_RemoteSensorPosOverflow";
        case Fault_TALONFX_OverSupplyV: return "Fault_TALONFX_OverSupplyV";
        case StickyFault_TALONFX_OverSupplyV: return "StickyFault_TALONFX_OverSupplyV";
        case ClearStickyFault_TALONFX_OverSupplyV: return "ClearStickyFault_TALONFX_OverSupplyV";
        case Fault_TALONFX_UnstableSupplyV: return "Fault_TALONFX_UnstableSupplyV";
        case StickyFault_TALONFX_UnstableSupplyV: return "StickyFault_TALONFX_UnstableSupplyV";
        case ClearStickyFault_TALONFX_UnstableSupplyV: return "ClearStickyFault_TALONFX_UnstableSupplyV";
        case Fault_TALONFX_ReverseHardLimit: return "Fault_TALONFX_ReverseHardLimit";
        case StickyFault_TALONFX_ReverseHardLimit: return "StickyFault_TALONFX_ReverseHardLimit";
        case ClearStickyFault_TALONFX_ReverseHardLimit: return "ClearStickyFault_TALONFX_ReverseHardLimit";
        case Fault_TALONFX_ForwardHardLimit: return "Fault_TALONFX_ForwardHardLimit";
        case StickyFault_TALONFX_ForwardHardLimit: return "StickyFault_TALONFX_ForwardHardLimit";
        case ClearStickyFault_TALONFX_ForwardHardLimit: return "ClearStickyFault_TALONFX_ForwardHardLimit";
        case Fault_TALONFX_ReverseSoftLimit: return "Fault_TALONFX_ReverseSoftLimit";
        case StickyFault_TALONFX_ReverseSoftLimit: return "StickyFault_TALONFX_ReverseSoftLimit";
        case ClearStickyFault_TALONFX_ReverseSoftLimit: return "ClearStickyFault_TALONFX_ReverseSoftLimit";
        case Fault_TALONFX_ForwardSoftLimit: return "Fault_TALONFX_ForwardSoftLimit";
        case StickyFault_TALONFX_ForwardSoftLimit: return "StickyFault_TALONFX_ForwardSoftLimit";
        case ClearStickyFault_TALONFX_ForwardSoftLimit: return "ClearStickyFault_TALONFX_ForwardSoftLimit";
        case Fault_TALONFX_MissingRemSoftLim: return "Fault_TALONFX_MissingRemSoftLim";
        case StickyFault_TALONFX_MissingRemSoftLim: return "StickyFault_TALONFX_MissingRemSoftLim";
        case ClearStickyFault_TALONFX_MissingRemSoftLim: return "ClearStickyFault_TALONFX_MissingRemSoftLim";
        case Fault_TALONFX_MissingRemHardLim: return "Fault_TALONFX_MissingRemHardLim";
        case StickyFault_TALONFX_MissingRemHardLim: return "StickyFault_TALONFX_MissingRemHardLim";
        case ClearStickyFault_TALONFX_MissingRemHardLim: return "ClearStickyFault_TALONFX_MissingRemHardLim";
        case Fault_TALONFX_MissingRemoteSensor: return "Fault_TALONFX_MissingRemoteSensor";
        case StickyFault_TALONFX_MissingRemoteSensor: return "StickyFault_TALONFX_MissingRemoteSensor";
        case ClearStickyFault_TALONFX_MissingRemoteSensor: return "ClearStickyFault_TALONFX_MissingRemoteSensor";
        case Fault_TALONFX_FusedSensorOutOfSync: return "Fault_TALONFX_FusedSensorOutOfSync";
        case StickyFault_TALONFX_FusedSensorOutOfSync: return "StickyFault_TALONFX_FusedSensorOutOfSync";
        case ClearStickyFault_TALONFX_FusedSensorOutOfSync: return "ClearStickyFault_TALONFX_FusedSensorOutOfSync";
        case Fault_TALONFX_StatorCurrLimit: return "Fault_TALONFX_StatorCurrLimit";
        case StickyFault_TALONFX_StatorCurrLimit: return "StickyFault_TALONFX_StatorCurrLimit";
        case ClearStickyFault_TALONFX_StatorCurrLimit: return "ClearStickyFault_TALONFX_StatorCurrLimit";
        case Fault_TALONFX_SupplyCurrLimit: return "Fault_TALONFX_SupplyCurrLimit";
        case StickyFault_TALONFX_SupplyCurrLimit: return "StickyFault_TALONFX_SupplyCurrLimit";
        case ClearStickyFault_TALONFX_SupplyCurrLimit: return "ClearStickyFault_TALONFX_SupplyCurrLimit";
        case Fault_TALONFX_UsingFusedCCWhileUnlicensed: return "Fault_TALONFX_UsingFusedCCWhileUnlicensed";
        case StickyFault_TALONFX_UsingFusedCCWhileUnlicensed: return "StickyFault_TALONFX_UsingFusedCCWhileUnlicensed";
        case ClearStickyFault_TALONFX_UsingFusedCCWhileUnlicensed: return "ClearStickyFault_TALONFX_UsingFusedCCWhileUnlicensed";
        case Fault_TALONFX_StaticBrakeDisabled: return "Fault_TALONFX_StaticBrakeDisabled";
        case StickyFault_TALONFX_StaticBrakeDisabled: return "StickyFault_TALONFX_StaticBrakeDisabled";
        case ClearStickyFault_TALONFX_StaticBrakeDisabled: return "ClearStickyFault_TALONFX_StaticBrakeDisabled";
        case Fault_TALONFX_BridgeShort: return "Fault_TALONFX_BridgeShort";
        case StickyFault_TALONFX_BridgeShort: return "StickyFault_TALONFX_BridgeShort";
        case ClearStickyFault_TALONFX_BridgeShort: return "ClearStickyFault_TALONFX_BridgeShort";
        case Fault_TALONFX_HallSensorMissing: return "Fault_TALONFX_HallSensorMissing";
        case StickyFault_TALONFX_HallSensorMissing: return "StickyFault_TALONFX_HallSensorMissing";
        case ClearStickyFault_TALONFX_HallSensorMissing: return "ClearStickyFault_TALONFX_HallSensorMissing";
        case Fault_TALONFX_DriveDisabledHallSensor: return "Fault_TALONFX_DriveDisabledHallSensor";
        case StickyFault_TALONFX_DriveDisabledHallSensor: return "StickyFault_TALONFX_DriveDisabledHallSensor";
        case ClearStickyFault_TALONFX_DriveDisabledHallSensor: return "ClearStickyFault_TALONFX_DriveDisabledHallSensor";
        case Fault_TALONFX_MotorTempSensorMissing: return "Fault_TALONFX_MotorTempSensorMissing";
        case StickyFault_TALONFX_MotorTempSensorMissing: return "StickyFault_TALONFX_MotorTempSensorMissing";
        case ClearStickyFault_TALONFX_MotorTempSensorMissing: return "ClearStickyFault_TALONFX_MotorTempSensorMissing";
        case Fault_TALONFX_MotorTempSensorTooHot: return "Fault_TALONFX_MotorTempSensorTooHot";
        case StickyFault_TALONFX_MotorTempSensorTooHot: return "StickyFault_TALONFX_MotorTempSensorTooHot";
        case ClearStickyFault_TALONFX_MotorTempSensorTooHot: return "ClearStickyFault_TALONFX_MotorTempSensorTooHot";
        case Fault_TALONFX_MotorArrangementNotSelected: return "Fault_TALONFX_MotorArrangementNotSelected";
        case StickyFault_TALONFX_MotorArrangementNotSelected: return "StickyFault_TALONFX_MotorArrangementNotSelected";
        case ClearStickyFault_TALONFX_MotorArrangementNotSelected: return "ClearStickyFault_TALONFX_MotorArrangementNotSelected";
        case Fault_TALONFX_5V: return "Fault_TALONFX_5V";
        case StickyFault_TALONFX_5V: return "StickyFault_TALONFX_5V";
        case Fault_CANDI_5V: return "Fault_CANDI_5V";
        case StickyFault_CANDI_5V: return "StickyFault_CANDI_5V";
        case ClearStickyFault_CANDI_5V: return "ClearStickyFault_CANDI_5V";
        case Fault_CANDLE_OVERVOLTAGE: return "Fault_CANDLE_OVERVOLTAGE";
        case StickyFault_CANDLE_OVERVOLTAGE: return "StickyFault_CANDLE_OVERVOLTAGE";
        case ClearStickyFault_CANDLE_OVERVOLTAGE: return "ClearStickyFault_CANDLE_OVERVOLTAGE";
        case Fault_CANDLE_5V_TOO_HIGH: return "Fault_CANDLE_5V_TOO_HIGH";
        case StickyFault_CANDLE_5V_TOO_HIGH: return "StickyFault_CANDLE_5V_TOO_HIGH";
        case ClearStickyFault_CANDLE_5V_TOO_HIGH: return "ClearStickyFault_CANDLE_5V_TOO_HIGH";
        case Fault_CANDLE_5V_TOO_LOW: return "Fault_CANDLE_5V_TOO_LOW";
        case StickyFault_CANDLE_5V_TOO_LOW: return "StickyFault_CANDLE_5V_TOO_LOW";
        case ClearStickyFault_CANDLE_5V_TOO_LOW: return "ClearStickyFault_CANDLE_5V_TOO_LOW";
        case Fault_CANDLE_THERMAL: return "Fault_CANDLE_THERMAL";
        case StickyFault_CANDLE_THERMAL: return "StickyFault_CANDLE_THERMAL";
        case ClearStickyFault_CANDLE_THERMAL: return "ClearStickyFault_CANDLE_THERMAL";
        case Fault_CANDLE_SOFTWARE_FUSE: return "Fault_CANDLE_SOFTWARE_FUSE";
        case StickyFault_CANDLE_SOFTWARE_FUSE: return "StickyFault_CANDLE_SOFTWARE_FUSE";
        case ClearStickyFault_CANDLE_SOFTWARE_FUSE: return "ClearStickyFault_CANDLE_SOFTWARE_FUSE";
        case Fault_CANDLE_SHORT_CIRCUIT: return "Fault_CANDLE_SHORT_CIRCUIT";
        case StickyFault_CANDLE_SHORT_CIRCUIT: return "StickyFault_CANDLE_SHORT_CIRCUIT";
        case ClearStickyFault_CANDLE_SHORT_CIRCUIT: return "ClearStickyFault_CANDLE_SHORT_CIRCUIT";
            default:
                return "Invalid Value";
        }
    }
}
