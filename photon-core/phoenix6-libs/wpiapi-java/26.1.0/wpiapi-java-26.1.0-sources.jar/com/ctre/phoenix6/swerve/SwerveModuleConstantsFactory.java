/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.swerve;

import com.ctre.phoenix6.configs.ClosedLoopGeneralConfigs;
import com.ctre.phoenix6.configs.CurrentLimitsConfigs;
import com.ctre.phoenix6.configs.FeedbackConfigs;
import com.ctre.phoenix6.configs.MagnetSensorConfigs;
import com.ctre.phoenix6.configs.MotionMagicConfigs;
import com.ctre.phoenix6.configs.MotorOutputConfigs;
import com.ctre.phoenix6.configs.ParentConfiguration;
import com.ctre.phoenix6.configs.Slot0Configs;
import com.ctre.phoenix6.configs.TorqueCurrentConfigs;
import com.ctre.phoenix6.swerve.SwerveModuleConstants.ClosedLoopOutputType;
import com.ctre.phoenix6.swerve.SwerveModuleConstants.DriveMotorArrangement;
import com.ctre.phoenix6.swerve.SwerveModuleConstants.SteerFeedbackType;
import com.ctre.phoenix6.swerve.SwerveModuleConstants.SteerMotorArrangement;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Constants that are common across the swerve modules, used
 * for creating instances of module-specific {@link SwerveModuleConstants}.
 */
public class SwerveModuleConstantsFactory<
    DriveMotorConfigsT extends ParentConfiguration,
    SteerMotorConfigsT extends ParentConfiguration,
    EncoderConfigsT extends ParentConfiguration
> {
    /**
     * Gear ratio between the drive motor and the wheel.
     */
    public double DriveMotorGearRatio = 0;
    /**
     * Gear ratio between the steer motor and the azimuth encoder. For example, the
     * SDS Mk4 has a steering ratio of 12.8.
     */
    public double SteerMotorGearRatio = 0;
    /**
     * Coupled gear ratio between the azimuth encoder and the drive motor.
     * <p>
     * For a typical swerve module, the azimuth turn motor also drives the wheel a
     * nontrivial amount, which affects the accuracy of odometry and control. This
     * ratio represents the number of rotations of the drive motor caused by a
     * rotation of the azimuth.
     */
    public double CouplingGearRatio = 0;
    /**
     * Radius of the driving wheel in meters.
     */
    public double WheelRadius = 0;
    /**
     * The steer motor closed-loop gains.
     * <p>
     * The steer motor uses the control ouput type specified by {@link
     * #SteerMotorClosedLoopOutput} and any {@link SwerveModule.SteerRequestType}.
     * These gains operate on azimuth rotations (after the gear ratio).
     */
    public Slot0Configs SteerMotorGains = new Slot0Configs();
    /**
     * The drive motor closed-loop gains.
     * <p>
     * When using closed-loop control, the drive motor uses the control output type
     * specified by {@link #DriveMotorClosedLoopOutput} and any closed-loop {@link
     * SwerveModule.DriveRequestType}. These gains operate on motor rotor rotations
     * (before the gear ratio).
     */
    public Slot0Configs DriveMotorGains = new Slot0Configs();
    /**
     * The closed-loop output type to use for the steer motors.
     */
    public ClosedLoopOutputType SteerMotorClosedLoopOutput = ClosedLoopOutputType.Voltage;
    /**
     * The closed-loop output type to use for the drive motors.
     */
    public ClosedLoopOutputType DriveMotorClosedLoopOutput = ClosedLoopOutputType.Voltage;
    /**
     * The maximum amount of stator current the drive motors can apply without
     * slippage.
     */
    public double SlipCurrent = 120;
    /**
     * When using open-loop drive control, this specifies the speed at which the
     * robot travels when driven with 12 volts. This is used to approximate the
     * output for a desired velocity. If using closed loop control, this value is
     * ignored.
     */
    public double SpeedAt12Volts = 0;
    /**
     * Choose the motor used for the drive motor.
     * <p>
     * If using a Talon FX, this should be set to TalonFX_Integrated. If using a
     * Talon FXS, this should be set to the motor attached to the Talon FXS.
     */
    public DriveMotorArrangement DriveMotorType = DriveMotorArrangement.TalonFX_Integrated;
    /**
     * Choose the motor used for the steer motor.
     * <p>
     * If using a Talon FX, this should be set to TalonFX_Integrated. If using a
     * Talon FXS, this should be set to the motor attached to the Talon FXS.
     */
    public SteerMotorArrangement SteerMotorType = SteerMotorArrangement.TalonFX_Integrated;
    /**
     * Choose how the feedback sensors should be configured.
     * <p>
     * If the robot does not support Pro, then this should be set to RemoteCANcoder.
     * Otherwise, users have the option to use either FusedCANcoder or SyncCANcoder
     * depending on if there is a risk that the CANcoder can fail in a way to
     * provide "good" data.
     * <p>
     * If this is set to FusedCANcoder or SyncCANcoder when the steer motor is not
     * Pro-licensed, the device will automatically fall back to RemoteCANcoder and
     * report a UsingProFeatureOnUnlicensedDevice status code.
     */
    public SteerFeedbackType FeedbackSource = SteerFeedbackType.FusedCANcoder;
    /**
     * The initial configs used to configure the drive motor of the swerve module.
     * The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * The list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MotorOutputConfigs#NeutralMode} (Brake mode, overwritten with
     *        {@link SwerveDrivetrain#configNeutralMode})
     *   <li> {@link MotorOutputConfigs#Inverted} ({@link
     *        SwerveModuleConstants#DriveMotorInverted})
     *   <li> {@link Slot0Configs} ({@link #DriveMotorGains})
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimit} / {@link
     *        TorqueCurrentConfigs#PeakForwardTorqueCurrent} / {@link
     *        TorqueCurrentConfigs#PeakReverseTorqueCurrent} ({@link #SlipCurrent})
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimitEnable} (Enabled)
     *   <li> {@link FeedbackConfigs#RotorToSensorRatio} / {@link
     *        FeedbackConfigs#SensorToMechanismRatio} (1.0)
     * </ul>
     * 
     */
    public DriveMotorConfigsT DriveMotorInitialConfigs = null;
    /**
     * The initial configs used to configure the steer motor of the swerve module.
     * The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * The list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MotorOutputConfigs#NeutralMode} (Brake mode)
     *   <li> {@link MotorOutputConfigs#Inverted} ({@link
     *        SwerveModuleConstants#SteerMotorInverted})
     *   <li> {@link Slot0Configs} ({@link #SteerMotorGains})
     *   <li> {@link FeedbackConfigs#FeedbackRemoteSensorID} ({@link
     *        SwerveModuleConstants#EncoderId})
     *   <li> {@link FeedbackConfigs#FeedbackSensorSource} ({@link #FeedbackSource})
     *   <li> {@link FeedbackConfigs#RotorToSensorRatio} ({@link
     *        #SteerMotorGearRatio})
     *   <li> {@link FeedbackConfigs#SensorToMechanismRatio} (1.0)
     *   <li> {@link MotionMagicConfigs#MotionMagicExpo_kV} / {@link
     *        MotionMagicConfigs#MotionMagicExpo_kA} (Calculated from gear ratios)
     *   <li> {@link ClosedLoopGeneralConfigs#ContinuousWrap} (true)
     * </ul>
     * 
     */
    public SteerMotorConfigsT SteerMotorInitialConfigs = null;
    /**
     * The initial configs used to configure the azimuth encoder of the swerve
     * module. The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * For CANcoder, the list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MagnetSensorConfigs#MagnetOffset} ({@link
     *        SwerveModuleConstants#EncoderOffset})
     *   <li> {@link MagnetSensorConfigs#SensorDirection} ({@link
     *        SwerveModuleConstants#EncoderInverted})
     * </ul>
     * 
     */
    public EncoderConfigsT EncoderInitialConfigs = null;
    /**
     * Simulated azimuthal inertia.
     */
    public double SteerInertia = 0.01;
    /**
     * Simulated drive inertia.
     */
    public double DriveInertia = 0.01;
    /**
     * Simulated steer voltage required to overcome friction.
     */
    public double SteerFrictionVoltage = 0.2;
    /**
     * Simulated drive voltage required to overcome friction.
     */
    public double DriveFrictionVoltage = 0.2;
    
    /**
     * Modifies the DriveMotorGearRatio parameter and returns itself.
     * <p>
     * Gear ratio between the drive motor and the wheel.
     *
     * @param newDriveMotorGearRatio Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorGearRatio(double newDriveMotorGearRatio) {
        this.DriveMotorGearRatio = newDriveMotorGearRatio;
        return this;
    }
    
    /**
     * Modifies the SteerMotorGearRatio parameter and returns itself.
     * <p>
     * Gear ratio between the steer motor and the azimuth encoder. For example, the
     * SDS Mk4 has a steering ratio of 12.8.
     *
     * @param newSteerMotorGearRatio Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorGearRatio(double newSteerMotorGearRatio) {
        this.SteerMotorGearRatio = newSteerMotorGearRatio;
        return this;
    }
    
    /**
     * Modifies the CouplingGearRatio parameter and returns itself.
     * <p>
     * Coupled gear ratio between the azimuth encoder and the drive motor.
     * <p>
     * For a typical swerve module, the azimuth turn motor also drives the wheel a
     * nontrivial amount, which affects the accuracy of odometry and control. This
     * ratio represents the number of rotations of the drive motor caused by a
     * rotation of the azimuth.
     *
     * @param newCouplingGearRatio Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withCouplingGearRatio(double newCouplingGearRatio) {
        this.CouplingGearRatio = newCouplingGearRatio;
        return this;
    }
    
    /**
     * Modifies the WheelRadius parameter and returns itself.
     * <p>
     * Radius of the driving wheel in meters.
     *
     * @param newWheelRadius Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withWheelRadius(double newWheelRadius) {
        this.WheelRadius = newWheelRadius;
        return this;
    }
    
    /**
     * Modifies the WheelRadius parameter and returns itself.
     * <p>
     * Radius of the driving wheel in meters.
     *
     * @param newWheelRadius Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withWheelRadius(Distance newWheelRadius) {
        this.WheelRadius = newWheelRadius.in(Meters);
        return this;
    }
    
    /**
     * Modifies the SteerMotorGains parameter and returns itself.
     * <p>
     * The steer motor closed-loop gains.
     * <p>
     * The steer motor uses the control ouput type specified by {@link
     * #SteerMotorClosedLoopOutput} and any {@link SwerveModule.SteerRequestType}.
     * These gains operate on azimuth rotations (after the gear ratio).
     *
     * @param newSteerMotorGains Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorGains(Slot0Configs newSteerMotorGains) {
        this.SteerMotorGains = newSteerMotorGains;
        return this;
    }
    
    /**
     * Modifies the DriveMotorGains parameter and returns itself.
     * <p>
     * The drive motor closed-loop gains.
     * <p>
     * When using closed-loop control, the drive motor uses the control output type
     * specified by {@link #DriveMotorClosedLoopOutput} and any closed-loop {@link
     * SwerveModule.DriveRequestType}. These gains operate on motor rotor rotations
     * (before the gear ratio).
     *
     * @param newDriveMotorGains Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorGains(Slot0Configs newDriveMotorGains) {
        this.DriveMotorGains = newDriveMotorGains;
        return this;
    }
    
    /**
     * Modifies the SteerMotorClosedLoopOutput parameter and returns itself.
     * <p>
     * The closed-loop output type to use for the steer motors.
     *
     * @param newSteerMotorClosedLoopOutput Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorClosedLoopOutput(ClosedLoopOutputType newSteerMotorClosedLoopOutput) {
        this.SteerMotorClosedLoopOutput = newSteerMotorClosedLoopOutput;
        return this;
    }
    
    /**
     * Modifies the DriveMotorClosedLoopOutput parameter and returns itself.
     * <p>
     * The closed-loop output type to use for the drive motors.
     *
     * @param newDriveMotorClosedLoopOutput Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorClosedLoopOutput(ClosedLoopOutputType newDriveMotorClosedLoopOutput) {
        this.DriveMotorClosedLoopOutput = newDriveMotorClosedLoopOutput;
        return this;
    }
    
    /**
     * Modifies the SlipCurrent parameter and returns itself.
     * <p>
     * The maximum amount of stator current the drive motors can apply without
     * slippage.
     *
     * @param newSlipCurrent Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSlipCurrent(double newSlipCurrent) {
        this.SlipCurrent = newSlipCurrent;
        return this;
    }
    
    /**
     * Modifies the SlipCurrent parameter and returns itself.
     * <p>
     * The maximum amount of stator current the drive motors can apply without
     * slippage.
     *
     * @param newSlipCurrent Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSlipCurrent(Current newSlipCurrent) {
        this.SlipCurrent = newSlipCurrent.in(Amps);
        return this;
    }
    
    /**
     * Modifies the SpeedAt12Volts parameter and returns itself.
     * <p>
     * When using open-loop drive control, this specifies the speed at which the
     * robot travels when driven with 12 volts. This is used to approximate the
     * output for a desired velocity. If using closed loop control, this value is
     * ignored.
     *
     * @param newSpeedAt12Volts Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSpeedAt12Volts(double newSpeedAt12Volts) {
        this.SpeedAt12Volts = newSpeedAt12Volts;
        return this;
    }
    
    /**
     * Modifies the SpeedAt12Volts parameter and returns itself.
     * <p>
     * When using open-loop drive control, this specifies the speed at which the
     * robot travels when driven with 12 volts. This is used to approximate the
     * output for a desired velocity. If using closed loop control, this value is
     * ignored.
     *
     * @param newSpeedAt12Volts Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSpeedAt12Volts(LinearVelocity newSpeedAt12Volts) {
        this.SpeedAt12Volts = newSpeedAt12Volts.in(MetersPerSecond);
        return this;
    }
    
    /**
     * Modifies the DriveMotorType parameter and returns itself.
     * <p>
     * Choose the motor used for the drive motor.
     * <p>
     * If using a Talon FX, this should be set to TalonFX_Integrated. If using a
     * Talon FXS, this should be set to the motor attached to the Talon FXS.
     *
     * @param newDriveMotorType Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorType(DriveMotorArrangement newDriveMotorType) {
        this.DriveMotorType = newDriveMotorType;
        return this;
    }
    
    /**
     * Modifies the SteerMotorType parameter and returns itself.
     * <p>
     * Choose the motor used for the steer motor.
     * <p>
     * If using a Talon FX, this should be set to TalonFX_Integrated. If using a
     * Talon FXS, this should be set to the motor attached to the Talon FXS.
     *
     * @param newSteerMotorType Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorType(SteerMotorArrangement newSteerMotorType) {
        this.SteerMotorType = newSteerMotorType;
        return this;
    }
    
    /**
     * Modifies the FeedbackSource parameter and returns itself.
     * <p>
     * Choose how the feedback sensors should be configured.
     * <p>
     * If the robot does not support Pro, then this should be set to RemoteCANcoder.
     * Otherwise, users have the option to use either FusedCANcoder or SyncCANcoder
     * depending on if there is a risk that the CANcoder can fail in a way to
     * provide "good" data.
     * <p>
     * If this is set to FusedCANcoder or SyncCANcoder when the steer motor is not
     * Pro-licensed, the device will automatically fall back to RemoteCANcoder and
     * report a UsingProFeatureOnUnlicensedDevice status code.
     *
     * @param newFeedbackSource Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withFeedbackSource(SteerFeedbackType newFeedbackSource) {
        this.FeedbackSource = newFeedbackSource;
        return this;
    }
    
    /**
     * Modifies the DriveMotorInitialConfigs parameter and returns itself.
     * <p>
     * The initial configs used to configure the drive motor of the swerve module.
     * The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * The list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MotorOutputConfigs#NeutralMode} (Brake mode, overwritten with
     *        {@link SwerveDrivetrain#configNeutralMode})
     *   <li> {@link MotorOutputConfigs#Inverted} ({@link
     *        SwerveModuleConstants#DriveMotorInverted})
     *   <li> {@link Slot0Configs} ({@link #DriveMotorGains})
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimit} / {@link
     *        TorqueCurrentConfigs#PeakForwardTorqueCurrent} / {@link
     *        TorqueCurrentConfigs#PeakReverseTorqueCurrent} ({@link #SlipCurrent})
     *   <li> {@link CurrentLimitsConfigs#StatorCurrentLimitEnable} (Enabled)
     *   <li> {@link FeedbackConfigs#RotorToSensorRatio} / {@link
     *        FeedbackConfigs#SensorToMechanismRatio} (1.0)
     * </ul>
     * 
     *
     * @param newDriveMotorInitialConfigs Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveMotorInitialConfigs(DriveMotorConfigsT newDriveMotorInitialConfigs) {
        this.DriveMotorInitialConfigs = newDriveMotorInitialConfigs;
        return this;
    }
    
    /**
     * Modifies the SteerMotorInitialConfigs parameter and returns itself.
     * <p>
     * The initial configs used to configure the steer motor of the swerve module.
     * The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * The list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MotorOutputConfigs#NeutralMode} (Brake mode)
     *   <li> {@link MotorOutputConfigs#Inverted} ({@link
     *        SwerveModuleConstants#SteerMotorInverted})
     *   <li> {@link Slot0Configs} ({@link #SteerMotorGains})
     *   <li> {@link FeedbackConfigs#FeedbackRemoteSensorID} ({@link
     *        SwerveModuleConstants#EncoderId})
     *   <li> {@link FeedbackConfigs#FeedbackSensorSource} ({@link #FeedbackSource})
     *   <li> {@link FeedbackConfigs#RotorToSensorRatio} ({@link
     *        #SteerMotorGearRatio})
     *   <li> {@link FeedbackConfigs#SensorToMechanismRatio} (1.0)
     *   <li> {@link MotionMagicConfigs#MotionMagicExpo_kV} / {@link
     *        MotionMagicConfigs#MotionMagicExpo_kA} (Calculated from gear ratios)
     *   <li> {@link ClosedLoopGeneralConfigs#ContinuousWrap} (true)
     * </ul>
     * 
     *
     * @param newSteerMotorInitialConfigs Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerMotorInitialConfigs(SteerMotorConfigsT newSteerMotorInitialConfigs) {
        this.SteerMotorInitialConfigs = newSteerMotorInitialConfigs;
        return this;
    }
    
    /**
     * Modifies the EncoderInitialConfigs parameter and returns itself.
     * <p>
     * The initial configs used to configure the azimuth encoder of the swerve
     * module. The default value is the factory-default.
     * <p>
     * Users may change the initial configuration as they need. Any config that's
     * not referenced in the {@link SwerveModuleConstants} class is available to be
     * changed.
     * <p>
     * For CANcoder, the list of configs that will be overwritten is as follows:
     * 
     * <ul>
     *   <li> {@link MagnetSensorConfigs#MagnetOffset} ({@link
     *        SwerveModuleConstants#EncoderOffset})
     *   <li> {@link MagnetSensorConfigs#SensorDirection} ({@link
     *        SwerveModuleConstants#EncoderInverted})
     * </ul>
     * 
     *
     * @param newEncoderInitialConfigs Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withEncoderInitialConfigs(EncoderConfigsT newEncoderInitialConfigs) {
        this.EncoderInitialConfigs = newEncoderInitialConfigs;
        return this;
    }
    
    /**
     * Modifies the SteerInertia parameter and returns itself.
     * <p>
     * Simulated azimuthal inertia.
     *
     * @param newSteerInertia Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerInertia(double newSteerInertia) {
        this.SteerInertia = newSteerInertia;
        return this;
    }
    
    /**
     * Modifies the SteerInertia parameter and returns itself.
     * <p>
     * Simulated azimuthal inertia.
     *
     * @param newSteerInertia Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerInertia(MomentOfInertia newSteerInertia) {
        this.SteerInertia = newSteerInertia.in(KilogramSquareMeters);
        return this;
    }
    
    /**
     * Modifies the DriveInertia parameter and returns itself.
     * <p>
     * Simulated drive inertia.
     *
     * @param newDriveInertia Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveInertia(double newDriveInertia) {
        this.DriveInertia = newDriveInertia;
        return this;
    }
    
    /**
     * Modifies the DriveInertia parameter and returns itself.
     * <p>
     * Simulated drive inertia.
     *
     * @param newDriveInertia Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveInertia(MomentOfInertia newDriveInertia) {
        this.DriveInertia = newDriveInertia.in(KilogramSquareMeters);
        return this;
    }
    
    /**
     * Modifies the SteerFrictionVoltage parameter and returns itself.
     * <p>
     * Simulated steer voltage required to overcome friction.
     *
     * @param newSteerFrictionVoltage Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerFrictionVoltage(double newSteerFrictionVoltage) {
        this.SteerFrictionVoltage = newSteerFrictionVoltage;
        return this;
    }
    
    /**
     * Modifies the SteerFrictionVoltage parameter and returns itself.
     * <p>
     * Simulated steer voltage required to overcome friction.
     *
     * @param newSteerFrictionVoltage Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withSteerFrictionVoltage(Voltage newSteerFrictionVoltage) {
        this.SteerFrictionVoltage = newSteerFrictionVoltage.in(Volts);
        return this;
    }
    
    /**
     * Modifies the DriveFrictionVoltage parameter and returns itself.
     * <p>
     * Simulated drive voltage required to overcome friction.
     *
     * @param newDriveFrictionVoltage Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveFrictionVoltage(double newDriveFrictionVoltage) {
        this.DriveFrictionVoltage = newDriveFrictionVoltage;
        return this;
    }
    
    /**
     * Modifies the DriveFrictionVoltage parameter and returns itself.
     * <p>
     * Simulated drive voltage required to overcome friction.
     *
     * @param newDriveFrictionVoltage Parameter to modify
     * @return this object
     */
    public SwerveModuleConstantsFactory<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> withDriveFrictionVoltage(Voltage newDriveFrictionVoltage) {
        this.DriveFrictionVoltage = newDriveFrictionVoltage.in(Volts);
        return this;
    }
    
    /**
     * Creates the constants for a swerve module with the given properties.
     *
     * @param steerMotorId CAN ID of the steer motor.
     * @param driveMotorId CAN ID of the drive motor.
     * @param encoderId CAN ID of the absolute encoder used for azimuth.
     * @param encoderOffset Offset of the azimuth encoder.
     * @param locationX The location of this module's wheels relative to the
     *                  physical center of the robot in meters along the X axis of
     *                  the robot.
     * @param locationY The location of this module's wheels relative to the
     *                  physical center of the robot in meters along the Y axis of
     *                  the robot.
     * @param driveMotorInverted True if the drive motor is inverted.
     * @param steerMotorInverted True if the steer motor is inverted from the
     *                           azimuth. The azimuth should rotate
     *                           counter-clockwise (as seen from the top of the
     *                           robot) for a positive motor output.
     * @param encoderInverted True if the azimuth encoder is inverted from the
     *                        azimuth. The encoder should report a positive velocity
     *                        when the azimuth rotates counter-clockwise (as seen
     *                        from the top of the robot).
     * @return Constants for the swerve module
     */
    public final SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> createModuleConstants(
            int steerMotorId,
            int driveMotorId,
            int encoderId,
            double encoderOffset,
            double locationX,
            double locationY,
            boolean driveMotorInverted,
            boolean steerMotorInverted,
            boolean encoderInverted)
    {
        return new SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT>()
            .withSteerMotorId(steerMotorId)
            .withDriveMotorId(driveMotorId)
            .withEncoderId(encoderId)
            .withEncoderOffset(encoderOffset)
            .withLocationX(locationX)
            .withLocationY(locationY)
            .withDriveMotorInverted(driveMotorInverted)
            .withSteerMotorInverted(steerMotorInverted)
            .withEncoderInverted(encoderInverted)
            .withDriveMotorGearRatio(DriveMotorGearRatio)
            .withSteerMotorGearRatio(SteerMotorGearRatio)
            .withCouplingGearRatio(CouplingGearRatio)
            .withWheelRadius(WheelRadius)
            .withSteerMotorGains(SteerMotorGains)
            .withDriveMotorGains(DriveMotorGains)
            .withSteerMotorClosedLoopOutput(SteerMotorClosedLoopOutput)
            .withDriveMotorClosedLoopOutput(DriveMotorClosedLoopOutput)
            .withSlipCurrent(SlipCurrent)
            .withSpeedAt12Volts(SpeedAt12Volts)
            .withDriveMotorType(DriveMotorType)
            .withSteerMotorType(SteerMotorType)
            .withFeedbackSource(FeedbackSource)
            .withDriveMotorInitialConfigs(DriveMotorInitialConfigs)
            .withSteerMotorInitialConfigs(SteerMotorInitialConfigs)
            .withEncoderInitialConfigs(EncoderInitialConfigs)
            .withSteerInertia(SteerInertia)
            .withDriveInertia(DriveInertia)
            .withSteerFrictionVoltage(SteerFrictionVoltage)
            .withDriveFrictionVoltage(DriveFrictionVoltage);
    }
    
    /**
     * Creates the constants for a swerve module with the given properties.
     *
     * @param steerMotorId CAN ID of the steer motor.
     * @param driveMotorId CAN ID of the drive motor.
     * @param encoderId CAN ID of the absolute encoder used for azimuth.
     * @param encoderOffset Offset of the azimuth encoder.
     * @param locationX The location of this module's wheels relative to the
     *                  physical center of the robot in meters along the X axis of
     *                  the robot.
     * @param locationY The location of this module's wheels relative to the
     *                  physical center of the robot in meters along the Y axis of
     *                  the robot.
     * @param driveMotorInverted True if the drive motor is inverted.
     * @param steerMotorInverted True if the steer motor is inverted from the
     *                           azimuth. The azimuth should rotate
     *                           counter-clockwise (as seen from the top of the
     *                           robot) for a positive motor output.
     * @param encoderInverted True if the azimuth encoder is inverted from the
     *                        azimuth. The encoder should report a positive velocity
     *                        when the azimuth rotates counter-clockwise (as seen
     *                        from the top of the robot).
     * @return Constants for the swerve module
     */
    public final SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT> createModuleConstants(
            int steerMotorId,
            int driveMotorId,
            int encoderId,
            Angle encoderOffset,
            Distance locationX,
            Distance locationY,
            boolean driveMotorInverted,
            boolean steerMotorInverted,
            boolean encoderInverted)
    {
        return new SwerveModuleConstants<DriveMotorConfigsT, SteerMotorConfigsT, EncoderConfigsT>()
            .withSteerMotorId(steerMotorId)
            .withDriveMotorId(driveMotorId)
            .withEncoderId(encoderId)
            .withEncoderOffset(encoderOffset.in(Rotations))
            .withLocationX(locationX.in(Meters))
            .withLocationY(locationY.in(Meters))
            .withDriveMotorInverted(driveMotorInverted)
            .withSteerMotorInverted(steerMotorInverted)
            .withEncoderInverted(encoderInverted)
            .withDriveMotorGearRatio(DriveMotorGearRatio)
            .withSteerMotorGearRatio(SteerMotorGearRatio)
            .withCouplingGearRatio(CouplingGearRatio)
            .withWheelRadius(WheelRadius)
            .withSteerMotorGains(SteerMotorGains)
            .withDriveMotorGains(DriveMotorGains)
            .withSteerMotorClosedLoopOutput(SteerMotorClosedLoopOutput)
            .withDriveMotorClosedLoopOutput(DriveMotorClosedLoopOutput)
            .withSlipCurrent(SlipCurrent)
            .withSpeedAt12Volts(SpeedAt12Volts)
            .withDriveMotorType(DriveMotorType)
            .withSteerMotorType(SteerMotorType)
            .withFeedbackSource(FeedbackSource)
            .withDriveMotorInitialConfigs(DriveMotorInitialConfigs)
            .withSteerMotorInitialConfigs(SteerMotorInitialConfigs)
            .withEncoderInitialConfigs(EncoderInitialConfigs)
            .withSteerInertia(SteerInertia)
            .withDriveInertia(DriveInertia)
            .withSteerFrictionVoltage(SteerFrictionVoltage)
            .withDriveFrictionVoltage(DriveFrictionVoltage);
    }
}
