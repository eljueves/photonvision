/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The type of animation running in slot 7 of the CANdle.
 */
public enum Animation7TypeValue
{
    /**
     * No animation.
     */
    Empty(0),
    /**
     * Color flow animation.
     */
    ColorFlow(1),
    /**
     * Fire animation.
     */
    Fire(2),
    /**
     * Larson animation.
     */
    Larson(3),
    /**
     * Rainbow animation.
     */
    Rainbow(4),
    /**
     * RGB Fade animation.
     */
    RgbFade(5),
    /**
     * Single fade animation.
     */
    SingleFade(6),
    /**
     * Strobe animation.
     */
    Strobe(7),
    /**
     * Twinkle animation.
     */
    Twinkle(8),
    /**
     * Twinkle off animation.
     */
    TwinkleOff(9),;

    public final int value;

    Animation7TypeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, Animation7TypeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, Animation7TypeValue>();
        for (Animation7TypeValue type : Animation7TypeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets Animation7TypeValue from specified value
     * @param value Value of Animation7TypeValue
     * @return Animation7TypeValue of specified value
     */
    public static Animation7TypeValue valueOf(int value)
    {
        Animation7TypeValue retval = _map.get(value);
        if (retval != null) return retval;
        return Animation7TypeValue.values()[0];
    }
}
