/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.wpiutils;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.ctre.phoenix6.HootReplay;

import edu.wpi.first.hal.AllianceStationID;
import edu.wpi.first.wpilibj.Notifier;
import edu.wpi.first.wpilibj.simulation.DriverStationSim;

public final class ReplayAutoEnable implements AutoCloseable {
    private static final ReplayAutoEnable replayAutoEnable = new ReplayAutoEnable();

    private final Notifier _enableNotifier;
    private final Lock _lck = new ReentrantLock();
    private int _startCount = 0;

    public static ReplayAutoEnable getInstance() {
        return replayAutoEnable;
    }

    private ReplayAutoEnable() {
        _enableNotifier = new Notifier(() -> {
            if (HootReplay.isPlaying()) {
                var dsAttachedSig = HootReplay.getBoolean("DS:IsDSAttached");
                if (dsAttachedSig.status.isOK()) {
                    DriverStationSim.setDsAttached(dsAttachedSig.value);
                }

                if (DriverStationSim.getDsAttached()) {
                    var fmsAttachedSig = HootReplay.getBoolean("DS:IsFMSAttached");
                    if (fmsAttachedSig.status.isOK()) {
                        DriverStationSim.setFmsAttached(fmsAttachedSig.value);
                    }

                    var enableSig = HootReplay.getBoolean("RobotEnable");
                    if (enableSig.status.isOK()) {
                        DriverStationSim.setEnabled(enableSig.value);
                    }

                    var robotModeSig = HootReplay.getString("RobotMode");
                    if (robotModeSig.status.isOK()) {
                        switch (robotModeSig.value) {
                            case "Autonomous":
                                DriverStationSim.setAutonomous(true);
                                DriverStationSim.setTest(false);
                                DriverStationSim.setEStop(false);
                                break;
                            case "Test":
                                DriverStationSim.setAutonomous(false);
                                DriverStationSim.setTest(true);
                                DriverStationSim.setEStop(false);
                                break;
                            case "EStopped":
                                DriverStationSim.setAutonomous(false);
                                DriverStationSim.setTest(false);
                                DriverStationSim.setEStop(true);
                                break;
                            default:
                                DriverStationSim.setAutonomous(false);
                                DriverStationSim.setTest(false);
                                DriverStationSim.setEStop(false);
                                break;
                        }
                    }

                    var allianceStationSig = HootReplay.getString("AllianceStation");
                    if (allianceStationSig.status.isOK()) {
                        switch (allianceStationSig.value) {
                            case "Red 1":
                                DriverStationSim.setAllianceStationId(AllianceStationID.Red1);
                                break;
                            case "Red 2":
                                DriverStationSim.setAllianceStationId(AllianceStationID.Red2);
                                break;
                            case "Red 3":
                                DriverStationSim.setAllianceStationId(AllianceStationID.Red3);
                                break;
                            case "Blue 1":
                                DriverStationSim.setAllianceStationId(AllianceStationID.Blue1);
                                break;
                            case "Blue 2":
                                DriverStationSim.setAllianceStationId(AllianceStationID.Blue2);
                                break;
                            case "Blue 3":
                                DriverStationSim.setAllianceStationId(AllianceStationID.Blue3);
                                break;
                            default:
                                DriverStationSim.setAllianceStationId(AllianceStationID.Unknown);
                                break;
                        }
                    }

                    DriverStationSim.notifyNewData();
                }
            }
        });
    }

    /**
     * Starts automatically enabling the robot in replay.
     */
    public void start() {
        _lck.lock();
        try {
            if (_startCount < Integer.MAX_VALUE) {
                if (_startCount++ == 0) {
                    /* start if we were previously at 0 */
                    _enableNotifier.startPeriodic(0.010);
                }
            }
        } finally {
            _lck.unlock();
        }
    }

    /**
     * Stops automatically enabling the robot in replay. The
     * replay enable will only be stopped when all actuators
     * have requested to stop the replay enable.
     */
    public void stop() {
        _lck.lock();
        try {
            if (_startCount > 0) {
                if (--_startCount == 0) {
                    /* stop if we are now at 0 */
                    _enableNotifier.stop();
                }
            }
        } finally {
            _lck.unlock();
        }
    }

    @Override
    public void close() {
        _enableNotifier.close();
    }
}
