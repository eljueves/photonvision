/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.traits;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.*;

/**
 * Contains all control functions available for motors that support playing
 * music.
 */
public interface SupportsMusic extends CommonDevice
{
    
    
    /**
     * Plays a single tone at the user specified frequency.
     * <ul>
     *   <li> <b>MusicTone Parameters:</b> 
     *   <ul>
     *     <li> <b>AudioFrequency:</b> Sound frequency to play.  A value of zero
     *                                 will silence the device. The effective
     *                                 frequency range is 10-20000 Hz.  Any nonzero
     *                                 frequency less than 10 Hz will be capped to
     *                                 10 Hz.  Any frequency above 20 kHz will be
     *                                 capped to 20 kHz.
     *   </ul>
     * </ul>
     *
     * @param request Control object to request of the device
     * @return Code response of the request
     */
    StatusCode setControl(MusicTone request);

    /**
     * Control device with generic control request object.
     * <p>
     * User must make sure the specified object is castable to a valid control request,
     * otherwise this function will fail at run-time and return the NotSupported StatusCode
     *
     * @param request Control object to request of the device
     * @return Status Code of the request, 0 is OK
     */
    StatusCode setControl(ControlRequest request);
    
}

