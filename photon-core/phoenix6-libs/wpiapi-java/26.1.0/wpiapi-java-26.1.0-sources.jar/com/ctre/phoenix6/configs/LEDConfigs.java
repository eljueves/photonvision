/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

/**
 * Configs related to CANdle LED control.
 * <p>
 * All the configs related to controlling LEDs with the CANdle,
 * including LED strip type and brightness.
 */
public class LEDConfigs implements ParentConfiguration, Cloneable {
    /**
     * The type of LEDs that are being controlled.
     * 
     */
    public StripTypeValue StripType = StripTypeValue.GRB;
    /**
     * The brightness scalar for all LEDs controlled. All LED values sent
     * to the CANdle will be scaled by this config.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     */
    public double BrightnessScalar = 1.0;
    /**
     * The behavior of the LEDs when the control signal is lost.
     * 
     */
    public LossOfSignalBehaviorValue LossOfSignalBehavior = LossOfSignalBehaviorValue.KeepRunning;
    
    /**
     * Modifies this configuration's StripType parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The type of LEDs that are being controlled.
     * 
     *
     * @param newStripType Parameter to modify
     * @return Itself
     */
    public final LEDConfigs withStripType(StripTypeValue newStripType)
    {
        StripType = newStripType;
        return this;
    }
    
    /**
     * Modifies this configuration's BrightnessScalar parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The brightness scalar for all LEDs controlled. All LED values sent
     * to the CANdle will be scaled by this config.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     *
     * @param newBrightnessScalar Parameter to modify
     * @return Itself
     */
    public final LEDConfigs withBrightnessScalar(double newBrightnessScalar)
    {
        BrightnessScalar = newBrightnessScalar;
        return this;
    }
    
    /**
     * Modifies this configuration's LossOfSignalBehavior parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The behavior of the LEDs when the control signal is lost.
     * 
     *
     * @param newLossOfSignalBehavior Parameter to modify
     * @return Itself
     */
    public final LEDConfigs withLossOfSignalBehavior(LossOfSignalBehaviorValue newLossOfSignalBehavior)
    {
        LossOfSignalBehavior = newLossOfSignalBehavior;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: LED\n";
        ss += "    StripType: " + StripType + "\n";
        ss += "    BrightnessScalar: " + BrightnessScalar + " scalar" + "\n";
        ss += "    LossOfSignalBehavior: " + LossOfSignalBehavior + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeint(SpnValue.Config_LED_StripType.value, StripType.value);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_LED_BrightnessScalar.value, BrightnessScalar);
        ss += ConfigJNI.Serializeint(SpnValue.Config_LED_LossOfSignalBehavior.value, LossOfSignalBehavior.value);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        StripType = StripTypeValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_LED_StripType.value, to_deserialize));
        BrightnessScalar = ConfigJNI.Deserializedouble(SpnValue.Config_LED_BrightnessScalar.value, to_deserialize);
        LossOfSignalBehavior = LossOfSignalBehaviorValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_LED_LossOfSignalBehavior.value, to_deserialize));
        return  StatusCode.OK;
    }

    @Override
    public LEDConfigs clone() {
        try {
            return (LEDConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

