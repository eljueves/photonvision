/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.jni.ControlJNI;
import com.ctre.phoenix6.hardware.traits.*;

import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Requires Phoenix Pro;
 * Request a specified motor current (field oriented control).
 * <p>
 * This control request will drive the motor to the requested motor (stator) current value.  This leverages
 * field oriented control (FOC), which means greater peak power than what is documented.  This scales to
 * torque based on Motor's kT constant.
 */
public final class TorqueCurrentFOC implements ControlRequest, Cloneable {
    /**
     * Amount of motor current in Amperes
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     */
    public double Output;
    /**
     * The maximum absolute motor output that can be applied, which effectively
     * limits the velocity. For example, 0.50 means no more than 50% output in
     * either direction.  This is useful for preventing the motor from spinning to
     * its terminal velocity when there is no external torque applied unto the
     * rotor.  Note this is absolute maximum, so the value should be between zero
     * and one.
     * 
     * <ul>
     *   <li> Units: fractional
     * </ul>
     * 
     */
    public double MaxAbsDutyCycle = 1.0;
    /**
     * Deadband in Amperes.  If torque request is within deadband, the bridge output
     * is neutral. If deadband is set to zero then there is effectively no deadband.
     * Note if deadband is zero, a free spinning motor will spin for quite a while
     * as the firmware attempts to hold the motor's bemf. If user expects motor to
     * cease spinning quickly with a demand of zero, we recommend a deadband of one
     * Ampere. This value will be converted to an integral value of amps.
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     */
    public double Deadband = 0.0;
    /**
     * Set to true to coast the rotor when output is zero (or within deadband).  Set
     * to false to use the NeutralMode configuration setting (default). This flag
     * exists to provide the fundamental behavior of this control when output is
     * zero, which is to provide 0A (zero torque).
     */
    public boolean OverrideCoastDurNeutral = false;
    /**
     * Set to true to force forward limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     */
    public boolean LimitForwardMotion = false;
    /**
     * Set to true to force reverse limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     */
    public boolean LimitReverseMotion = false;
    /**
     * Set to true to ignore hardware limit switches and the LimitForwardMotion and
     * LimitReverseMotion parameters, instead allowing motion.
     * <p>
     * This can be useful on mechanisms such as an intake/feeder, where a limit
     * switch stops motion while intaking but should be ignored when feeding to a
     * shooter.
     * <p>
     * The hardware limit faults and Forward/ReverseLimit signals will still report
     * the values of the limit switches regardless of this parameter.
     */
    public boolean IgnoreHardwareLimits = false;
    /**
     * Set to true to ignore software limits, instead allowing motion.
     * <p>
     * This can be useful when calibrating the zero point of a mechanism such as an
     * elevator.
     * <p>
     * The software limit faults will still report the values of the software limits
     * regardless of this parameter.
     */
    public boolean IgnoreSoftwareLimits = false;
    /**
     * Set to true to delay applying this control request until a timesync boundary
     * (requires Phoenix Pro and CANivore). This eliminates the impact of
     * nondeterministic network delays in exchange for a larger but deterministic
     * control latency.
     * <p>
     * This requires setting the ControlTimesyncFreqHz config in MotorOutputConfigs.
     * Additionally, when this is enabled, the UpdateFreqHz of this request should
     * be set to 0 Hz.
     */
    public boolean UseTimesync = false;

    /**
     * The frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     */
    public double UpdateFreqHz = 100;

    /**
     * Requires Phoenix Pro;
     * Request a specified motor current (field oriented control).
     * <p>
     * This control request will drive the motor to the requested motor (stator)
     * current value.  This leverages field oriented control (FOC), which means
     * greater peak power than what is documented.  This scales to torque based on
     * Motor's kT constant.
     * 
     * @param Output Amount of motor current in Amperes
     */
    public TorqueCurrentFOC(double Output) {
        this.Output = Output;
    }

    /**
     * Requires Phoenix Pro;
     * Request a specified motor current (field oriented control).
     * <p>
     * This control request will drive the motor to the requested motor (stator)
     * current value.  This leverages field oriented control (FOC), which means
     * greater peak power than what is documented.  This scales to torque based on
     * Motor's kT constant.
     * 
     * @param Output Amount of motor current in Amperes
     */
    public TorqueCurrentFOC(Current Output) {
        this(Output.in(Amps));
    }

    @Override
    public String getName() {
        return "TorqueCurrentFOC";
    }

    @Override
    public String toString() {
        String ss = "Control: TorqueCurrentFOC\n";
        ss += "    Output: " + Output + " A" + "\n";
        ss += "    MaxAbsDutyCycle: " + MaxAbsDutyCycle + " fractional" + "\n";
        ss += "    Deadband: " + Deadband + " A" + "\n";
        ss += "    OverrideCoastDurNeutral: " + OverrideCoastDurNeutral + "\n";
        ss += "    LimitForwardMotion: " + LimitForwardMotion + "\n";
        ss += "    LimitReverseMotion: " + LimitReverseMotion + "\n";
        ss += "    IgnoreHardwareLimits: " + IgnoreHardwareLimits + "\n";
        ss += "    IgnoreSoftwareLimits: " + IgnoreSoftwareLimits + "\n";
        ss += "    UseTimesync: " + UseTimesync + "\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlTorqueCurrentFOC(
                network, deviceHash, UpdateFreqHz, Output, MaxAbsDutyCycle, Deadband, OverrideCoastDurNeutral, LimitForwardMotion, LimitReverseMotion, IgnoreHardwareLimits, IgnoreSoftwareLimits, UseTimesync));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String, String>();
        controlInfo.put("Name", getName());
        controlInfo.put("Output", String.valueOf(this.Output));
        controlInfo.put("MaxAbsDutyCycle", String.valueOf(this.MaxAbsDutyCycle));
        controlInfo.put("Deadband", String.valueOf(this.Deadband));
        controlInfo.put("OverrideCoastDurNeutral", String.valueOf(this.OverrideCoastDurNeutral));
        controlInfo.put("LimitForwardMotion", String.valueOf(this.LimitForwardMotion));
        controlInfo.put("LimitReverseMotion", String.valueOf(this.LimitReverseMotion));
        controlInfo.put("IgnoreHardwareLimits", String.valueOf(this.IgnoreHardwareLimits));
        controlInfo.put("IgnoreSoftwareLimits", String.valueOf(this.IgnoreSoftwareLimits));
        controlInfo.put("UseTimesync", String.valueOf(this.UseTimesync));
        return controlInfo;
    }
    
    /**
     * Modifies this Control Request's Output parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Amount of motor current in Amperes
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     *
     * @param newOutput Parameter to modify
     * @return Itself
     */
    public TorqueCurrentFOC withOutput(double newOutput) {
        Output = newOutput;
        return this;
    }
    
    /**
     * Modifies this Control Request's Output parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Amount of motor current in Amperes
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     *
     * @param newOutput Parameter to modify
     * @return Itself
     */
    public TorqueCurrentFOC withOutput(Current newOutput) {
        Output = newOutput.in(Amps);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's Output parameter converted
     * to a unit type. If not using the Java units library, {@link #Output}
     * can be accessed directly instead.
     * <p>
     * Amount of motor current in Amperes
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     *
     * @return Output
     */
    public Current getOutputMeasure() {
        return Amps.of(Output);
    }
    
    /**
     * Modifies this Control Request's MaxAbsDutyCycle parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * The maximum absolute motor output that can be applied, which effectively
     * limits the velocity. For example, 0.50 means no more than 50% output in
     * either direction.  This is useful for preventing the motor from spinning to
     * its terminal velocity when there is no external torque applied unto the
     * rotor.  Note this is absolute maximum, so the value should be between zero
     * and one.
     * 
     * <ul>
     *   <li> Units: fractional
     * </ul>
     * 
     *
     * @param newMaxAbsDutyCycle Parameter to modify
     * @return Itself
     */
    public TorqueCurrentFOC withMaxAbsDutyCycle(double newMaxAbsDutyCycle) {
        MaxAbsDutyCycle = newMaxAbsDutyCycle;
        return this;
    }
    
    /**
     * Modifies this Control Request's Deadband parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Deadband in Amperes.  If torque request is within deadband, the bridge output
     * is neutral. If deadband is set to zero then there is effectively no deadband.
     * Note if deadband is zero, a free spinning motor will spin for quite a while
     * as the firmware attempts to hold the motor's bemf. If user expects motor to
     * cease spinning quickly with a demand of zero, we recommend a deadband of one
     * Ampere. This value will be converted to an integral value of amps.
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     *
     * @param newDeadband Parameter to modify
     * @return Itself
     */
    public TorqueCurrentFOC withDeadband(double newDeadband) {
        Deadband = newDeadband;
        return this;
    }
    
    /**
     * Modifies this Control Request's Deadband parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Deadband in Amperes.  If torque request is within deadband, the bridge output
     * is neutral. If deadband is set to zero then there is effectively no deadband.
     * Note if deadband is zero, a free spinning motor will spin for quite a while
     * as the firmware attempts to hold the motor's bemf. If user expects motor to
     * cease spinning quickly with a demand of zero, we recommend a deadband of one
     * Ampere. This value will be converted to an integral value of amps.
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     *
     * @param newDeadband Parameter to modify
     * @return Itself
     */
    public TorqueCurrentFOC withDeadband(Current newDeadband) {
        Deadband = newDeadband.in(Amps);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's Deadband parameter converted
     * to a unit type. If not using the Java units library, {@link #Deadband}
     * can be accessed directly instead.
     * <p>
     * Deadband in Amperes.  If torque request is within deadband, the bridge output
     * is neutral. If deadband is set to zero then there is effectively no deadband.
     * Note if deadband is zero, a free spinning motor will spin for quite a while
     * as the firmware attempts to hold the motor's bemf. If user expects motor to
     * cease spinning quickly with a demand of zero, we recommend a deadband of one
     * Ampere. This value will be converted to an integral value of amps.
     * 
     * <ul>
     *   <li> Units: A
     * </ul>
     * 
     *
     * @return Deadband
     */
    public Current getDeadbandMeasure() {
        return Amps.of(Deadband);
    }
    
    /**
     * Modifies this Control Request's OverrideCoastDurNeutral parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to coast the rotor when output is zero (or within deadband).  Set
     * to false to use the NeutralMode configuration setting (default). This flag
     * exists to provide the fundamental behavior of this control when output is
     * zero, which is to provide 0A (zero torque).
     *
     * @param newOverrideCoastDurNeutral Parameter to modify
     * @return Itself
     */
    public TorqueCurrentFOC withOverrideCoastDurNeutral(boolean newOverrideCoastDurNeutral) {
        OverrideCoastDurNeutral = newOverrideCoastDurNeutral;
        return this;
    }
    
    /**
     * Modifies this Control Request's LimitForwardMotion parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to force forward limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     *
     * @param newLimitForwardMotion Parameter to modify
     * @return Itself
     */
    public TorqueCurrentFOC withLimitForwardMotion(boolean newLimitForwardMotion) {
        LimitForwardMotion = newLimitForwardMotion;
        return this;
    }
    
    /**
     * Modifies this Control Request's LimitReverseMotion parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to force reverse limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     *
     * @param newLimitReverseMotion Parameter to modify
     * @return Itself
     */
    public TorqueCurrentFOC withLimitReverseMotion(boolean newLimitReverseMotion) {
        LimitReverseMotion = newLimitReverseMotion;
        return this;
    }
    
    /**
     * Modifies this Control Request's IgnoreHardwareLimits parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to ignore hardware limit switches and the LimitForwardMotion and
     * LimitReverseMotion parameters, instead allowing motion.
     * <p>
     * This can be useful on mechanisms such as an intake/feeder, where a limit
     * switch stops motion while intaking but should be ignored when feeding to a
     * shooter.
     * <p>
     * The hardware limit faults and Forward/ReverseLimit signals will still report
     * the values of the limit switches regardless of this parameter.
     *
     * @param newIgnoreHardwareLimits Parameter to modify
     * @return Itself
     */
    public TorqueCurrentFOC withIgnoreHardwareLimits(boolean newIgnoreHardwareLimits) {
        IgnoreHardwareLimits = newIgnoreHardwareLimits;
        return this;
    }
    
    /**
     * Modifies this Control Request's IgnoreSoftwareLimits parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to ignore software limits, instead allowing motion.
     * <p>
     * This can be useful when calibrating the zero point of a mechanism such as an
     * elevator.
     * <p>
     * The software limit faults will still report the values of the software limits
     * regardless of this parameter.
     *
     * @param newIgnoreSoftwareLimits Parameter to modify
     * @return Itself
     */
    public TorqueCurrentFOC withIgnoreSoftwareLimits(boolean newIgnoreSoftwareLimits) {
        IgnoreSoftwareLimits = newIgnoreSoftwareLimits;
        return this;
    }
    
    /**
     * Modifies this Control Request's UseTimesync parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to delay applying this control request until a timesync boundary
     * (requires Phoenix Pro and CANivore). This eliminates the impact of
     * nondeterministic network delays in exchange for a larger but deterministic
     * control latency.
     * <p>
     * This requires setting the ControlTimesyncFreqHz config in MotorOutputConfigs.
     * Additionally, when this is enabled, the UpdateFreqHz of this request should
     * be set to 0 Hz.
     *
     * @param newUseTimesync Parameter to modify
     * @return Itself
     */
    public TorqueCurrentFOC withUseTimesync(boolean newUseTimesync) {
        UseTimesync = newUseTimesync;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public TorqueCurrentFOC withUpdateFreqHz(double newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public TorqueCurrentFOC withUpdateFreqHz(Frequency newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz.in(Hertz);
        return this;
    }

    @Override
    public TorqueCurrentFOC clone() {
        try {
            return (TorqueCurrentFOC)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

