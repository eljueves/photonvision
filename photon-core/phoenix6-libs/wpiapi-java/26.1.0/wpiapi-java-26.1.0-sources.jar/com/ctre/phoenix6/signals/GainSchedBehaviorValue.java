/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The behavior of the gain scheduler on this slot. This specifies which gains
 * to use while within the configured GainSchedErrorThreshold. The default is to
 * continue using the specified slot.
 * <p>
 * Gain scheduling will not take effect when running velocity closed-loop
 * controls.
 */
public enum GainSchedBehaviorValue
{
    /**
     * No gain scheduling will occur.
     */
    Inactive(0),
    /**
     * The output of the PID controller will be completely zeroed, except for kG and
     * the user FeedForward control request parameter.
     */
    ZeroOutput(1),
    /**
     * Switch to Slot 0 while within the configured GainSchedErrorThreshold.
     */
    UseSlot0(2),
    /**
     * Switch to Slot 1 while within the configured GainSchedErrorThreshold.
     */
    UseSlot1(3),
    /**
     * Switch to Slot 2 while within the configured GainSchedErrorThreshold.
     */
    UseSlot2(4),;

    public final int value;

    GainSchedBehaviorValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, GainSchedBehaviorValue> _map = null;
    static
    {
        _map = new HashMap<Integer, GainSchedBehaviorValue>();
        for (GainSchedBehaviorValue type : GainSchedBehaviorValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets GainSchedBehaviorValue from specified value
     * @param value Value of GainSchedBehaviorValue
     * @return GainSchedBehaviorValue of specified value
     */
    public static GainSchedBehaviorValue valueOf(int value)
    {
        GainSchedBehaviorValue retval = _map.get(value);
        if (retval != null) return retval;
        return GainSchedBehaviorValue.values()[0];
    }
}
