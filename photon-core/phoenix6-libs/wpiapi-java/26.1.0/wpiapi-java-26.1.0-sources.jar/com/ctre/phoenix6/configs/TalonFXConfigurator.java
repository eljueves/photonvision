/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.hardware.DeviceIdentifier;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Class description for the Talon FX integrated motor controller.
 *
 * This defines all configurations for the {@link com.ctre.phoenix6.hardware.TalonFX}.
 */
public class TalonFXConfigurator extends ParentConfigurator {
    public TalonFXConfigurator(DeviceIdentifier id) {
        super(id);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(TalonFXConfiguration configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(TalonFXConfiguration configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(TalonFXConfiguration configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(TalonFXConfiguration configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, configs.FutureProofConfigs, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(MotorOutputConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(MotorOutputConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(MotorOutputConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(MotorOutputConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CurrentLimitsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CurrentLimitsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CurrentLimitsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CurrentLimitsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(VoltageConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(VoltageConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(VoltageConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(VoltageConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(TorqueCurrentConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(TorqueCurrentConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(TorqueCurrentConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(TorqueCurrentConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(FeedbackConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(FeedbackConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(FeedbackConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(FeedbackConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(DifferentialSensorsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(DifferentialSensorsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(DifferentialSensorsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(DifferentialSensorsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(DifferentialConstantsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(DifferentialConstantsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(DifferentialConstantsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(DifferentialConstantsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(OpenLoopRampsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(OpenLoopRampsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(OpenLoopRampsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(OpenLoopRampsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(ClosedLoopRampsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(ClosedLoopRampsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(ClosedLoopRampsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(ClosedLoopRampsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(HardwareLimitSwitchConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(HardwareLimitSwitchConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(HardwareLimitSwitchConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(HardwareLimitSwitchConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(AudioConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(AudioConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(AudioConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(AudioConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(SoftwareLimitSwitchConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(SoftwareLimitSwitchConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(SoftwareLimitSwitchConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(SoftwareLimitSwitchConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(MotionMagicConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(MotionMagicConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(MotionMagicConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(MotionMagicConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CustomParamsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CustomParamsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CustomParamsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CustomParamsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(ClosedLoopGeneralConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(ClosedLoopGeneralConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(ClosedLoopGeneralConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(ClosedLoopGeneralConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(Slot0Configs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(Slot0Configs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(Slot0Configs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(Slot0Configs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(Slot1Configs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(Slot1Configs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(Slot1Configs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(Slot1Configs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(Slot2Configs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(Slot2Configs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(Slot2Configs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(Slot2Configs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(SlotConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(SlotConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(SlotConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(SlotConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }

    
    /**
     * Sets the mechanism position of the device in mechanism rotations.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(double newValue) {
        return setPosition(newValue, DefaultTimeoutSeconds);
    }
    /**
     * Sets the mechanism position of the device in mechanism rotations.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(double newValue, double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.TalonFX_SetSensorPosition.value, newValue);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Sets the mechanism position of the device in mechanism rotations.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(Angle newValue) {
        return setPosition(newValue.in(Rotations));
    }
    /**
     * Sets the mechanism position of the device in mechanism rotations.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(Angle newValue, double timeoutSeconds) {
        return setPosition(newValue.in(Rotations), timeoutSeconds);
    }
    
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults() {
        return clearStickyFaults(DefaultTimeoutSeconds);
    }
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.SPN_ClearStickyFaults.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware() {
        return clearStickyFault_Hardware(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_Hardware.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Processor temperature exceeded limit
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ProcTemp() {
        return clearStickyFault_ProcTemp(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Processor temperature exceeded limit
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ProcTemp(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_ProcTemp.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Device temperature exceeded limit
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_DeviceTemp() {
        return clearStickyFault_DeviceTemp(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Device temperature exceeded limit
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_DeviceTemp(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_DeviceTemp.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage() {
        return clearStickyFault_Undervoltage(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_Undervoltage.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable() {
        return clearStickyFault_BootDuringEnable(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_BootDuringEnable.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse() {
        return clearStickyFault_UnlicensedFeatureInUse(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_UnlicensedFeatureInUse.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Bridge was disabled most likely due to supply
     * voltage dropping too low.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BridgeBrownout() {
        return clearStickyFault_BridgeBrownout(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Bridge was disabled most likely due to supply
     * voltage dropping too low.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BridgeBrownout(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_BridgeBrownout.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: The remote sensor has reset.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_RemoteSensorReset() {
        return clearStickyFault_RemoteSensorReset(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: The remote sensor has reset.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_RemoteSensorReset(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_RemoteSensorReset.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: The remote Talon used for differential control
     * is not present on CAN Bus.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_MissingDifferentialFX() {
        return clearStickyFault_MissingDifferentialFX(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: The remote Talon used for differential control
     * is not present on CAN Bus.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_MissingDifferentialFX(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_MissingDifferentialFX.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: The remote sensor position has overflowed.
     * Because of the nature of remote sensors, it is possible for the
     * remote sensor position to overflow beyond what is supported by the
     * status signal frame. However, this is rare and cannot occur over
     * the course of an FRC match under normal use.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_RemoteSensorPosOverflow() {
        return clearStickyFault_RemoteSensorPosOverflow(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: The remote sensor position has overflowed.
     * Because of the nature of remote sensors, it is possible for the
     * remote sensor position to overflow beyond what is supported by the
     * status signal frame. However, this is rare and cannot occur over
     * the course of an FRC match under normal use.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_RemoteSensorPosOverflow(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_RemoteSensorPosOverflow.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Supply Voltage has exceeded the maximum voltage
     * rating of device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_OverSupplyV() {
        return clearStickyFault_OverSupplyV(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Supply Voltage has exceeded the maximum voltage
     * rating of device.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_OverSupplyV(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_OverSupplyV.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Supply Voltage is unstable.  Ensure you are
     * using a battery and current limited power supply.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnstableSupplyV() {
        return clearStickyFault_UnstableSupplyV(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Supply Voltage is unstable.  Ensure you are
     * using a battery and current limited power supply.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnstableSupplyV(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_UnstableSupplyV.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Reverse limit switch has been asserted.  Output
     * is set to neutral.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ReverseHardLimit() {
        return clearStickyFault_ReverseHardLimit(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Reverse limit switch has been asserted.  Output
     * is set to neutral.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ReverseHardLimit(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_ReverseHardLimit.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Forward limit switch has been asserted.  Output
     * is set to neutral.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ForwardHardLimit() {
        return clearStickyFault_ForwardHardLimit(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Forward limit switch has been asserted.  Output
     * is set to neutral.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ForwardHardLimit(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_ForwardHardLimit.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Reverse soft limit has been asserted.  Output
     * is set to neutral.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ReverseSoftLimit() {
        return clearStickyFault_ReverseSoftLimit(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Reverse soft limit has been asserted.  Output
     * is set to neutral.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ReverseSoftLimit(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_ReverseSoftLimit.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Forward soft limit has been asserted.  Output
     * is set to neutral.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ForwardSoftLimit() {
        return clearStickyFault_ForwardSoftLimit(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Forward soft limit has been asserted.  Output
     * is set to neutral.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_ForwardSoftLimit(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_ForwardSoftLimit.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: The remote soft limit device is not present on
     * CAN Bus.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_MissingSoftLimitRemote() {
        return clearStickyFault_MissingSoftLimitRemote(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: The remote soft limit device is not present on
     * CAN Bus.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_MissingSoftLimitRemote(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_MissingRemSoftLim.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: The remote limit switch device is not present
     * on CAN Bus.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_MissingHardLimitRemote() {
        return clearStickyFault_MissingHardLimitRemote(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: The remote limit switch device is not present
     * on CAN Bus.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_MissingHardLimitRemote(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_MissingRemHardLim.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: The remote sensor's data is no longer trusted.
     * This can happen if the remote sensor disappears from the CAN bus or
     * if the remote sensor indicates its data is no longer valid, such as
     * when a CANcoder's magnet strength falls into the "red" range.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_RemoteSensorDataInvalid() {
        return clearStickyFault_RemoteSensorDataInvalid(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: The remote sensor's data is no longer trusted.
     * This can happen if the remote sensor disappears from the CAN bus or
     * if the remote sensor indicates its data is no longer valid, such as
     * when a CANcoder's magnet strength falls into the "red" range.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_RemoteSensorDataInvalid(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_MissingRemoteSensor.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: The remote sensor used for fusion has fallen
     * out of sync to the local sensor. A re-synchronization has occurred,
     * which may cause a discontinuity. This typically happens if there is
     * significant slop in the mechanism, or if the RotorToSensorRatio
     * configuration parameter is incorrect.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_FusedSensorOutOfSync() {
        return clearStickyFault_FusedSensorOutOfSync(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: The remote sensor used for fusion has fallen
     * out of sync to the local sensor. A re-synchronization has occurred,
     * which may cause a discontinuity. This typically happens if there is
     * significant slop in the mechanism, or if the RotorToSensorRatio
     * configuration parameter is incorrect.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_FusedSensorOutOfSync(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_FusedSensorOutOfSync.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Stator current limit occured.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_StatorCurrLimit() {
        return clearStickyFault_StatorCurrLimit(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Stator current limit occured.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_StatorCurrLimit(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_StatorCurrLimit.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Supply current limit occured.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SupplyCurrLimit() {
        return clearStickyFault_SupplyCurrLimit(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Supply current limit occured.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_SupplyCurrLimit(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_SupplyCurrLimit.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Using Fused CANcoder feature while unlicensed.
     * Device has fallen back to remote CANcoder.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UsingFusedCANcoderWhileUnlicensed() {
        return clearStickyFault_UsingFusedCANcoderWhileUnlicensed(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Using Fused CANcoder feature while unlicensed.
     * Device has fallen back to remote CANcoder.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UsingFusedCANcoderWhileUnlicensed(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_UsingFusedCCWhileUnlicensed.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Static brake was momentarily disabled due to
     * excessive braking current while disabled.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_StaticBrakeDisabled() {
        return clearStickyFault_StaticBrakeDisabled(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Static brake was momentarily disabled due to
     * excessive braking current while disabled.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_StaticBrakeDisabled(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_TALONFX_StaticBrakeDisabled.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
}
