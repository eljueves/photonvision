/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The output mode of the PID controller.
 */
public enum PIDOutput_PIDOutputModeValue
{
    DutyCycle(0),
    Voltage(1),
    TorqueCurrentFOC(2),;

    public final int value;

    PIDOutput_PIDOutputModeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, PIDOutput_PIDOutputModeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, PIDOutput_PIDOutputModeValue>();
        for (PIDOutput_PIDOutputModeValue type : PIDOutput_PIDOutputModeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets PIDOutput_PIDOutputModeValue from specified value
     * @param value Value of PIDOutput_PIDOutputModeValue
     * @return PIDOutput_PIDOutputModeValue of specified value
     */
    public static PIDOutput_PIDOutputModeValue valueOf(int value)
    {
        PIDOutput_PIDOutputModeValue retval = _map.get(value);
        if (retval != null) return retval;
        return PIDOutput_PIDOutputModeValue.values()[0];
    }
}
