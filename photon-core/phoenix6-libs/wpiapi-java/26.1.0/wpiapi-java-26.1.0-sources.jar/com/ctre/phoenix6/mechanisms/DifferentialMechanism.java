/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.mechanisms;

import java.util.Optional;
import java.util.OptionalInt;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;

import edu.wpi.first.units.measure.*;
import edu.wpi.first.wpilibj.DriverStation;

import static edu.wpi.first.units.Units.*;

import com.ctre.phoenix6.BaseStatusSignal;
import com.ctre.phoenix6.CANBus;
import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.StatusSignal;
import com.ctre.phoenix6.configs.DifferentialSensorsConfigs;
import com.ctre.phoenix6.configs.MotorOutputConfigs;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.configs.TalonFXSConfiguration;
import com.ctre.phoenix6.controls.DifferentialFollower;
import com.ctre.phoenix6.controls.NeutralOut;
import com.ctre.phoenix6.controls.CoastOut;
import com.ctre.phoenix6.controls.StaticBrake;
import com.ctre.phoenix6.hardware.CANcoder;
import com.ctre.phoenix6.hardware.CANdi;
import com.ctre.phoenix6.hardware.Pigeon2;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.hardware.TalonFXS;
import com.ctre.phoenix6.hardware.traits.CommonTalon;
import com.ctre.phoenix6.mechanisms.DifferentialMotorConstants.*;
import com.ctre.phoenix6.signals.DifferentialSensorSourceValue;
import com.ctre.phoenix6.signals.InvertedValue;
import com.ctre.phoenix6.signals.MotorAlignmentValue;
import com.ctre.phoenix6.signals.NeutralModeValue;

import com.ctre.phoenix6.controls.ControlRequest;
import com.ctre.phoenix6.controls.DutyCycleOut;
import com.ctre.phoenix6.controls.MotionMagicDutyCycle;
import com.ctre.phoenix6.controls.MotionMagicExpoDutyCycle;
import com.ctre.phoenix6.controls.MotionMagicExpoTorqueCurrentFOC;
import com.ctre.phoenix6.controls.MotionMagicExpoVoltage;
import com.ctre.phoenix6.controls.MotionMagicTorqueCurrentFOC;
import com.ctre.phoenix6.controls.MotionMagicVelocityDutyCycle;
import com.ctre.phoenix6.controls.MotionMagicVelocityTorqueCurrentFOC;
import com.ctre.phoenix6.controls.MotionMagicVelocityVoltage;
import com.ctre.phoenix6.controls.MotionMagicVoltage;
import com.ctre.phoenix6.controls.PositionDutyCycle;
import com.ctre.phoenix6.controls.PositionTorqueCurrentFOC;
import com.ctre.phoenix6.controls.PositionVoltage;
import com.ctre.phoenix6.controls.TorqueCurrentFOC;
import com.ctre.phoenix6.controls.VelocityDutyCycle;
import com.ctre.phoenix6.controls.VelocityTorqueCurrentFOC;
import com.ctre.phoenix6.controls.VelocityVoltage;
import com.ctre.phoenix6.controls.VoltageOut;
import com.ctre.phoenix6.controls.compound.Diff_DutyCycleOut_Open;
import com.ctre.phoenix6.controls.compound.Diff_DutyCycleOut_Position;
import com.ctre.phoenix6.controls.compound.Diff_DutyCycleOut_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicDutyCycle_Open;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicDutyCycle_Position;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicDutyCycle_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicExpoDutyCycle_Open;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicExpoDutyCycle_Position;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicExpoDutyCycle_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicExpoTorqueCurrentFOC_Open;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicExpoTorqueCurrentFOC_Position;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicExpoTorqueCurrentFOC_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicExpoVoltage_Open;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicExpoVoltage_Position;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicExpoVoltage_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicTorqueCurrentFOC_Open;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicTorqueCurrentFOC_Position;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicTorqueCurrentFOC_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVelocityDutyCycle_Open;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVelocityDutyCycle_Position;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVelocityDutyCycle_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVelocityTorqueCurrentFOC_Open;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVelocityTorqueCurrentFOC_Position;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVelocityVoltage_Open;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVelocityVoltage_Position;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVelocityVoltage_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVoltage_Open;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVoltage_Position;
import com.ctre.phoenix6.controls.compound.Diff_MotionMagicVoltage_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_PositionDutyCycle_Open;
import com.ctre.phoenix6.controls.compound.Diff_PositionDutyCycle_Position;
import com.ctre.phoenix6.controls.compound.Diff_PositionDutyCycle_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_PositionTorqueCurrentFOC_Open;
import com.ctre.phoenix6.controls.compound.Diff_PositionTorqueCurrentFOC_Position;
import com.ctre.phoenix6.controls.compound.Diff_PositionTorqueCurrentFOC_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_PositionVoltage_Open;
import com.ctre.phoenix6.controls.compound.Diff_PositionVoltage_Position;
import com.ctre.phoenix6.controls.compound.Diff_PositionVoltage_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_TorqueCurrentFOC_Open;
import com.ctre.phoenix6.controls.compound.Diff_TorqueCurrentFOC_Position;
import com.ctre.phoenix6.controls.compound.Diff_TorqueCurrentFOC_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_VelocityDutyCycle_Open;
import com.ctre.phoenix6.controls.compound.Diff_VelocityDutyCycle_Position;
import com.ctre.phoenix6.controls.compound.Diff_VelocityDutyCycle_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_VelocityTorqueCurrentFOC_Open;
import com.ctre.phoenix6.controls.compound.Diff_VelocityTorqueCurrentFOC_Position;
import com.ctre.phoenix6.controls.compound.Diff_VelocityTorqueCurrentFOC_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_VelocityVoltage_Open;
import com.ctre.phoenix6.controls.compound.Diff_VelocityVoltage_Position;
import com.ctre.phoenix6.controls.compound.Diff_VelocityVoltage_Velocity;
import com.ctre.phoenix6.controls.compound.Diff_VoltageOut_Open;
import com.ctre.phoenix6.controls.compound.Diff_VoltageOut_Position;
import com.ctre.phoenix6.controls.compound.Diff_VoltageOut_Velocity;

/**
 * Manages control of a two-axis differential mechanism.
 * <p>
 * This mechanism requires the devices to be Pro licensed and
 * connected to a CAN FD bus. Unlicensed users and users on a CAN
 * 2.0 bus can use the {@link SimpleDifferentialMechanism} instead
 * with limited functionality.
 * <p>
 * A differential mechanism has two axes of motion, where the position
 * along each axis is determined by two motors in separate gearboxes:
 * <ul>
 *   <li>Driving both motors in a common direction causes the mechanism
 *       to move forward/reverse, up/down, etc.
 *   <ul>
 *     <li>This is the Average axis: position is determined by the
 *         average of the two motors' positions.
 *   </ul>
 *   <li>Driving the motors in opposing directions causes the mechanism
 *       to twist or rotate left/right.
 *   <ul>
 *     <li>This is the Difference axis: rotation is determined by half
 *         the difference of the two motors' positions.
 *   </ul>
 * </ul>
 */
public class DifferentialMechanism<MotorT extends CommonTalon> {
    /**
     * Functional interface for device constructors.
     */
    @FunctionalInterface
    public static interface DeviceConstructor<DeviceT> {
        DeviceT create(int id, CANBus canbus);
    }

    /**
     * Possible reasons for the mechanism to disable.
     */
    public enum DisabledReasonValue {
        /**
         * No reason given.
         */
        None,
        /**
         * A remote sensor is not present on CAN Bus.
         */
        MissingRemoteSensor,
        /**
         * The remote Talon FX used for differential
         * control is not present on CAN Bus.
         */
        MissingDifferentialFX,
        /**
         * A remote sensor position has overflowed. Because of the nature
         * of remote sensors, it is possible for a remote sensor position
         * to overflow beyond what is supported by the status signal frame.
         * However, this is rare and cannot occur over the course of an FRC
         * match under normal use.
         */
        RemoteSensorPosOverflow,
        /**
         * A device or remote sensor has reset.
         */
        DeviceHasReset,
    }

    /**
     * Possible reasons for the mechanism to require
     * user action to resume control.
     */
    public enum RequiresUserReasonValue {
        /**
         * No reason given.
         */
        None,
        /**
         * A remote sensor position has overflowed. Because of the nature
         * of remote sensors, it is possible for a remote sensor position
         * to overflow beyond what is supported by the status signal frame.
         * However, this is rare and cannot occur over the course of an FRC
         * match under normal use.
         */
        RemoteSensorPosOverflow,
        /**
         * A device or remote sensor has reset.
         */
        DeviceHasReset,
    }

    /** Number of times to attempt config applies. */
    private static final int kNumConfigAttempts = 2;

    private final MotorT _diffLeaderFX;
    private final MotorT _diffFollowerFX;

    private final double _sensorToDiffRatio;

    private final BooleanSupplier _diffLeaderFXResetChecker;
    private final BooleanSupplier _diffFollowerFXResetChecker;
    private final Optional<BooleanSupplier> _diffSensorResetChecker;

    private final DifferentialFollower _diffFollow;

    private final NeutralOut _neutral = new NeutralOut();
    private final CoastOut _coast = new CoastOut();
    private final StaticBrake _brake = new StaticBrake();

    private final AtomicBoolean _mechanismDisabled = new AtomicBoolean(false);
    private final AtomicBoolean _requiresUserAction = new AtomicBoolean(false);

    private DisabledReasonValue _disabledReason = DisabledReasonValue.None;
    private RequiresUserReasonValue _requiresUserReason = RequiresUserReasonValue.None;

    /**
     * Creates a new differential mechanism using two {@link CommonTalon} devices.
     * The mechanism will use the average of the two Talon FX sensors on the primary axis,
     * and half of the difference between the two Talon FX sensors on the differential axis.
     * <p>
     * This mechanism requires the devices to be Pro licensed and connected to a CAN FD bus.
     * Unlicensed users and users on a CAN 2.0 bus can use the {@link SimpleDifferentialMechanism}
     * instead with limited functionality.
     *
     * @param motorConstructor Constructor for the motors, such as {@code TalonFX::new}
     * @param constants Constants used to construct the mechanism
     */
    public DifferentialMechanism(DeviceConstructor<MotorT> motorConstructor, DifferentialMotorConstants<?> constants) {
        final var canbus = new CANBus(constants.CANBusName);
        _diffLeaderFX = motorConstructor.create(constants.LeaderId, canbus);
        _diffFollowerFX = motorConstructor.create(constants.FollowerId, canbus);
        _sensorToDiffRatio = constants.SensorToDifferentialRatio;
        _diffLeaderFXResetChecker = _diffLeaderFX.getResetOccurredChecker();
        _diffFollowerFXResetChecker = _diffFollowerFX.getResetOccurredChecker();
        _diffFollow = new DifferentialFollower(_diffLeaderFX.getDeviceID(), constants.Alignment);
        _diffSensorResetChecker = Optional.empty();

        applyConfigs(constants, DifferentialSensorSourceValue.RemoteTalonFX_HalfDiff, OptionalInt.empty());
        /* Set update frequency of relevant signals */
        BaseStatusSignal.setUpdateFrequencyForAll(
            constants.ClosedLoopRate,
            _diffLeaderFX.getDifferentialOutput(false),
            _diffFollowerFX.getPosition(false),
            _diffFollowerFX.getVelocity(false)
        );
    }

    /**
     * Creates a new differential mechanism using two {@link CommonTalon} devices and
     * a {@link Pigeon2}. The mechanism will use the average of the two Talon FX sensors on the
     * primary axis, and the selected Pigeon 2 sensor source on the differential axis.
     * <p>
     * This mechanism requires the devices to be Pro licensed and connected to a CAN FD bus.
     * Unlicensed users and users on a CAN 2.0 bus can use the {@link SimpleDifferentialMechanism}
     * instead with limited functionality.
     *
     * @param motorConstructor Constructor for the motors, such as {@code TalonFX::new}
     * @param constants Constants used to construct the mechanism
     * @param pigeon2 The Pigeon 2 to use for the differential axis
     * @param pigeonSource The sensor source to use for the Pigeon 2 (Yaw, Pitch, or Roll)
     */
    public DifferentialMechanism(DeviceConstructor<MotorT> motorConstructor, DifferentialMotorConstants<?> constants, Pigeon2 pigeon2, DifferentialPigeon2Source pigeonSource) {
        final var canbus = new CANBus(constants.CANBusName);
        _diffLeaderFX = motorConstructor.create(constants.LeaderId, canbus);
        _diffFollowerFX = motorConstructor.create(constants.FollowerId, canbus);
        _sensorToDiffRatio = constants.SensorToDifferentialRatio;
        _diffLeaderFXResetChecker = _diffLeaderFX.getResetOccurredChecker();
        _diffFollowerFXResetChecker = _diffFollowerFX.getResetOccurredChecker();
        _diffSensorResetChecker = Optional.of(pigeon2.getResetOccurredChecker());
        _diffFollow = new DifferentialFollower(_diffLeaderFX.getDeviceID(), constants.Alignment);

        DifferentialSensorSourceValue diffSensorSource;
        switch (pigeonSource) {
            case Yaw:
            default:
                diffSensorSource = DifferentialSensorSourceValue.RemotePigeon2Yaw;
                break;
            case Pitch:
                diffSensorSource = DifferentialSensorSourceValue.RemotePigeon2Pitch;
                break;
            case Roll:
                diffSensorSource = DifferentialSensorSourceValue.RemotePigeon2Roll;
                break;
        }
        applyConfigs(constants, diffSensorSource, OptionalInt.of(pigeon2.getDeviceID()));

        /* Set update frequency of relevant signals */
        BaseStatusSignal.setUpdateFrequencyForAll(
            constants.ClosedLoopRate,
            _diffLeaderFX.getDifferentialOutput(false),
            _diffFollowerFX.getPosition(false),
            _diffFollowerFX.getVelocity(false)
        );
        switch (pigeonSource) {
            case Yaw:
                pigeon2.getYaw(false).setUpdateFrequency(constants.ClosedLoopRate);
                break;
            case Pitch:
                pigeon2.getPitch(false).setUpdateFrequency(constants.ClosedLoopRate);
                break;
            case Roll:
                pigeon2.getRoll(false).setUpdateFrequency(constants.ClosedLoopRate);
                break;
        }
    }

    /**
     * Creates a new differential mechanism using two {@link CommonTalon} devices and
     * a {@link CANcoder}. The mechanism will use the average of the two Talon FX sensors on the
     * primary axis, and the CANcoder position/velocity on the differential axis.
     * <p>
     * This mechanism requires the devices to be Pro licensed and connected to a CAN FD bus.
     * Unlicensed users and users on a CAN 2.0 bus can use the {@link SimpleDifferentialMechanism}
     * instead with limited functionality.
     *
     * @param motorConstructor Constructor for the motors, such as {@code TalonFX::new}
     * @param constants Constants used to construct the mechanism
     * @param cancoder The CANcoder to use for the differential axis
     */
    public DifferentialMechanism(DeviceConstructor<MotorT> motorConstructor, DifferentialMotorConstants<?> constants, CANcoder cancoder) {
        final var canbus = new CANBus(constants.CANBusName);
        _diffLeaderFX = motorConstructor.create(constants.LeaderId, canbus);
        _diffFollowerFX = motorConstructor.create(constants.FollowerId, canbus);
        _sensorToDiffRatio = constants.SensorToDifferentialRatio;
        _diffLeaderFXResetChecker = _diffLeaderFX.getResetOccurredChecker();
        _diffFollowerFXResetChecker = _diffFollowerFX.getResetOccurredChecker();
        _diffSensorResetChecker = Optional.of(cancoder.getResetOccurredChecker());
        _diffFollow = new DifferentialFollower(_diffLeaderFX.getDeviceID(), constants.Alignment);

        applyConfigs(constants, DifferentialSensorSourceValue.RemoteCANcoder, OptionalInt.of(cancoder.getDeviceID()));
        /* Set update frequency of relevant signals */
        BaseStatusSignal.setUpdateFrequencyForAll(
            constants.ClosedLoopRate,
            _diffLeaderFX.getDifferentialOutput(false),
            _diffFollowerFX.getPosition(false),
            _diffFollowerFX.getVelocity(false),
            cancoder.getPosition(false),
            cancoder.getVelocity(false)
        );
    }

    /**
     * Creates a new differential mechanism using two {@link CommonTalon} devices and a
     * {@link CANdi}. The mechanism will use the average of the two Talon FX sensors on the primary
     * axis, and the selected CTR Electronics' CANdi™ branded sensor source on the differential axis.
     * <p>
     * This mechanism requires the devices to be Pro licensed and connected to a CAN FD bus.
     * Unlicensed users and users on a CAN 2.0 bus can use the {@link SimpleDifferentialMechanism}
     * instead with limited functionality.
     *
     * @param motorConstructor Constructor for the motors, such as {@code TalonFX::new}
     * @param constants Constants used to construct the mechanism
     * @param candi The CTR Electronics' CANdi™ branded device to use for the differential axis
     * @param candiSource The sensor source to use for the CTR Electronics' CANdi™ branded device
     */
    public DifferentialMechanism(DeviceConstructor<MotorT> motorConstructor, DifferentialMotorConstants<?> constants, CANdi candi, DifferentialCANdiSource candiSource) {
        final var canbus = new CANBus(constants.CANBusName);
        _diffLeaderFX = motorConstructor.create(constants.LeaderId, canbus);
        _diffFollowerFX = motorConstructor.create(constants.FollowerId, canbus);
        _sensorToDiffRatio = constants.SensorToDifferentialRatio;
        _diffLeaderFXResetChecker = _diffLeaderFX.getResetOccurredChecker();
        _diffFollowerFXResetChecker = _diffFollowerFX.getResetOccurredChecker();
        _diffSensorResetChecker = Optional.of(candi.getResetOccurredChecker());
        _diffFollow = new DifferentialFollower(_diffLeaderFX.getDeviceID(), constants.Alignment);

        DifferentialSensorSourceValue diffSensorSource;
        switch (candiSource) {
            case PWM1:
            default:
                diffSensorSource = DifferentialSensorSourceValue.RemoteCANdiPWM1;
                break;
            case PWM2:
                diffSensorSource = DifferentialSensorSourceValue.RemoteCANdiPWM2;
                break;
            case Quadrature:
                diffSensorSource = DifferentialSensorSourceValue.RemoteCANdiQuadrature;
                break;
        }
        applyConfigs(constants, diffSensorSource, OptionalInt.of(candi.getDeviceID()));

        /* Set update frequency of relevant signals */
        BaseStatusSignal.setUpdateFrequencyForAll(
            constants.ClosedLoopRate,
            _diffLeaderFX.getDifferentialOutput(false),
            _diffFollowerFX.getPosition(false),
            _diffFollowerFX.getVelocity(false)
        );
        switch (candiSource) {
            case PWM1:
                BaseStatusSignal.setUpdateFrequencyForAll(
                    constants.ClosedLoopRate,
                    candi.getPWM1Position(false),
                    candi.getPWM1Velocity(false)
                );
                break;
            case PWM2:
                BaseStatusSignal.setUpdateFrequencyForAll(
                    constants.ClosedLoopRate,
                    candi.getPWM2Position(false),
                    candi.getPWM2Velocity(false)
                );
                break;
            case Quadrature:
                BaseStatusSignal.setUpdateFrequencyForAll(
                    constants.ClosedLoopRate,
                    candi.getQuadraturePosition(false),
                    candi.getQuadratureVelocity(false)
                );
                break;
        }
    }

    private void applyConfigs(DifferentialMotorConstants<?> constants, DifferentialSensorSourceValue diffSensorSource, OptionalInt diffSensorID) {
        /*
         * The onboard differential controller adds the differential output to its own output
         * and subtracts the differential output for differential followers, so use _diffLeaderFX
         * as the primary controller.
         */

        InvertedValue leaderInvert;

        /* set up differential control on _diffLeaderFX */
        {
            var diff_cfg = new DifferentialSensorsConfigs();

            diff_cfg.DifferentialTalonFXSensorID = _diffFollowerFX.getDeviceID();
            diff_cfg.DifferentialSensorSource = diffSensorSource;
            diffSensorID.ifPresent(id -> diff_cfg.DifferentialRemoteSensorID = id);
            diff_cfg.SensorToDifferentialRatio = constants.SensorToDifferentialRatio;

            StatusCode response = StatusCode.OK;

            if (
                _diffLeaderFX instanceof TalonFX diffLeaderFX &&
                (constants.LeaderInitialConfigs == null || constants.LeaderInitialConfigs instanceof TalonFXConfiguration)
            ) {
                var leaderConfigs = (TalonFXConfiguration)constants.LeaderInitialConfigs;
                if (leaderConfigs == null) {
                    leaderConfigs = new TalonFXConfiguration();
                }
                leaderInvert = leaderConfigs.MotorOutput.Inverted;

                leaderConfigs.DifferentialSensors = diff_cfg;
                for (int i = 0; i < kNumConfigAttempts; ++i) {
                    response = diffLeaderFX.getConfigurator().apply(leaderConfigs);
                    if (response.isOK()) break;
                }
            } else if (
                _diffLeaderFX instanceof TalonFXS diffLeaderFXS &&
                (constants.LeaderInitialConfigs == null || constants.LeaderInitialConfigs instanceof TalonFXSConfiguration)
            ) {
                var leaderConfigs = (TalonFXSConfiguration)constants.LeaderInitialConfigs;
                if (leaderConfigs == null) {
                    leaderConfigs = new TalonFXSConfiguration();
                }
                leaderInvert = leaderConfigs.MotorOutput.Inverted;

                leaderConfigs.DifferentialSensors = diff_cfg;
                for (int i = 0; i < kNumConfigAttempts; ++i) {
                    response = diffLeaderFXS.getConfigurator().apply(leaderConfigs);
                    if (response.isOK()) break;
                }
            } else {
                DriverStation.reportError(
                    "[phoenix] DifferentialMechanism motor type does not match the DifferentialMotorConstants initial configs type. Ensure that the DifferentialMechanism and DifferentialMotorConstants instances are both constructed with the same motor type (TalonFX/TalonFXConfiguration, TalonFXS/TalonFXSConfiguration, etc.).",
                    true
                );
                return;
            }

            if (!response.isOK()) {
                System.out.println(
                    "Talon ID " + _diffLeaderFX.getDeviceID() + " failed config with error " + response.toString()
                );
            }
        }

        /* disable differential control on _diffFollowerFX */
        {
            StatusCode response = StatusCode.OK;

            if (_diffFollowerFX instanceof TalonFX diffFollowerFX) {
                var followerConfigs = (TalonFXConfiguration)constants.FollowerInitialConfigs;
                if (followerConfigs == null) {
                    followerConfigs = new TalonFXConfiguration();
                }
                followerConfigs.DifferentialSensors = new DifferentialSensorsConfigs();
                followerConfigs.MotorOutput.Inverted = constants.Alignment == MotorAlignmentValue.Aligned
                    ? leaderInvert
                    : leaderInvert == InvertedValue.CounterClockwise_Positive
                        ? InvertedValue.Clockwise_Positive
                        : InvertedValue.CounterClockwise_Positive;

                if (constants.FollowerUsesCommonLeaderConfigs) {
                    /* copy over common config groups from the leader */
                    var leaderConfigs = (TalonFXConfiguration)constants.LeaderInitialConfigs;
                    if (leaderConfigs == null) {
                        leaderConfigs = new TalonFXConfiguration();
                    }

                    followerConfigs.Audio = leaderConfigs.Audio;
                    followerConfigs.CurrentLimits = leaderConfigs.CurrentLimits;
                    followerConfigs.MotorOutput = leaderConfigs.MotorOutput.clone()
                        .withInverted(followerConfigs.MotorOutput.Inverted);
                    followerConfigs.Voltage = leaderConfigs.Voltage;
                    followerConfigs.TorqueCurrent = leaderConfigs.TorqueCurrent;
                }

                for (int i = 0; i < kNumConfigAttempts; ++i) {
                    response = diffFollowerFX.getConfigurator().apply(followerConfigs);
                    if (response.isOK()) break;
                }
            } else if (_diffFollowerFX instanceof TalonFXS diffFollowerFXS) {
                var followerConfigs = (TalonFXSConfiguration)constants.FollowerInitialConfigs;
                if (followerConfigs == null) {
                    followerConfigs = new TalonFXSConfiguration();
                }
                followerConfigs.DifferentialSensors = new DifferentialSensorsConfigs();
                followerConfigs.MotorOutput.Inverted = constants.Alignment == MotorAlignmentValue.Aligned
                    ? leaderInvert
                    : leaderInvert == InvertedValue.CounterClockwise_Positive
                        ? InvertedValue.Clockwise_Positive
                        : InvertedValue.CounterClockwise_Positive;

                if (constants.FollowerUsesCommonLeaderConfigs) {
                    /* copy over common config groups from the leader */
                    var leaderConfigs = (TalonFXSConfiguration)constants.LeaderInitialConfigs;
                    if (leaderConfigs == null) {
                        leaderConfigs = new TalonFXSConfiguration();
                    }

                    followerConfigs.Audio = leaderConfigs.Audio;
                    followerConfigs.CurrentLimits = leaderConfigs.CurrentLimits;
                    followerConfigs.MotorOutput = leaderConfigs.MotorOutput.clone()
                        .withInverted(followerConfigs.MotorOutput.Inverted);
                    followerConfigs.Voltage = leaderConfigs.Voltage;
                }

                for (int i = 0; i < kNumConfigAttempts; ++i) {
                    response = diffFollowerFXS.getConfigurator().apply(followerConfigs);
                    if (response.isOK()) break;
                }
            } else {
                DriverStation.reportError(
                    "[phoenix] DifferentialMechanism motor type does not match the DifferentialMotorConstants initial configs type. Ensure that the DifferentialMechanism and DifferentialMotorConstants instances are both constructed with the same motor type (TalonFX/TalonFXConfiguration, TalonFXS/TalonFXSConfiguration, etc.).",
                    true
                );
                return;
            }

            if (!response.isOK()) {
                System.out.println(
                    "Talon ID " + _diffFollowerFX.getDeviceID() + " failed config with error " + response.toString()
                );
            }
        }
    }

    private StatusCode configNeutralModeImpl(MotorT motor, NeutralModeValue neutralMode, double timeoutSeconds) {
        StatusCode status = StatusCode.OK;

        var motorOutCfg = new MotorOutputConfigs();
        if (motor instanceof TalonFX motorFX) {
            /* First read the configs so they're up-to-date */
            status = motorFX.getConfigurator().refresh(motorOutCfg, timeoutSeconds);
            if (status.isOK()) {
                /* Then set the neutral mode config to the appropriate value */
                motorOutCfg.NeutralMode = neutralMode;
                status = motorFX.getConfigurator().apply(motorOutCfg, timeoutSeconds);
            }
        } else if (motor instanceof TalonFXS motorFXS) {
            /* First read the configs so they're up-to-date */
            status = motorFXS.getConfigurator().refresh(motorOutCfg, timeoutSeconds);
            if (status.isOK()) {
                /* Then set the neutral mode config to the appropriate value */
                motorOutCfg.NeutralMode = neutralMode;
                status = motorFXS.getConfigurator().apply(motorOutCfg, timeoutSeconds);
            }
        }

        if (!status.isOK()) {
            System.out.println(
                "Talon ID " + motor.getDeviceID() + " failed config with error " + status.toString()
            );
        }
        return status;
    }

    /**
     * Configures the neutral mode to use for both motors in the mechanism.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     *
     * @param neutralMode The state of the motor controller bridge when output is neutral or disabled
     * @return Status code of the first failed config call, or OK if all succeeded
     */
    public final StatusCode configNeutralMode(NeutralModeValue neutralMode) {
        return configNeutralMode(neutralMode, 0.100);
    }

    /**
     * Configures the neutral mode to use for both motors in the mechanism.
     *
     * @param neutralMode The state of the motor controller bridge when output is neutral or disabled
     * @param timeoutSeconds Maximum amount of time to wait when performing each configuration
     * @return Status code of the first failed config call, or OK if all succeeded
     */
    public final StatusCode configNeutralMode(NeutralModeValue neutralMode, double timeoutSeconds) {
        StatusCode retval = StatusCode.OK;
        {
            final var status = configNeutralModeImpl(_diffLeaderFX, neutralMode, timeoutSeconds);
            if (retval.isOK()) retval = status;
        }
        {
            final var status = configNeutralModeImpl(_diffFollowerFX, neutralMode, timeoutSeconds);
            if (retval.isOK()) retval = status;
        }
        return retval;
    }

    /**
     * Call this method periodically to automatically protect against dangerous
     * fault conditions and keep {@link #getMechanismState()} updated.
     */
    public final void periodic() {
        StatusCode retval = StatusCode.OK;

        /* handle remote sensor position overflow fault */
        if (_diffLeaderFX.getFault_RemoteSensorPosOverflow().getValue()) {
            /* fault the mechanism until the user clears it manually */
            _requiresUserReason = RequiresUserReasonValue.RemoteSensorPosOverflow;
            _requiresUserAction.setRelease(true);

            _disabledReason = DisabledReasonValue.RemoteSensorPosOverflow;
            retval = StatusCode.MechanismFaulted;
        }

        /* handle missing remote sensor fault */
        if (_diffLeaderFX.getFault_RemoteSensorDataInvalid().getValue() ||
            _diffFollowerFX.getFault_RemoteSensorDataInvalid().getValue()
        ) {
            /* temporarily fault the mechanism while the fault is active */
            _disabledReason = DisabledReasonValue.MissingRemoteSensor;
            retval = StatusCode.MechanismFaulted;
        }
        /* handle missing differential Talon FX fault */
        if (_diffLeaderFX.getFault_MissingDifferentialFX().getValue()) {
            /* temporarily fault the mechanism while the fault is active */
            _disabledReason = DisabledReasonValue.MissingDifferentialFX;
            retval = StatusCode.MechanismFaulted;
        }

        /* handle if any of the devices have power cycled */
        final boolean diffLeaderFX_hasReset = _diffLeaderFXResetChecker.getAsBoolean();
        final boolean diffFollowerFX_hasReset = _diffFollowerFXResetChecker.getAsBoolean();
        final boolean diffSensor_hasReset = _diffSensorResetChecker.isPresent() && _diffSensorResetChecker.get().getAsBoolean();
        final boolean diffLeaderFX_remsens_hasReset = _diffLeaderFX.getStickyFault_RemoteSensorReset().getValue();
        final boolean diffFollowerFX_remsens_hasReset = _diffFollowerFX.getStickyFault_RemoteSensorReset().getValue();

        if (diffLeaderFX_hasReset || diffFollowerFX_hasReset || diffSensor_hasReset ||
            diffLeaderFX_remsens_hasReset || diffFollowerFX_remsens_hasReset
        ) {
            /* fault the mechanism until the user clears it manually */
            _requiresUserReason = RequiresUserReasonValue.DeviceHasReset;
            _requiresUserAction.setRelease(true);

            _disabledReason = DisabledReasonValue.DeviceHasReset;
            retval = StatusCode.MechanismFaulted;
        }

        if (retval.isOK() && _requiresUserAction.getOpaque()) {
            /* keep the mechanism faulted until user clears the fault */
            retval = StatusCode.MechanismFaulted;
        }

        if (!retval.isOK()) {
            /* disable the mechanism */
            _mechanismDisabled.setRelease(true);
        } else {
            /* re-enable the mechanism */
            _disabledReason = DisabledReasonValue.None;
            _mechanismDisabled.setRelease(false);
        }
    }

    /**
     * Get whether the mechanism is currently disabled due to an issue.
     *
     * @return true if the mechanism is temporarily disabled
     */
    public final boolean isDisabled() {
        return _mechanismDisabled.getAcquire();
    }

    /**
     * Get whether the mechanism is currently disabled and requires
     * user action to re-enable mechanism control.
     *
     * @return true if the mechanism is disabled and the user must manually
     *         perform an action
     */
    public final boolean requiresUserAction() {
        return _requiresUserAction.getAcquire();
    }

    /**
     * Gets the state of the mechanism.
     *
     * @return MechanismState representing the state of the mechanism
     */
    public final MechanismState getMechanismState() {
        if (requiresUserAction()) {
            return MechanismState.RequiresUserAction;
        } else if (isDisabled()) {
            return MechanismState.Disabled;
        } else {
            return MechanismState.OK;
        }
    }

    /**
     * Indicate to the mechanism that the user has performed the required
     * action to resume mechanism control.
     */
    public final void clearUserRequirement() {
        if (_diffLeaderFX.getStickyFault_RemoteSensorReset().getValue()) {
            _diffLeaderFX.clearStickyFault_RemoteSensorReset();
        }
        if (_diffFollowerFX.getStickyFault_RemoteSensorReset().getValue()) {
            _diffFollowerFX.clearStickyFault_RemoteSensorReset();
        }
        _requiresUserReason = RequiresUserReasonValue.None;
        _requiresUserAction.setRelease(false);
    }

    /**
     * @return The reason for the mechanism being disabled
     */
    public final DisabledReasonValue getDisabledReason() {
        return _disabledReason;
    }
    /**
     * @return The reason for the mechanism requiring user
     *         action to resume control
     */
    public final RequiresUserReasonValue getRequiresUserReason() {
        return _requiresUserReason;
    }

    /**
     * Average component of the mechanism position.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialAveragePosition Status Signal Object
     */
    public final StatusSignal<Angle> getAveragePosition() {
        return getAveragePosition(true);
    }
    /**
     * Average component of the mechanism position.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it; defaults to true
     * @return DifferentialAveragePosition Status Signal Object
     */
    public final StatusSignal<Angle> getAveragePosition(boolean refresh) {
        return _diffLeaderFX.getDifferentialAveragePosition(refresh);
    }

    /**
     * Average component of the mechanism velocity.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialAverageVelocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAverageVelocity() {
        return getAverageVelocity(true);
    }
    /**
     * Average component of the mechanism velocity.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it; defaults to true
     * @return DifferentialAverageVelocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getAverageVelocity(boolean refresh) {
        return _diffLeaderFX.getDifferentialAverageVelocity(refresh);
    }

    /**
     * Differential component of the mechanism position.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialDifferencePosition Status Signal Object
     */
    public final StatusSignal<Angle> getDifferentialPosition() {
        return getDifferentialPosition(true);
    }
    /**
     * Differential component of the mechanism position.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it; defaults to true
     * @return DifferentialDifferencePosition Status Signal Object
     */
    public final StatusSignal<Angle> getDifferentialPosition(boolean refresh) {
        return _diffLeaderFX.getDifferentialDifferencePosition(refresh);
    }

    /**
     * Differential component of the mechanism velocity.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialDifferenceVelocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getDifferentialVelocity() {
        return getDifferentialVelocity(true);
    }
    /**
     * Differential component of the mechanism velocity.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it; defaults to true
     * @return DifferentialDifferenceVelocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getDifferentialVelocity(boolean refresh) {
        return _diffLeaderFX.getDifferentialDifferenceVelocity(refresh);
    }

    /**
     * Value that the average closed loop is targeting.
     * <p>
     * This is the value that the closed loop PID controller targets.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopReference Status Signal object
     */
    public final StatusSignal<Double> getAverageClosedLoopReference() {
        return getAverageClosedLoopReference(true);
    }
    /**
     * Value that the average closed loop is targeting.
     * <p>
     * This is the value that the closed loop PID controller targets.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it; defaults to true
     * @return ClosedLoopReference Status Signal object
     */
    public final StatusSignal<Double> getAverageClosedLoopReference(boolean refresh) {
        return _diffLeaderFX.getClosedLoopReference(refresh);
    }

    /**
     * Derivative of the target that the average closed loop is targeting.
     * <p>
     * This is the change in the closed loop reference. This may be used
     * in the feed-forward calculation, the derivative-error, or in
     * application of the signage for kS. Typically, this represents the
     * target velocity during Motion Magic®.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopReferenceSlope Status Signal object
     */
    public final StatusSignal<Double> getAverageClosedLoopReferenceSlope() {
        return getAverageClosedLoopReferenceSlope(true);
    }
    /**
     * Derivative of the target that the average closed loop is targeting.
     * <p>
     * This is the change in the closed loop reference. This may be used
     * in the feed-forward calculation, the derivative-error, or in
     * application of the signage for kS. Typically, this represents the
     * target velocity during Motion Magic®.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it; defaults to true
     * @return ClosedLoopReferenceSlope Status Signal object
     */
    public final StatusSignal<Double> getAverageClosedLoopReferenceSlope(boolean refresh) {
        return _diffLeaderFX.getClosedLoopReferenceSlope(refresh);
    }

    /**
     * The difference between target average reference and current measurement.
     * <p>
     * This is the value that is treated as the error in the PID loop.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopError Status Signal object
     */
    public final StatusSignal<Double> getAverageClosedLoopError() {
        return getAverageClosedLoopError(true);
    }
    /**
     * The difference between target average reference and current measurement.
     * <p>
     * This is the value that is treated as the error in the PID loop.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it; defaults to true
     * @return ClosedLoopError Status Signal object
     */
    public final StatusSignal<Double> getAverageClosedLoopError(boolean refresh) {
        return _diffLeaderFX.getClosedLoopError(refresh);
    }

    /**
     * Value that the differential closed loop is targeting.
     * <p>
     * This is the value that the differential closed loop PID controller
     * targets (on the difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopReference Status Signal object
     */
    public final StatusSignal<Double> getDifferentialClosedLoopReference() {
        return getDifferentialClosedLoopReference(true);
    }
    /**
     * Value that the differential closed loop is targeting.
     * <p>
     * This is the value that the differential closed loop PID controller
     * targets (on the difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it; defaults to true
     * @return DifferentialClosedLoopReference Status Signal object
     */
    public final StatusSignal<Double> getDifferentialClosedLoopReference(boolean refresh) {
        return _diffLeaderFX.getDifferentialClosedLoopReference(refresh);
    }

    /**
     * Derivative of the target that the differential closed loop is
     * targeting.
     * <p>
     * This is the change in the closed loop reference (on the difference
     * axis). This may be used in the feed-forward calculation, the
     * derivative-error, or in application of the signage for kS.
     * Typically, this represents the target velocity during Motion
     * Magic®.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopReferenceSlope Status Signal object
     */
    public final StatusSignal<Double> getDifferentialClosedLoopReferenceSlope() {
        return getDifferentialClosedLoopReferenceSlope(true);
    }
    /**
     * Derivative of the target that the differential closed loop is
     * targeting.
     * <p>
     * This is the change in the closed loop reference (on the difference
     * axis). This may be used in the feed-forward calculation, the
     * derivative-error, or in application of the signage for kS.
     * Typically, this represents the target velocity during Motion
     * Magic®.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it; defaults to true
     * @return DifferentialClosedLoopReferenceSlope Status Signal object
     */
    public final StatusSignal<Double> getDifferentialClosedLoopReferenceSlope(boolean refresh) {
        return _diffLeaderFX.getDifferentialClosedLoopReferenceSlope(refresh);
    }

    /**
     * The difference between target differential reference and current
     * measurement.
     * <p>
     * This is the value that is treated as the error in the differential
     * PID loop (on the difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopError Status Signal object
     */
    public final StatusSignal<Double> getDifferentialClosedLoopError() {
        return getDifferentialClosedLoopError(true);
    }
    /**
     * The difference between target differential reference and current
     * measurement.
     * <p>
     * This is the value that is treated as the error in the differential
     * PID loop (on the difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it; defaults to true
     * @return DifferentialClosedLoopError Status Signal object
     */
    public final StatusSignal<Double> getDifferentialClosedLoopError(boolean refresh) {
        return _diffLeaderFX.getDifferentialClosedLoopError(refresh);
    }

    /**
     * Sets the position of the mechanism in rotations, assuming a differential
     * position of 0 rotations.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     *
     * @param avgPosition The average position of the mechanism, in rotations
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(double avgPosition) {
        return setPosition(avgPosition, 0.0, 0.100);
    }
    /**
     * Sets the position of the mechanism in rotations.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     *
     * @param avgPosition The average position of the mechanism, in rotations
     * @param diffPosition The differential position of the mechanism, in rotations
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(double avgPosition, double diffPosition) {
        return setPosition(avgPosition, diffPosition, 0.100);
    }
    /**
     * Sets the position of the mechanism in rotations.
     *
     * @param avgPosition The average position of the mechanism, in rotations
     * @param diffPosition The differential position of the mechanism, in rotations
     * @param timeoutSeconds Maximum time to wait up to in seconds
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(double avgPosition, double diffPosition, double timeoutSeconds) {
        var retval = StatusCode.OK;

        var response = _diffLeaderFX.setPosition(avgPosition + diffPosition * _sensorToDiffRatio, timeoutSeconds);
        if (retval.isOK()) retval = response;
        response = _diffFollowerFX.setPosition(avgPosition - diffPosition * _sensorToDiffRatio, timeoutSeconds);
        if (retval.isOK()) retval = response;

        return retval;
    }

    /**
     * Sets the position of the mechanism, assuming a differential
     * position of 0 rotations.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     *
     * @param avgPosition The average position of the mechanism
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(Angle avgPosition) {
        return setPosition(avgPosition.in(Rotations));
    }
    /**
     * Sets the position of the mechanism.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     *
     * @param avgPosition The average position of the mechanism
     * @param diffPosition The differential position of the mechanism
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(Angle avgPosition, Angle diffPosition) {
        return setPosition(avgPosition.in(Rotations), diffPosition.in(Rotations));
    }
    /**
     * Sets the position of the mechanism.
     *
     * @param avgPosition The average position of the mechanism
     * @param diffPosition The differential position of the mechanism
     * @param timeoutSeconds Maximum time to wait up to in seconds
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(Angle avgPosition, Angle diffPosition, double timeoutSeconds) {
        return setPosition(avgPosition.in(Rotations), diffPosition.in(Rotations), timeoutSeconds);
    }

    /**
     * Get the Talon FX that is differential leader. The differential
     * leader calculates the output for the differential follower. The
     * differential leader is also useful for fault detection, and it
     * reports status signals for the differential controller.
     *
     * @return Differential leader Talon FX
     */
    public final MotorT getLeader() {
        return _diffLeaderFX;
    }

    /**
     * Get the Talon FX that is differential follower. The differential
     * follower's position and velocity are used by the differential leader
     * for the differential controller.
     *
     * @return Differential follower Talon FX
     */
    public final MotorT getFollower() {
        return _diffFollowerFX;
    }

    private StatusCode beforeControl() {
        StatusCode retval = StatusCode.OK;
        if (_mechanismDisabled.getOpaque()) {
            /* disable the mechanism */
            retval = StatusCode.MechanismFaulted;
        }

        if (!retval.isOK()) {
            /* neutral the output */
            setNeutralOut();
        }
        return retval;
    }

    /**
     * Request neutral output of mechanism. The applied brake type
     * is determined by the NeutralMode configuration of each device.
     * <p>
     * Since the NeutralMode configuration of devices may not align, users
     * may prefer to use the {@link #setCoastOut()} or {@link #setStaticBrake()} method.
     *
     * @return Status Code of the request.
     */
    public final StatusCode setNeutralOut() {
        var retval = StatusCode.OK;
        {
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_neutral);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_neutral);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        return retval;
    }

    /**
     * Request coast neutral output of mechanism. The bridge is
     * disabled and the rotor is allowed to coast.
     *
     * @return Status Code of the request.
     */
    public final StatusCode setCoastOut() {
        var retval = StatusCode.OK;
        {
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_coast);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_coast);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        return retval;
    }

    /**
     * Applies full neutral-brake on the mechanism by shorting
     * motor leads together.
     *
     * @return Status Code of the request.
     */
    public final StatusCode setStaticBrake() {
        var retval = StatusCode.OK;
        {
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_brake);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_brake);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        return retval;
    }

    private ControlRequest _diffLeaderFX_req = null;
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average DutyCycleOut request of the mechanism.
     * @param DifferentialRequest Differential PositionDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(DutyCycleOut AverageRequest, PositionDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_DutyCycleOut_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_DutyCycleOut_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_DutyCycleOut_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average PositionDutyCycle request of the mechanism.
     * @param DifferentialRequest Differential PositionDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(PositionDutyCycle AverageRequest, PositionDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_PositionDutyCycle_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_PositionDutyCycle_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_PositionDutyCycle_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VelocityDutyCYcle request of the mechanism.
     * @param DifferentialRequest Differential PositionDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VelocityDutyCycle AverageRequest, PositionDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VelocityDutyCycle_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VelocityDutyCycle_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VelocityDutyCycle_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicDutyCycle request of the mechanism.
     * @param DifferentialRequest Differential PositionDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicDutyCycle AverageRequest, PositionDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicDutyCycle_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicDutyCycle_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicDutyCycle_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicExpoDutyCycle request of the
     *                       mechanism.
     * @param DifferentialRequest Differential PositionDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicExpoDutyCycle AverageRequest, PositionDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicExpoDutyCycle_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicExpoDutyCycle_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicExpoDutyCycle_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVelocityDutyCycle request of the
     *                       mechanism.
     * @param DifferentialRequest Differential PositionDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVelocityDutyCycle AverageRequest, PositionDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVelocityDutyCycle_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVelocityDutyCycle_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVelocityDutyCycle_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average DutyCycleOut request of the mechanism.
     * @param DifferentialRequest Differential VelocityDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(DutyCycleOut AverageRequest, VelocityDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_DutyCycleOut_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_DutyCycleOut_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_DutyCycleOut_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average PositionDutyCycle request of the mechanism.
     * @param DifferentialRequest Differential VelocityDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(PositionDutyCycle AverageRequest, VelocityDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_PositionDutyCycle_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_PositionDutyCycle_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_PositionDutyCycle_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VelocityDutyCycle request of the mechanism.
     * @param DifferentialRequest Differential VelocityDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VelocityDutyCycle AverageRequest, VelocityDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VelocityDutyCycle_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VelocityDutyCycle_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VelocityDutyCycle_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicDutyCycle request of the mechanism.
     * @param DifferentialRequest Differential VelocityDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicDutyCycle AverageRequest, VelocityDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicDutyCycle_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicDutyCycle_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicDutyCycle_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicExpoDutyCycle request of the
     *                       mechanism.
     * @param DifferentialRequest Differential VelocityDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicExpoDutyCycle AverageRequest, VelocityDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicExpoDutyCycle_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicExpoDutyCycle_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicExpoDutyCycle_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVelocityDutyCycle request of the
     *                       mechanism.
     * @param DifferentialRequest Differential VelocityDutyCycle request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVelocityDutyCycle AverageRequest, VelocityDutyCycle DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVelocityDutyCycle_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVelocityDutyCycle_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVelocityDutyCycle_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average DutyCycleOut request of the mechanism.
     * @param DifferentialRequest Differential DutyCycleOut request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(DutyCycleOut AverageRequest, DutyCycleOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_DutyCycleOut_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_DutyCycleOut_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_DutyCycleOut_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average PositionDutyCycle request of the mechanism.
     * @param DifferentialRequest Differential DutyCycleOut request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(PositionDutyCycle AverageRequest, DutyCycleOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_PositionDutyCycle_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_PositionDutyCycle_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_PositionDutyCycle_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VelocityDutyCYcle request of the mechanism.
     * @param DifferentialRequest Differential DutyCycleOut request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VelocityDutyCycle AverageRequest, DutyCycleOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VelocityDutyCycle_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VelocityDutyCycle_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VelocityDutyCycle_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicDutyCycle request of the mechanism.
     * @param DifferentialRequest Differential DutyCycleOut request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicDutyCycle AverageRequest, DutyCycleOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicDutyCycle_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicDutyCycle_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicDutyCycle_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicExpoDutyCycle request of the
     *                       mechanism.
     * @param DifferentialRequest Differential DutyCycleOut request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicExpoDutyCycle AverageRequest, DutyCycleOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicExpoDutyCycle_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicExpoDutyCycle_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicExpoDutyCycle_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVelocityDutyCycle request of the
     *                       mechanism.
     * @param DifferentialRequest Differential DutyCycleOut request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVelocityDutyCycle AverageRequest, DutyCycleOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVelocityDutyCycle_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVelocityDutyCycle_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVelocityDutyCycle_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VoltageOut request of the mechanism.
     * @param DifferentialRequest Differential PositionVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VoltageOut AverageRequest, PositionVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VoltageOut_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VoltageOut_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VoltageOut_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average PositionVoltage request of the mechanism.
     * @param DifferentialRequest Differential PositionVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(PositionVoltage AverageRequest, PositionVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_PositionVoltage_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_PositionVoltage_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_PositionVoltage_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VelocityVoltage request of the mechanism.
     * @param DifferentialRequest Differential PositionVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VelocityVoltage AverageRequest, PositionVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VelocityVoltage_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VelocityVoltage_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VelocityVoltage_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVoltage request of the mechanism.
     * @param DifferentialRequest Differential PositionVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVoltage AverageRequest, PositionVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVoltage_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVoltage_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVoltage_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicExpoVoltage request of the
     *                       mechanism.
     * @param DifferentialRequest Differential PositionVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicExpoVoltage AverageRequest, PositionVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicExpoVoltage_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicExpoVoltage_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicExpoVoltage_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVelocityVoltage request of the
     *                       mechanism.
     * @param DifferentialRequest Differential PositionVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVelocityVoltage AverageRequest, PositionVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVelocityVoltage_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVelocityVoltage_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVelocityVoltage_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VoltageOut request of the mechanism.
     * @param DifferentialRequest Differential VelocityVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VoltageOut AverageRequest, VelocityVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VoltageOut_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VoltageOut_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VoltageOut_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average PositionVoltage request of the mechanism.
     * @param DifferentialRequest Differential VelocityVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(PositionVoltage AverageRequest, VelocityVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_PositionVoltage_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_PositionVoltage_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_PositionVoltage_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VelocityVoltage request of the mechanism.
     * @param DifferentialRequest Differential VelocityVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VelocityVoltage AverageRequest, VelocityVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VelocityVoltage_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VelocityVoltage_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VelocityVoltage_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVoltage request of the mechanism.
     * @param DifferentialRequest Differential VelocityVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVoltage AverageRequest, VelocityVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVoltage_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVoltage_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVoltage_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicExpoVoltage request of the
     *                       mechanism.
     * @param DifferentialRequest Differential VelocityVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicExpoVoltage AverageRequest, VelocityVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicExpoVoltage_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicExpoVoltage_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicExpoVoltage_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVelocityVoltage request of the
     *                       mechanism.
     * @param DifferentialRequest Differential VelocityVoltage request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVelocityVoltage AverageRequest, VelocityVoltage DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVelocityVoltage_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVelocityVoltage_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVelocityVoltage_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VoltageOut request of the mechanism.
     * @param DifferentialRequest Differential VoltageOut request of the mechanism.
     *                            Note: The UpdateFreqHz parameter for this control
     *                            request will be ignored by the control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VoltageOut AverageRequest, VoltageOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VoltageOut_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VoltageOut_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VoltageOut_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average PositionVoltage request of the mechanism.
     * @param DifferentialRequest Differential VoltageOut request of the mechanism.
     *                            Note: The UpdateFreqHz parameter for this control
     *                            request will be ignored by the control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(PositionVoltage AverageRequest, VoltageOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_PositionVoltage_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_PositionVoltage_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_PositionVoltage_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VelocityVoltage request of the mechanism.
     * @param DifferentialRequest Differential VoltageOut request of the mechanism.
     *                            Note: The UpdateFreqHz parameter for this control
     *                            request will be ignored by the control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VelocityVoltage AverageRequest, VoltageOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VelocityVoltage_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VelocityVoltage_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VelocityVoltage_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVoltage request of the mechanism.
     * @param DifferentialRequest Differential VoltageOut request of the mechanism.
     *                            Note: The UpdateFreqHz parameter for this control
     *                            request will be ignored by the control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVoltage AverageRequest, VoltageOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVoltage_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVoltage_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVoltage_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicExpoVoltage request of the
     *                       mechanism.
     * @param DifferentialRequest Differential VoltageOut request of the mechanism.
     *                            Note: The UpdateFreqHz parameter for this control
     *                            request will be ignored by the control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicExpoVoltage AverageRequest, VoltageOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicExpoVoltage_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicExpoVoltage_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicExpoVoltage_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVelocityVoltage request of the
     *                       mechanism.
     * @param DifferentialRequest Differential VoltageOut request of the mechanism.
     *                            Note: The UpdateFreqHz parameter for this control
     *                            request will be ignored by the control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVelocityVoltage AverageRequest, VoltageOut DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVelocityVoltage_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVelocityVoltage_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVelocityVoltage_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average TorqueCurrentFOC request of the mechanism.
     * @param DifferentialRequest Differential PositionTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(TorqueCurrentFOC AverageRequest, PositionTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_TorqueCurrentFOC_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_TorqueCurrentFOC_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_TorqueCurrentFOC_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average PositionTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential PositionTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(PositionTorqueCurrentFOC AverageRequest, PositionTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_PositionTorqueCurrentFOC_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_PositionTorqueCurrentFOC_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_PositionTorqueCurrentFOC_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VelocityTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential PositionTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VelocityTorqueCurrentFOC AverageRequest, PositionTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VelocityTorqueCurrentFOC_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VelocityTorqueCurrentFOC_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VelocityTorqueCurrentFOC_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential PositionTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicTorqueCurrentFOC AverageRequest, PositionTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicTorqueCurrentFOC_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicTorqueCurrentFOC_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicTorqueCurrentFOC_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicExpoTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential PositionTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicExpoTorqueCurrentFOC AverageRequest, PositionTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicExpoTorqueCurrentFOC_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicExpoTorqueCurrentFOC_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicExpoTorqueCurrentFOC_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVelocityTorqueCurrentFOC request of
     *                       the mechanism.
     * @param DifferentialRequest Differential PositionTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVelocityTorqueCurrentFOC AverageRequest, PositionTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVelocityTorqueCurrentFOC_Position _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVelocityTorqueCurrentFOC_Position req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVelocityTorqueCurrentFOC_Position(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average TorqueCurrentFOC request of the mechanism.
     * @param DifferentialRequest Differential VelocityTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(TorqueCurrentFOC AverageRequest, VelocityTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_TorqueCurrentFOC_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_TorqueCurrentFOC_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_TorqueCurrentFOC_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average PositionTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential VelocityTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(PositionTorqueCurrentFOC AverageRequest, VelocityTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_PositionTorqueCurrentFOC_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_PositionTorqueCurrentFOC_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_PositionTorqueCurrentFOC_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VelocityTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential VelocityTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VelocityTorqueCurrentFOC AverageRequest, VelocityTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VelocityTorqueCurrentFOC_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VelocityTorqueCurrentFOC_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VelocityTorqueCurrentFOC_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential VelocityTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicTorqueCurrentFOC AverageRequest, VelocityTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicTorqueCurrentFOC_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicTorqueCurrentFOC_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicTorqueCurrentFOC_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicExpoTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential VelocityTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicExpoTorqueCurrentFOC AverageRequest, VelocityTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicExpoTorqueCurrentFOC_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicExpoTorqueCurrentFOC_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicExpoTorqueCurrentFOC_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVelocityTorqueCurrentFOC request of
     *                       the mechanism.
     * @param DifferentialRequest Differential VelocityTorqueCurrentFOC request of
     *                            the mechanism. Note: The UpdateFreqHz parameter
     *                            for this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVelocityTorqueCurrentFOC AverageRequest, VelocityTorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVelocityTorqueCurrentFOC_Velocity(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average TorqueCurrentFOC request of the mechanism.
     * @param DifferentialRequest Differential TorqueCurrentFOC request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(TorqueCurrentFOC AverageRequest, TorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_TorqueCurrentFOC_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_TorqueCurrentFOC_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_TorqueCurrentFOC_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average PositionTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential TorqueCurrentFOC request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(PositionTorqueCurrentFOC AverageRequest, TorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_PositionTorqueCurrentFOC_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_PositionTorqueCurrentFOC_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_PositionTorqueCurrentFOC_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average VelocityTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential TorqueCurrentFOC request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(VelocityTorqueCurrentFOC AverageRequest, TorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_VelocityTorqueCurrentFOC_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_VelocityTorqueCurrentFOC_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_VelocityTorqueCurrentFOC_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential TorqueCurrentFOC request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicTorqueCurrentFOC AverageRequest, TorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicTorqueCurrentFOC_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicTorqueCurrentFOC_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicTorqueCurrentFOC_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicExpoTorqueCurrentFOC request of the
     *                       mechanism.
     * @param DifferentialRequest Differential TorqueCurrentFOC request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicExpoTorqueCurrentFOC AverageRequest, TorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicExpoTorqueCurrentFOC_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicExpoTorqueCurrentFOC_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicExpoTorqueCurrentFOC_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
    /**
     * Sets the control request for this mechanism.
     *
     * @param AverageRequest Average MotionMagicVelocityTorqueCurrentFOC request of
     *                       the mechanism.
     * @param DifferentialRequest Differential TorqueCurrentFOC request of the
     *                            mechanism. Note: The UpdateFreqHz parameter for
     *                            this control request will be ignored by the
     *                            control frame.
     * @return Status Code of the request.
     */
    public final StatusCode setControl(MotionMagicVelocityTorqueCurrentFOC AverageRequest, TorqueCurrentFOC DifferentialRequest) {
        var retval = StatusCode.OK;
    
        retval = beforeControl();
        if (!retval.isOK()) {
            return retval;
        }
        
        {
            final Diff_MotionMagicVelocityTorqueCurrentFOC_Open _diffLeaderFX_reqPtr;
            if (_diffLeaderFX_req instanceof Diff_MotionMagicVelocityTorqueCurrentFOC_Open req) {
                _diffLeaderFX_reqPtr = req;
                _diffLeaderFX_reqPtr.AverageRequest = AverageRequest;
                _diffLeaderFX_reqPtr.DifferentialRequest = DifferentialRequest;
            } else {
                _diffLeaderFX_reqPtr = new Diff_MotionMagicVelocityTorqueCurrentFOC_Open(AverageRequest, DifferentialRequest);
                _diffLeaderFX_req = _diffLeaderFX_reqPtr;
            }
            _diffLeaderFX_reqPtr.UpdateFreqHz = _diffLeaderFX_reqPtr.AverageRequest.UpdateFreqHz;
            
            final var _diffLeaderFX_retval = _diffLeaderFX.setControl(_diffLeaderFX_reqPtr);
            if (retval.isOK()) {
                retval = _diffLeaderFX_retval;
            }
        }
        
        {
            final var _diffFollowerFX_retval = _diffFollowerFX.setControl(_diffFollow);
            if (retval.isOK()) {
                retval = _diffFollowerFX_retval;
            }
        }
        
        return retval;
    }
    
}
