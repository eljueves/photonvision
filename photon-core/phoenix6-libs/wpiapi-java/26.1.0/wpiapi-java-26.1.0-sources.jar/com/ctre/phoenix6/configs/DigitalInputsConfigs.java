/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

/**
 * Configs related to the CANdi™ branded device's digital I/O settings
 * <p>
 * Contains float-state settings and when to assert the S1/S2 inputs.
 */
public class DigitalInputsConfigs implements ParentConfiguration, Cloneable {
    /**
     * The floating state of the Signal 1 input (S1IN).
     * 
     */
    public S1FloatStateValue S1FloatState = S1FloatStateValue.FloatDetect;
    /**
     * The floating state of the Signal 2 input (S2IN).
     * 
     */
    public S2FloatStateValue S2FloatState = S2FloatStateValue.FloatDetect;
    /**
     * What value the Signal 1 input (S1IN) needs to be for the CTR
     * Electronics' CANdi™ to detect as Closed.
     * <p>
     * Devices using the S1 input as a remote limit switch will treat the
     * switch as closed when the S1 input is this state.
     * 
     */
    public S1CloseStateValue S1CloseState = S1CloseStateValue.CloseWhenNotFloating;
    /**
     * What value the Signal 2 input (S2IN) needs to be for the CTR
     * Electronics' CANdi™ to detect as Closed.
     * <p>
     * Devices using the S2 input as a remote limit switch will treat the
     * switch as closed when the S2 input is this state.
     * 
     */
    public S2CloseStateValue S2CloseState = S2CloseStateValue.CloseWhenNotFloating;
    
    /**
     * Modifies this configuration's S1FloatState parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The floating state of the Signal 1 input (S1IN).
     * 
     *
     * @param newS1FloatState Parameter to modify
     * @return Itself
     */
    public final DigitalInputsConfigs withS1FloatState(S1FloatStateValue newS1FloatState)
    {
        S1FloatState = newS1FloatState;
        return this;
    }
    
    /**
     * Modifies this configuration's S2FloatState parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The floating state of the Signal 2 input (S2IN).
     * 
     *
     * @param newS2FloatState Parameter to modify
     * @return Itself
     */
    public final DigitalInputsConfigs withS2FloatState(S2FloatStateValue newS2FloatState)
    {
        S2FloatState = newS2FloatState;
        return this;
    }
    
    /**
     * Modifies this configuration's S1CloseState parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * What value the Signal 1 input (S1IN) needs to be for the CTR
     * Electronics' CANdi™ to detect as Closed.
     * <p>
     * Devices using the S1 input as a remote limit switch will treat the
     * switch as closed when the S1 input is this state.
     * 
     *
     * @param newS1CloseState Parameter to modify
     * @return Itself
     */
    public final DigitalInputsConfigs withS1CloseState(S1CloseStateValue newS1CloseState)
    {
        S1CloseState = newS1CloseState;
        return this;
    }
    
    /**
     * Modifies this configuration's S2CloseState parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * What value the Signal 2 input (S2IN) needs to be for the CTR
     * Electronics' CANdi™ to detect as Closed.
     * <p>
     * Devices using the S2 input as a remote limit switch will treat the
     * switch as closed when the S2 input is this state.
     * 
     *
     * @param newS2CloseState Parameter to modify
     * @return Itself
     */
    public final DigitalInputsConfigs withS2CloseState(S2CloseStateValue newS2CloseState)
    {
        S2CloseState = newS2CloseState;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: DigitalInputs\n";
        ss += "    S1FloatState: " + S1FloatState + "\n";
        ss += "    S2FloatState: " + S2FloatState + "\n";
        ss += "    S1CloseState: " + S1CloseState + "\n";
        ss += "    S2CloseState: " + S2CloseState + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeint(SpnValue.CANdi_S1FloatState.value, S1FloatState.value);
        ss += ConfigJNI.Serializeint(SpnValue.CANdi_S2FloatState.value, S2FloatState.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_S1_CloseState.value, S1CloseState.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_S2_CloseState.value, S2CloseState.value);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        S1FloatState = S1FloatStateValue.valueOf(ConfigJNI.Deserializeint(SpnValue.CANdi_S1FloatState.value, to_deserialize));
        S2FloatState = S2FloatStateValue.valueOf(ConfigJNI.Deserializeint(SpnValue.CANdi_S2FloatState.value, to_deserialize));
        S1CloseState = S1CloseStateValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_S1_CloseState.value, to_deserialize));
        S2CloseState = S2CloseStateValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_S2_CloseState.value, to_deserialize));
        return  StatusCode.OK;
    }

    @Override
    public DigitalInputsConfigs clone() {
        try {
            return (DigitalInputsConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

