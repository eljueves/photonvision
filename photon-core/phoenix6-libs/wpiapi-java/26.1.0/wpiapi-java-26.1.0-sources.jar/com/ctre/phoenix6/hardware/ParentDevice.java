/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware;

import static edu.wpi.first.units.Units.*;

import com.ctre.phoenix6.BaseStatusSignal;
import com.ctre.phoenix6.CANBus;
import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.StatusSignal;
import com.ctre.phoenix6.Utils;
import com.ctre.phoenix6.controls.ControlRequest;
import com.ctre.phoenix6.controls.EmptyControl;
import com.ctre.phoenix6.hardware.traits.CommonDevice;
import com.ctre.phoenix6.jni.CtreJniWrapper;
import com.ctre.phoenix6.jni.ErrorReportingJNI;
import com.ctre.phoenix6.jni.StatusSignalJNI;
import com.ctre.phoenix6.spns.SpnValue;
import com.ctre.phoenix6.unmanaged.Unmanaged;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleFunction;

import edu.wpi.first.units.measure.*;

public abstract class ParentDevice extends CtreJniWrapper implements CommonDevice {
    protected static final EmptyControl _emptyControl = new EmptyControl();

    protected final DeviceIdentifier deviceIdentifier;

    private final Map<Integer, BaseStatusSignal> _signalValues = new ConcurrentHashMap<Integer, BaseStatusSignal>();
    private ControlRequest _controlReq = _emptyControl;
    private final Lock _controlReqLck = new ReentrantLock();

    private static class FirmwareVersChecker {
        private final DeviceIdentifier deviceIdentifier;

        public final double _creationTime = Utils.getCurrentTimeSeconds();
        public double _timeToRefreshVersion = Utils.getCurrentTimeSeconds();
        public StatusCode _versionStatus = StatusCode.CouldNotRetrieveV6Firmware;

        public StatusSignal<Integer> _compliancy = null;

        public FirmwareVersChecker(DeviceIdentifier deviceIdentifier) {
            this.deviceIdentifier = deviceIdentifier;
        }

        public void reportIfTooOld() {
            /* if version is correct, no more checking */
            if (_versionStatus.isOK()) {
                return;
            }
            /* Check if we have our versions initialized */
            if (_compliancy == null) {
                return;
            }

            /* get fresh data if enough time has passed */
            final double currentTime = Utils.getCurrentTimeSeconds();
            if (currentTime >= _timeToRefreshVersion) {
                /* Try to refresh again after 250ms */
                _timeToRefreshVersion = currentTime + 0.25;
                /* Refresh versions, don't print out if there's an error with refreshing */
                _compliancy.refresh(false);

                /* process the fetched version */
                StatusCode code = StatusCode.OK;

                /* First check if we have good versions or not */
                if (_compliancy.getStatus().isOK()) {
                    final int firmwareCompliancy = _compliancy.getValue();
                    final int apiCompliancy = Unmanaged.getApiCompliancy();

                    if (apiCompliancy > firmwareCompliancy) {
                        code = StatusCode.FirmwareTooOld;
                    } else if (apiCompliancy < firmwareCompliancy) {
                        code = StatusCode.ApiTooOld;
                    }
                } else {
                    /* don't care why we couldn't get message, just report we didn't get it */
                    code = StatusCode.CouldNotRetrieveV6Firmware;
                }

                /* how much time has passed */
                final double deltaTimeSec = currentTime - _creationTime;

                if (code.isOK()) {
                    /* version is retrieved and healthy */
                } else if (code == StatusCode.FirmwareTooOld || code == StatusCode.ApiTooOld || deltaTimeSec >= 3.0) {
                    /* report error */
                    ErrorReportingJNI.reportStatusCode(code.value, deviceIdentifier.toString());
                } else {
                    /* don't start reporting CouldNotRetrieveV6Firmware yet, device was likely recently constructed */
                }
                /* save the status code */
                _versionStatus = code;
            }
        }
    }

    private final FirmwareVersChecker _versChecker;
    private final StatusSignal<Integer> _resetSignal;

    public interface MapGenerator {
        Map<Integer, String> run();
    }

    public ParentDevice(int deviceID, String model, CANBus canbus) {
        this.deviceIdentifier = new DeviceIdentifier(deviceID, model, canbus);

        _versChecker = new FirmwareVersChecker(deviceIdentifier);
        _versChecker._compliancy = lookupStatusSignal(
            SpnValue.Compliancy_Version.value,
            "Compliancy",
            Integer.class,
            val -> (int)val,
            false,
            true);

        _resetSignal = lookupStatusSignal(
            SpnValue.Startup_ResetFlags.value,
            "ResetFlags",
            Integer.class,
            val -> (int)val,
            false,
            true);
    }

    /**
     * @return The device ID of this device [0,62].
     */
    @Override
    public final int getDeviceID() {
        return deviceIdentifier.deviceID;
    }

    /**
     * @return The network this device is on.
     */
    @Override
    public final CANBus getNetwork() {
        return deviceIdentifier.network;
    }

    /**
     * Gets a number unique for this device's hardware type and ID.
     * This number is not unique across networks.
     * <p>
     * This can be used to easily reference hardware devices on the
     * same network in collections such as maps.
     *
     * @return Hash of this device.
     */
    @Override
    public final long getDeviceHash() {
        return deviceIdentifier.deviceHash;
    }

    /**
     * Get the latest applied control.
     * Caller can cast this to the derived class if they know its type. Otherwise,
     * use {@link ControlRequest#getControlInfo} to get info out of it.
     *
     * @return Latest applied control
     */
    @Override
    public final ControlRequest getAppliedControl() {
        return _controlReq;
    }

    /**
     * @return true if device has reset since the previous call of this routine.
     */
    @Override
    public final boolean hasResetOccurred() {
        return _resetSignal.refresh(false).hasUpdated();
    }

    /**
     * @return a {@link BooleanSupplier} that checks for device resets.
     */
    @Override
    public final BooleanSupplier getResetOccurredChecker() {
        final var resetSignal = _resetSignal.clone();
        return () -> resetSignal.refresh(false).hasUpdated();
    }

    /**
     * Returns whether the device is still connected to the robot.
     * This is equivalent to refreshing and checking the latency of the
     * Version status signal.
     * <p>
     * This defaults to reporting a device as disconnected if it has
     * not been seen for over 0.5 seconds.
     *
     * @return true if the device is connected
     */
    @Override
    public final boolean isConnected() {
        return isConnected(0.500);
    }

    /**
     * Returns whether the device is still connected to the robot.
     * This is equivalent to refreshing and checking the latency of the
     * Version status signal.
     *
     * @param maxLatencySeconds The maximum latency of the Version status signal
     *                          before the device is reported as disconnected
     * @return true if the device is connected
     */
    @Override
    public final boolean isConnected(double maxLatencySeconds) {
        return _versChecker._compliancy != null &&
            _versChecker._compliancy.refresh(false).getTimestamp().getLatency() <= maxLatencySeconds;
    }

    /**
     * Optimizes the device's bus utilization by reducing the update frequencies of its status signals.
     * This API defaults to an optimized update frequency of 4 Hz to preserve log data.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once in the robot program. Additionally, this method does
     * not necessarily need to be called after setting the update frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequencies}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the device on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each signal by default.
     *
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    @Override
    public final StatusCode optimizeBusUtilization() {
        return optimizeBusUtilization(4.0);
    }

    /**
     * Optimizes the device's bus utilization by reducing the update frequencies of its status signals.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once on this device in the robot program. Additionally, this
     * method does not necessarily need to be called after setting the update frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequencies}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the device on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each signal by default.
     *
     * @param optimizedFreqHz The update frequency to apply to the optimized status signals. A frequency
     *                        of 0 Hz will turn off the signals. Otherwise, the minimum supported signal
     *                        frequency is 4 Hz (default).
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    @Override
    public final StatusCode optimizeBusUtilization(double optimizedFreqHz) {
        return optimizeBusUtilization(optimizedFreqHz, 0.100);
    }
    /**
     * Optimizes the device's bus utilization by reducing the update frequencies of its status signals.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once on this device in the robot program. Additionally, this
     * method does not necessarily need to be called after setting the update frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequencies}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the device on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each signal by default.
     *
     * @param optimizedFreq The update frequency to apply to the optimized status signals. A frequency
     *                      of 0 Hz will turn off the signals. Otherwise, the minimum supported signal
     *                      frequency is 4 Hz (default).
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    @Override
    public final StatusCode optimizeBusUtilization(Frequency optimizedFreq) {
        return optimizeBusUtilization(optimizedFreq.in(Hertz));
    }

    /**
     * Optimizes the device's bus utilization by reducing the update frequencies of its status signals.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once on this device in the robot program. Additionally, this
     * method does not necessarily need to be called after setting the update frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequencies}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the device on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     *
     * @param optimizedFreqHz The update frequency to apply to the optimized status signals. A frequency
     *                        of 0 Hz will turn off the signals. Otherwise, the minimum supported signal
     *                        frequency is 4 Hz (default).
     * @param timeoutSeconds Maximum amount of time to wait for each status frame when performing the action
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    @Override
    public final StatusCode optimizeBusUtilization(double optimizedFreqHz, double timeoutSeconds) {
        return StatusCode.valueOf(StatusSignalJNI.JNI_OptimizeUpdateFrequencies(deviceIdentifier.getNetwork().getName(), deviceIdentifier.getDeviceHash(), optimizedFreqHz, timeoutSeconds));
    }
    /**
     * Optimizes the device's bus utilization by reducing the update frequencies of its status signals.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once on this device in the robot program. Additionally, this
     * method does not necessarily need to be called after setting the update frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequencies}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the device on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     *
     * @param optimizedFreq The update frequency to apply to the optimized status signals. A frequency
     *                      of 0 Hz will turn off the signals. Otherwise, the minimum supported signal
     *                      frequency is 4 Hz (default).
     * @param timeoutSeconds Maximum amount of time to wait for each status frame when performing the action
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    @Override
    public final StatusCode optimizeBusUtilization(Frequency optimizedFreq, double timeoutSeconds) {
        return optimizeBusUtilization(optimizedFreq.in(Hertz), timeoutSeconds);
    }

    /**
     * Optimizes the bus utilization of the provided devices by reducing the update frequencies
     * of their status signals. This API defaults to an optimized update frequency of 4 Hz to
     * preserve log data.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once in the robot program for the provided devices.
     * Additionally, this method does not necessarily need to be called after setting the update
     * frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequenciesForAll}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the devices on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each status frame.
     *
     * @param devices Devices for which to opimize bus utilization
     * @return Status code of the first failed optimize call, or OK if all succeeded
     */
    public static StatusCode optimizeBusUtilizationForAll(CommonDevice... devices) {
        return optimizeBusUtilizationForAll(4.0, devices);
    }

    /**
     * Optimizes the bus utilization of the provided devices by reducing the update frequencies
     * of their status signals.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once in the robot program for the provided devices.
     * Additionally, this method does not necessarily need to be called after setting the update
     * frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequenciesForAll}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the devices on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each status frame.
     *
     * @param optimizedFreqHz The update frequency to apply to the optimized status signals. A frequency
     *                        of 0 Hz will turn off the signals. Otherwise, the minimum supported signal
     *                        frequency is 4 Hz (default).
     * @param devices Devices for which to opimize bus utilization
     * @return Status code of the first failed optimize call, or OK if all succeeded
     */
    public static StatusCode optimizeBusUtilizationForAll(double optimizedFreqHz, CommonDevice... devices) {
        StatusCode retval = StatusCode.OK;
        for (var device : devices) {
            StatusCode err = device.optimizeBusUtilization(optimizedFreqHz, 0.100);
            if (retval.isOK()) {
                retval = err;
            }
        }
        return retval;
    }
    /**
     * Optimizes the bus utilization of the provided devices by reducing the update frequencies
     * of their status signals.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once in the robot program for the provided devices.
     * Additionally, this method does not necessarily need to be called after setting the update
     * frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequenciesForAll}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the devices on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each status frame.
     *
     * @param optimizedFreq The update frequency to apply to the optimized status signals. A frequency
     *                      of 0 Hz will turn off the signals. Otherwise, the minimum supported signal
     *                      frequency is 4 Hz (default).
     * @param devices Devices for which to opimize bus utilization
     * @return Status code of the first failed optimize call, or OK if all succeeded
     */
    public static StatusCode optimizeBusUtilizationForAll(Frequency optimizedFreq, CommonDevice... devices) {
        return optimizeBusUtilizationForAll(optimizedFreq.in(Hertz), devices);
    }

    /**
     * Resets the update frequencies of all the device's status signals to the defaults.
     * <p>
     * This restores the default update frequency of all status signals, including status signals
     * explicitly given an update frequency using {@link BaseStatusSignal#setUpdateFrequency} and status
     * signals optimized out using {@link #optimizeBusUtilization}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each signal by default.
     *
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    @Override
    public final StatusCode resetSignalFrequencies() {
        return resetSignalFrequencies(0.100);
    }
    /**
     * Resets the update frequencies of all the device's status signals to the defaults.
     * <p>
     * This restores the default update frequency of all status signals, including status signals
     * explicitly given an update frequency using {@link BaseStatusSignal#setUpdateFrequency} and status
     * signals optimized out using {@link #optimizeBusUtilization}.
     *
     * @param timeoutSeconds Maximum amount of time to wait for each status frame when performing the action
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    @Override
    public final StatusCode resetSignalFrequencies(double timeoutSeconds) {
        return StatusCode.valueOf(StatusSignalJNI.JNI_ResetUpdateFrequencies(deviceIdentifier.getNetwork().getName(), deviceIdentifier.getDeviceHash(), timeoutSeconds));
    }

    /**
     * Resets the update frequencies of all the devices' status signals to the defaults.
     * <p>
     * This restores the default update frequency of all status signals, including status signals
     * explicitly given an update frequency using {@link BaseStatusSignal#setUpdateFrequency} and status
     * signals optimized out using {@link #optimizeBusUtilizationForAll}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each status frame.
     *
     * @param devices Devices for which to restore default update frequencies
     * @return Status code of the first failed restore call, or OK if all succeeded
     */
    public static StatusCode resetSignalFrequenciesForAll(CommonDevice... devices) {
        StatusCode retval = StatusCode.OK;
        for (var device : devices) {
            StatusCode err = device.resetSignalFrequencies();
            if (retval.isOK()) {
                retval = err;
            }
        }
        return retval;
    }

    protected StatusCode setControlPrivate(ControlRequest request) {
        StatusCode status;

        _controlReqLck.lock();
        /* make sure we always unlock */
        try {
            _versChecker.reportIfTooOld();
            if (
                _versChecker._compliancy != null &&
                !_versChecker._versionStatus.isOK() &&
                _versChecker._compliancy.getStatus().isOK()
            ) {
                /* version mismatch, cancel controls and report the error */
                _controlReq = _emptyControl;
                _emptyControl.sendRequest(deviceIdentifier.network.getName(), deviceIdentifier.deviceHash);

                status = _versChecker._versionStatus;
            } else {
                /* send the request */
                _controlReq = request;
                status = _controlReq.sendRequest(deviceIdentifier.network.getName(), deviceIdentifier.deviceHash);
            }
        } finally {
            _controlReqLck.unlock();
        }

        if (!status.isOK()) {
            ErrorReportingJNI.reportStatusCode(status.value, deviceIdentifier.toString() + " SetControl "
                    + request.getName());
        }
        return status;
    }

    private <T> StatusSignal<T> commonLookup(
        int spn, String signalName, MapGenerator unitsGenerator,
        Class<T> classOfSignal, DoubleFunction<T> toValue,
        boolean reportOnConstruction, boolean refresh
    ) {
        /* lookup and return if found */
        BaseStatusSignal toFind = _signalValues.get(spn);
        if (toFind != null) {
            /* Found it, toFind is now the found StatusSignal */
            /* since we didn't construct, report errors */
            reportOnConstruction = true;
        } else {
            /* insert into map */
            if (unitsGenerator == null) {
                _signalValues.put(
                    spn, new StatusSignal<T>(
                        deviceIdentifier, spn, signalName,
                        _versChecker::reportIfTooOld, classOfSignal, toValue
                    )
                );
            } else {
                _signalValues.put(
                    spn, new StatusSignal<T>(
                        deviceIdentifier, spn, signalName,
                        _versChecker::reportIfTooOld, unitsGenerator,
                        classOfSignal, toValue
                    )
                );
            }

            /* look up and return */
            toFind = _signalValues.get(spn);
        }
        /* Try to return the found value cast to the child class */

        /* Turn off unchecked warning, we check the type afterwards */
        @SuppressWarnings("unchecked")
        StatusSignal<T> toReturn = StatusSignal.class.cast(toFind);

        if (toReturn == null) {
            /* Cast failed, so return with error */
            return new StatusSignal<T>(StatusCode.InvalidParamValue, classOfSignal, toValue);
        } else if (!toReturn.getTypeClass().equals(classOfSignal)) {
            /* Type does not match, return with error */
            return new StatusSignal<T>(StatusCode.InvalidParamValue, classOfSignal, toValue);
        } else {
            if (refresh) {
                /* Refresh the signal before we pass it down */
                toReturn.refresh(reportOnConstruction);
            }
            /* We're good, go ahead and return */
            return toReturn;
        }
    }

    protected final <T> StatusSignal<T> lookupStatusSignal(
        int spn, String signalName,
        Class<T> classOfSignal, DoubleFunction<T> toValue,
        boolean reportOnConstruction, boolean refresh
    ) {
        return commonLookup(spn, signalName, null, classOfSignal, toValue, reportOnConstruction, refresh);
    }

    protected final <T> StatusSignal<T> lookupStatusSignal(
        int spn, String signalName, MapGenerator unitsGenerator,
        Class<T> classOfSignal, DoubleFunction<T> toValue,
        boolean reportOnConstruction, boolean refresh
    ) {
        return commonLookup(spn, signalName, unitsGenerator, classOfSignal, toValue, reportOnConstruction, refresh);
    }
}
