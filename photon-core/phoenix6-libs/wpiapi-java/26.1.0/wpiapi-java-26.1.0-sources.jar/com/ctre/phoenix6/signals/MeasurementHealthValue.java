/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Health of the distance measurement.
 */
public enum MeasurementHealthValue
{
    /**
     * Measurement is good.
     */
    Good(0),
    /**
     * Measurement is likely okay, but the target is either very far away or moving
     * very quickly.
     */
    Limited(1),
    /**
     * Measurement is compromised.
     */
    Bad(2),;

    public final int value;

    MeasurementHealthValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, MeasurementHealthValue> _map = null;
    static
    {
        _map = new HashMap<Integer, MeasurementHealthValue>();
        for (MeasurementHealthValue type : MeasurementHealthValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets MeasurementHealthValue from specified value
     * @param value Value of MeasurementHealthValue
     * @return MeasurementHealthValue of specified value
     */
    public static MeasurementHealthValue valueOf(int value)
    {
        MeasurementHealthValue retval = _map.get(value);
        if (retval != null) return retval;
        return MeasurementHealthValue.values()[0];
    }
}
