/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Determines if the forward limit switch is normally-open (default) or
 * normally-closed.
 */
public enum ForwardLimitTypeValue
{
    NormallyOpen(0),
    NormallyClosed(1),;

    public final int value;

    ForwardLimitTypeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, ForwardLimitTypeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, ForwardLimitTypeValue>();
        for (ForwardLimitTypeValue type : ForwardLimitTypeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets ForwardLimitTypeValue from specified value
     * @param value Value of ForwardLimitTypeValue
     * @return ForwardLimitTypeValue of specified value
     */
    public static ForwardLimitTypeValue valueOf(int value)
    {
        ForwardLimitTypeValue retval = _map.get(value);
        if (retval != null) return retval;
        return ForwardLimitTypeValue.values()[0];
    }
}
