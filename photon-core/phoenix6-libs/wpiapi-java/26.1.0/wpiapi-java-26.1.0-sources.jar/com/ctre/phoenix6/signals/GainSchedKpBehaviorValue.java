/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The behavior of kP output as the error crosses the GainSchedErrorThreshold
 * during gain scheduling. The output of kP can be adjusted to maintain
 * continuity in output, or it can be left discontinuous.
 */
public enum GainSchedKpBehaviorValue
{
    /**
     * The gain scheduler will maintain continuity in the kP output as the error
     * crosses the gain threshold. This results in the best system stability, but it
     * may result in output that does not match pOut = kP * error.
     */
    Continuous(0),
    /**
     * The gain scheduler will allow for a discontinuity in the kP output. This
     * ensures that pOut = kP * error, but it may result in instability as the
     * system's error crosses the gain threshold.
     */
    Discontinuous(1),;

    public final int value;

    GainSchedKpBehaviorValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, GainSchedKpBehaviorValue> _map = null;
    static
    {
        _map = new HashMap<Integer, GainSchedKpBehaviorValue>();
        for (GainSchedKpBehaviorValue type : GainSchedKpBehaviorValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets GainSchedKpBehaviorValue from specified value
     * @param value Value of GainSchedKpBehaviorValue
     * @return GainSchedKpBehaviorValue of specified value
     */
    public static GainSchedKpBehaviorValue valueOf(int value)
    {
        GainSchedKpBehaviorValue retval = _map.get(value);
        if (retval != null) return retval;
        return GainSchedKpBehaviorValue.values()[0];
    }
}
