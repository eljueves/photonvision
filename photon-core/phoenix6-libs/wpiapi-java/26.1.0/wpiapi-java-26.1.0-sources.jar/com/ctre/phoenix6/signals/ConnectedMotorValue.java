/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The type of motor attached to the Talon.
 * <p>
 * This can be used to determine what motor is attached to the Talon FX.  Return
 * will be "Unknown" if firmware is too old or device is not present.
 */
public enum ConnectedMotorValue
{
    /**
     * Talon could not determine the type of motor attached.
     */
    Unknown(0),
    /**
     * Talon is attached to an integrated Falcon motor.
     */
    Falcon500_Integrated(1),
    /**
     * Talon is attached to an integrated Kraken X60 motor.
     */
    KrakenX60_Integrated(2),
    /**
     * Talon is attached to an integrated Kraken X44 motor.
     */
    KrakenX44_Integrated(3),
    /**
     * Talon is connected to a CTR Electronics Minion® brushless three phase motor.
     */
    Minion_JST(4),
    /**
     * Talon is connected to a third party brushed DC motor with leads A and B.
     */
    Brushed_AB(5),
    /**
     * Talon is connected to a third party brushed DC motor with leads A and C.
     */
    Brushed_AC(6),
    /**
     * Talon is connected to a third party brushed DC motor with leads B and C.
     */
    Brushed_BC(7),
    /**
     * Talon is connected to a third party NEO brushless three phase motor.
     */
    NEO_JST(8),
    /**
     * Talon is connected to a third party NEO550 brushless three phase motor.
     */
    NEO550_JST(9),
    /**
     * Talon is connected to a third party VORTEX brushless three phase motor.
     */
    VORTEX_JST(10),
    /**
     * Talon is connected to a custom brushless three phase motor. This requires
     * that the device is not FRC-Locked.
     */
    CustomBrushless(11),;

    public final int value;

    ConnectedMotorValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, ConnectedMotorValue> _map = null;
    static
    {
        _map = new HashMap<Integer, ConnectedMotorValue>();
        for (ConnectedMotorValue type : ConnectedMotorValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets ConnectedMotorValue from specified value
     * @param value Value of ConnectedMotorValue
     * @return ConnectedMotorValue of specified value
     */
    public static ConnectedMotorValue valueOf(int value)
    {
        ConnectedMotorValue retval = _map.get(value);
        if (retval != null) return retval;
        return ConnectedMotorValue.values()[0];
    }
}
