/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.hardware.DeviceIdentifier;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Class for CTR Electronics' CANdi™ branded device, a device that integrates
 * digital signals into the existing CAN bus network.
 *
 * This defines all configurations for the {@link com.ctre.phoenix6.hardware.CANdi}.
 */
public class CANdiConfigurator extends ParentConfigurator {
    public CANdiConfigurator(DeviceIdentifier id) {
        super(id);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CANdiConfiguration configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CANdiConfiguration configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CANdiConfiguration configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CANdiConfiguration configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, configs.FutureProofConfigs, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CustomParamsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(CustomParamsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CustomParamsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(CustomParamsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(DigitalInputsConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(DigitalInputsConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(DigitalInputsConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(DigitalInputsConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(QuadratureConfigs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(QuadratureConfigs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(QuadratureConfigs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(QuadratureConfigs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(PWM1Configs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(PWM1Configs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(PWM1Configs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(PWM1Configs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }


    /**
     * Refreshes the values of the specified config group.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(PWM2Configs configs) {
        return refresh(configs, DefaultTimeoutSeconds);
    }

    /**
     * Refreshes the values of the specified config group.
     * <p>
     * Call to refresh the selected configs from the device.
     *
     * @param configs The configs to refresh
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of refreshing the configs
     */
    public final StatusCode refresh(PWM2Configs configs, double timeoutSeconds) {
        StringBuilder serializedString = new StringBuilder();
        StatusCode err = getConfigsPrivate(serializedString, timeoutSeconds);
        if (err == StatusCode.OK) {
            /* Only deserialize if we successfully got configs */
            configs.deserialize(serializedString.toString());
        }
        return err;
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @return StatusCode of the set command
     */
    public final StatusCode apply(PWM2Configs configs) {
        return apply(configs, DefaultTimeoutSeconds);
    }

    /**
     * Applies the contents of the specified config to the device.
     * <p>
     * Call to apply the selected configs.
     *
     * @param configs Configs to apply against.
     * @param timeoutSeconds Maximum amount of time to wait when performing configuration
     * @return StatusCode of the set command
     */
    public final StatusCode apply(PWM2Configs configs, double timeoutSeconds) {
        return setConfigsPrivate(configs.serialize(), timeoutSeconds, false, false);
    }

    
    /**
     * Sets the position of the quadrature input.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @return StatusCode of the set command
     */
    public final StatusCode setQuadraturePosition(double newValue) {
        return setQuadraturePosition(newValue, DefaultTimeoutSeconds);
    }
    /**
     * Sets the position of the quadrature input.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setQuadraturePosition(double newValue, double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.CANdi_SetQuadPosition.value, newValue);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Sets the position of the quadrature input.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @return StatusCode of the set command
     */
    public final StatusCode setQuadraturePosition(Angle newValue) {
        return setQuadraturePosition(newValue.in(Rotations));
    }
    /**
     * Sets the position of the quadrature input.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setQuadraturePosition(Angle newValue, double timeoutSeconds) {
        return setQuadraturePosition(newValue.in(Rotations), timeoutSeconds);
    }
    
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults() {
        return clearStickyFaults(DefaultTimeoutSeconds);
    }
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.SPN_ClearStickyFaults.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware() {
        return clearStickyFault_Hardware(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_Hardware.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage() {
        return clearStickyFault_Undervoltage(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_Undervoltage.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable() {
        return clearStickyFault_BootDuringEnable(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_BootDuringEnable.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse() {
        return clearStickyFault_UnlicensedFeatureInUse(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_UnlicensedFeatureInUse.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
    
    /**
     * Clear sticky fault: The CTR Electronics' CANdi™ branded device has
     * detected a 5V fault. This may be due to overcurrent or a
     * short-circuit.
     * <p>
     * This will wait up to {@link #DefaultTimeoutSeconds}.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_5V() {
        return clearStickyFault_5V(DefaultTimeoutSeconds);
    }
    /**
     * Clear sticky fault: The CTR Electronics' CANdi™ branded device has
     * detected a 5V fault. This may be due to overcurrent or a
     * short-circuit.
     * <p>
     * This is available in the configurator in case the user wants
     * to initialize their device entirely without passing a device
     * reference down to the code that performs the initialization.
     * In this case, the user passes down the configurator object
     * and performs all the initialization code on the object.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_5V(double timeoutSeconds) {
        String serialized = ConfigJNI.Serializedouble(SpnValue.ClearStickyFault_CANDI_5V.value, 0);
        return setConfigsPrivate(serialized, timeoutSeconds, false, true);
    }
}
