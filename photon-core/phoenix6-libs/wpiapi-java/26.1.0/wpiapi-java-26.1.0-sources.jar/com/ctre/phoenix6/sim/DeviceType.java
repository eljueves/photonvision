/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.sim;

import java.util.HashMap;

/**
 * Enumeration of all supported device types.
 */
public enum DeviceType
{
    TalonSRXType(0),
    VictorSPXType(1),
    PigeonIMUType(2),
    RibbonPigeonIMUType(3),
    P6_TalonFXType(4),
    P6_CANcoderType(5),
    P6_Pigeon2Type(6),
    P6_TalonFXSType(7),
    P6_CANrangeType(8),
    P6_CANdiType(9),
    P6_CANdleType(10),;

    public final int value;

    DeviceType(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, DeviceType> _map = null;
    static
    {
        _map = new HashMap<Integer, DeviceType>();
        for (DeviceType type : DeviceType.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets DeviceType from specified value
     * @param value Value of DeviceType
     * @return DeviceType of specified value
     */
    public static DeviceType valueOf(int value)
    {
        DeviceType retval = _map.get(value);
        if (retval != null) return retval;
        return DeviceType.values()[0];
    }
}
