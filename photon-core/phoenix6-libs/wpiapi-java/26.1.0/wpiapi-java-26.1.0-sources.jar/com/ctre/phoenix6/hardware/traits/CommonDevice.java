/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.traits;

import java.util.function.BooleanSupplier;

import com.ctre.phoenix6.BaseStatusSignal;
import com.ctre.phoenix6.CANBus;
import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.ControlRequest;

import edu.wpi.first.units.measure.Frequency;

/**
 * Contains everything common across Phoenix 6 devices.
 */
public interface CommonDevice {
    /**
     * @return The device ID of this device [0,62].
     */
    int getDeviceID();

    /**
     * @return The network this device is on.
     */
    CANBus getNetwork();

    /**
     * Gets a number unique for this device's hardware type and ID.
     * This number is not unique across networks.
     * <p>
     * This can be used to easily reference hardware devices on the
     * same network in collections such as maps.
     *
     * @return Hash of this device.
     */
    long getDeviceHash();

    /**
     * Get the latest applied control.
     * Caller can cast this to the derived class if they know its type. Otherwise,
     * use {@link ControlRequest#getControlInfo} to get info out of it.
     *
     * @return Latest applied control
     */
    ControlRequest getAppliedControl();

    /**
     * @return true if device has reset since the previous call of this routine.
     */
    boolean hasResetOccurred();

    /**
     * @return a {@link BooleanSupplier} that checks for device resets.
     */
    BooleanSupplier getResetOccurredChecker();

    /**
     * Returns whether the device is still connected to the robot.
     * This is equivalent to refreshing and checking the latency of the
     * Version status signal.
     * <p>
     * This defaults to reporting a device as disconnected if it has
     * not been seen for over 0.5 seconds.
     *
     * @return true if the device is connected
     */
    boolean isConnected();

    /**
     * Returns whether the device is still connected to the robot.
     * This is equivalent to refreshing and checking the latency of the
     * Version status signal.
     *
     * @param maxLatencySeconds The maximum latency of the Version status signal
     *                          before the device is reported as disconnected
     * @return true if the device is connected
     */
    boolean isConnected(double maxLatencySeconds);

    /**
     * Optimizes the device's bus utilization by reducing the update frequencies of its status signals.
     * This API defaults to an optimized update frequency of 4 Hz to preserve log data.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once in the robot program. Additionally, this method does
     * not necessarily need to be called after setting the update frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequencies}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the device on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each signal by default.
     *
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    StatusCode optimizeBusUtilization();

    /**
     * Optimizes the device's bus utilization by reducing the update frequencies of its status signals.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once on this device in the robot program. Additionally, this
     * method does not necessarily need to be called after setting the update frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequencies}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the device on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each signal by default.
     *
     * @param optimizedFreqHz The update frequency to apply to the optimized status signals. A frequency
     *                        of 0 Hz will turn off the signals. Otherwise, the minimum supported signal
     *                        frequency is 4 Hz (default).
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    StatusCode optimizeBusUtilization(double optimizedFreqHz);
    /**
     * Optimizes the device's bus utilization by reducing the update frequencies of its status signals.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once on this device in the robot program. Additionally, this
     * method does not necessarily need to be called after setting the update frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequencies}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the device on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each signal by default.
     *
     * @param optimizedFreq The update frequency to apply to the optimized status signals. A frequency
     *                      of 0 Hz will turn off the signals. Otherwise, the minimum supported signal
     *                      frequency is 4 Hz (default).
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    StatusCode optimizeBusUtilization(Frequency optimizedFreq);

    /**
     * Optimizes the device's bus utilization by reducing the update frequencies of its status signals.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once on this device in the robot program. Additionally, this
     * method does not necessarily need to be called after setting the update frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequencies}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the device on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     *
     * @param optimizedFreqHz The update frequency to apply to the optimized status signals. A frequency
     *                        of 0 Hz will turn off the signals. Otherwise, the minimum supported signal
     *                        frequency is 4 Hz (default).
     * @param timeoutSeconds Maximum amount of time to wait for each status frame when performing the action
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    StatusCode optimizeBusUtilization(double optimizedFreqHz, double timeoutSeconds);
    /**
     * Optimizes the device's bus utilization by reducing the update frequencies of its status signals.
     * <p>
     * All status signals that have not been explicitly given an update frequency using
     * {@link BaseStatusSignal#setUpdateFrequency} will be slowed down. Note that if other
     * status signals in the same status frame have been given an update frequency, the
     * update frequency will be honored for the entire frame.
     * <p>
     * This function only needs to be called once on this device in the robot program. Additionally, this
     * method does not necessarily need to be called after setting the update frequencies of other signals.
     * <p>
     * To restore the default status update frequencies, call {@link #resetSignalFrequencies}.
     * Alternatively, remove this method call, redeploy the robot application, and power-cycle
     * the device on the bus. The user can also override individual status update frequencies
     * using {@link BaseStatusSignal#setUpdateFrequency}.
     *
     * @param optimizedFreq The update frequency to apply to the optimized status signals. A frequency
     *                      of 0 Hz will turn off the signals. Otherwise, the minimum supported signal
     *                      frequency is 4 Hz (default).
     * @param timeoutSeconds Maximum amount of time to wait for each status frame when performing the action
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    StatusCode optimizeBusUtilization(Frequency optimizedFreq, double timeoutSeconds);

    /**
     * Resets the update frequencies of all the device's status signals to the defaults.
     * <p>
     * This restores the default update frequency of all status signals, including status signals
     * explicitly given an update frequency using {@link BaseStatusSignal#setUpdateFrequency} and status
     * signals optimized out using {@link #optimizeBusUtilization}.
     * <p>
     * This will wait up to 0.100 seconds (100ms) for each signal by default.
     *
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    StatusCode resetSignalFrequencies();
    /**
     * Resets the update frequencies of all the device's status signals to the defaults.
     * <p>
     * This restores the default update frequency of all status signals, including status signals
     * explicitly given an update frequency using {@link BaseStatusSignal#setUpdateFrequency} and status
     * signals optimized out using {@link #optimizeBusUtilization}.
     *
     * @param timeoutSeconds Maximum amount of time to wait for each status frame when performing the action
     * @return Status code of the first failed update frequency set call, or OK if all succeeded
     */
    StatusCode resetSignalFrequencies(double timeoutSeconds);
}
