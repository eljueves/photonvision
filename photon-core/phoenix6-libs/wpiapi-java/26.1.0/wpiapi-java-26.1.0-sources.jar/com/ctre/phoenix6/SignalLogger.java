/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.ctre.phoenix6.jni.ErrorReportingJNI;
import com.ctre.phoenix6.jni.SignalLoggerJNI;
import edu.wpi.first.units.Measure;
import edu.wpi.first.units.Unit;
import edu.wpi.first.util.protobuf.Protobuf;
import edu.wpi.first.util.protobuf.ProtobufBuffer;
import edu.wpi.first.util.struct.Struct;
import edu.wpi.first.util.struct.StructBuffer;
import us.hebi.quickbuf.Descriptors.FileDescriptor;

/**
 * Static class for controlling the Phoenix 6 signal logger.
 * <p>
 * This logs all the signals from the CAN buses into .hoot files. Each file name starts with the
 * CANivore serial number or "rio" for the roboRIO CAN bus, followed by the timestamp. In the
 * header of a hoot file, the CANivore name and firmware version are logged in plain text.
 * <p>
 * During an FRC match, the log file will be renamed to include the event name, match type, and
 * match number at the start of the file name. The match type will be 'P' for practice matches,
 * 'Q' for qualification matches, and 'E' for elimination matches.
 * <p>
 * During Hoot Replay, the signal logger always runs while replay is running. All custom signals
 * written during replay will be automatically placed under {@code hoot_replay/}. Additionally,
 * the log will contain all status signals and custom signals from the original log.
 */
public class SignalLogger {
    /**
     * Sets the destination for logging, restarting logger if the path changed.
     * <p>
     * If this is not called or the path is left empty, the default path will be used. The
     * default path on the roboRIO is a logs folder on the first USB flash drive found, or
     * /home/lvuser/logs if none is available. The default path on all other platforms is
     * a logs folder in the current working directory.
     * <p>
     * Typical use for this routine is to use a removable USB flash drive for logging.
     * <p>
     * This is ignored during Hoot Replay, where the hoot log will always be written to a
     * subfolder next to the log being replayed.
     *
     * @param path Folder path for the log files; path must exist
     * @return Status of setting the path and restarting the log
     */
    public static StatusCode setPath(String path) {
        var retval = StatusCode.valueOf(SignalLoggerJNI.JNI_SetLoggerPath(path));

        if (!retval.isOK()) {
            ErrorReportingJNI.reportStatusCode(retval.value, "ctre.phoenix6.SignalLogger.setPath");
        }

        return retval;
    }

    /**
     * Starts logging status signals. Starts regardless of auto logging status.
     * <p>
     * If using a roboRIO 1, we recommend setting the logging path to an external drive
     * using {@link #setPath} to avoid running out of internal storage space.
     * <p>
     * This is ignored during Hoot Replay, where logging is automatically started when
     * Hoot Replay starts running or restarts.
     *
     * @return Status of starting the logger
     */
    public static StatusCode start() {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_StartLogger());
    }

    /**
     * Stops logging status signals. Stops regardless of auto logging status.
     * <p>
     * This is ignored during Hoot Replay, where logging is automatically stopped when
     * Hoot Replay is stopped or reaches the end of the file.
     *
     * @return Status of stopping the logger
     */
    public static StatusCode stop() {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_StopLogger());
    }

    /**
     * Enables or disables auto logging.
     * <p>
     * Auto logging is only supported on the roboRIO. Additionally, on a roboRIO 1,
     * auto logging will only be active if a USB flash drive is present.
     * <p>
     * When auto logging is enabled, logging is started by any of the following
     * (whichever occurs first):
     *
     * <ul>
     *   <li> The robot is enabled.
     *   <li> It has been at least 5 seconds since program startup (allowing for calls
     *        to {@link #setPath}), and the Driver Station is connected to the robot.
     * </ul>
     *
     * After auto logging has started the log once, logging will not be automatically
     * stopped or restarted by auto logging.
     *
     * @param enable Whether to enable auto logging
     * @return Status of auto logging enable/disable
     */
    public static StatusCode enableAutoLogging(boolean enable) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_EnableAutoLogging(enable));
    }

    /**
     * Adds the schema to the log file.
     * <p>
     * Users can call {@link #writeStruct}, {@link #writeStructArray}, and
     * {@link #writeProtobuf} to directly write schema values instead.
     * <p>
     * The schema name should typically exactly match the name of the type
     * (without any extra prefix or suffix).
     * <p>
     * For protobuf, first register all relevant file descriptors by file name
     * (such as "geometry2d.proto"). Then, for each top-level type being used,
     * add a separate empty schema with the full name of the type (such as
     * "wpi.proto.ProtobufPose2d").
     *
     * @param name Name of the schema
     * @param type Type of the schema, such as struct or protobuf
     * @param schema Schema bytes to write
     * @return Status of adding the schema
     */
    public static StatusCode addSchema(String name, HootSchemaType type, byte[] schema) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_AddSchema(name, type.value, schema));
    }
    /**
     * Adds the schema to the log file.
     * <p>
     * Users can call {@link #writeStruct}, {@link #writeStructArray}, and
     * {@link #writeProtobuf} to directly write schema values instead.
     * <p>
     * The schema name should typically exactly match the name of the type
     * (without any extra prefix or suffix).
     * <p>
     * For protobuf, first register all relevant file descriptors by file name
     * (such as "geometry2d.proto"). Then, for each top-level type being used,
     * add a separate empty schema with the full name of the type (such as
     * "wpi.proto.ProtobufPose2d").
     *
     * @param name Name of the schema
     * @param type Type of the schema, such as struct or protobuf
     * @param schema Schema string to write
     * @return Status of adding the schema
     */
    public static StatusCode addSchema(String name, HootSchemaType type, String schema) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_AddSchemaString(name, type.value, schema));
    }

    /**
     * Checks if the schema has already been added to the log files.
     *
     * @param name Name of the schema
     * @param type Type of the schema, such as struct or protobuf
     * @return Whether the schema has been added to the log files
     */
    public static boolean hasSchema(String name, HootSchemaType type) {
        return SignalLoggerJNI.JNI_HasSchema(name, type.value);
    }

    /**
     * Writes the schema-serialized bytes to the log file.
     * <p>
     * Users can call {@link #writeStruct}, {@link #writeStructArray}, and
     * {@link #writeProtobuf} to directly write schema values instead.
     * <p>
     * The name of the associated schema must exactly match the type of the data
     * (such as "Pose2d" or "wpi.proto.ProtobufPose2d"). Additionally, the schema
     * name must be registered with {@link #addSchema} before calling this API.
     *
     * @param name Name of the signal
     * @param schema Name of the associated schema
     * @param type Type of the associated schema, such as struct or protobuf
     * @param data Serialized data bytes
     * @return Status of writing the data
     */
    public static StatusCode writeSchemaValue(String name, String schema, HootSchemaType type, byte[] data) {
        return writeSchemaValue(name, schema, type, data, 0);
    }
    /**
     * Writes the schema-serialized bytes to the log file.
     * <p>
     * Users can call {@link #writeStruct}, {@link #writeStructArray}, and
     * {@link #writeProtobuf} to directly write schema values instead.
     * <p>
     * The name of the associated schema must exactly match the type of the data
     * (such as "Pose2d" or "wpi.proto.ProtobufPose2d"). Additionally, the schema
     * name must be registered with {@link #addSchema} before calling this API.
     *
     * @param name Name of the signal
     * @param schema Name of the associated schema
     * @param type Type of the associated schema, such as struct or protobuf
     * @param data Serialized data bytes
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeSchemaValue(String name, String schema, HootSchemaType type, byte[] data, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteSchemaValue(name, schema, type.value, data, 0, data.length, latencySeconds));
    }

    /**
     * Writes the schema-serialized buffer to the log file.
     * <p>
     * Users can call {@link #writeStruct}, {@link #writeStructArray}, and
     * {@link #writeProtobuf} to directly write schema values instead.
     * <p>
     * The name of the associated schema must exactly match the type of the data
     * (such as "Pose2d" or "wpi.proto.ProtobufPose2d"). Additionally, the schema
     * name must be registered with {@link #addSchema} before calling this API.
     *
     * @param name Name of the signal
     * @param schema Name of the associated schema
     * @param type Type of the associated schema, such as struct or protobuf
     * @param data Serialized data buffer, where [0, data.position()) will be written
     * @return Status of writing the data
     */
    public static StatusCode writeSchemaValue(String name, String schema, HootSchemaType type, ByteBuffer data) {
        return writeSchemaValue(name, schema, type, data, 0);
    }
    /**
     * Writes the schema-serialized buffer to the log file.
     * <p>
     * Users can call {@link #writeStruct}, {@link #writeStructArray}, and
     * {@link #writeProtobuf} to directly write schema values instead.
     * <p>
     * The name of the associated schema must exactly match the type of the data
     * (such as "Pose2d" or "wpi.proto.ProtobufPose2d"). Additionally, the schema
     * name must be registered with {@link #addSchema} before calling this API.
     *
     * @param name Name of the signal
     * @param schema Name of the associated schema
     * @param type Type of the associated schema, such as struct or protobuf
     * @param data Serialized data buffer, where [0, data.position()) will be written
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeSchemaValue(String name, String schema, HootSchemaType type, ByteBuffer data, double latencySeconds) {
        if (data.isDirect()) {
            return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteSchemaBuffer(name, schema, type.value, data, 0, data.position(), latencySeconds));
        } else if (data.hasArray()) {
            return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteSchemaValue(name, schema, type.value, data.array(), data.arrayOffset(), data.position(), latencySeconds));
        } else {
            throw new UnsupportedOperationException("ByteBuffer must be direct or have a backing array");
        }
    }

    /**
     * Writes the WPILib Struct to the log file.
     *
     * @param name Name of the signal
     * @param struct Struct serialization implementation
     * @param value Value to write
     * @return Status of writing the data
     */
    public static <T> StatusCode writeStruct(String name, Struct<T> struct, T value) {
        return writeStruct(name, struct, value, 0);
    }
    /**
     * Writes the WPILib Struct to the log file.
     *
     * @param name Name of the signal
     * @param struct Struct serialization implementation
     * @param value Value to write
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static <T> StatusCode writeStruct(String name, Struct<T> struct, T value, double latencySeconds) {
        final var typeName = struct.getTypeName();
        if (!hasSchema(typeName, HootSchemaType.Struct)) {
            addStructSchema(struct, new HashSet<>());
        }

        try {
            _structBufferLck.lock();

            @SuppressWarnings("unchecked")
            StructBuffer<T> buf = (StructBuffer<T>)_structBuffers.get(typeName);
            if (buf == null) {
                buf = StructBuffer.create(struct);
                _structBuffers.put(typeName, buf);
            }
            return writeSchemaValue(name, typeName, HootSchemaType.Struct, buf.write(value), latencySeconds);
        } finally {
            _structBufferLck.unlock();
        }
    }

    /**
     * Writes the array of WPILib Structs to the log file.
     *
     * @param name Name of the signal
     * @param struct Struct serialization implementation
     * @param values Values to write
     * @return Status of writing the data
     */
    public static <T> StatusCode writeStructArray(String name, Struct<T> struct, T[] values) {
        return writeStructArray(name, struct, values, 0);
    }
    /**
     * Writes the array of WPILib Structs to the log file.
     *
     * @param name Name of the signal
     * @param struct Struct serialization implementation
     * @param values Values to write
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static <T> StatusCode writeStructArray(String name, Struct<T> struct, T[] values, double latencySeconds) {
        final var typeName = struct.getTypeName() + "[]";
        if (!hasSchema(typeName, HootSchemaType.Struct)) {
            addStructSchema(struct, new HashSet<>());
            addSchema(typeName, HootSchemaType.Struct, new byte[0]);
        }

        try {
            _structBufferLck.lock();

            @SuppressWarnings("unchecked")
            StructBuffer<T> buf = (StructBuffer<T>)_structBuffers.get(typeName);
            if (buf == null) {
                buf = StructBuffer.create(struct);
                _structBuffers.put(typeName, buf);
            }
            return writeSchemaValue(name, typeName, HootSchemaType.Struct, buf.writeArray(values), latencySeconds);
        } finally {
            _structBufferLck.unlock();
        }
    }

    /**
     * Writes the protobuf to the log file.
     *
     * @param name Name of the signal
     * @param proto Protobuf serialization implementation
     * @param value Value to write
     * @return Status of writing the data
     */
    public static <T> StatusCode writeProtobuf(String name, Protobuf<T, ?> proto, T value) {
        return writeProtobuf(name, proto, value, 0);
    }
    /**
     * Writes the protobuf to the log file.
     *
     * @param name Name of the signal
     * @param proto Protobuf serialization implementation
     * @param value Value to write
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static <T> StatusCode writeProtobuf(String name, Protobuf<T, ?> proto, T value, double latencySeconds) {
        final var typeName = proto.getDescriptor().getFullName();
        if (!hasSchema(typeName, HootSchemaType.Protobuf)) {
            addProtobufSchema(proto.getDescriptor().getFile());
            addSchema(typeName, HootSchemaType.Protobuf, new byte[0]);
        }

        try {
            _protoBufferLck.lock();

            @SuppressWarnings("unchecked")
            ProtobufBuffer<T, ?> buf = (ProtobufBuffer<T, ?>)_protoBuffers.get(typeName);
            if (buf == null) {
                buf = ProtobufBuffer.create(proto);
                _protoBuffers.put(typeName, buf);
            }
            return writeSchemaValue(name, typeName, HootSchemaType.Protobuf, buf.write(value), latencySeconds);
        } catch (IOException e) {
            return StatusCode.InvalidParamValue;
        } finally {
            _protoBufferLck.unlock();
        }
    }

    /**
     * Writes the raw data bytes to the log file.
     *
     * @param name Name of the signal
     * @param data Raw data bytes
     * @return Status of writing the data
     */
    public static StatusCode writeRaw(String name, byte[] data) {
        return writeRaw(name, data, 0);
    }
    /**
     * Writes the raw data bytes to the log file.
     *
     * @param name Name of the signal
     * @param data Raw data bytes
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeRaw(String name, byte[] data, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteRaw(name, data, latencySeconds));
    }

    /**
     * Writes the boolean to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @return Status of writing the data
     */
    public static StatusCode writeBoolean(String name, boolean value) {
        return writeBoolean(name, value, 0);
    }
    /**
     * Writes the boolean to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeBoolean(String name, boolean value, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteBoolean(name, value, latencySeconds));
    }

    /**
     * Writes the integer to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @return Status of writing the data
     */
    public static StatusCode writeInteger(String name, long value) {
        return writeInteger(name, value, "");
    }
    /**
     * Writes the integer to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @param units Units of the signal
     * @return Status of writing the data
     */
    public static StatusCode writeInteger(String name, long value, String units) {
        return writeInteger(name, value, units, 0);
    }
    /**
     * Writes the integer to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @param units Units of the signal
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeInteger(String name, long value, String units, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteInteger(name, value, units, latencySeconds));
    }

    /**
     * Writes the float to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @return Status of writing the data
     */
    public static StatusCode writeFloat(String name, float value) {
        return writeFloat(name, value, "");
    }
    /**
     * Writes the float to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @param units Units of the signal
     * @return Status of writing the data
     */
    public static StatusCode writeFloat(String name, float value, String units) {
        return writeFloat(name, value, units, 0);
    }
    /**
     * Writes the float to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @param units Units of the signal
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeFloat(String name, float value, String units, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteFloat(name, value, units, latencySeconds));
    }

    /**
     * Writes the double to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @return Status of writing the data
     */
    public static StatusCode writeDouble(String name, double value) {
        return writeDouble(name, value, "");
    }
    /**
     * Writes the double to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @param units Units of the signal
     * @return Status of writing the data
     */
    public static StatusCode writeDouble(String name, double value, String units) {
        return writeDouble(name, value, units, 0);
    }
    /**
     * Writes the double to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @param units Units of the signal
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeDouble(String name, double value, String units, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteDouble(name, value, units, latencySeconds));
    }

    /**
     * Writes the string to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @return Status of writing the data
     */
    public static StatusCode writeString(String name, String value) {
        return writeString(name, value, 0);
    }
    /**
     * Writes the string to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeString(String name, String value, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteString(name, value, latencySeconds));
    }

    /**
     * Writes the unit value to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @return Status of writing the data
     */
    public static StatusCode writeValue(String name, Measure<?> value) {
        return writeValue(name, value, 0);
    }
    /**
     * Writes the unit value to the log file.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeValue(String name, Measure<?> value, double latencySeconds) {
        return writeDouble(name, value.magnitude(), value.unit().symbol(), latencySeconds);
    }

    /**
     * Writes the unit value to the log file in the given units.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @param units Units to use for logging the measure
     * @return Status of writing the data
     */
    public static <U extends Unit> StatusCode writeValue(String name, Measure<U> value, U units) {
        return writeValue(name, value, units, 0);
    }
    /**
     * Writes the unit value to the log file in the given units.
     *
     * @param name Name of the signal
     * @param value Value to write
     * @param units Units to use for logging the measure
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static <U extends Unit> StatusCode writeValue(String name, Measure<U> value, U units, double latencySeconds) {
        return writeDouble(name, value.in(units), units.symbol(), latencySeconds);
    }

    /**
     * Writes the array of booleans to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @return Status of writing the data
     */
    public static StatusCode writeBooleanArray(String name, boolean[] values) {
        return writeBooleanArray(name, values, 0);
    }
    /**
     * Writes the array of booleans to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeBooleanArray(String name, boolean[] values, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteBooleanArray(name, values, latencySeconds));
    }

    /**
     * Writes the array of integers to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @return Status of writing the data
     */
    public static StatusCode writeIntegerArray(String name, long[] values) {
        return writeIntegerArray(name, values, "");
    }
    /**
     * Writes the array of integers to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @param units Units of the signals
     * @return Status of writing the data
     */
    public static StatusCode writeIntegerArray(String name, long[] values, String units) {
        return writeIntegerArray(name, values, units, 0);
    }
    /**
     * Writes the array of integers to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @param units Units of the signals
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeIntegerArray(String name, long[] values, String units, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteIntegerArray(name, values, units, latencySeconds));
    }

    /**
     * Writes the array of floats to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @return Status of writing the data
     */
    public static StatusCode writeFloatArray(String name, float[] values) {
        return writeFloatArray(name, values, "");
    }
    /**
     * Writes the array of floats to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @param units Units of the signals
     * @return Status of writing the data
     */
    public static StatusCode writeFloatArray(String name, float[] values, String units) {
        return writeFloatArray(name, values, units, 0);
    }
    /**
     * Writes the array of floats to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @param units Units of the signals
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeFloatArray(String name, float[] values, String units, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteFloatArray(name, values, units, latencySeconds));
    }

    /**
     * Writes the array of doubles to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @return Status of writing the data
     */
    public static StatusCode writeDoubleArray(String name, double[] values) {
        return writeDoubleArray(name, values, "");
    }
    /**
     * Writes the array of doubles to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @param units Units of the signals
     * @return Status of writing the data
     */
    public static StatusCode writeDoubleArray(String name, double[] values, String units) {
        return writeDoubleArray(name, values, units, 0);
    }
    /**
     * Writes the array of doubles to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @param units Units of the signals
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeDoubleArray(String name, double[] values, String units, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteDoubleArray(name, values, units, latencySeconds));
    }

    /**
     * Writes the array of strings to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @return Status of writing the data
     */
    public static StatusCode writeStringArray(String name, String[] values) {
        return writeStringArray(name, values, 0);
    }
    /**
     * Writes the array of strings to the log file.
     *
     * @param name Name of the signal
     * @param values Array of values to write
     * @param latencySeconds Latency of the signal in seconds; this value is subtracted
     *                       from the current time to get the timestamp written to the log
     * @return Status of writing the data
     */
    public static StatusCode writeStringArray(String name, String[] values, double latencySeconds) {
        return StatusCode.valueOf(SignalLoggerJNI.JNI_WriteStringArray(name, values, latencySeconds));
    }

    private static final Lock _structBufferLck = new ReentrantLock();
    private static final Map<String, StructBuffer<?>> _structBuffers = new HashMap<>();

    private static final Lock _protoBufferLck = new ReentrantLock();
    private static final Map<String, ProtobufBuffer<?, ?>> _protoBuffers = new HashMap<>();

    private static void addStructSchema(Struct<?> struct, Set<String> seen) {
        final var typeName = struct.getTypeName();
        if (hasSchema(typeName, HootSchemaType.Struct)) {
            return;
        }
        if (!seen.add(typeName)) {
            throw new UnsupportedOperationException(typeName + ": circular reference with " + seen);
        }

        for (var nested : struct.getNested()) {
            addStructSchema(nested, seen);
        }
        addSchema(typeName, HootSchemaType.Struct, struct.getSchema());
        seen.remove(typeName);
    }

    private static void addProtobufSchema(FileDescriptor desc) {
        final var typeName = desc.getFullName();
        if (hasSchema(typeName, HootSchemaType.Protobuf)) {
            return;
        }

        for (var dep : desc.getDependencies()) {
            addProtobufSchema(dep);
        }
        addSchema(typeName, HootSchemaType.Protobuf, desc.toProtoBytes());
    }
}
