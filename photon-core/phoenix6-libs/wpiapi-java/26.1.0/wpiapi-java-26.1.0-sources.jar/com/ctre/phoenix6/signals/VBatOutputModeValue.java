/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The behavior of the VBat output. CANdle supports modulating VBat output for
 * single-color LED strips.
 */
public enum VBatOutputModeValue
{
    /**
     * VBat output is on at full power.
     */
    On(0),
    /**
     * VBat output is off.
     */
    Off(1),
    /**
     * VBat output is on at the specified modulation.
     */
    Modulated(2),;

    public final int value;

    VBatOutputModeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, VBatOutputModeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, VBatOutputModeValue>();
        for (VBatOutputModeValue type : VBatOutputModeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets VBatOutputModeValue from specified value
     * @param value Value of VBatOutputModeValue
     * @return VBatOutputModeValue of specified value
     */
    public static VBatOutputModeValue valueOf(int value)
    {
        VBatOutputModeValue retval = _map.get(value);
        if (retval != null) return retval;
        return VBatOutputModeValue.values()[0];
    }
}
