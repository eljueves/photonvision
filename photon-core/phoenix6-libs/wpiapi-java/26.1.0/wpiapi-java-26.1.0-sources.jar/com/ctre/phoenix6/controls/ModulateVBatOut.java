/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.jni.ControlJNI;
import com.ctre.phoenix6.hardware.traits.*;

import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Modulates the CANdle VBat output to the specified duty cycle. This can be
 * used to control a single-color LED strip.
 * <p>
 * Note that CANdleFeaturesConfigs.VBatOutputMode must be set to
 * VBatOutputModeValue.Modulated.
 * <p>
 * 
 */
public final class ModulateVBatOut implements ControlRequest, Cloneable {
    /**
     * Proportion of VBat to output in fractional units between 0.0 and 1.0.
     * 
     * <ul>
     *   <li> Units: fractional
     * </ul>
     * 
     */
    public double Output;

    /**
     * The frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     */
    public double UpdateFreqHz = 50;

    /**
     * Modulates the CANdle VBat output to the specified duty cycle. This can be
     * used to control a single-color LED strip.
     * <p>
     * Note that CANdleFeaturesConfigs.VBatOutputMode must be set to
     * VBatOutputModeValue.Modulated.
     * <p>
     * 
     * 
     * @param Output Proportion of VBat to output in fractional units between 0.0
     *               and 1.0.
     */
    public ModulateVBatOut(double Output) {
        this.Output = Output;
    }

    @Override
    public String getName() {
        return "ModulateVBatOut";
    }

    @Override
    public String toString() {
        String ss = "Control: ModulateVBatOut\n";
        ss += "    Output: " + Output + " fractional" + "\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlModulateVBatOut(
                network, deviceHash, UpdateFreqHz, Output));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String, String>();
        controlInfo.put("Name", getName());
        controlInfo.put("Output", String.valueOf(this.Output));
        return controlInfo;
    }
    
    /**
     * Modifies this Control Request's Output parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Proportion of VBat to output in fractional units between 0.0 and 1.0.
     * 
     * <ul>
     *   <li> Units: fractional
     * </ul>
     * 
     *
     * @param newOutput Parameter to modify
     * @return Itself
     */
    public ModulateVBatOut withOutput(double newOutput) {
        Output = newOutput;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public ModulateVBatOut withUpdateFreqHz(double newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public ModulateVBatOut withUpdateFreqHz(Frequency newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz.in(Hertz);
        return this;
    }

    @Override
    public ModulateVBatOut clone() {
        try {
            return (ModulateVBatOut)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

