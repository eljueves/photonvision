/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Direction of the sensor to determine positive rotation, as seen facing the
 * LED side of the CANcoder.
 */
public enum SensorDirectionValue
{
    /**
     * Counter-clockwise motion reports positive rotation.
     */
    CounterClockwise_Positive(0),
    /**
     * Clockwise motion reports positive rotation.
     */
    Clockwise_Positive(1),;

    public final int value;

    SensorDirectionValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, SensorDirectionValue> _map = null;
    static
    {
        _map = new HashMap<Integer, SensorDirectionValue>();
        for (SensorDirectionValue type : SensorDirectionValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets SensorDirectionValue from specified value
     * @param value Value of SensorDirectionValue
     * @return SensorDirectionValue of specified value
     */
    public static SensorDirectionValue valueOf(int value)
    {
        SensorDirectionValue retval = _map.get(value);
        if (retval != null) return retval;
        return SensorDirectionValue.values()[0];
    }
}
