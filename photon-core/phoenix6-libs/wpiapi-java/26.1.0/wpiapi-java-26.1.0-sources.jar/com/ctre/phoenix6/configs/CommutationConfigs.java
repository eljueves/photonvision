/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

/**
 * Configs that determine motor selection and commutation.
 * <p>
 * Set these configs to match your motor setup before commanding motor
 * output.
 */
public class CommutationConfigs implements ParentConfiguration, Cloneable {
    /**
     * Requires Phoenix Pro; Improves commutation and velocity measurement
     * for motors with hall sensors.  Talon can use advanced features to
     * improve commutation and velocity measurement when using a motor
     * with hall sensors.  This can improve peak efficiency by as high as
     * 2% and reduce noise in the measured velocity.
     * 
     */
    public AdvancedHallSupportValue AdvancedHallSupport = AdvancedHallSupportValue.Disabled;
    /**
     * Selects the motor and motor connections used with Talon.
     * <p>
     * This setting determines what kind of motor and sensors are used
     * with the Talon.  This also determines what signals are used on the
     * JST and Gadgeteer port.
     * <p>
     * Motor drive will not function correctly if this setting does not
     * match the physical setup.
     * 
     */
    public MotorArrangementValue MotorArrangement = MotorArrangementValue.Disabled;
    /**
     * If a brushed motor is selected with Motor Arrangement, this config
     * determines which of three leads to use.
     * 
     */
    public BrushedMotorWiringValue BrushedMotorWiring = BrushedMotorWiringValue.Leads_A_and_B;
    
    /**
     * Modifies this configuration's AdvancedHallSupport parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Requires Phoenix Pro; Improves commutation and velocity measurement
     * for motors with hall sensors.  Talon can use advanced features to
     * improve commutation and velocity measurement when using a motor
     * with hall sensors.  This can improve peak efficiency by as high as
     * 2% and reduce noise in the measured velocity.
     * 
     *
     * @param newAdvancedHallSupport Parameter to modify
     * @return Itself
     */
    public final CommutationConfigs withAdvancedHallSupport(AdvancedHallSupportValue newAdvancedHallSupport)
    {
        AdvancedHallSupport = newAdvancedHallSupport;
        return this;
    }
    
    /**
     * Modifies this configuration's MotorArrangement parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Selects the motor and motor connections used with Talon.
     * <p>
     * This setting determines what kind of motor and sensors are used
     * with the Talon.  This also determines what signals are used on the
     * JST and Gadgeteer port.
     * <p>
     * Motor drive will not function correctly if this setting does not
     * match the physical setup.
     * 
     *
     * @param newMotorArrangement Parameter to modify
     * @return Itself
     */
    public final CommutationConfigs withMotorArrangement(MotorArrangementValue newMotorArrangement)
    {
        MotorArrangement = newMotorArrangement;
        return this;
    }
    
    /**
     * Modifies this configuration's BrushedMotorWiring parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If a brushed motor is selected with Motor Arrangement, this config
     * determines which of three leads to use.
     * 
     *
     * @param newBrushedMotorWiring Parameter to modify
     * @return Itself
     */
    public final CommutationConfigs withBrushedMotorWiring(BrushedMotorWiringValue newBrushedMotorWiring)
    {
        BrushedMotorWiring = newBrushedMotorWiring;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: Commutation\n";
        ss += "    AdvancedHallSupport: " + AdvancedHallSupport + "\n";
        ss += "    MotorArrangement: " + MotorArrangement + "\n";
        ss += "    BrushedMotorWiring: " + BrushedMotorWiring + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeint(SpnValue.Config_AdvancedHallSupport.value, AdvancedHallSupport.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_MotorType.value, MotorArrangement.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_BrushedMotorWiring.value, BrushedMotorWiring.value);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        AdvancedHallSupport = AdvancedHallSupportValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_AdvancedHallSupport.value, to_deserialize));
        MotorArrangement = MotorArrangementValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_MotorType.value, to_deserialize));
        BrushedMotorWiring = BrushedMotorWiringValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_BrushedMotorWiring.value, to_deserialize));
        return  StatusCode.OK;
    }

    @Override
    public CommutationConfigs clone() {
        try {
            return (CommutationConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

