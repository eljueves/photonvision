/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.traits;

import com.ctre.phoenix6.*;
import com.ctre.phoenix6.signals.*;
import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;

/**
 * Contains all status signals for motor controllers that support external
 * motors.
 */
public interface HasExternalMotor extends CommonDevice
{
        
    /**
     * Status of the temperature sensor of the external motor.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ExternalMotorTempStatus Status Signal Object
     */
    StatusSignal<ExternalMotorTempStatusValue> getExternalMotorTempStatus();
    
    /**
     * Status of the temperature sensor of the external motor.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ExternalMotorTempStatus Status Signal Object
     */
    StatusSignal<ExternalMotorTempStatusValue> getExternalMotorTempStatus(boolean refresh);
        
    /**
     * Temperature of the external motor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 255.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ExternalMotorTemp Status Signal Object
     */
    StatusSignal<Temperature> getExternalMotorTemp();
    
    /**
     * Temperature of the external motor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 255.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ExternalMotorTemp Status Signal Object
     */
    StatusSignal<Temperature> getExternalMotorTemp(boolean refresh);
        
    /**
     * The measured voltage of the 5V rail available on the JST and
     * dataport connectors.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 40.95
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> Volts
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return FiveVRailVoltage Status Signal Object
     */
    StatusSignal<Voltage> getFiveVRailVoltage();
    
    /**
     * The measured voltage of the 5V rail available on the JST and
     * dataport connectors.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 40.95
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> Volts
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return FiveVRailVoltage Status Signal Object
     */
    StatusSignal<Voltage> getFiveVRailVoltage(boolean refresh);
        
    /**
     * The voltage of the analog pin (pin 3) of the Talon FXS data port.
     * The analog pin reads a nominal voltage of 0-5V.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 6
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> Volts
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AnalogVoltage Status Signal Object
     */
    StatusSignal<Voltage> getAnalogVoltage();
    
    /**
     * The voltage of the analog pin (pin 3) of the Talon FXS data port.
     * The analog pin reads a nominal voltage of 0-5V.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 6
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> Volts
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AnalogVoltage Status Signal Object
     */
    StatusSignal<Voltage> getAnalogVoltage(boolean refresh);
        
    /**
     * The raw position retrieved from the connected quadrature encoder.
     * This is only affected by the QuadratureEdgesPerRotation config. In
     * most situations, the user should instead configure the
     * ExternalFeedbackSensorSource and use the regular position getter.
     * <p>
     * This signal must have its update frequency configured before it
     * will have data.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RawQuadraturePosition Status Signal Object
     */
    StatusSignal<Angle> getRawQuadraturePosition();
    
    /**
     * The raw position retrieved from the connected quadrature encoder.
     * This is only affected by the QuadratureEdgesPerRotation config. In
     * most situations, the user should instead configure the
     * ExternalFeedbackSensorSource and use the regular position getter.
     * <p>
     * This signal must have its update frequency configured before it
     * will have data.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RawQuadraturePosition Status Signal Object
     */
    StatusSignal<Angle> getRawQuadraturePosition(boolean refresh);
        
    /**
     * The raw velocity retrieved from the connected quadrature encoder.
     * This is only affected by the QuadratureEdgesPerRotation config. In
     * most situations, the user should instead configure the
     * ExternalFeedbackSensorSource and use the regular velocity getter.
     * <p>
     * This signal must have its update frequency configured before it
     * will have data.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RawQuadratureVelocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getRawQuadratureVelocity();
    
    /**
     * The raw velocity retrieved from the connected quadrature encoder.
     * This is only affected by the QuadratureEdgesPerRotation config. In
     * most situations, the user should instead configure the
     * ExternalFeedbackSensorSource and use the regular velocity getter.
     * <p>
     * This signal must have its update frequency configured before it
     * will have data.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RawQuadratureVelocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getRawQuadratureVelocity(boolean refresh);
        
    /**
     * The raw position retrieved from the connected pulse-width encoder.
     * This is not affected by any config. In most situations, the user
     * should instead configure the ExternalFeedbackSensorSource and use
     * the regular position getter.
     * <p>
     * This signal must have its update frequency configured before it
     * will have data.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RawPulseWidthPosition Status Signal Object
     */
    StatusSignal<Angle> getRawPulseWidthPosition();
    
    /**
     * The raw position retrieved from the connected pulse-width encoder.
     * This is not affected by any config. In most situations, the user
     * should instead configure the ExternalFeedbackSensorSource and use
     * the regular position getter.
     * <p>
     * This signal must have its update frequency configured before it
     * will have data.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RawPulseWidthPosition Status Signal Object
     */
    StatusSignal<Angle> getRawPulseWidthPosition(boolean refresh);
        
    /**
     * The raw velocity retrieved from the connected pulse-width encoder.
     * This is not affected by any config. In most situations, the user
     * should instead configure the ExternalFeedbackSensorSource and use
     * the regular velocity getter.
     * <p>
     * This signal must have its update frequency configured before it
     * will have data.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RawPulseWidthVelocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getRawPulseWidthVelocity();
    
    /**
     * The raw velocity retrieved from the connected pulse-width encoder.
     * This is not affected by any config. In most situations, the user
     * should instead configure the ExternalFeedbackSensorSource and use
     * the regular velocity getter.
     * <p>
     * This signal must have its update frequency configured before it
     * will have data.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RawPulseWidthVelocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getRawPulseWidthVelocity(boolean refresh);
        
    /**
     * Bridge was disabled most likely due to a short in the motor leads.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BridgeShort Status Signal Object
     */
    StatusSignal<Boolean> getFault_BridgeShort();
    
    /**
     * Bridge was disabled most likely due to a short in the motor leads.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BridgeShort Status Signal Object
     */
    StatusSignal<Boolean> getFault_BridgeShort(boolean refresh);
        
    /**
     * Bridge was disabled most likely due to a short in the motor leads.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BridgeShort Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_BridgeShort();
    
    /**
     * Bridge was disabled most likely due to a short in the motor leads.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BridgeShort Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_BridgeShort(boolean refresh);
        
    /**
     * Hall sensor signals are invalid.  Check hall sensor and cabling. 
     * This fault can be used to detect when hall cable is unplugged.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_HallSensorMissing Status Signal Object
     */
    StatusSignal<Boolean> getFault_HallSensorMissing();
    
    /**
     * Hall sensor signals are invalid.  Check hall sensor and cabling. 
     * This fault can be used to detect when hall cable is unplugged.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_HallSensorMissing Status Signal Object
     */
    StatusSignal<Boolean> getFault_HallSensorMissing(boolean refresh);
        
    /**
     * Hall sensor signals are invalid.  Check hall sensor and cabling. 
     * This fault can be used to detect when hall cable is unplugged.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_HallSensorMissing Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_HallSensorMissing();
    
    /**
     * Hall sensor signals are invalid.  Check hall sensor and cabling. 
     * This fault can be used to detect when hall cable is unplugged.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_HallSensorMissing Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_HallSensorMissing(boolean refresh);
        
    /**
     * Hall sensor signals are invalid during motor drive, so motor was
     * disabled.  Check hall sensor and cabling.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_DriveDisabledHallSensor Status Signal Object
     */
    StatusSignal<Boolean> getFault_DriveDisabledHallSensor();
    
    /**
     * Hall sensor signals are invalid during motor drive, so motor was
     * disabled.  Check hall sensor and cabling.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_DriveDisabledHallSensor Status Signal Object
     */
    StatusSignal<Boolean> getFault_DriveDisabledHallSensor(boolean refresh);
        
    /**
     * Hall sensor signals are invalid during motor drive, so motor was
     * disabled.  Check hall sensor and cabling.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_DriveDisabledHallSensor Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_DriveDisabledHallSensor();
    
    /**
     * Hall sensor signals are invalid during motor drive, so motor was
     * disabled.  Check hall sensor and cabling.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_DriveDisabledHallSensor Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_DriveDisabledHallSensor(boolean refresh);
        
    /**
     * Motor temperature signal appears to not be connected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_MotorTempSensorMissing Status Signal Object
     */
    StatusSignal<Boolean> getFault_MotorTempSensorMissing();
    
    /**
     * Motor temperature signal appears to not be connected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_MotorTempSensorMissing Status Signal Object
     */
    StatusSignal<Boolean> getFault_MotorTempSensorMissing(boolean refresh);
        
    /**
     * Motor temperature signal appears to not be connected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_MotorTempSensorMissing Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MotorTempSensorMissing();
    
    /**
     * Motor temperature signal appears to not be connected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_MotorTempSensorMissing Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MotorTempSensorMissing(boolean refresh);
        
    /**
     * Motor temperature signal indicates motor is too hot.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_MotorTempSensorTooHot Status Signal Object
     */
    StatusSignal<Boolean> getFault_MotorTempSensorTooHot();
    
    /**
     * Motor temperature signal indicates motor is too hot.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_MotorTempSensorTooHot Status Signal Object
     */
    StatusSignal<Boolean> getFault_MotorTempSensorTooHot(boolean refresh);
        
    /**
     * Motor temperature signal indicates motor is too hot.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_MotorTempSensorTooHot Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MotorTempSensorTooHot();
    
    /**
     * Motor temperature signal indicates motor is too hot.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_MotorTempSensorTooHot Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MotorTempSensorTooHot(boolean refresh);
        
    /**
     * Motor arrangement has not been set in configuration.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_MotorArrangementNotSelected Status Signal Object
     */
    StatusSignal<Boolean> getFault_MotorArrangementNotSelected();
    
    /**
     * Motor arrangement has not been set in configuration.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_MotorArrangementNotSelected Status Signal Object
     */
    StatusSignal<Boolean> getFault_MotorArrangementNotSelected(boolean refresh);
        
    /**
     * Motor arrangement has not been set in configuration.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_MotorArrangementNotSelected Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MotorArrangementNotSelected();
    
    /**
     * Motor arrangement has not been set in configuration.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_MotorArrangementNotSelected Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MotorArrangementNotSelected(boolean refresh);
        
    /**
     * The CTR Electronics' TalonFX device has detected a 5V fault. This
     * may be due to overcurrent or a short-circuit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_5V Status Signal Object
     */
    StatusSignal<Boolean> getFault_5V();
    
    /**
     * The CTR Electronics' TalonFX device has detected a 5V fault. This
     * may be due to overcurrent or a short-circuit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_5V Status Signal Object
     */
    StatusSignal<Boolean> getFault_5V(boolean refresh);
        
    /**
     * The CTR Electronics' TalonFX device has detected a 5V fault. This
     * may be due to overcurrent or a short-circuit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_5V Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_5V();
    
    /**
     * The CTR Electronics' TalonFX device has detected a 5V fault. This
     * may be due to overcurrent or a short-circuit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_5V Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_5V(boolean refresh);
    

    
    /**
     * Clear sticky fault: Bridge was disabled most likely due to a short
     * in the motor leads.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_BridgeShort();
    /**
     * Clear sticky fault: Bridge was disabled most likely due to a short
     * in the motor leads.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_BridgeShort(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Hall sensor signals are invalid.  Check hall
     * sensor and cabling.  This fault can be used to detect when hall
     * cable is unplugged.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_HallSensorMissing();
    /**
     * Clear sticky fault: Hall sensor signals are invalid.  Check hall
     * sensor and cabling.  This fault can be used to detect when hall
     * cable is unplugged.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_HallSensorMissing(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Hall sensor signals are invalid during motor
     * drive, so motor was disabled.  Check hall sensor and cabling.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_DriveDisabledHallSensor();
    /**
     * Clear sticky fault: Hall sensor signals are invalid during motor
     * drive, so motor was disabled.  Check hall sensor and cabling.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_DriveDisabledHallSensor(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Motor temperature signal appears to not be
     * connected.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MotorTempSensorMissing();
    /**
     * Clear sticky fault: Motor temperature signal appears to not be
     * connected.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MotorTempSensorMissing(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Motor temperature signal indicates motor is too
     * hot.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MotorTempSensorTooHot();
    /**
     * Clear sticky fault: Motor temperature signal indicates motor is too
     * hot.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MotorTempSensorTooHot(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Motor arrangement has not been set in
     * configuration.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MotorArrangementNotSelected();
    /**
     * Clear sticky fault: Motor arrangement has not been set in
     * configuration.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MotorArrangementNotSelected(double timeoutSeconds);
}

