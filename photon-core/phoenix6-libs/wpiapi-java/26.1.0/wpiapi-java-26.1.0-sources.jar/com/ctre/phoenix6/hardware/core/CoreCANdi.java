/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.core;

import com.ctre.phoenix6.hardware.ParentDevice;
import com.ctre.phoenix6.controls.*;
import com.ctre.phoenix6.configs.*;
import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.jni.PlatformJNI;
import com.ctre.phoenix6.sim.DeviceType;
import com.ctre.phoenix6.sim.CANdiSimState;
import com.ctre.phoenix6.*;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;
import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Class for CTR Electronics' CANdi™ branded device, a device that integrates
 * digital signals into the existing CAN bus network.
 * 
 * <pre>
 * // Constants used in CANdi construction
 * final int kCANdiId = 0;
 * final CANBus kCANdiCANbus = new CANBus("canivore");
 * 
 * // Construct the CANdi
 * final CANdi candi = new CANdi(kCANdiId, kCANdiCANbus);
 * 
 * // Configure the CANdi for basic use
 * CANdiConfiguration configs = new CANdiConfiguration();
 * 
 * // Write these configs to the CANdi
 * candi.getConfigurator().apply(configs);
 * 
 * // Get Pin 1
 * var p1State = candi.getP1State();
 * 
 * // Refresh and print these values
 * System.out.println("Pin 1 is " + p1State.refresh().toString());
 * </pre>
 */
public class CoreCANdi extends ParentDevice
{
    private CANdiConfigurator _configurator;

    /**
     * Constructs a new CANdi object.
     * <p>
     * Constructs the device using the default CAN bus for the system
     * (see {@link CANBus#CANBus()}).
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     */
    public CoreCANdi(int deviceId)
    {
        this(deviceId, new CANBus());
    }

    /**
     * Constructs a new CANdi object.
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     * @param canbus      Name of the CAN bus this device is on. Possible CAN bus strings are:
     *                    <ul>
     *                      <li>"rio" for the native roboRIO CAN bus
     *                      <li>CANivore name or serial number
     *                      <li>SocketCAN interface (non-FRC Linux only)
     *                      <li>"*" for any CANivore seen by the program
     *                      <li>empty string (default) to select the default for the system:
     *                      <ul>
     *                        <li>"rio" on roboRIO
     *                        <li>"can0" on Linux
     *                        <li>"*" on Windows
     *                      </ul>
     *                    </ul>
     *
     * @deprecated Constructing devices with a CAN bus string is deprecated for removal
     * in the 2027 season. Construct devices using a {@link CANBus} instance instead.
     */
    @Deprecated(since = "2026", forRemoval = true)
    public CoreCANdi(int deviceId, String canbus)
    {
        this(deviceId, new CANBus(canbus));
    }

    /**
     * Constructs a new CANdi object.
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     * @param canbus      The CAN bus this device is on
     */
    public CoreCANdi(int deviceId, CANBus canbus)
    {
        super(deviceId, "candi", canbus);
        _configurator = new CANdiConfigurator(this.deviceIdentifier);
        PlatformJNI.JNI_SimCreate(DeviceType.P6_CANdiType.value, deviceId);
    }

    /**
     * Gets the configurator to use with this device's configs
     *
     * @return Configurator for this object
     */
    public final CANdiConfigurator getConfigurator()
    {
        return this._configurator;
    }


    private CANdiSimState _simState = null;
    /**
     * Get the simulation state for this device.
     * <p>
     * This function reuses an allocated simulation state
     * object, so it is safe to call this function multiple
     * times in a robot loop.
     *
     * @return Simulation state
     */
    public final CANdiSimState getSimState() {
        if (_simState == null)
            _simState = new CANdiSimState(this);
        return _simState;
    }


        
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMajor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMajor()
    {
        return getVersionMajor(true);
    }
    
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMajor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMajor(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Major.value, "VersionMajor", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMinor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMinor()
    {
        return getVersionMinor(true);
    }
    
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMinor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMinor(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Minor.value, "VersionMinor", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBugfix Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBugfix()
    {
        return getVersionBugfix(true);
    }
    
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBugfix Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBugfix(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Bugfix.value, "VersionBugfix", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBuild Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBuild()
    {
        return getVersionBuild(true);
    }
    
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBuild Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBuild(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Build.value, "VersionBuild", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Version Status Signal Object
     */
    public final StatusSignal<Integer> getVersion()
    {
        return getVersion(true);
    }
    
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Version Status Signal Object
     */
    public final StatusSignal<Integer> getVersion(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Full.value, "Version", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return FaultField Status Signal Object
     */
    public final StatusSignal<Integer> getFaultField()
    {
        return getFaultField(true);
    }
    
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return FaultField Status Signal Object
     */
    public final StatusSignal<Integer> getFaultField(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.AllFaults.value, "FaultField", Integer.class, val -> (int)val, true, refresh);
        return retval;
    }
        
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFaultField Status Signal Object
     */
    public final StatusSignal<Integer> getStickyFaultField()
    {
        return getStickyFaultField(true);
    }
    
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFaultField Status Signal Object
     */
    public final StatusSignal<Integer> getStickyFaultField(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.AllStickyFaults.value, "StickyFaultField", Integer.class, val -> (int)val, true, refresh);
        return retval;
    }
        
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return IsProLicensed Status Signal Object
     */
    public final StatusSignal<Boolean> getIsProLicensed()
    {
        return getIsProLicensed(true);
    }
    
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return IsProLicensed Status Signal Object
     */
    public final StatusSignal<Boolean> getIsProLicensed(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_IsProLicensed.value, "IsProLicensed", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * State of the Signal 1 input (S1IN).
     * 
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return S1State Status Signal Object
     */
    public final StatusSignal<S1StateValue> getS1State()
    {
        return getS1State(true);
    }
    
    /**
     * State of the Signal 1 input (S1IN).
     * 
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return S1State Status Signal Object
     */
    public final StatusSignal<S1StateValue> getS1State(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_Pin1State.value, "S1State", S1StateValue.class, val -> S1StateValue.valueOf((int)val), true, refresh);
        return retval;
    }
        
    /**
     * State of the Signal 2 input (S2IN).
     * 
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return S2State Status Signal Object
     */
    public final StatusSignal<S2StateValue> getS2State()
    {
        return getS2State(true);
    }
    
    /**
     * State of the Signal 2 input (S2IN).
     * 
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return S2State Status Signal Object
     */
    public final StatusSignal<S2StateValue> getS2State(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_Pin2State.value, "S2State", S2StateValue.class, val -> S2StateValue.valueOf((int)val), true, refresh);
        return retval;
    }
        
    /**
     * Position from a quadrature encoder sensor connected to both the
     * S1IN and S2IN inputs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return QuadraturePosition Status Signal Object
     */
    public final StatusSignal<Angle> getQuadraturePosition()
    {
        return getQuadraturePosition(true);
    }
    
    /**
     * Position from a quadrature encoder sensor connected to both the
     * S1IN and S2IN inputs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return QuadraturePosition Status Signal Object
     */
    public final StatusSignal<Angle> getQuadraturePosition(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_QuadPosition.value, "QuadraturePosition", Angle.class, val -> Rotations.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Measured rise to rise time of the PWM signal at the S1 input of the
     * CTR Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 131070
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> us
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return PWM1RiseToRise Status Signal Object
     */
    public final StatusSignal<Time> getPWM1RiseToRise()
    {
        return getPWM1RiseToRise(true);
    }
    
    /**
     * Measured rise to rise time of the PWM signal at the S1 input of the
     * CTR Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 131070
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> us
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return PWM1RiseToRise Status Signal Object
     */
    public final StatusSignal<Time> getPWM1RiseToRise(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_Pwm1_RiseToRise.value, "PWM1RiseToRise", Time.class, val -> Microseconds.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Measured position of the PWM sensor at the S1 input of the CTR
     * Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return PWM1Position Status Signal Object
     */
    public final StatusSignal<Angle> getPWM1Position()
    {
        return getPWM1Position(true);
    }
    
    /**
     * Measured position of the PWM sensor at the S1 input of the CTR
     * Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return PWM1Position Status Signal Object
     */
    public final StatusSignal<Angle> getPWM1Position(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_Pwm1_Position.value, "PWM1Position", Angle.class, val -> Rotations.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Measured velocity of the PWM sensor at the S1 input of the CTR
     * Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return PWM1Velocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getPWM1Velocity()
    {
        return getPWM1Velocity(true);
    }
    
    /**
     * Measured velocity of the PWM sensor at the S1 input of the CTR
     * Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return PWM1Velocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getPWM1Velocity(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_Pwm1_Velocity.value, "PWM1Velocity", AngularVelocity.class, val -> RotationsPerSecond.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Measured rise to rise time of the PWM signal at the S2 input of the
     * CTR Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 131070
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> us
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return PWM2RiseToRise Status Signal Object
     */
    public final StatusSignal<Time> getPWM2RiseToRise()
    {
        return getPWM2RiseToRise(true);
    }
    
    /**
     * Measured rise to rise time of the PWM signal at the S2 input of the
     * CTR Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 131070
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> us
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return PWM2RiseToRise Status Signal Object
     */
    public final StatusSignal<Time> getPWM2RiseToRise(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_Pwm2_RiseToRise.value, "PWM2RiseToRise", Time.class, val -> Microseconds.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Measured position of the PWM sensor at the S2 input of the CTR
     * Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return PWM2Position Status Signal Object
     */
    public final StatusSignal<Angle> getPWM2Position()
    {
        return getPWM2Position(true);
    }
    
    /**
     * Measured position of the PWM sensor at the S2 input of the CTR
     * Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return PWM2Position Status Signal Object
     */
    public final StatusSignal<Angle> getPWM2Position(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_Pwm2_Position.value, "PWM2Position", Angle.class, val -> Rotations.of(val), true, refresh);
        return retval;
    }
        
    /**
     * True when the CANdi™ is in overcurrent protection mode. This may be
     * due to either overcurrent or a short-circuit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> 0
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Overcurrent Status Signal Object
     */
    public final StatusSignal<Boolean> getOvercurrent()
    {
        return getOvercurrent(true);
    }
    
    /**
     * True when the CANdi™ is in overcurrent protection mode. This may be
     * due to either overcurrent or a short-circuit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> 0
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Overcurrent Status Signal Object
     */
    public final StatusSignal<Boolean> getOvercurrent(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_Overcurrent.value, "Overcurrent", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Measured supply voltage to the CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 4.0
     *   <li> <b>Maximum Value:</b> 29.5
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return SupplyVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getSupplyVoltage()
    {
        return getSupplyVoltage(true);
    }
    
    /**
     * Measured supply voltage to the CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 4.0
     *   <li> <b>Maximum Value:</b> 29.5
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return SupplyVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getSupplyVoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_VSense.value, "SupplyVoltage", Voltage.class, val -> Volts.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Measured output current. This includes both Vbat and 5V output
     * current.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 0.51
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return OutputCurrent Status Signal Object
     */
    public final StatusSignal<Current> getOutputCurrent()
    {
        return getOutputCurrent(true);
    }
    
    /**
     * Measured output current. This includes both Vbat and 5V output
     * current.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 0.51
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return OutputCurrent Status Signal Object
     */
    public final StatusSignal<Current> getOutputCurrent(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_OutputCurrent.value, "OutputCurrent", Current.class, val -> Amps.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Measured velocity of the PWM sensor at the S2 input of the CTR
     * Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return PWM2Velocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getPWM2Velocity()
    {
        return getPWM2Velocity(true);
    }
    
    /**
     * Measured velocity of the PWM sensor at the S2 input of the CTR
     * Electronics' CANdi™.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return PWM2Velocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getPWM2Velocity(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_Pwm2_Velocity.value, "PWM2Velocity", AngularVelocity.class, val -> RotationsPerSecond.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Velocity from a quadrature encoder sensor connected to both the
     * S1IN and S2IN inputs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return QuadratureVelocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getQuadratureVelocity()
    {
        return getQuadratureVelocity(true);
    }
    
    /**
     * Velocity from a quadrature encoder sensor connected to both the
     * S1IN and S2IN inputs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 20.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return QuadratureVelocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getQuadratureVelocity(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_QuadVelocity.value, "QuadratureVelocity", AngularVelocity.class, val -> RotationsPerSecond.of(val), true, refresh);
        return retval;
    }
        
    /**
     * True if the Signal 1 input (S1IN) matches the configured S1 Closed
     * State.
     * <p>
     * Configure the S1 closed state in the Digitals configuration object
     * to change when this is asserted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return S1Closed Status Signal Object
     */
    public final StatusSignal<Boolean> getS1Closed()
    {
        return getS1Closed(true);
    }
    
    /**
     * True if the Signal 1 input (S1IN) matches the configured S1 Closed
     * State.
     * <p>
     * Configure the S1 closed state in the Digitals configuration object
     * to change when this is asserted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return S1Closed Status Signal Object
     */
    public final StatusSignal<Boolean> getS1Closed(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_S1Closed.value, "S1Closed", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * True if the Signal 2 input (S2IN) matches the configured S2 Closed
     * State.
     * <p>
     * Configure the S2 closed state in the Digitals configuration object
     * to change when this is asserted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return S2Closed Status Signal Object
     */
    public final StatusSignal<Boolean> getS2Closed()
    {
        return getS2Closed(true);
    }
    
    /**
     * True if the Signal 2 input (S2IN) matches the configured S2 Closed
     * State.
     * <p>
     * Configure the S2 closed state in the Digitals configuration object
     * to change when this is asserted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return S2Closed Status Signal Object
     */
    public final StatusSignal<Boolean> getS2Closed(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANdi_S2Closed.value, "S2Closed", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Hardware()
    {
        return getFault_Hardware(true);
    }
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Hardware(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_Hardware.value, "Fault_Hardware", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Hardware()
    {
        return getStickyFault_Hardware(true);
    }
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Hardware(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_Hardware.value, "StickyFault_Hardware", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Undervoltage()
    {
        return getFault_Undervoltage(true);
    }
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Undervoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_Undervoltage.value, "Fault_Undervoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Undervoltage()
    {
        return getStickyFault_Undervoltage(true);
    }
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Undervoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_Undervoltage.value, "StickyFault_Undervoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootDuringEnable()
    {
        return getFault_BootDuringEnable(true);
    }
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootDuringEnable(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_BootDuringEnable.value, "Fault_BootDuringEnable", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootDuringEnable()
    {
        return getStickyFault_BootDuringEnable(true);
    }
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootDuringEnable(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_BootDuringEnable.value, "StickyFault_BootDuringEnable", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_UnlicensedFeatureInUse()
    {
        return getFault_UnlicensedFeatureInUse(true);
    }
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_UnlicensedFeatureInUse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_UnlicensedFeatureInUse.value, "Fault_UnlicensedFeatureInUse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse()
    {
        return getStickyFault_UnlicensedFeatureInUse(true);
    }
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_UnlicensedFeatureInUse.value, "StickyFault_UnlicensedFeatureInUse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * The CTR Electronics' CANdi™ branded device has detected a 5V fault.
     * This may be due to overcurrent or a short-circuit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_5V Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_5V()
    {
        return getFault_5V(true);
    }
    
    /**
     * The CTR Electronics' CANdi™ branded device has detected a 5V fault.
     * This may be due to overcurrent or a short-circuit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_5V Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_5V(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_CANDI_5V.value, "Fault_5V", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * The CTR Electronics' CANdi™ branded device has detected a 5V fault.
     * This may be due to overcurrent or a short-circuit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_5V Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_5V()
    {
        return getStickyFault_5V(true);
    }
    
    /**
     * The CTR Electronics' CANdi™ branded device has detected a 5V fault.
     * This may be due to overcurrent or a short-circuit.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_5V Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_5V(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_CANDI_5V.value, "StickyFault_5V", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }

    

    /**
     * Control device with generic control request object.
     * <p>
     * User must make sure the specified object is castable to a valid control request,
     * otherwise this function will fail at run-time and return the NotSupported StatusCode
     *
     * @param request Control object to request of the device
     * @return Status Code of the request, 0 is OK
     */
    public final StatusCode setControl(ControlRequest request)
    {
        
        return StatusCode.NotSupported;
    }

    
    /**
     * Sets the position of the quadrature input.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @return StatusCode of the set command
     */
    public final StatusCode setQuadraturePosition(double newValue) {
        return setQuadraturePosition(newValue, 0.100);
    }
    /**
     * Sets the position of the quadrature input.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setQuadraturePosition(double newValue, double timeoutSeconds) {
        return getConfigurator().setQuadraturePosition(newValue, timeoutSeconds);
    }
    
    /**
     * Sets the position of the quadrature input.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @return StatusCode of the set command
     */
    public final StatusCode setQuadraturePosition(Angle newValue) {
        return setQuadraturePosition(newValue.in(Rotations));
    }
    /**
     * Sets the position of the quadrature input.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setQuadraturePosition(Angle newValue, double timeoutSeconds) {
        return setQuadraturePosition(newValue.in(Rotations), timeoutSeconds);
    }
    
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults() {
        return clearStickyFaults(0.100);
    }
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults(double timeoutSeconds) {
        return getConfigurator().clearStickyFaults(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware() {
        return clearStickyFault_Hardware(0.100);
    }
    /**
     * Clear sticky fault: Hardware fault occurred
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Hardware(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage() {
        return clearStickyFault_Undervoltage(0.100);
    }
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Undervoltage(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable() {
        return clearStickyFault_BootDuringEnable(0.100);
    }
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_BootDuringEnable(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse() {
        return clearStickyFault_UnlicensedFeatureInUse(0.100);
    }
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_UnlicensedFeatureInUse(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: The CTR Electronics' CANdi™ branded device has
     * detected a 5V fault. This may be due to overcurrent or a
     * short-circuit.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_5V() {
        return clearStickyFault_5V(0.100);
    }
    /**
     * Clear sticky fault: The CTR Electronics' CANdi™ branded device has
     * detected a 5V fault. This may be due to overcurrent or a
     * short-circuit.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_5V(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_5V(timeoutSeconds);
    }
}

