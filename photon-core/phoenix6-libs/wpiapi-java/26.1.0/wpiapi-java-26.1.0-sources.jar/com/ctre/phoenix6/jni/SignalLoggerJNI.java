/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.jni;

import java.nio.ByteBuffer;

public class SignalLoggerJNI extends CtreJniWrapper{
    public static native int JNI_SetLoggerPath(String path);
    public static native int JNI_StartLogger();
    public static native int JNI_StopLogger();
    public static native int JNI_EnableAutoLogging(boolean enable);

    public static native int JNI_AddSchema(String name, int type, byte[] schema);
    public static native int JNI_AddSchemaString(String name, int type, String schema);
    public static native boolean JNI_HasSchema(String name, int type);
    public static native int JNI_WriteSchemaValue(String name, String schema, int type, byte[] data, int start, int len, double latencySeconds);
    public static native int JNI_WriteSchemaBuffer(String name, String schema, int type, ByteBuffer data, int start, int len, double latencySeconds);
    public static native int JNI_WriteRaw(String name, byte[] data, double latencySeconds);
    public static native int JNI_WriteBoolean(String name, boolean value, double latencySeconds);
    public static native int JNI_WriteInteger(String name, long value, String units, double latencySeconds);
    public static native int JNI_WriteFloat(String name, float value, String units, double latencySeconds);
    public static native int JNI_WriteDouble(String name, double value, String units, double latencySeconds);
    public static native int JNI_WriteString(String name, String value, double latencySeconds);
    public static native int JNI_WriteBooleanArray(String name, boolean[] values, double latencySeconds);
    public static native int JNI_WriteIntegerArray(String name, long[] values, String units, double latencySeconds);
    public static native int JNI_WriteFloatArray(String name, float[] values, String units, double latencySeconds);
    public static native int JNI_WriteDoubleArray(String name, double[] values, String units, double latencySeconds);
    public static native int JNI_WriteStringArray(String name, String[] values, double latencySeconds);
}
