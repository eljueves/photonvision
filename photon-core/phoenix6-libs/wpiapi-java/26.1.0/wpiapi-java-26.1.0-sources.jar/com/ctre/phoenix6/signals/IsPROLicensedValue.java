/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether the device is Pro licensed.
 */
public enum IsPROLicensedValue
{
    NotLicensed(0),
    Licensed(1),;

    public final int value;

    IsPROLicensedValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, IsPROLicensedValue> _map = null;
    static
    {
        _map = new HashMap<Integer, IsPROLicensedValue>();
        for (IsPROLicensedValue type : IsPROLicensedValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets IsPROLicensedValue from specified value
     * @param value Value of IsPROLicensedValue
     * @return IsPROLicensedValue of specified value
     */
    public static IsPROLicensedValue valueOf(int value)
    {
        IsPROLicensedValue retval = _map.get(value);
        if (retval != null) return retval;
        return IsPROLicensedValue.values()[0];
    }
}
