/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.swerve;

import com.ctre.phoenix6.hardware.CANcoder;
import com.ctre.phoenix6.hardware.CANdi;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.hardware.TalonFXS;
import com.ctre.phoenix6.sim.CANcoderSimState;
import com.ctre.phoenix6.sim.CANdiSimState;
import com.ctre.phoenix6.sim.ChassisReference;
import com.ctre.phoenix6.sim.Pigeon2SimState;
import com.ctre.phoenix6.sim.TalonFXSSimState;
import com.ctre.phoenix6.sim.TalonFXSimState;
import com.ctre.phoenix6.swerve.SwerveModuleConstants.DriveMotorArrangement;
import com.ctre.phoenix6.swerve.SwerveModuleConstants.SteerFeedbackType;
import com.ctre.phoenix6.swerve.SwerveModuleConstants.SteerMotorArrangement;

import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.kinematics.SwerveDriveKinematics;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.math.system.plant.DCMotor;
import edu.wpi.first.math.system.plant.LinearSystemId;
import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj.simulation.DCMotorSim;

/**
 * Simplified swerve drive simulation class.
 * <p>
 * This class assumes that the swerve drive is perfect, meaning
 * that there is no scrub and the wheels do not slip.
 * <p>
 * In addition, it assumes the inertia of the robot is governed only
 * by the inertia of the steer module and the individual drive wheels.
 * Robot-wide inertia is not accounted for, and neither is translational
 * vs rotational inertia of the robot.
 * <p>
 * These assumptions provide a simplified example that can demonstrate the
 * behavior of a swerve drive in simulation. Users are encouraged to
 * expand this model for their own use.
 */
public class SimSwerveDrivetrain {
    protected static class SimSwerveModule {
        /** Reference to motor simulation for drive motor */
        public final DCMotorSim DriveMotor;
        /** Reference to motor simulation for the steer motor */
        public final DCMotorSim SteerMotor;
        /** Reference to steer gearing for updating encoder */
        public final double DriveGearing;
        /** Reference to steer gearing for updating encoder */
        public final double SteerGearing;
        /** Voltage necessary for the drive motor to overcome friction */
        public final double DriveFrictionVoltage;
        /** Voltage necessary for the steer motor to overcome friction */
        public final double SteerFrictionVoltage;
        /** Whether the drive motor is inverted */
        public final boolean DriveMotorInverted;
        /** Whether the steer motor is inverted */
        public final boolean SteerMotorInverted;
        /** Whether the azimuth encoder is inverted */
        public final boolean EncoderInverted;
        /** Offset of the azimuth encoder */
        public final double EncoderOffset;
        /** The type of encoder to use for the azimuth */
        public final SteerFeedbackType EncoderType;

        public SimSwerveModule(
            double driveGearing, double driveInertia,
            double driveFrictionVoltage, boolean driveMotorInverted,
            DriveMotorArrangement driveMotorType,
            double steerGearing, double steerInertia,
            double steerFrictionVoltage, boolean steerMotorInverted,
            SteerMotorArrangement steerMotorType,
            boolean encoderInverted,
            double encoderOffset,
            SteerFeedbackType encoderType
        ) {
            var driveGearbox = switch (driveMotorType) {
                case TalonFX_Integrated -> DCMotor.getKrakenX60Foc(1);
                case TalonFXS_NEO_JST -> DCMotor.getNEO(1);
                case TalonFXS_VORTEX_JST -> DCMotor.getNeoVortex(1);
            };
            var steerGearbox = switch (steerMotorType) {
                case TalonFX_Integrated -> DCMotor.getKrakenX60Foc(1);
                case TalonFXS_Minion_JST -> new DCMotor(12, 3.1, 202, 4, 774, 1);
                case TalonFXS_NEO_JST -> DCMotor.getNEO(1);
                case TalonFXS_VORTEX_JST -> DCMotor.getNeoVortex(1);
                case TalonFXS_NEO550_JST -> DCMotor.getNeo550(1);
                case TalonFXS_Brushed_AB, TalonFXS_Brushed_AC, TalonFXS_Brushed_BC -> DCMotor.getCIM(1);
            };

            DriveMotor = new DCMotorSim(LinearSystemId.createDCMotorSystem(driveGearbox, driveInertia, driveGearing), driveGearbox);
            SteerMotor = new DCMotorSim(LinearSystemId.createDCMotorSystem(steerGearbox, steerInertia, steerGearing), steerGearbox);
            DriveGearing = driveGearing;
            SteerGearing = steerGearing;
            DriveFrictionVoltage = driveFrictionVoltage;
            SteerFrictionVoltage = steerFrictionVoltage;
            DriveMotorInverted = driveMotorInverted;
            SteerMotorInverted = steerMotorInverted;
            EncoderInverted = encoderInverted;
            EncoderOffset = encoderOffset;
            EncoderType = encoderType;
        }
    }

    protected final Pigeon2SimState m_pigeonSim;
    protected final SimSwerveModule[] m_modules;

    protected final SwerveDriveKinematics m_kinem;
    protected Rotation2d m_lastAngle = new Rotation2d();

    public SimSwerveDrivetrain(
        Translation2d[] wheelLocations,
        Pigeon2SimState pigeonSim,
        SwerveModuleConstants<?, ?, ?>... moduleConstants
    ) {
        m_pigeonSim = pigeonSim;
        m_modules = new SimSwerveModule[moduleConstants.length];
        for (int i = 0; i < m_modules.length; ++i) {
            m_modules[i] = new SimSwerveModule(
                moduleConstants[i].DriveMotorGearRatio, moduleConstants[i].DriveInertia,
                moduleConstants[i].DriveFrictionVoltage, moduleConstants[i].DriveMotorInverted,
                moduleConstants[i].DriveMotorType,
                moduleConstants[i].SteerMotorGearRatio, moduleConstants[i].SteerInertia,
                moduleConstants[i].SteerFrictionVoltage, moduleConstants[i].SteerMotorInverted,
                moduleConstants[i].SteerMotorType,
                moduleConstants[i].EncoderInverted,
                moduleConstants[i].EncoderOffset,
                moduleConstants[i].FeedbackSource
            );
        }

        m_kinem = new SwerveDriveKinematics(wheelLocations);
    }

    /**
     * Update this simulation for the time duration.
     * <p>
     * This performs a simulation update on all the simulated devices
     *
     * @param dtSeconds The time delta between this update and the previous update
     * @param supplyVoltage The voltage as seen at the motor controllers
     * @param modulesToApply What modules to apply the update to
     */
    public final void update(double dtSeconds, double supplyVoltage, SwerveModule<?, ?, ?>... modulesToApply) {
        if (modulesToApply.length != m_modules.length) return;

        SwerveModuleState[] states = new SwerveModuleState[m_modules.length];
        /* Update our sim devices */
        for (int i = 0; i < m_modules.length; ++i) {
            if (modulesToApply[i].getDriveMotor() instanceof TalonFX driveFX) {
                TalonFXSimState driveMotor = driveFX.getSimState();
                driveMotor.Orientation = m_modules[i].DriveMotorInverted ? ChassisReference.Clockwise_Positive : ChassisReference.CounterClockwise_Positive;

                driveMotor.setSupplyVoltage(supplyVoltage);

                m_modules[i].DriveMotor.setInputVoltage(addFriction(driveMotor.getMotorVoltage(), m_modules[i].DriveFrictionVoltage));
                m_modules[i].DriveMotor.update(dtSeconds);

                driveMotor.setRawRotorPosition(m_modules[i].DriveMotor.getAngularPositionRotations() * m_modules[i].DriveGearing);
                driveMotor.setRotorVelocity(m_modules[i].DriveMotor.getAngularVelocityRPM() / 60.0 * m_modules[i].DriveGearing);
            } else if (modulesToApply[i].getDriveMotor() instanceof TalonFXS driveFXS) {
                TalonFXSSimState driveMotor = driveFXS.getSimState();
                driveMotor.MotorOrientation = m_modules[i].DriveMotorInverted ? ChassisReference.Clockwise_Positive : ChassisReference.CounterClockwise_Positive;

                driveMotor.setSupplyVoltage(supplyVoltage);

                m_modules[i].DriveMotor.setInputVoltage(addFriction(driveMotor.getMotorVoltage(), m_modules[i].DriveFrictionVoltage));
                m_modules[i].DriveMotor.update(dtSeconds);

                driveMotor.setRawRotorPosition(m_modules[i].DriveMotor.getAngularPositionRotations() * m_modules[i].DriveGearing);
                driveMotor.setRotorVelocity(m_modules[i].DriveMotor.getAngularVelocityRPM() / 60.0 * m_modules[i].DriveGearing);
            }

            if (modulesToApply[i].getSteerMotor() instanceof TalonFX steerFX) {
                TalonFXSimState steerMotor = steerFX.getSimState();
                steerMotor.Orientation = m_modules[i].SteerMotorInverted ? ChassisReference.Clockwise_Positive : ChassisReference.CounterClockwise_Positive;

                steerMotor.setSupplyVoltage(supplyVoltage);

                m_modules[i].SteerMotor.setInputVoltage(addFriction(steerMotor.getMotorVoltage(), m_modules[i].SteerFrictionVoltage));
                m_modules[i].SteerMotor.update(dtSeconds);

                steerMotor.setRawRotorPosition(m_modules[i].SteerMotor.getAngularPositionRotations() * m_modules[i].SteerGearing);
                steerMotor.setRotorVelocity(m_modules[i].SteerMotor.getAngularVelocityRPM() / 60.0 * m_modules[i].SteerGearing);
            } else if (modulesToApply[i].getSteerMotor() instanceof TalonFXS steerFXS) {
                TalonFXSSimState steerMotor = steerFXS.getSimState();
                steerMotor.MotorOrientation = m_modules[i].SteerMotorInverted ? ChassisReference.Clockwise_Positive : ChassisReference.CounterClockwise_Positive;
                steerMotor.ExtSensorOrientation = m_modules[i].SteerMotorInverted != m_modules[i].EncoderInverted ? ChassisReference.Clockwise_Positive : ChassisReference.CounterClockwise_Positive;
                steerMotor.PulseWidthSensorOffset = m_modules[i].EncoderOffset;

                steerMotor.setSupplyVoltage(supplyVoltage);

                m_modules[i].SteerMotor.setInputVoltage(addFriction(steerMotor.getMotorVoltage(), m_modules[i].SteerFrictionVoltage));
                m_modules[i].SteerMotor.update(dtSeconds);

                steerMotor.setRawRotorPosition(m_modules[i].SteerMotor.getAngularPositionRotations() * m_modules[i].SteerGearing);
                steerMotor.setRotorVelocity(m_modules[i].SteerMotor.getAngularVelocityRPM() / 60.0 * m_modules[i].SteerGearing);
                /* azimuth encoders see the mechanism, so don't account for the steer gearing */
                steerMotor.setPulseWidthPosition(m_modules[i].SteerMotor.getAngularPositionRotations());
                steerMotor.setPulseWidthVelocity(m_modules[i].SteerMotor.getAngularVelocityRPM() / 60.0);
            }

            if (modulesToApply[i].getEncoder() instanceof CANcoder cancoder) {
                CANcoderSimState encoder = cancoder.getSimState();
                encoder.Orientation = m_modules[i].EncoderInverted ? ChassisReference.Clockwise_Positive : ChassisReference.CounterClockwise_Positive;
                encoder.SensorOffset = m_modules[i].EncoderOffset;

                encoder.setSupplyVoltage(supplyVoltage);

                /* azimuth encoders see the mechanism, so don't account for the steer gearing */
                encoder.setRawPosition(m_modules[i].SteerMotor.getAngularPositionRotations());
                encoder.setVelocity(m_modules[i].SteerMotor.getAngularVelocityRPM() / 60.0);
            } else if (modulesToApply[i].getEncoder() instanceof CANdi candi) {
                CANdiSimState encoder = candi.getSimState();
                encoder.setSupplyVoltage(supplyVoltage);

                switch (m_modules[i].EncoderType) {
                    case FusedCANdiPWM1:
                    case SyncCANdiPWM1:
                    case RemoteCANdiPWM1:
                        encoder.Pwm1Orientation = m_modules[i].EncoderInverted ? ChassisReference.Clockwise_Positive : ChassisReference.CounterClockwise_Positive;
                        encoder.Pwm1SensorOffset = m_modules[i].EncoderOffset;

                        /* azimuth encoders see the mechanism, so don't account for the steer gearing */
                        encoder.setPwm1Connected(true);
                        encoder.setPwm1Position(m_modules[i].SteerMotor.getAngularPositionRotations());
                        encoder.setPwm1Velocity(m_modules[i].SteerMotor.getAngularVelocityRPM() / 60.0);
                        break;

                    case FusedCANdiPWM2:
                    case SyncCANdiPWM2:
                    case RemoteCANdiPWM2:
                        encoder.Pwm2Orientation = m_modules[i].EncoderInverted ? ChassisReference.Clockwise_Positive : ChassisReference.CounterClockwise_Positive;
                        encoder.Pwm2SensorOffset = m_modules[i].EncoderOffset;

                        /* azimuth encoders see the mechanism, so don't account for the steer gearing */
                        encoder.setPwm2Connected(true);
                        encoder.setPwm2Position(m_modules[i].SteerMotor.getAngularPositionRotations());
                        encoder.setPwm2Velocity(m_modules[i].SteerMotor.getAngularVelocityRPM() / 60.0);
                        break;

                    default:
                        break;
                }
            }

            states[i] = modulesToApply[i].getCurrentState();
        }

        double angularVelRadPerSec = m_kinem.toChassisSpeeds(states).omegaRadiansPerSecond;
        m_lastAngle = m_lastAngle.plus(Rotation2d.fromRadians(angularVelRadPerSec * dtSeconds));
        m_pigeonSim.setRawYaw(m_lastAngle.getDegrees());
        m_pigeonSim.setAngularVelocityZ(Units.radiansToDegrees(angularVelRadPerSec));
    }

    /**
     * Applies the effects of friction to dampen the motor voltage.
     *
     * @param motorVoltage Voltage output by the motor
     * @param frictionVoltage Voltage required to overcome friction
     * @return Friction-dampened motor voltage
     */
    protected double addFriction(double motorVoltage, double frictionVoltage) {
        if (Math.abs(motorVoltage) < frictionVoltage) {
            motorVoltage = 0.0;
        } else if (motorVoltage > 0.0) {
            motorVoltage -= frictionVoltage;
        } else {
            motorVoltage += frictionVoltage;
        }
        return motorVoltage;
    }
}
