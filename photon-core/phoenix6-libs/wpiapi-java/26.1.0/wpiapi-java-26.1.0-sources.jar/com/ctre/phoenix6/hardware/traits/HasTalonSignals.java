/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.traits;

import com.ctre.phoenix6.*;
import com.ctre.phoenix6.signals.*;
import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;

/**
 * Contains all status signals available for devices that support Talon signals.
 */
public interface HasTalonSignals extends CommonDevice
{
        
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMajor Status Signal Object
     */
    StatusSignal<Integer> getVersionMajor();
    
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMajor Status Signal Object
     */
    StatusSignal<Integer> getVersionMajor(boolean refresh);
        
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMinor Status Signal Object
     */
    StatusSignal<Integer> getVersionMinor();
    
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMinor Status Signal Object
     */
    StatusSignal<Integer> getVersionMinor(boolean refresh);
        
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBugfix Status Signal Object
     */
    StatusSignal<Integer> getVersionBugfix();
    
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBugfix Status Signal Object
     */
    StatusSignal<Integer> getVersionBugfix(boolean refresh);
        
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBuild Status Signal Object
     */
    StatusSignal<Integer> getVersionBuild();
    
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBuild Status Signal Object
     */
    StatusSignal<Integer> getVersionBuild(boolean refresh);
        
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Version Status Signal Object
     */
    StatusSignal<Integer> getVersion();
    
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Version Status Signal Object
     */
    StatusSignal<Integer> getVersion(boolean refresh);
        
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return FaultField Status Signal Object
     */
    StatusSignal<Integer> getFaultField();
    
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return FaultField Status Signal Object
     */
    StatusSignal<Integer> getFaultField(boolean refresh);
        
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFaultField Status Signal Object
     */
    StatusSignal<Integer> getStickyFaultField();
    
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFaultField Status Signal Object
     */
    StatusSignal<Integer> getStickyFaultField(boolean refresh);
        
    /**
     * The applied (output) motor voltage.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -40.96
     *   <li> <b>Maximum Value:</b> 40.95
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> V
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MotorVoltage Status Signal Object
     */
    StatusSignal<Voltage> getMotorVoltage();
    
    /**
     * The applied (output) motor voltage.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -40.96
     *   <li> <b>Maximum Value:</b> 40.95
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> V
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MotorVoltage Status Signal Object
     */
    StatusSignal<Voltage> getMotorVoltage(boolean refresh);
        
    /**
     * Forward Limit Pin.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ForwardLimit Status Signal Object
     */
    StatusSignal<ForwardLimitValue> getForwardLimit();
    
    /**
     * Forward Limit Pin.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ForwardLimit Status Signal Object
     */
    StatusSignal<ForwardLimitValue> getForwardLimit(boolean refresh);
        
    /**
     * Reverse Limit Pin.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ReverseLimit Status Signal Object
     */
    StatusSignal<ReverseLimitValue> getReverseLimit();
    
    /**
     * Reverse Limit Pin.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ReverseLimit Status Signal Object
     */
    StatusSignal<ReverseLimitValue> getReverseLimit(boolean refresh);
        
    /**
     * The applied rotor polarity as seen from the front of the motor. 
     * This typically is determined by the Inverted config, but can be
     * overridden if using Follower features.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AppliedRotorPolarity Status Signal Object
     */
    StatusSignal<AppliedRotorPolarityValue> getAppliedRotorPolarity();
    
    /**
     * The applied rotor polarity as seen from the front of the motor. 
     * This typically is determined by the Inverted config, but can be
     * overridden if using Follower features.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AppliedRotorPolarity Status Signal Object
     */
    StatusSignal<AppliedRotorPolarityValue> getAppliedRotorPolarity(boolean refresh);
        
    /**
     * The applied motor duty cycle.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2.0
     *   <li> <b>Maximum Value:</b> 1.9990234375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> fractional
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DutyCycle Status Signal Object
     */
    StatusSignal<Double> getDutyCycle();
    
    /**
     * The applied motor duty cycle.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2.0
     *   <li> <b>Maximum Value:</b> 1.9990234375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> fractional
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DutyCycle Status Signal Object
     */
    StatusSignal<Double> getDutyCycle(boolean refresh);
        
    /**
     * Current corresponding to the torque output by the motor. Similar to
     * StatorCurrent. Users will likely prefer this current to calculate
     * the applied torque to the rotor.
     * <p>
     * Stator current where positive current means torque is applied in
     * the forward direction as determined by the Inverted setting.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -327.68
     *   <li> <b>Maximum Value:</b> 327.67
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return TorqueCurrent Status Signal Object
     */
    StatusSignal<Current> getTorqueCurrent();
    
    /**
     * Current corresponding to the torque output by the motor. Similar to
     * StatorCurrent. Users will likely prefer this current to calculate
     * the applied torque to the rotor.
     * <p>
     * Stator current where positive current means torque is applied in
     * the forward direction as determined by the Inverted setting.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -327.68
     *   <li> <b>Maximum Value:</b> 327.67
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return TorqueCurrent Status Signal Object
     */
    StatusSignal<Current> getTorqueCurrent(boolean refresh);
        
    /**
     * Current corresponding to the stator windings. Similar to
     * TorqueCurrent. Users will likely prefer TorqueCurrent over
     * StatorCurrent.
     * <p>
     * Stator current where Positive current indicates motoring regardless
     * of direction. Negative current indicates regenerative braking
     * regardless of direction.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -327.68
     *   <li> <b>Maximum Value:</b> 327.66
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StatorCurrent Status Signal Object
     */
    StatusSignal<Current> getStatorCurrent();
    
    /**
     * Current corresponding to the stator windings. Similar to
     * TorqueCurrent. Users will likely prefer TorqueCurrent over
     * StatorCurrent.
     * <p>
     * Stator current where Positive current indicates motoring regardless
     * of direction. Negative current indicates regenerative braking
     * regardless of direction.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -327.68
     *   <li> <b>Maximum Value:</b> 327.66
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StatorCurrent Status Signal Object
     */
    StatusSignal<Current> getStatorCurrent(boolean refresh);
        
    /**
     * Measured supply side current.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -327.68
     *   <li> <b>Maximum Value:</b> 327.66
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return SupplyCurrent Status Signal Object
     */
    StatusSignal<Current> getSupplyCurrent();
    
    /**
     * Measured supply side current.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -327.68
     *   <li> <b>Maximum Value:</b> 327.66
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return SupplyCurrent Status Signal Object
     */
    StatusSignal<Current> getSupplyCurrent(boolean refresh);
        
    /**
     * Measured supply voltage to the device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 4
     *   <li> <b>Maximum Value:</b> 29.575
     *   <li> <b>Default Value:</b> 4
     *   <li> <b>Units:</b> V
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return SupplyVoltage Status Signal Object
     */
    StatusSignal<Voltage> getSupplyVoltage();
    
    /**
     * Measured supply voltage to the device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 4
     *   <li> <b>Maximum Value:</b> 29.575
     *   <li> <b>Default Value:</b> 4
     *   <li> <b>Units:</b> V
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return SupplyVoltage Status Signal Object
     */
    StatusSignal<Voltage> getSupplyVoltage(boolean refresh);
        
    /**
     * Temperature of device.
     * <p>
     * This is the temperature that the device measures itself to be at.
     * Similar to Processor Temperature.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 255.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DeviceTemp Status Signal Object
     */
    StatusSignal<Temperature> getDeviceTemp();
    
    /**
     * Temperature of device.
     * <p>
     * This is the temperature that the device measures itself to be at.
     * Similar to Processor Temperature.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 255.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DeviceTemp Status Signal Object
     */
    StatusSignal<Temperature> getDeviceTemp(boolean refresh);
        
    /**
     * Temperature of the processor.
     * <p>
     * This is the temperature that the processor measures itself to be
     * at. Similar to Device Temperature.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 255.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ProcessorTemp Status Signal Object
     */
    StatusSignal<Temperature> getProcessorTemp();
    
    /**
     * Temperature of the processor.
     * <p>
     * This is the temperature that the processor measures itself to be
     * at. Similar to Device Temperature.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 255.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ProcessorTemp Status Signal Object
     */
    StatusSignal<Temperature> getProcessorTemp(boolean refresh);
        
    /**
     * Velocity of the motor rotor. This velocity is not affected by any
     * feedback configs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RotorVelocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getRotorVelocity();
    
    /**
     * Velocity of the motor rotor. This velocity is not affected by any
     * feedback configs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RotorVelocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getRotorVelocity(boolean refresh);
        
    /**
     * Position of the motor rotor. This position is only affected by the
     * RotorOffset config and calls to setPosition.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RotorPosition Status Signal Object
     */
    StatusSignal<Angle> getRotorPosition();
    
    /**
     * Position of the motor rotor. This position is only affected by the
     * RotorOffset config and calls to setPosition.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RotorPosition Status Signal Object
     */
    StatusSignal<Angle> getRotorPosition(boolean refresh);
        
    /**
     * Velocity of the device in mechanism rotations per second. This can
     * be the velocity of a remote sensor and is affected by the
     * RotorToSensorRatio and SensorToMechanismRatio configs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Velocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getVelocity();
    
    /**
     * Velocity of the device in mechanism rotations per second. This can
     * be the velocity of a remote sensor and is affected by the
     * RotorToSensorRatio and SensorToMechanismRatio configs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Velocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getVelocity(boolean refresh);
        
    /**
     * Position of the device in mechanism rotations. This can be the
     * position of a remote sensor and is affected by the
     * RotorToSensorRatio and SensorToMechanismRatio configs, as well as
     * calls to setPosition.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Position Status Signal Object
     */
    StatusSignal<Angle> getPosition();
    
    /**
     * Position of the device in mechanism rotations. This can be the
     * position of a remote sensor and is affected by the
     * RotorToSensorRatio and SensorToMechanismRatio configs, as well as
     * calls to setPosition.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Position Status Signal Object
     */
    StatusSignal<Angle> getPosition(boolean refresh);
        
    /**
     * Acceleration of the device in mechanism rotations per second². This
     * can be the acceleration of a remote sensor and is affected by the
     * RotorToSensorRatio and SensorToMechanismRatio configs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2048.0
     *   <li> <b>Maximum Value:</b> 2047.75
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second²
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Acceleration Status Signal Object
     */
    StatusSignal<AngularAcceleration> getAcceleration();
    
    /**
     * Acceleration of the device in mechanism rotations per second². This
     * can be the acceleration of a remote sensor and is affected by the
     * RotorToSensorRatio and SensorToMechanismRatio configs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -2048.0
     *   <li> <b>Maximum Value:</b> 2047.75
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second²
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Acceleration Status Signal Object
     */
    StatusSignal<AngularAcceleration> getAcceleration(boolean refresh);
        
    /**
     * The active control mode of the motor controller.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ControlMode Status Signal Object
     */
    StatusSignal<ControlModeValue> getControlMode();
    
    /**
     * The active control mode of the motor controller.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ControlMode Status Signal Object
     */
    StatusSignal<ControlModeValue> getControlMode(boolean refresh);
        
    /**
     * Check if the Motion Magic® profile has reached the target. This is
     * equivalent to checking that MotionMagicIsRunning, the
     * ClosedLoopReference is the target, and the ClosedLoopReferenceSlope
     * is 0.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MotionMagicAtTarget Status Signal Object
     */
    StatusSignal<Boolean> getMotionMagicAtTarget();
    
    /**
     * Check if the Motion Magic® profile has reached the target. This is
     * equivalent to checking that MotionMagicIsRunning, the
     * ClosedLoopReference is the target, and the ClosedLoopReferenceSlope
     * is 0.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MotionMagicAtTarget Status Signal Object
     */
    StatusSignal<Boolean> getMotionMagicAtTarget(boolean refresh);
        
    /**
     * Check if Motion Magic® is running.  This is equivalent to checking
     * that the reported control mode is a Motion Magic® based mode.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MotionMagicIsRunning Status Signal Object
     */
    StatusSignal<Boolean> getMotionMagicIsRunning();
    
    /**
     * Check if Motion Magic® is running.  This is equivalent to checking
     * that the reported control mode is a Motion Magic® based mode.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MotionMagicIsRunning Status Signal Object
     */
    StatusSignal<Boolean> getMotionMagicIsRunning(boolean refresh);
        
    /**
     * Indicates if the robot is enabled.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return RobotEnable Status Signal Object
     */
    StatusSignal<RobotEnableValue> getRobotEnable();
    
    /**
     * Indicates if the robot is enabled.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return RobotEnable Status Signal Object
     */
    StatusSignal<RobotEnableValue> getRobotEnable(boolean refresh);
        
    /**
     * Indicates if device is actuator enabled.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DeviceEnable Status Signal Object
     */
    StatusSignal<DeviceEnableValue> getDeviceEnable();
    
    /**
     * Indicates if device is actuator enabled.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DeviceEnable Status Signal Object
     */
    StatusSignal<DeviceEnableValue> getDeviceEnable(boolean refresh);
        
    /**
     * The slot that the closed-loop PID is using.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopSlot Status Signal Object
     */
    StatusSignal<Integer> getClosedLoopSlot();
    
    /**
     * The slot that the closed-loop PID is using.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ClosedLoopSlot Status Signal Object
     */
    StatusSignal<Integer> getClosedLoopSlot(boolean refresh);
        
    /**
     * Assess the status of the motor output with respect to load and
     * supply.
     * <p>
     * This routine can be used to determine the general status of motor
     * commutation.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MotorOutputStatus Status Signal Object
     */
    StatusSignal<MotorOutputStatusValue> getMotorOutputStatus();
    
    /**
     * Assess the status of the motor output with respect to load and
     * supply.
     * <p>
     * This routine can be used to determine the general status of motor
     * commutation.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MotorOutputStatus Status Signal Object
     */
    StatusSignal<MotorOutputStatusValue> getMotorOutputStatus(boolean refresh);
        
    /**
     * The active control mode of the differential controller.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialControlMode Status Signal Object
     */
    StatusSignal<DifferentialControlModeValue> getDifferentialControlMode();
    
    /**
     * The active control mode of the differential controller.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialControlMode Status Signal Object
     */
    StatusSignal<DifferentialControlModeValue> getDifferentialControlMode(boolean refresh);
        
    /**
     * Average component of the differential velocity of device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialAverageVelocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getDifferentialAverageVelocity();
    
    /**
     * Average component of the differential velocity of device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialAverageVelocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getDifferentialAverageVelocity(boolean refresh);
        
    /**
     * Average component of the differential position of device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialAveragePosition Status Signal Object
     */
    StatusSignal<Angle> getDifferentialAveragePosition();
    
    /**
     * Average component of the differential position of device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialAveragePosition Status Signal Object
     */
    StatusSignal<Angle> getDifferentialAveragePosition(boolean refresh);
        
    /**
     * Difference component of the differential velocity of device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialDifferenceVelocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getDifferentialDifferenceVelocity();
    
    /**
     * Difference component of the differential velocity of device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialDifferenceVelocity Status Signal Object
     */
    StatusSignal<AngularVelocity> getDifferentialDifferenceVelocity(boolean refresh);
        
    /**
     * Difference component of the differential position of device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialDifferencePosition Status Signal Object
     */
    StatusSignal<Angle> getDifferentialDifferencePosition();
    
    /**
     * Difference component of the differential position of device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialDifferencePosition Status Signal Object
     */
    StatusSignal<Angle> getDifferentialDifferencePosition(boolean refresh);
        
    /**
     * The slot that the closed-loop differential PID is using.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopSlot Status Signal Object
     */
    StatusSignal<Integer> getDifferentialClosedLoopSlot();
    
    /**
     * The slot that the closed-loop differential PID is using.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 2
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialClosedLoopSlot Status Signal Object
     */
    StatusSignal<Integer> getDifferentialClosedLoopSlot(boolean refresh);
        
    /**
     * The torque constant (K_T) of the motor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 0.025500000000000002
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> Nm/A
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MotorKT Status Signal Object
     */
    StatusSignal<Per<TorqueUnit, CurrentUnit>> getMotorKT();
    
    /**
     * The torque constant (K_T) of the motor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 0.025500000000000002
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> Nm/A
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MotorKT Status Signal Object
     */
    StatusSignal<Per<TorqueUnit, CurrentUnit>> getMotorKT(boolean refresh);
        
    /**
     * The velocity constant (K_V) of the motor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 2047.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> RPM/V
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MotorKV Status Signal Object
     */
    StatusSignal<Per<AngularVelocityUnit, VoltageUnit>> getMotorKV();
    
    /**
     * The velocity constant (K_V) of the motor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 2047.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> RPM/V
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MotorKV Status Signal Object
     */
    StatusSignal<Per<AngularVelocityUnit, VoltageUnit>> getMotorKV(boolean refresh);
        
    /**
     * The stall current of the motor at 12 V output.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1023.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MotorStallCurrent Status Signal Object
     */
    StatusSignal<Current> getMotorStallCurrent();
    
    /**
     * The stall current of the motor at 12 V output.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1023.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> A
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MotorStallCurrent Status Signal Object
     */
    StatusSignal<Current> getMotorStallCurrent(boolean refresh);
        
    /**
     * The applied output of the bridge.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return BridgeOutput Status Signal Object
     */
    StatusSignal<BridgeOutputValue> getBridgeOutput();
    
    /**
     * The applied output of the bridge.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return BridgeOutput Status Signal Object
     */
    StatusSignal<BridgeOutputValue> getBridgeOutput(boolean refresh);
        
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return IsProLicensed Status Signal Object
     */
    StatusSignal<Boolean> getIsProLicensed();
    
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return IsProLicensed Status Signal Object
     */
    StatusSignal<Boolean> getIsProLicensed(boolean refresh);
        
    /**
     * Temperature of device from second sensor.
     * <p>
     * Newer versions of Talon have multiple temperature measurement
     * methods.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 255.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AncillaryDeviceTemp Status Signal Object
     */
    StatusSignal<Temperature> getAncillaryDeviceTemp();
    
    /**
     * Temperature of device from second sensor.
     * <p>
     * Newer versions of Talon have multiple temperature measurement
     * methods.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 255.0
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> ℃
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AncillaryDeviceTemp Status Signal Object
     */
    StatusSignal<Temperature> getAncillaryDeviceTemp(boolean refresh);
        
    /**
     * The type of motor attached to the Talon.
     * <p>
     * This can be used to determine what motor is attached to the Talon
     * FX.  Return will be "Unknown" if firmware is too old or device is
     * not present.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ConnectedMotor Status Signal Object
     */
    StatusSignal<ConnectedMotorValue> getConnectedMotor();
    
    /**
     * The type of motor attached to the Talon.
     * <p>
     * This can be used to determine what motor is attached to the Talon
     * FX.  Return will be "Unknown" if firmware is too old or device is
     * not present.
     * 
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ConnectedMotor Status Signal Object
     */
    StatusSignal<ConnectedMotorValue> getConnectedMotor(boolean refresh);
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Hardware Status Signal Object
     */
    StatusSignal<Boolean> getFault_Hardware();
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Hardware Status Signal Object
     */
    StatusSignal<Boolean> getFault_Hardware(boolean refresh);
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Hardware Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_Hardware();
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Hardware Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_Hardware(boolean refresh);
        
    /**
     * Processor temperature exceeded limit
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_ProcTemp Status Signal Object
     */
    StatusSignal<Boolean> getFault_ProcTemp();
    
    /**
     * Processor temperature exceeded limit
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_ProcTemp Status Signal Object
     */
    StatusSignal<Boolean> getFault_ProcTemp(boolean refresh);
        
    /**
     * Processor temperature exceeded limit
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_ProcTemp Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_ProcTemp();
    
    /**
     * Processor temperature exceeded limit
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_ProcTemp Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_ProcTemp(boolean refresh);
        
    /**
     * Device temperature exceeded limit
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_DeviceTemp Status Signal Object
     */
    StatusSignal<Boolean> getFault_DeviceTemp();
    
    /**
     * Device temperature exceeded limit
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_DeviceTemp Status Signal Object
     */
    StatusSignal<Boolean> getFault_DeviceTemp(boolean refresh);
        
    /**
     * Device temperature exceeded limit
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_DeviceTemp Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_DeviceTemp();
    
    /**
     * Device temperature exceeded limit
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_DeviceTemp Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_DeviceTemp(boolean refresh);
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Undervoltage Status Signal Object
     */
    StatusSignal<Boolean> getFault_Undervoltage();
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Undervoltage Status Signal Object
     */
    StatusSignal<Boolean> getFault_Undervoltage(boolean refresh);
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Undervoltage Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_Undervoltage();
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Undervoltage Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_Undervoltage(boolean refresh);
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BootDuringEnable Status Signal Object
     */
    StatusSignal<Boolean> getFault_BootDuringEnable();
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BootDuringEnable Status Signal Object
     */
    StatusSignal<Boolean> getFault_BootDuringEnable(boolean refresh);
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_BootDuringEnable();
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_BootDuringEnable(boolean refresh);
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    StatusSignal<Boolean> getFault_UnlicensedFeatureInUse();
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    StatusSignal<Boolean> getFault_UnlicensedFeatureInUse(boolean refresh);
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse();
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse(boolean refresh);
        
    /**
     * Bridge was disabled most likely due to supply voltage dropping too
     * low.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BridgeBrownout Status Signal Object
     */
    StatusSignal<Boolean> getFault_BridgeBrownout();
    
    /**
     * Bridge was disabled most likely due to supply voltage dropping too
     * low.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BridgeBrownout Status Signal Object
     */
    StatusSignal<Boolean> getFault_BridgeBrownout(boolean refresh);
        
    /**
     * Bridge was disabled most likely due to supply voltage dropping too
     * low.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BridgeBrownout Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_BridgeBrownout();
    
    /**
     * Bridge was disabled most likely due to supply voltage dropping too
     * low.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BridgeBrownout Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_BridgeBrownout(boolean refresh);
        
    /**
     * The remote sensor has reset.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_RemoteSensorReset Status Signal Object
     */
    StatusSignal<Boolean> getFault_RemoteSensorReset();
    
    /**
     * The remote sensor has reset.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_RemoteSensorReset Status Signal Object
     */
    StatusSignal<Boolean> getFault_RemoteSensorReset(boolean refresh);
        
    /**
     * The remote sensor has reset.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_RemoteSensorReset Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_RemoteSensorReset();
    
    /**
     * The remote sensor has reset.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_RemoteSensorReset Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_RemoteSensorReset(boolean refresh);
        
    /**
     * The remote Talon used for differential control is not present on
     * CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_MissingDifferentialFX Status Signal Object
     */
    StatusSignal<Boolean> getFault_MissingDifferentialFX();
    
    /**
     * The remote Talon used for differential control is not present on
     * CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_MissingDifferentialFX Status Signal Object
     */
    StatusSignal<Boolean> getFault_MissingDifferentialFX(boolean refresh);
        
    /**
     * The remote Talon used for differential control is not present on
     * CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_MissingDifferentialFX Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MissingDifferentialFX();
    
    /**
     * The remote Talon used for differential control is not present on
     * CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_MissingDifferentialFX Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MissingDifferentialFX(boolean refresh);
        
    /**
     * The remote sensor position has overflowed. Because of the nature of
     * remote sensors, it is possible for the remote sensor position to
     * overflow beyond what is supported by the status signal frame.
     * However, this is rare and cannot occur over the course of an FRC
     * match under normal use.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_RemoteSensorPosOverflow Status Signal Object
     */
    StatusSignal<Boolean> getFault_RemoteSensorPosOverflow();
    
    /**
     * The remote sensor position has overflowed. Because of the nature of
     * remote sensors, it is possible for the remote sensor position to
     * overflow beyond what is supported by the status signal frame.
     * However, this is rare and cannot occur over the course of an FRC
     * match under normal use.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_RemoteSensorPosOverflow Status Signal Object
     */
    StatusSignal<Boolean> getFault_RemoteSensorPosOverflow(boolean refresh);
        
    /**
     * The remote sensor position has overflowed. Because of the nature of
     * remote sensors, it is possible for the remote sensor position to
     * overflow beyond what is supported by the status signal frame.
     * However, this is rare and cannot occur over the course of an FRC
     * match under normal use.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_RemoteSensorPosOverflow Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_RemoteSensorPosOverflow();
    
    /**
     * The remote sensor position has overflowed. Because of the nature of
     * remote sensors, it is possible for the remote sensor position to
     * overflow beyond what is supported by the status signal frame.
     * However, this is rare and cannot occur over the course of an FRC
     * match under normal use.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_RemoteSensorPosOverflow Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_RemoteSensorPosOverflow(boolean refresh);
        
    /**
     * Supply Voltage has exceeded the maximum voltage rating of device.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_OverSupplyV Status Signal Object
     */
    StatusSignal<Boolean> getFault_OverSupplyV();
    
    /**
     * Supply Voltage has exceeded the maximum voltage rating of device.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_OverSupplyV Status Signal Object
     */
    StatusSignal<Boolean> getFault_OverSupplyV(boolean refresh);
        
    /**
     * Supply Voltage has exceeded the maximum voltage rating of device.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_OverSupplyV Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_OverSupplyV();
    
    /**
     * Supply Voltage has exceeded the maximum voltage rating of device.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_OverSupplyV Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_OverSupplyV(boolean refresh);
        
    /**
     * Supply Voltage is unstable.  Ensure you are using a battery and
     * current limited power supply.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_UnstableSupplyV Status Signal Object
     */
    StatusSignal<Boolean> getFault_UnstableSupplyV();
    
    /**
     * Supply Voltage is unstable.  Ensure you are using a battery and
     * current limited power supply.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_UnstableSupplyV Status Signal Object
     */
    StatusSignal<Boolean> getFault_UnstableSupplyV(boolean refresh);
        
    /**
     * Supply Voltage is unstable.  Ensure you are using a battery and
     * current limited power supply.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_UnstableSupplyV Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_UnstableSupplyV();
    
    /**
     * Supply Voltage is unstable.  Ensure you are using a battery and
     * current limited power supply.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_UnstableSupplyV Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_UnstableSupplyV(boolean refresh);
        
    /**
     * Reverse limit switch has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_ReverseHardLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_ReverseHardLimit();
    
    /**
     * Reverse limit switch has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_ReverseHardLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_ReverseHardLimit(boolean refresh);
        
    /**
     * Reverse limit switch has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_ReverseHardLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_ReverseHardLimit();
    
    /**
     * Reverse limit switch has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_ReverseHardLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_ReverseHardLimit(boolean refresh);
        
    /**
     * Forward limit switch has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_ForwardHardLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_ForwardHardLimit();
    
    /**
     * Forward limit switch has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_ForwardHardLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_ForwardHardLimit(boolean refresh);
        
    /**
     * Forward limit switch has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_ForwardHardLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_ForwardHardLimit();
    
    /**
     * Forward limit switch has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_ForwardHardLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_ForwardHardLimit(boolean refresh);
        
    /**
     * Reverse soft limit has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_ReverseSoftLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_ReverseSoftLimit();
    
    /**
     * Reverse soft limit has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_ReverseSoftLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_ReverseSoftLimit(boolean refresh);
        
    /**
     * Reverse soft limit has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_ReverseSoftLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_ReverseSoftLimit();
    
    /**
     * Reverse soft limit has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_ReverseSoftLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_ReverseSoftLimit(boolean refresh);
        
    /**
     * Forward soft limit has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_ForwardSoftLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_ForwardSoftLimit();
    
    /**
     * Forward soft limit has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_ForwardSoftLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_ForwardSoftLimit(boolean refresh);
        
    /**
     * Forward soft limit has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_ForwardSoftLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_ForwardSoftLimit();
    
    /**
     * Forward soft limit has been asserted.  Output is set to neutral.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_ForwardSoftLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_ForwardSoftLimit(boolean refresh);
        
    /**
     * The remote soft limit device is not present on CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_MissingSoftLimitRemote Status Signal Object
     */
    StatusSignal<Boolean> getFault_MissingSoftLimitRemote();
    
    /**
     * The remote soft limit device is not present on CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_MissingSoftLimitRemote Status Signal Object
     */
    StatusSignal<Boolean> getFault_MissingSoftLimitRemote(boolean refresh);
        
    /**
     * The remote soft limit device is not present on CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_MissingSoftLimitRemote Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MissingSoftLimitRemote();
    
    /**
     * The remote soft limit device is not present on CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_MissingSoftLimitRemote Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MissingSoftLimitRemote(boolean refresh);
        
    /**
     * The remote limit switch device is not present on CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_MissingHardLimitRemote Status Signal Object
     */
    StatusSignal<Boolean> getFault_MissingHardLimitRemote();
    
    /**
     * The remote limit switch device is not present on CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_MissingHardLimitRemote Status Signal Object
     */
    StatusSignal<Boolean> getFault_MissingHardLimitRemote(boolean refresh);
        
    /**
     * The remote limit switch device is not present on CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_MissingHardLimitRemote Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MissingHardLimitRemote();
    
    /**
     * The remote limit switch device is not present on CAN Bus.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_MissingHardLimitRemote Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_MissingHardLimitRemote(boolean refresh);
        
    /**
     * The remote sensor's data is no longer trusted. This can happen if
     * the remote sensor disappears from the CAN bus or if the remote
     * sensor indicates its data is no longer valid, such as when a
     * CANcoder's magnet strength falls into the "red" range.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_RemoteSensorDataInvalid Status Signal Object
     */
    StatusSignal<Boolean> getFault_RemoteSensorDataInvalid();
    
    /**
     * The remote sensor's data is no longer trusted. This can happen if
     * the remote sensor disappears from the CAN bus or if the remote
     * sensor indicates its data is no longer valid, such as when a
     * CANcoder's magnet strength falls into the "red" range.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_RemoteSensorDataInvalid Status Signal Object
     */
    StatusSignal<Boolean> getFault_RemoteSensorDataInvalid(boolean refresh);
        
    /**
     * The remote sensor's data is no longer trusted. This can happen if
     * the remote sensor disappears from the CAN bus or if the remote
     * sensor indicates its data is no longer valid, such as when a
     * CANcoder's magnet strength falls into the "red" range.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_RemoteSensorDataInvalid Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_RemoteSensorDataInvalid();
    
    /**
     * The remote sensor's data is no longer trusted. This can happen if
     * the remote sensor disappears from the CAN bus or if the remote
     * sensor indicates its data is no longer valid, such as when a
     * CANcoder's magnet strength falls into the "red" range.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_RemoteSensorDataInvalid Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_RemoteSensorDataInvalid(boolean refresh);
        
    /**
     * The remote sensor used for fusion has fallen out of sync to the
     * local sensor. A re-synchronization has occurred, which may cause a
     * discontinuity. This typically happens if there is significant slop
     * in the mechanism, or if the RotorToSensorRatio configuration
     * parameter is incorrect.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_FusedSensorOutOfSync Status Signal Object
     */
    StatusSignal<Boolean> getFault_FusedSensorOutOfSync();
    
    /**
     * The remote sensor used for fusion has fallen out of sync to the
     * local sensor. A re-synchronization has occurred, which may cause a
     * discontinuity. This typically happens if there is significant slop
     * in the mechanism, or if the RotorToSensorRatio configuration
     * parameter is incorrect.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_FusedSensorOutOfSync Status Signal Object
     */
    StatusSignal<Boolean> getFault_FusedSensorOutOfSync(boolean refresh);
        
    /**
     * The remote sensor used for fusion has fallen out of sync to the
     * local sensor. A re-synchronization has occurred, which may cause a
     * discontinuity. This typically happens if there is significant slop
     * in the mechanism, or if the RotorToSensorRatio configuration
     * parameter is incorrect.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_FusedSensorOutOfSync Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_FusedSensorOutOfSync();
    
    /**
     * The remote sensor used for fusion has fallen out of sync to the
     * local sensor. A re-synchronization has occurred, which may cause a
     * discontinuity. This typically happens if there is significant slop
     * in the mechanism, or if the RotorToSensorRatio configuration
     * parameter is incorrect.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_FusedSensorOutOfSync Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_FusedSensorOutOfSync(boolean refresh);
        
    /**
     * Stator current limit occured.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_StatorCurrLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_StatorCurrLimit();
    
    /**
     * Stator current limit occured.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_StatorCurrLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_StatorCurrLimit(boolean refresh);
        
    /**
     * Stator current limit occured.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_StatorCurrLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_StatorCurrLimit();
    
    /**
     * Stator current limit occured.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_StatorCurrLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_StatorCurrLimit(boolean refresh);
        
    /**
     * Supply current limit occured.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_SupplyCurrLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_SupplyCurrLimit();
    
    /**
     * Supply current limit occured.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_SupplyCurrLimit Status Signal Object
     */
    StatusSignal<Boolean> getFault_SupplyCurrLimit(boolean refresh);
        
    /**
     * Supply current limit occured.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_SupplyCurrLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_SupplyCurrLimit();
    
    /**
     * Supply current limit occured.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_SupplyCurrLimit Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_SupplyCurrLimit(boolean refresh);
        
    /**
     * Using Fused CANcoder feature while unlicensed. Device has fallen
     * back to remote CANcoder.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_UsingFusedCANcoderWhileUnlicensed Status Signal Object
     */
    StatusSignal<Boolean> getFault_UsingFusedCANcoderWhileUnlicensed();
    
    /**
     * Using Fused CANcoder feature while unlicensed. Device has fallen
     * back to remote CANcoder.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_UsingFusedCANcoderWhileUnlicensed Status Signal Object
     */
    StatusSignal<Boolean> getFault_UsingFusedCANcoderWhileUnlicensed(boolean refresh);
        
    /**
     * Using Fused CANcoder feature while unlicensed. Device has fallen
     * back to remote CANcoder.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_UsingFusedCANcoderWhileUnlicensed Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_UsingFusedCANcoderWhileUnlicensed();
    
    /**
     * Using Fused CANcoder feature while unlicensed. Device has fallen
     * back to remote CANcoder.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_UsingFusedCANcoderWhileUnlicensed Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_UsingFusedCANcoderWhileUnlicensed(boolean refresh);
        
    /**
     * Static brake was momentarily disabled due to excessive braking
     * current while disabled.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_StaticBrakeDisabled Status Signal Object
     */
    StatusSignal<Boolean> getFault_StaticBrakeDisabled();
    
    /**
     * Static brake was momentarily disabled due to excessive braking
     * current while disabled.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_StaticBrakeDisabled Status Signal Object
     */
    StatusSignal<Boolean> getFault_StaticBrakeDisabled(boolean refresh);
        
    /**
     * Static brake was momentarily disabled due to excessive braking
     * current while disabled.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_StaticBrakeDisabled Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_StaticBrakeDisabled();
    
    /**
     * Static brake was momentarily disabled due to excessive braking
     * current while disabled.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_StaticBrakeDisabled Status Signal Object
     */
    StatusSignal<Boolean> getStickyFault_StaticBrakeDisabled(boolean refresh);
    
    /**
     * Closed loop proportional component.
     * <p>
     * The portion of the closed loop output that is proportional to the
     * error. Alternatively, the kP contribution of the closed loop
     * output.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopProportionalOutput Status Signal object
     */
    StatusSignal<Double> getClosedLoopProportionalOutput();
    
    /**
     * Closed loop proportional component.
     * <p>
     * The portion of the closed loop output that is proportional to the
     * error. Alternatively, the kP contribution of the closed loop
     * output.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ClosedLoopProportionalOutput Status Signal object
     */
    StatusSignal<Double> getClosedLoopProportionalOutput(boolean refresh);
    
    /**
     * Closed loop integrated component.
     * <p>
     * The portion of the closed loop output that is proportional to the
     * integrated error. Alternatively, the kI contribution of the closed
     * loop output.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopIntegratedOutput Status Signal object
     */
    StatusSignal<Double> getClosedLoopIntegratedOutput();
    
    /**
     * Closed loop integrated component.
     * <p>
     * The portion of the closed loop output that is proportional to the
     * integrated error. Alternatively, the kI contribution of the closed
     * loop output.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ClosedLoopIntegratedOutput Status Signal object
     */
    StatusSignal<Double> getClosedLoopIntegratedOutput(boolean refresh);
    
    /**
     * Feedforward passed by the user.
     * <p>
     * This is the general feedforward that the user provides for the
     * closed loop.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopFeedForward Status Signal object
     */
    StatusSignal<Double> getClosedLoopFeedForward();
    
    /**
     * Feedforward passed by the user.
     * <p>
     * This is the general feedforward that the user provides for the
     * closed loop.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ClosedLoopFeedForward Status Signal object
     */
    StatusSignal<Double> getClosedLoopFeedForward(boolean refresh);
    
    /**
     * Closed loop derivative component.
     * <p>
     * The portion of the closed loop output that is proportional to the
     * deriviative of error. Alternatively, the kD contribution of the
     * closed loop output.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopDerivativeOutput Status Signal object
     */
    StatusSignal<Double> getClosedLoopDerivativeOutput();
    
    /**
     * Closed loop derivative component.
     * <p>
     * The portion of the closed loop output that is proportional to the
     * deriviative of error. Alternatively, the kD contribution of the
     * closed loop output.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ClosedLoopDerivativeOutput Status Signal object
     */
    StatusSignal<Double> getClosedLoopDerivativeOutput(boolean refresh);
    
    /**
     * Closed loop total output.
     * <p>
     * The total output of the closed loop output.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopOutput Status Signal object
     */
    StatusSignal<Double> getClosedLoopOutput();
    
    /**
     * Closed loop total output.
     * <p>
     * The total output of the closed loop output.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ClosedLoopOutput Status Signal object
     */
    StatusSignal<Double> getClosedLoopOutput(boolean refresh);
    
    /**
     * Value that the closed loop is targeting.
     * <p>
     * This is the value that the closed loop PID controller targets.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopReference Status Signal object
     */
    StatusSignal<Double> getClosedLoopReference();
    
    /**
     * Value that the closed loop is targeting.
     * <p>
     * This is the value that the closed loop PID controller targets.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ClosedLoopReference Status Signal object
     */
    StatusSignal<Double> getClosedLoopReference(boolean refresh);
    
    /**
     * Derivative of the target that the closed loop is targeting.
     * <p>
     * This is the change in the closed loop reference. This may be used
     * in the feed-forward calculation, the derivative-error, or in
     * application of the signage for kS. Typically, this represents the
     * target velocity during Motion Magic®.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopReferenceSlope Status Signal object
     */
    StatusSignal<Double> getClosedLoopReferenceSlope();
    
    /**
     * Derivative of the target that the closed loop is targeting.
     * <p>
     * This is the change in the closed loop reference. This may be used
     * in the feed-forward calculation, the derivative-error, or in
     * application of the signage for kS. Typically, this represents the
     * target velocity during Motion Magic®.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ClosedLoopReferenceSlope Status Signal object
     */
    StatusSignal<Double> getClosedLoopReferenceSlope(boolean refresh);
    
    /**
     * The difference between target reference and current measurement.
     * <p>
     * This is the value that is treated as the error in the PID loop.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return ClosedLoopError Status Signal object
     */
    StatusSignal<Double> getClosedLoopError();
    
    /**
     * The difference between target reference and current measurement.
     * <p>
     * This is the value that is treated as the error in the PID loop.
     * <p>
     * When using differential control, this applies to the average axis.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return ClosedLoopError Status Signal object
     */
    StatusSignal<Double> getClosedLoopError(boolean refresh);
    
    /**
     * The calculated motor output for differential followers.
     * <p>
     * This is a torque request when using the TorqueCurrentFOC control
     * output type, a voltage request when using the Voltage control
     * output type, and a duty cycle when using the DutyCycle control
     * output type.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialOutput Status Signal object
     */
    StatusSignal<Double> getDifferentialOutput();
    
    /**
     * The calculated motor output for differential followers.
     * <p>
     * This is a torque request when using the TorqueCurrentFOC control
     * output type, a voltage request when using the Voltage control
     * output type, and a duty cycle when using the DutyCycle control
     * output type.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialOutput Status Signal object
     */
    StatusSignal<Double> getDifferentialOutput(boolean refresh);
    
    /**
     * Differential closed loop proportional component.
     * <p>
     * The portion of the differential closed loop output (on the
     * difference axis) that is proportional to the error. Alternatively,
     * the kP contribution of the closed loop output.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopProportionalOutput Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopProportionalOutput();
    
    /**
     * Differential closed loop proportional component.
     * <p>
     * The portion of the differential closed loop output (on the
     * difference axis) that is proportional to the error. Alternatively,
     * the kP contribution of the closed loop output.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialClosedLoopProportionalOutput Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopProportionalOutput(boolean refresh);
    
    /**
     * Differential closed loop integrated component.
     * <p>
     * The portion of the differential closed loop output (on the
     * difference axis) that is proportional to the integrated error.
     * Alternatively, the kI contribution of the closed loop output.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopIntegratedOutput Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopIntegratedOutput();
    
    /**
     * Differential closed loop integrated component.
     * <p>
     * The portion of the differential closed loop output (on the
     * difference axis) that is proportional to the integrated error.
     * Alternatively, the kI contribution of the closed loop output.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialClosedLoopIntegratedOutput Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopIntegratedOutput(boolean refresh);
    
    /**
     * Differential Feedforward passed by the user.
     * <p>
     * This is the general feedforward that the user provides for the
     * differential closed loop (on the difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopFeedForward Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopFeedForward();
    
    /**
     * Differential Feedforward passed by the user.
     * <p>
     * This is the general feedforward that the user provides for the
     * differential closed loop (on the difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialClosedLoopFeedForward Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopFeedForward(boolean refresh);
    
    /**
     * Differential closed loop derivative component.
     * <p>
     * The portion of the differential closed loop output (on the
     * difference axis) that is proportional to the deriviative of error.
     * Alternatively, the kD contribution of the closed loop output.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopDerivativeOutput Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopDerivativeOutput();
    
    /**
     * Differential closed loop derivative component.
     * <p>
     * The portion of the differential closed loop output (on the
     * difference axis) that is proportional to the deriviative of error.
     * Alternatively, the kD contribution of the closed loop output.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialClosedLoopDerivativeOutput Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopDerivativeOutput(boolean refresh);
    
    /**
     * Differential closed loop total output.
     * <p>
     * The total output of the differential closed loop output (on the
     * difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopOutput Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopOutput();
    
    /**
     * Differential closed loop total output.
     * <p>
     * The total output of the differential closed loop output (on the
     * difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialClosedLoopOutput Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopOutput(boolean refresh);
    
    /**
     * Value that the differential closed loop is targeting.
     * <p>
     * This is the value that the differential closed loop PID controller
     * targets (on the difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopReference Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopReference();
    
    /**
     * Value that the differential closed loop is targeting.
     * <p>
     * This is the value that the differential closed loop PID controller
     * targets (on the difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialClosedLoopReference Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopReference(boolean refresh);
    
    /**
     * Derivative of the target that the differential closed loop is
     * targeting.
     * <p>
     * This is the change in the closed loop reference (on the difference
     * axis). This may be used in the feed-forward calculation, the
     * derivative-error, or in application of the signage for kS.
     * Typically, this represents the target velocity during Motion
     * Magic®.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopReferenceSlope Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopReferenceSlope();
    
    /**
     * Derivative of the target that the differential closed loop is
     * targeting.
     * <p>
     * This is the change in the closed loop reference (on the difference
     * axis). This may be used in the feed-forward calculation, the
     * derivative-error, or in application of the signage for kS.
     * Typically, this represents the target velocity during Motion
     * Magic®.
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialClosedLoopReferenceSlope Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopReferenceSlope(boolean refresh);
    
    /**
     * The difference between target differential reference and current
     * measurement.
     * <p>
     * This is the value that is treated as the error in the differential
     * PID loop (on the difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return DifferentialClosedLoopError Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopError();
    
    /**
     * The difference between target differential reference and current
     * measurement.
     * <p>
     * This is the value that is treated as the error in the differential
     * PID loop (on the difference axis).
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return DifferentialClosedLoopError Status Signal object
     */
    StatusSignal<Double> getDifferentialClosedLoopError(boolean refresh);
    

    
    /**
     * Sets the mechanism position of the device in mechanism rotations.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @return StatusCode of the set command
     */
    StatusCode setPosition(double newValue);
    /**
     * Sets the mechanism position of the device in mechanism rotations.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode setPosition(double newValue, double timeoutSeconds);
    
    /**
     * Sets the mechanism position of the device in mechanism rotations.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @return StatusCode of the set command
     */
    StatusCode setPosition(Angle newValue);
    /**
     * Sets the mechanism position of the device in mechanism rotations.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode setPosition(Angle newValue, double timeoutSeconds);
    
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFaults();
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFaults(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_Hardware();
    /**
     * Clear sticky fault: Hardware fault occurred
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_Hardware(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Processor temperature exceeded limit
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_ProcTemp();
    /**
     * Clear sticky fault: Processor temperature exceeded limit
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_ProcTemp(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Device temperature exceeded limit
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_DeviceTemp();
    /**
     * Clear sticky fault: Device temperature exceeded limit
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_DeviceTemp(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_Undervoltage();
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_Undervoltage(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_BootDuringEnable();
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_BootDuringEnable(double timeoutSeconds);
    
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_UnlicensedFeatureInUse();
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_UnlicensedFeatureInUse(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Bridge was disabled most likely due to supply
     * voltage dropping too low.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_BridgeBrownout();
    /**
     * Clear sticky fault: Bridge was disabled most likely due to supply
     * voltage dropping too low.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_BridgeBrownout(double timeoutSeconds);
    
    /**
     * Clear sticky fault: The remote sensor has reset.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_RemoteSensorReset();
    /**
     * Clear sticky fault: The remote sensor has reset.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_RemoteSensorReset(double timeoutSeconds);
    
    /**
     * Clear sticky fault: The remote Talon used for differential control
     * is not present on CAN Bus.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MissingDifferentialFX();
    /**
     * Clear sticky fault: The remote Talon used for differential control
     * is not present on CAN Bus.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MissingDifferentialFX(double timeoutSeconds);
    
    /**
     * Clear sticky fault: The remote sensor position has overflowed.
     * Because of the nature of remote sensors, it is possible for the
     * remote sensor position to overflow beyond what is supported by the
     * status signal frame. However, this is rare and cannot occur over
     * the course of an FRC match under normal use.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_RemoteSensorPosOverflow();
    /**
     * Clear sticky fault: The remote sensor position has overflowed.
     * Because of the nature of remote sensors, it is possible for the
     * remote sensor position to overflow beyond what is supported by the
     * status signal frame. However, this is rare and cannot occur over
     * the course of an FRC match under normal use.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_RemoteSensorPosOverflow(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Supply Voltage has exceeded the maximum voltage
     * rating of device.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_OverSupplyV();
    /**
     * Clear sticky fault: Supply Voltage has exceeded the maximum voltage
     * rating of device.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_OverSupplyV(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Supply Voltage is unstable.  Ensure you are
     * using a battery and current limited power supply.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_UnstableSupplyV();
    /**
     * Clear sticky fault: Supply Voltage is unstable.  Ensure you are
     * using a battery and current limited power supply.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_UnstableSupplyV(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Reverse limit switch has been asserted.  Output
     * is set to neutral.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_ReverseHardLimit();
    /**
     * Clear sticky fault: Reverse limit switch has been asserted.  Output
     * is set to neutral.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_ReverseHardLimit(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Forward limit switch has been asserted.  Output
     * is set to neutral.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_ForwardHardLimit();
    /**
     * Clear sticky fault: Forward limit switch has been asserted.  Output
     * is set to neutral.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_ForwardHardLimit(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Reverse soft limit has been asserted.  Output
     * is set to neutral.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_ReverseSoftLimit();
    /**
     * Clear sticky fault: Reverse soft limit has been asserted.  Output
     * is set to neutral.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_ReverseSoftLimit(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Forward soft limit has been asserted.  Output
     * is set to neutral.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_ForwardSoftLimit();
    /**
     * Clear sticky fault: Forward soft limit has been asserted.  Output
     * is set to neutral.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_ForwardSoftLimit(double timeoutSeconds);
    
    /**
     * Clear sticky fault: The remote soft limit device is not present on
     * CAN Bus.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MissingSoftLimitRemote();
    /**
     * Clear sticky fault: The remote soft limit device is not present on
     * CAN Bus.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MissingSoftLimitRemote(double timeoutSeconds);
    
    /**
     * Clear sticky fault: The remote limit switch device is not present
     * on CAN Bus.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MissingHardLimitRemote();
    /**
     * Clear sticky fault: The remote limit switch device is not present
     * on CAN Bus.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_MissingHardLimitRemote(double timeoutSeconds);
    
    /**
     * Clear sticky fault: The remote sensor's data is no longer trusted.
     * This can happen if the remote sensor disappears from the CAN bus or
     * if the remote sensor indicates its data is no longer valid, such as
     * when a CANcoder's magnet strength falls into the "red" range.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_RemoteSensorDataInvalid();
    /**
     * Clear sticky fault: The remote sensor's data is no longer trusted.
     * This can happen if the remote sensor disappears from the CAN bus or
     * if the remote sensor indicates its data is no longer valid, such as
     * when a CANcoder's magnet strength falls into the "red" range.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_RemoteSensorDataInvalid(double timeoutSeconds);
    
    /**
     * Clear sticky fault: The remote sensor used for fusion has fallen
     * out of sync to the local sensor. A re-synchronization has occurred,
     * which may cause a discontinuity. This typically happens if there is
     * significant slop in the mechanism, or if the RotorToSensorRatio
     * configuration parameter is incorrect.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_FusedSensorOutOfSync();
    /**
     * Clear sticky fault: The remote sensor used for fusion has fallen
     * out of sync to the local sensor. A re-synchronization has occurred,
     * which may cause a discontinuity. This typically happens if there is
     * significant slop in the mechanism, or if the RotorToSensorRatio
     * configuration parameter is incorrect.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_FusedSensorOutOfSync(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Stator current limit occured.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_StatorCurrLimit();
    /**
     * Clear sticky fault: Stator current limit occured.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_StatorCurrLimit(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Supply current limit occured.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_SupplyCurrLimit();
    /**
     * Clear sticky fault: Supply current limit occured.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_SupplyCurrLimit(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Using Fused CANcoder feature while unlicensed.
     * Device has fallen back to remote CANcoder.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_UsingFusedCANcoderWhileUnlicensed();
    /**
     * Clear sticky fault: Using Fused CANcoder feature while unlicensed.
     * Device has fallen back to remote CANcoder.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_UsingFusedCANcoderWhileUnlicensed(double timeoutSeconds);
    
    /**
     * Clear sticky fault: Static brake was momentarily disabled due to
     * excessive braking current while disabled.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_StaticBrakeDisabled();
    /**
     * Clear sticky fault: Static brake was momentarily disabled due to
     * excessive braking current while disabled.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    StatusCode clearStickyFault_StaticBrakeDisabled(double timeoutSeconds);
}

