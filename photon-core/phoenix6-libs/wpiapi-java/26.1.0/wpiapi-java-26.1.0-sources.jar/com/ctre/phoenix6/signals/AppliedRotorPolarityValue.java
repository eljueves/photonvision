/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The applied rotor polarity as seen from the front of the motor.  This
 * typically is determined by the Inverted config, but can be overridden if
 * using Follower features.
 */
public enum AppliedRotorPolarityValue
{
    /**
     * Positive motor output results in counter-clockwise motion.
     */
    PositiveIsCounterClockwise(0),
    /**
     * Positive motor output results in clockwise motion.
     */
    PositiveIsClockwise(1),;

    public final int value;

    AppliedRotorPolarityValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, AppliedRotorPolarityValue> _map = null;
    static
    {
        _map = new HashMap<Integer, AppliedRotorPolarityValue>();
        for (AppliedRotorPolarityValue type : AppliedRotorPolarityValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets AppliedRotorPolarityValue from specified value
     * @param value Value of AppliedRotorPolarityValue
     * @return AppliedRotorPolarityValue of specified value
     */
    public static AppliedRotorPolarityValue valueOf(int value)
    {
        AppliedRotorPolarityValue retval = _map.get(value);
        if (retval != null) return retval;
        return AppliedRotorPolarityValue.values()[0];
    }
}
