/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

/**
 * Configs related to sensors used for differential control of a
 * mechanism.
 * <p>
 * Includes the differential sensor sources and IDs.
 */
public class DifferentialSensorsConfigs implements ParentConfiguration, Cloneable {
    /**
     * Choose what sensor source is used for differential control of a
     * mechanism.  The default is Disabled.  All other options require
     * setting the DifferentialTalonFXSensorID, as the average of this
     * Talon FX's sensor and the remote TalonFX's sensor is used for the
     * differential controller's primary targets.
     * <p>
     * Choose RemoteTalonFX_HalfDiff to use another TalonFX on the same
     * CAN bus.  Talon FX will update its differential position and
     * velocity whenever the remote TalonFX publishes its information on
     * CAN bus.  The differential controller will use half of the
     * difference between this TalonFX's sensor and the remote Talon FX's
     * sensor for the differential component of the output.
     * <p>
     * Choose RemotePigeon2Yaw, RemotePigeon2Pitch, and RemotePigeon2Roll
     * to use another Pigeon2 on the same CAN bus (this also requires
     * setting DifferentialRemoteSensorID).  Talon FX will update its
     * differential position to match the selected value whenever Pigeon2
     * publishes its information on CAN bus. Note that the Talon FX
     * differential position will be in rotations and not degrees.
     * <p>
     * Choose RemoteCANcoder to use another CANcoder on the same CAN bus
     * (this also requires setting DifferentialRemoteSensorID).  Talon FX
     * will update its differential position and velocity to match the
     * CANcoder whenever CANcoder publishes its information on CAN bus.
     * 
     */
    public DifferentialSensorSourceValue DifferentialSensorSource = DifferentialSensorSourceValue.Disabled;
    /**
     * Device ID of which remote Talon FX to use.  This is used whenever
     * the Differential Sensor Source is not disabled.
     * <p>
     * The differential Talon FX must enable its Position and Velocity
     * status signals. The update rate of the status signals determines
     * the update rate of differential control.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int DifferentialTalonFXSensorID = 0;
    /**
     * Device ID of which remote sensor to use on the differential axis. 
     * This is used when the Differential Sensor Source is not Disabled or
     * RemoteTalonFX_HalfDiff.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int DifferentialRemoteSensorID = 0;
    /**
     * The ratio of sensor rotations to the differential mechanism's
     * difference output, where a ratio greater than 1 is a reduction.
     * <p>
     * When using RemoteTalonFX_HalfDiff, the sensor is considered half of
     * the difference between the two devices' mechanism
     * positions/velocities. As a result, this should be set to the gear
     * ratio on the difference axis when using RemoteTalonFX_HalfDiff, or
     * any gear ratio between the sensor and the mechanism differential
     * when using another sensor source.
     * <p>
     * We recommend against using this config to perform onboard unit
     * conversions.  Instead, unit conversions should be performed in
     * robot code using the units library.
     * <p>
     * If this is set to zero, the device will reset back to one.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1000
     *   <li> <b>Maximum Value:</b> 1000
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     */
    public double SensorToDifferentialRatio = 1.0;
    
    /**
     * Modifies this configuration's DifferentialSensorSource parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Choose what sensor source is used for differential control of a
     * mechanism.  The default is Disabled.  All other options require
     * setting the DifferentialTalonFXSensorID, as the average of this
     * Talon FX's sensor and the remote TalonFX's sensor is used for the
     * differential controller's primary targets.
     * <p>
     * Choose RemoteTalonFX_HalfDiff to use another TalonFX on the same
     * CAN bus.  Talon FX will update its differential position and
     * velocity whenever the remote TalonFX publishes its information on
     * CAN bus.  The differential controller will use half of the
     * difference between this TalonFX's sensor and the remote Talon FX's
     * sensor for the differential component of the output.
     * <p>
     * Choose RemotePigeon2Yaw, RemotePigeon2Pitch, and RemotePigeon2Roll
     * to use another Pigeon2 on the same CAN bus (this also requires
     * setting DifferentialRemoteSensorID).  Talon FX will update its
     * differential position to match the selected value whenever Pigeon2
     * publishes its information on CAN bus. Note that the Talon FX
     * differential position will be in rotations and not degrees.
     * <p>
     * Choose RemoteCANcoder to use another CANcoder on the same CAN bus
     * (this also requires setting DifferentialRemoteSensorID).  Talon FX
     * will update its differential position and velocity to match the
     * CANcoder whenever CANcoder publishes its information on CAN bus.
     * 
     *
     * @param newDifferentialSensorSource Parameter to modify
     * @return Itself
     */
    public final DifferentialSensorsConfigs withDifferentialSensorSource(DifferentialSensorSourceValue newDifferentialSensorSource)
    {
        DifferentialSensorSource = newDifferentialSensorSource;
        return this;
    }
    
    /**
     * Modifies this configuration's DifferentialTalonFXSensorID parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Device ID of which remote Talon FX to use.  This is used whenever
     * the Differential Sensor Source is not disabled.
     * <p>
     * The differential Talon FX must enable its Position and Velocity
     * status signals. The update rate of the status signals determines
     * the update rate of differential control.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newDifferentialTalonFXSensorID Parameter to modify
     * @return Itself
     */
    public final DifferentialSensorsConfigs withDifferentialTalonFXSensorID(int newDifferentialTalonFXSensorID)
    {
        DifferentialTalonFXSensorID = newDifferentialTalonFXSensorID;
        return this;
    }
    
    /**
     * Modifies this configuration's DifferentialRemoteSensorID parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Device ID of which remote sensor to use on the differential axis. 
     * This is used when the Differential Sensor Source is not Disabled or
     * RemoteTalonFX_HalfDiff.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newDifferentialRemoteSensorID Parameter to modify
     * @return Itself
     */
    public final DifferentialSensorsConfigs withDifferentialRemoteSensorID(int newDifferentialRemoteSensorID)
    {
        DifferentialRemoteSensorID = newDifferentialRemoteSensorID;
        return this;
    }
    
    /**
     * Modifies this configuration's SensorToDifferentialRatio parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The ratio of sensor rotations to the differential mechanism's
     * difference output, where a ratio greater than 1 is a reduction.
     * <p>
     * When using RemoteTalonFX_HalfDiff, the sensor is considered half of
     * the difference between the two devices' mechanism
     * positions/velocities. As a result, this should be set to the gear
     * ratio on the difference axis when using RemoteTalonFX_HalfDiff, or
     * any gear ratio between the sensor and the mechanism differential
     * when using another sensor source.
     * <p>
     * We recommend against using this config to perform onboard unit
     * conversions.  Instead, unit conversions should be performed in
     * robot code using the units library.
     * <p>
     * If this is set to zero, the device will reset back to one.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1000
     *   <li> <b>Maximum Value:</b> 1000
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     *
     * @param newSensorToDifferentialRatio Parameter to modify
     * @return Itself
     */
    public final DifferentialSensorsConfigs withSensorToDifferentialRatio(double newSensorToDifferentialRatio)
    {
        SensorToDifferentialRatio = newSensorToDifferentialRatio;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: DifferentialSensors\n";
        ss += "    DifferentialSensorSource: " + DifferentialSensorSource + "\n";
        ss += "    DifferentialTalonFXSensorID: " + DifferentialTalonFXSensorID + "\n";
        ss += "    DifferentialRemoteSensorID: " + DifferentialRemoteSensorID + "\n";
        ss += "    SensorToDifferentialRatio: " + SensorToDifferentialRatio + " scalar" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeint(SpnValue.Config_DifferentialSensorSource.value, DifferentialSensorSource.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_DifferentialTalonFXSensorID.value, DifferentialTalonFXSensorID);
        ss += ConfigJNI.Serializeint(SpnValue.Config_DifferentialRemoteSensorID.value, DifferentialRemoteSensorID);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_SensorToDifferentialRatio.value, SensorToDifferentialRatio);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        DifferentialSensorSource = DifferentialSensorSourceValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_DifferentialSensorSource.value, to_deserialize));
        DifferentialTalonFXSensorID = ConfigJNI.Deserializeint(SpnValue.Config_DifferentialTalonFXSensorID.value, to_deserialize);
        DifferentialRemoteSensorID = ConfigJNI.Deserializeint(SpnValue.Config_DifferentialRemoteSensorID.value, to_deserialize);
        SensorToDifferentialRatio = ConfigJNI.Deserializedouble(SpnValue.Config_SensorToDifferentialRatio.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public DifferentialSensorsConfigs clone() {
        try {
            return (DifferentialSensorsConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

