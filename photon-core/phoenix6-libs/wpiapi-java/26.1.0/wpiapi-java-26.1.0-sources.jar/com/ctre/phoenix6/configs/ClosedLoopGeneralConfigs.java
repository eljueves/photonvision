/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs that affect general behavior during closed-looping.
 * <p>
 * Includes Continuous Wrap features.
 */
public class ClosedLoopGeneralConfigs implements ParentConfiguration, Cloneable {
    /**
     * Wrap position error within [-0.5, +0.5) mechanism rotations. 
     * Typically used for continuous position closed-loops like swerve
     * azimuth.
     * <p>
     * This uses the mechanism rotation value. If there is a gear ratio
     * between the sensor and the mechanism, make sure to apply a
     * SensorToMechanismRatio so the closed loop operates on the full
     * rotation.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean ContinuousWrap = false;
    /**
     * Wrap differential difference position error within [-0.5, +0.5)
     * mechanism rotations.  Typically used for continuous position
     * closed-loops like a differential wrist.
     * <p>
     * This uses the differential difference rotation value. If there is a
     * gear ratio on the difference axis, make sure to apply a
     * SensorToDifferentialRatio so the closed loop operates on the full
     * rotation.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean DifferentialContinuousWrap = false;
    /**
     * The position closed-loop error threshold for gain scheduling. When
     * the absolute value of the closed-loop error is within the threshold
     * (inclusive), the PID controller will automatically switch gains
     * according to the configured GainSchedBehavior of the slot.
     * <p>
     * When this is zero (default), no gain scheduling will occur.
     * Additionally, this does not take effect for velocity closed-loop
     * controls.
     * <p>
     * This can be used to implement a closed-loop deadband or, less
     * commonly, to switch to weaker gains when close to the target.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double GainSchedErrorThreshold = 0.0;
    /**
     * The behavior of kP output as the error crosses the
     * GainSchedErrorThreshold during gain scheduling. The output of kP
     * can be adjusted to maintain continuity in output, or it can be left
     * discontinuous.
     * 
     */
    public GainSchedKpBehaviorValue GainSchedKpBehavior = GainSchedKpBehaviorValue.Continuous;
    
    /**
     * Modifies this configuration's ContinuousWrap parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Wrap position error within [-0.5, +0.5) mechanism rotations. 
     * Typically used for continuous position closed-loops like swerve
     * azimuth.
     * <p>
     * This uses the mechanism rotation value. If there is a gear ratio
     * between the sensor and the mechanism, make sure to apply a
     * SensorToMechanismRatio so the closed loop operates on the full
     * rotation.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newContinuousWrap Parameter to modify
     * @return Itself
     */
    public final ClosedLoopGeneralConfigs withContinuousWrap(boolean newContinuousWrap)
    {
        ContinuousWrap = newContinuousWrap;
        return this;
    }
    
    /**
     * Modifies this configuration's DifferentialContinuousWrap parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Wrap differential difference position error within [-0.5, +0.5)
     * mechanism rotations.  Typically used for continuous position
     * closed-loops like a differential wrist.
     * <p>
     * This uses the differential difference rotation value. If there is a
     * gear ratio on the difference axis, make sure to apply a
     * SensorToDifferentialRatio so the closed loop operates on the full
     * rotation.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newDifferentialContinuousWrap Parameter to modify
     * @return Itself
     */
    public final ClosedLoopGeneralConfigs withDifferentialContinuousWrap(boolean newDifferentialContinuousWrap)
    {
        DifferentialContinuousWrap = newDifferentialContinuousWrap;
        return this;
    }
    
    /**
     * Modifies this configuration's GainSchedErrorThreshold parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The position closed-loop error threshold for gain scheduling. When
     * the absolute value of the closed-loop error is within the threshold
     * (inclusive), the PID controller will automatically switch gains
     * according to the configured GainSchedBehavior of the slot.
     * <p>
     * When this is zero (default), no gain scheduling will occur.
     * Additionally, this does not take effect for velocity closed-loop
     * controls.
     * <p>
     * This can be used to implement a closed-loop deadband or, less
     * commonly, to switch to weaker gains when close to the target.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newGainSchedErrorThreshold Parameter to modify
     * @return Itself
     */
    public final ClosedLoopGeneralConfigs withGainSchedErrorThreshold(double newGainSchedErrorThreshold)
    {
        GainSchedErrorThreshold = newGainSchedErrorThreshold;
        return this;
    }
    
    /**
     * Modifies this configuration's GainSchedErrorThreshold parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The position closed-loop error threshold for gain scheduling. When
     * the absolute value of the closed-loop error is within the threshold
     * (inclusive), the PID controller will automatically switch gains
     * according to the configured GainSchedBehavior of the slot.
     * <p>
     * When this is zero (default), no gain scheduling will occur.
     * Additionally, this does not take effect for velocity closed-loop
     * controls.
     * <p>
     * This can be used to implement a closed-loop deadband or, less
     * commonly, to switch to weaker gains when close to the target.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newGainSchedErrorThreshold Parameter to modify
     * @return Itself
     */
    public final ClosedLoopGeneralConfigs withGainSchedErrorThreshold(Angle newGainSchedErrorThreshold)
    {
        GainSchedErrorThreshold = newGainSchedErrorThreshold.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's GainSchedErrorThreshold parameter converted
     * to a unit type. If not using the Java units library, {@link #GainSchedErrorThreshold}
     * can be accessed directly instead.
     * <p>
     * The position closed-loop error threshold for gain scheduling. When
     * the absolute value of the closed-loop error is within the threshold
     * (inclusive), the PID controller will automatically switch gains
     * according to the configured GainSchedBehavior of the slot.
     * <p>
     * When this is zero (default), no gain scheduling will occur.
     * Additionally, this does not take effect for velocity closed-loop
     * controls.
     * <p>
     * This can be used to implement a closed-loop deadband or, less
     * commonly, to switch to weaker gains when close to the target.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return GainSchedErrorThreshold
     */
    public final Angle getGainSchedErrorThresholdMeasure()
    {
        return Rotations.of(GainSchedErrorThreshold);
    }
    
    /**
     * Modifies this configuration's GainSchedKpBehavior parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The behavior of kP output as the error crosses the
     * GainSchedErrorThreshold during gain scheduling. The output of kP
     * can be adjusted to maintain continuity in output, or it can be left
     * discontinuous.
     * 
     *
     * @param newGainSchedKpBehavior Parameter to modify
     * @return Itself
     */
    public final ClosedLoopGeneralConfigs withGainSchedKpBehavior(GainSchedKpBehaviorValue newGainSchedKpBehavior)
    {
        GainSchedKpBehavior = newGainSchedKpBehavior;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: ClosedLoopGeneral\n";
        ss += "    ContinuousWrap: " + ContinuousWrap + "\n";
        ss += "    DifferentialContinuousWrap: " + DifferentialContinuousWrap + "\n";
        ss += "    GainSchedErrorThreshold: " + GainSchedErrorThreshold + " rotations" + "\n";
        ss += "    GainSchedKpBehavior: " + GainSchedKpBehavior + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_ContinuousWrap.value, ContinuousWrap);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_DifferentialContinuousWrap.value, DifferentialContinuousWrap);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_GainSchedErrorThreshold.value, GainSchedErrorThreshold);
        ss += ConfigJNI.Serializeint(SpnValue.Config_GainSchedKpBehavior.value, GainSchedKpBehavior.value);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        ContinuousWrap = ConfigJNI.Deserializeboolean(SpnValue.Config_ContinuousWrap.value, to_deserialize);
        DifferentialContinuousWrap = ConfigJNI.Deserializeboolean(SpnValue.Config_DifferentialContinuousWrap.value, to_deserialize);
        GainSchedErrorThreshold = ConfigJNI.Deserializedouble(SpnValue.Config_GainSchedErrorThreshold.value, to_deserialize);
        GainSchedKpBehavior = GainSchedKpBehaviorValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_GainSchedKpBehavior.value, to_deserialize));
        return  StatusCode.OK;
    }

    @Override
    public ClosedLoopGeneralConfigs clone() {
        try {
            return (ClosedLoopGeneralConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

