/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Selects the motor and motor connections used with Talon.
 * <p>
 * This setting determines what kind of motor and sensors are used with the
 * Talon.  This also determines what signals are used on the JST and Gadgeteer
 * port.
 * <p>
 * Motor drive will not function correctly if this setting does not match the
 * physical setup.
 */
public enum MotorArrangementValue
{
    /**
     * Motor is not selected.  This is the default setting to ensure the user has an
     * opportunity to select the correct motor arrangement before attempting to
     * drive motor.
     */
    Disabled(0),
    /**
     * CTR Electronics Minion® brushless three phase motor.
     * Motor leads: red(terminal A), black (terminal B), and white (terminal C).
     * JST Connector: hall [A, B, C] is on pins [4, 3, 2] and temperature is on pin
     * [5]. Motor JST cable can be plugged directly into the JST connector.
     * Gadgeteer Connector: quadrature [A, B] are on pins [7, 5], limit [forward,
     * reverse] are on pins [4, 8], and pulse width position is on pin [9].
     */
    Minion_JST(1),
    /**
     * Third party brushed DC motor with two leads.
     * Use the Brushed Motor Wiring config to determine which leads to use on the
     * Talon (motor leads may be flipped to correct for clockwise vs
     * counterclockwise).
     * Note that the invert configuration can still be used to invert rotor
     * orientation.
     * Gadgeteer Connector: quadrature [A, B] are on pins [7, 5], limit [forward,
     * reverse] are on pins [4, 8], and pulse width position is on pin [9].
     */
    Brushed_DC(2),
    /**
     * Third party NEO brushless three phase motor (~6000 RPM at 12V).
     * Motor leads: red(terminal A), black (terminal B), and white (terminal C).
     * JST Connector: hall [A, B, C] is on pins [4, 3, 2] and temperature is on pin
     * [5]. Motor JST cable can be plugged directly into the JST connector.
     * Gadgeteer Connector: quadrature [A, B] are on pins [7, 5], limit [forward,
     * reverse] are on pins [4, 8], and pulse width position is on pin [9].
     */
    NEO_JST(5),
    /**
     * Third party NEO550 brushless three phase motor (~11000 RPM at 12V).
     * Motor leads: red(terminal A), black (terminal B), and white (terminal C).
     * JST Connector: hall [A, B, C] is on pins [4, 3, 2] and temperature is on pin
     * [5]. Motor JST cable can be plugged directly into the JST connector.
     * Gadgeteer Connector: quadrature [A, B] are on pins [7, 5], limit [forward,
     * reverse] are on pins [4, 8], and pulse width position is on pin [9].
     */
    NEO550_JST(6),
    /**
     * Third party VORTEX brushless three phase motor.
     * Motor leads: red(terminal A), black (terminal B), and white (terminal C).
     * JST Connector: hall [A, B, C] is on pins [4, 3, 2] and temperature is on pin
     * [5]. Motor JST cable can be plugged directly into the JST connector.
     * Gadgeteer Connector: quadrature [A, B] are on pins [7, 5], limit [forward,
     * reverse] are on pins [4, 8], and pulse width position is on pin [9].
     */
    VORTEX_JST(7),
    /**
     * Third party custom brushless three phase motor.
     * This setting allows use of TalonFXS with motors that are not explicitly
     * supported above.  Note that this requires user to set the Custom Motor
     * configuration parameters.
     * This setting will only work outside of the FRC use case.  If selected during
     * FRC use, motor output will be neutral.
     * Motor leads: red(terminal A), black (terminal B), and white (terminal C).
     * JST Connector: hall [A, B, C] is on pins [4, 3, 2] and temperature is on pin
     * [5]. Motor JST cable can be plugged directly into the JST connector.
     * Gadgeteer Connector: quadrature [A, B] are on pins [7, 5], limit [forward,
     * reverse] are on pins [4, 8], and pulse width position is on pin [9].
     */
    CustomBrushless(8),;

    public final int value;

    MotorArrangementValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, MotorArrangementValue> _map = null;
    static
    {
        _map = new HashMap<Integer, MotorArrangementValue>();
        for (MotorArrangementValue type : MotorArrangementValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets MotorArrangementValue from specified value
     * @param value Value of MotorArrangementValue
     * @return MotorArrangementValue of specified value
     */
    public static MotorArrangementValue valueOf(int value)
    {
        MotorArrangementValue retval = _map.get(value);
        if (retval != null) return retval;
        return MotorArrangementValue.values()[0];
    }
}
