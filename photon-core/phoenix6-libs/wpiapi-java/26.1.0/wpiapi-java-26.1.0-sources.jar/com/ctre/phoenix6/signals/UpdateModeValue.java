/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Update mode of the CANrange. The CANrange supports short-range and long-range
 * detection at various update frequencies.
 */
public enum UpdateModeValue
{
    /**
     * Updates distance/proximity at 100hz using short-range detection mode.
     */
    ShortRange100Hz(0),
    /**
     * Uses short-range detection mode for improved detection under high ambient
     * infrared light conditions. Uses user-specified update frequency.
     */
    ShortRangeUserFreq(1),
    /**
     * Uses long-range detection mode and user-specified update frequency.
     */
    LongRangeUserFreq(2),;

    public final int value;

    UpdateModeValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, UpdateModeValue> _map = null;
    static
    {
        _map = new HashMap<Integer, UpdateModeValue>();
        for (UpdateModeValue type : UpdateModeValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets UpdateModeValue from specified value
     * @param value Value of UpdateModeValue
     * @return UpdateModeValue of specified value
     */
    public static UpdateModeValue valueOf(int value)
    {
        UpdateModeValue retval = _map.get(value);
        if (retval != null) return retval;
        return UpdateModeValue.values()[0];
    }
}
