/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware;

import java.util.ArrayList;

import com.ctre.phoenix6.BaseStatusSignal;
import com.ctre.phoenix6.CANBus;
import com.ctre.phoenix6.StatusSignal;
import com.ctre.phoenix6.Utils;
import com.ctre.phoenix6.hardware.core.CorePigeon2;
import com.ctre.phoenix6.jni.PlatformJNI;
import com.ctre.phoenix6.sim.DeviceType;
import com.ctre.phoenix6.wpiutils.AutoFeedEnable;
import com.ctre.phoenix6.wpiutils.CallbackHelper;
import com.ctre.phoenix6.wpiutils.ReplayAutoEnable;

import edu.wpi.first.hal.HAL;
import edu.wpi.first.hal.HAL.SimPeriodicBeforeCallback;
import edu.wpi.first.hal.HALValue;
import edu.wpi.first.hal.SimDevice;
import edu.wpi.first.hal.SimDevice.Direction;
import edu.wpi.first.hal.SimDouble;
import edu.wpi.first.hal.simulation.SimDeviceDataJNI;
import edu.wpi.first.math.geometry.Quaternion;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.units.measure.Angle;
import edu.wpi.first.util.sendable.Sendable;
import edu.wpi.first.util.sendable.SendableBuilder;
import edu.wpi.first.util.sendable.SendableRegistry;
import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.wpilibj.simulation.CallbackStore;
import edu.wpi.first.wpilibj.simulation.SimDeviceSim;

/**
 * WPILib-integrated version of {@link CorePigeon2}.
 */
public class Pigeon2 extends CorePigeon2 implements Sendable, AutoCloseable {
    /**
     * The StatusSignal getters are copies so that calls
     * to the WPI interface do not update any references
     */
    @SuppressWarnings("this-escape")
    private final StatusSignal<Angle> m_yawGetter = getYaw(false).clone();
    @SuppressWarnings("this-escape")
    private final StatusSignal<Double> m_quatWGetter = getQuatW(false).clone();
    @SuppressWarnings("this-escape")
    private final StatusSignal<Double> m_quatXGetter = getQuatX(false).clone();
    @SuppressWarnings("this-escape")
    private final StatusSignal<Double> m_quatYGetter = getQuatY(false).clone();
    @SuppressWarnings("this-escape")
    private final StatusSignal<Double> m_quatZGetter = getQuatZ(false).clone();

    private static final DeviceType kSimDeviceType = DeviceType.P6_Pigeon2Type;

    private SimDevice m_simPigeon;
    private SimDouble m_simSupplyVoltage;
    private SimDouble m_simYaw;
    private SimDouble m_simRawYaw;
    private SimDouble m_simPitch;
    private SimDouble m_simRoll;
    private SimDouble m_simAngularVelocityX;
    private SimDouble m_simAngularVelocityY;
    private SimDouble m_simAngularVelocityZ;

    // returned registered callbacks
    private final ArrayList<CallbackStore> m_simValueChangedCallbacks = new ArrayList<CallbackStore>();
    private SimPeriodicBeforeCallback m_simPeriodicBeforeCallback = null;

    /**
     * Constructs a new Pigeon 2 sensor object.
     * <p>
     * Constructs the device using the default CAN bus for the system
     * (see {@link CANBus#CANBus()}).
     *
     * @param deviceId ID of the device, as configured in Phoenix Tuner
     */
    public Pigeon2(int deviceId) {
        this(deviceId, new CANBus());
    }

    /**
     * Constructs a new Pigeon 2 sensor object.
     *
     * @param deviceId ID of the device, as configured in Phoenix Tuner
     * @param canbus   Name of the CAN bus this device is on. Possible CAN bus
     *                 strings are:
     *                 <ul>
     *                   <li>"rio" for the native roboRIO CAN bus
     *                   <li>CANivore name or serial number
     *                   <li>SocketCAN interface (non-FRC Linux only)
     *                   <li>"*" for any CANivore seen by the program
     *                   <li>empty string (default) to select the default for the
     *                       system:
     *                   <ul>
     *                     <li>"rio" on roboRIO
     *                     <li>"can0" on Linux
     *                     <li>"*" on Windows
     *                   </ul>
     *                 </ul>
     *
     * @deprecated Constructing devices with a CAN bus string is deprecated for removal
     * in the 2027 season. Construct devices using a {@link CANBus} instance instead.
     */
    @Deprecated(since = "2026", forRemoval = true)
    public Pigeon2(int deviceId, String canbus) {
        this(deviceId, new CANBus(canbus));
    }

    /**
     * Constructs a new Pigeon 2 sensor object.
     *
     * @param deviceId ID of the device, as configured in Phoenix Tuner
     * @param canbus   The CAN bus this device is on
     */
    @SuppressWarnings("this-escape")
    public Pigeon2(int deviceId, CANBus canbus) {
        super(deviceId, canbus);
        SendableRegistry.addLW(this, "Pigeon 2 (v6) ", deviceId);

        if (RobotBase.isSimulation()) {
            /* run in both swsim and hwsim */
            AutoFeedEnable.getInstance().start();
        }
        if (Utils.isReplay()) {
            ReplayAutoEnable.getInstance().start();
        }

        m_simPigeon = SimDevice.create("CANGyro:Pigeon 2 (v6)", deviceId);
        if (m_simPigeon != null) {
            /* Simulated Pigeon2 LEDs change if it's enabled, so make sure we enable it */
            m_simPeriodicBeforeCallback = HAL.registerSimPeriodicBeforeCallback(this::onPeriodic);

            m_simSupplyVoltage = m_simPigeon.createDouble("supplyVoltage", Direction.kInput, 12.0);

            m_simYaw = m_simPigeon.createDouble("yaw", Direction.kOutput, 0);

            m_simRawYaw = m_simPigeon.createDouble("rawYawInput", Direction.kInput, 0);
            m_simPitch = m_simPigeon.createDouble("pitch", Direction.kInput, 0);
            m_simRoll = m_simPigeon.createDouble("roll", Direction.kInput, 0);
            m_simAngularVelocityX = m_simPigeon.createDouble("angularVelX", Direction.kInput, 0);
            m_simAngularVelocityY = m_simPigeon.createDouble("angularVelY", Direction.kInput, 0);
            m_simAngularVelocityZ = m_simPigeon.createDouble("angularVelZ", Direction.kInput, 0);

            final SimDeviceSim sim = new SimDeviceSim("CANGyro:Pigeon 2 (v6)");
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simSupplyVoltage, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simRawYaw, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simPitch, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simRoll, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simAngularVelocityX, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simAngularVelocityY, this::onValueChanged, true)
            );
            m_simValueChangedCallbacks.add(
                sim.registerValueChangedCallback(m_simAngularVelocityZ, this::onValueChanged, true)
            );
        }
    }

    // ----- Auto-Closable, from Gyro ----- //
    @Override
    public void close() {
        SendableRegistry.remove(this);
        if (m_simPeriodicBeforeCallback != null) {
            m_simPeriodicBeforeCallback.close();
            m_simPeriodicBeforeCallback = null;
        }
        if (m_simPigeon != null) {
            m_simPigeon.close();
            m_simPigeon = null;
        }

        for (var callback : m_simValueChangedCallbacks) {
            callback.close();
        }
        m_simValueChangedCallbacks.clear();

        AutoFeedEnable.getInstance().stop();
        ReplayAutoEnable.getInstance().stop();
    }

    // ----- Callbacks for Sim ----- //
    private void onValueChanged(String name, int handle, int direction, HALValue value) {
        String deviceName = SimDeviceDataJNI.getSimDeviceName(SimDeviceDataJNI.getSimValueDeviceHandle(handle));
        String physType = deviceName + ":" + name;
        PlatformJNI.JNI_SimSetPhysicsInput(
            kSimDeviceType.value, getDeviceID(),
            physType, CallbackHelper.getRawValue(value)
        );
    }

    private void onPeriodic() {
        double value = 0;
        int err = 0;

        final int deviceID = getDeviceID();

        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "SupplyVoltage");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simSupplyVoltage.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "Yaw");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simYaw.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "RawYaw");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simRawYaw.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "Pitch");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simPitch.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "Roll");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simRoll.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "AngularVelocityX");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simAngularVelocityX.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "AngularVelocityY");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simAngularVelocityY.set(value);
        }
        value = PlatformJNI.JNI_SimGetPhysicsValue(kSimDeviceType.value, deviceID, "AngularVelocityZ");
        err = PlatformJNI.JNI_SimGetLastError(kSimDeviceType.value, deviceID);
        if (err == 0) {
            m_simAngularVelocityZ.set(value);
        }
    }

    // ----- WPILib Gyro Interface ----- //
    //WPILib no longer has a Gyro interface, but these methods are standard in FRC.

    /**
     * Resets the Pigeon 2 to a heading of zero.
     * <p>
     * This can be used if there is significant drift in the gyro,
     * and it needs to be recalibrated after it has been running.
     */
    public final void reset() {
        setYaw(0);
    }

    /**
     * Returns the heading of the robot as a {@link Rotation2d}.
     * <p>
     * The angle increases as the Pigeon 2 turns counterclockwise when
     * looked at from the top. This follows the NWU axis convention.
     * <p>
     * The angle is continuous; that is, it will continue from 360 to
     * 361 degrees. This allows for algorithms that wouldn't want to
     * see a discontinuity in the gyro output as it sweeps past from
     * 360 to 0 on the second time around.
     *
     * @return The current heading of the robot as a {@link Rotation2d}
     */
    public final Rotation2d getRotation2d() {
        // Rotation2d and Pigeon are both ccw+
        return Rotation2d.fromDegrees(m_yawGetter.refresh().getValueAsDouble());
    }

    /**
     * Returns the orientation of the robot as a {@link Rotation3d}
     * created from the quaternion signals.
     *
     * @return The current orientation of the robot as a {@link Rotation3d}
     */
    public final Rotation3d getRotation3d() {
        BaseStatusSignal.refreshAll(m_quatWGetter, m_quatXGetter, m_quatYGetter, m_quatZGetter);
        return new Rotation3d(new Quaternion(m_quatWGetter.getValue(), m_quatXGetter.getValue(), m_quatYGetter.getValue(), m_quatZGetter.getValue()));
    }

    // ----- Sendable ----- //
    @Override
    public void initSendable(SendableBuilder builder) {
        builder.setSmartDashboardType("Gyro");
        builder.addDoubleProperty("Value", () -> m_yawGetter.refresh().getValueAsDouble(), this::setYaw);
    }

}
