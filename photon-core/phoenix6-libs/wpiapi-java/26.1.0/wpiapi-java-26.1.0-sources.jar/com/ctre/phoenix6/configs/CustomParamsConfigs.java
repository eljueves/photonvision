/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

/**
 * Custom Params.
 * <p>
 * Custom paramaters that have no real impact on controller.
 */
public class CustomParamsConfigs implements ParentConfiguration, Cloneable {
    /**
     * Custom parameter 0.  This is provided to allow end-applications to
     * store persistent information in the device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32768
     *   <li> <b>Maximum Value:</b> 32767
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int CustomParam0 = 0;
    /**
     * Custom parameter 1.  This is provided to allow end-applications to
     * store persistent information in the device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32768
     *   <li> <b>Maximum Value:</b> 32767
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int CustomParam1 = 0;
    
    /**
     * Modifies this configuration's CustomParam0 parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Custom parameter 0.  This is provided to allow end-applications to
     * store persistent information in the device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32768
     *   <li> <b>Maximum Value:</b> 32767
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newCustomParam0 Parameter to modify
     * @return Itself
     */
    public final CustomParamsConfigs withCustomParam0(int newCustomParam0)
    {
        CustomParam0 = newCustomParam0;
        return this;
    }
    
    /**
     * Modifies this configuration's CustomParam1 parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Custom parameter 1.  This is provided to allow end-applications to
     * store persistent information in the device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -32768
     *   <li> <b>Maximum Value:</b> 32767
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newCustomParam1 Parameter to modify
     * @return Itself
     */
    public final CustomParamsConfigs withCustomParam1(int newCustomParam1)
    {
        CustomParam1 = newCustomParam1;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: CustomParams\n";
        ss += "    CustomParam0: " + CustomParam0 + "\n";
        ss += "    CustomParam1: " + CustomParam1 + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeint(SpnValue.CustomParam0.value, CustomParam0);
        ss += ConfigJNI.Serializeint(SpnValue.CustomParam1.value, CustomParam1);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        CustomParam0 = ConfigJNI.Deserializeint(SpnValue.CustomParam0.value, to_deserialize);
        CustomParam1 = ConfigJNI.Deserializeint(SpnValue.CustomParam1.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public CustomParamsConfigs clone() {
        try {
            return (CustomParamsConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

