/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.jni.ControlJNI;
import com.ctre.phoenix6.hardware.traits.*;
import com.ctre.phoenix6.signals.*;

import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Sets LEDs to a solid color.
 * <p>
 * 
 */
public final class SolidColor implements ControlRequest, Cloneable {
    /**
     * The index of the first LED this animation controls (inclusive). Indices 0-7
     * control the onboard LEDs, and 8-399 control an attached LED strip.
     */
    public int LEDStartIndex;
    /**
     * The index of the last LED this animation controls (inclusive). Indices 0-7
     * control the onboard LEDs, and 8-399 control an attached LED strip.
     */
    public int LEDEndIndex;
    /**
     * The color to apply to the LEDs.
     */
    public RGBWColor Color = new RGBWColor();

    /**
     * The frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     */
    // This request is always 0 Hz. public double UpdateFreqHz = 0;

    /**
     * Sets LEDs to a solid color.
     * <p>
     * 
     * 
     * @param LEDStartIndex The index of the first LED this animation controls
     *                      (inclusive). Indices 0-7 control the onboard LEDs, and
     *                      8-399 control an attached LED strip.
     * @param LEDEndIndex The index of the last LED this animation controls
     *                    (inclusive). Indices 0-7 control the onboard LEDs, and
     *                    8-399 control an attached LED strip.
     */
    public SolidColor(int LEDStartIndex, int LEDEndIndex) {
        this.LEDStartIndex = LEDStartIndex;
        this.LEDEndIndex = LEDEndIndex;
    }

    @Override
    public String getName() {
        return "SolidColor";
    }

    @Override
    public String toString() {
        String ss = "Control: SolidColor\n";
        ss += "    LEDStartIndex: " + LEDStartIndex + "\n";
        ss += "    LEDEndIndex: " + LEDEndIndex + "\n";
        ss += "    Color: " + Color + "\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlSolidColor(
                network, deviceHash, 0, LEDStartIndex, LEDEndIndex, Color.Red, Color.Green, Color.Blue, Color.White));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String, String>();
        controlInfo.put("Name", getName());
        controlInfo.put("LEDStartIndex", String.valueOf(this.LEDStartIndex));
        controlInfo.put("LEDEndIndex", String.valueOf(this.LEDEndIndex));
        controlInfo.put("Color", String.valueOf(this.Color));
        return controlInfo;
    }
    
    /**
     * Modifies this Control Request's LEDStartIndex parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * The index of the first LED this animation controls (inclusive). Indices 0-7
     * control the onboard LEDs, and 8-399 control an attached LED strip.
     *
     * @param newLEDStartIndex Parameter to modify
     * @return Itself
     */
    public SolidColor withLEDStartIndex(int newLEDStartIndex) {
        LEDStartIndex = newLEDStartIndex;
        return this;
    }
    
    /**
     * Modifies this Control Request's LEDEndIndex parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * The index of the last LED this animation controls (inclusive). Indices 0-7
     * control the onboard LEDs, and 8-399 control an attached LED strip.
     *
     * @param newLEDEndIndex Parameter to modify
     * @return Itself
     */
    public SolidColor withLEDEndIndex(int newLEDEndIndex) {
        LEDEndIndex = newLEDEndIndex;
        return this;
    }
    
    /**
     * Modifies this Control Request's Color parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * The color to apply to the LEDs.
     *
     * @param newColor Parameter to modify
     * @return Itself
     */
    public SolidColor withColor(RGBWColor newColor) {
        Color = newColor;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public SolidColor withUpdateFreqHz(double newUpdateFreqHz) {
        // This request is always 0 Hz. UpdateFreqHz = newUpdateFreqHz;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public SolidColor withUpdateFreqHz(Frequency newUpdateFreqHz) {
        // This request is always 0 Hz. UpdateFreqHz = newUpdateFreqHz.in(Hertz);
        return this;
    }

    @Override
    public SolidColor clone() {
        try {
            return (SolidColor)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

