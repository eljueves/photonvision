/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.unmanaged;

import com.ctre.phoenix6.jni.CtreJniWrapper;
import com.ctre.phoenix6.unmanaged.jni.UnmanagedJNI;

/**
 * Handles enabling when used in a non-FRC manner
 */
public class Unmanaged extends CtreJniWrapper {
    /**
     * Feed the robot enable.
     * This function does nothing on a roborio during FRC use.
     * <p>
     * If running an application in simulation, creating a WPI_*
     * object automatically enables actuators.
     * Otherwise, call this to enable actuators.
     * <p>
     * A timeout of 0 disables actuators.
     *
     * @param timeoutMs Timeout before disabling
     */
    public static void feedEnable(int timeoutMs) {
        UnmanagedJNI.JNI_FeedEnable(timeoutMs);
    }

    /**
     * @return true if non-FRC enabled
     */
    public static boolean getEnableState() {
        return UnmanagedJNI.JNI_GetEnableState();
    }

    /**
     * @return Phoenix version
     */
    public static int getPhoenixVersion() {
        return UnmanagedJNI.JNI_GetPhoenixVersion();
    }

    /**
     * Calling this function will load and start
     * the Phoenix background tasks.
     *
     * This can be useful if you need the
     * Enable/Disable functionality for CAN devices
     * but aren't using any of the CAN device classes.
     *
     * This function does NOT need to be called if
     * you are using any of the Phoenix CAN device classes.
     */
    public static void loadPhoenix() {
        UnmanagedJNI.JNI_LoadPhoenix();
    }

    /**
     * Sets the duration of the delay before starting
     * the Phoenix diagnostics server.
     *
     * @param startTimeSeconds Magnitude of the delay (in seconds) before
     *                         starting the server.
     *                         A value of 0 will start the server immediately.
     *                         A negative value will signal the server
     *                         to shutdown or never start.
     */
    public static void setPhoenixDiagnosticsStartTime(double startTimeSeconds) {
        UnmanagedJNI.JNI_SetPhoenixDiagnosticsStartTime(startTimeSeconds);
    }

    /**
     * Gets this API's compliancy version
     * <p>
     * This is purely used to check compliancy of API against firmware, and if there
     * is a mismatch to report to the user.
     *
     * @return This API's compliancy version
     */
    public static int getApiCompliancy() {
        return UnmanagedJNI.JNI_GetApiCompliancy();
    }
}
