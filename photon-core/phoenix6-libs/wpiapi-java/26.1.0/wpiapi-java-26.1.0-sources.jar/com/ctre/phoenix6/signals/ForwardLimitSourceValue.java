/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Determines where to poll the forward limit switch.  This defaults to the
 * forward limit switch pin on the limit switch connector.
 * <p>
 * Choose RemoteTalonFX to use the forward limit switch attached to another
 * Talon FX on the same CAN bus (this also requires setting
 * ForwardLimitRemoteSensorID).
 * <p>
 * Choose RemoteCANifier to use the forward limit switch attached to another
 * CANifier on the same CAN bus (this also requires setting
 * ForwardLimitRemoteSensorID).
 * <p>
 * Choose RemoteCANcoder to use another CANcoder on the same CAN bus (this also
 * requires setting ForwardLimitRemoteSensorID).  The forward limit will assert
 * when the CANcoder magnet strength changes from BAD (red) to ADEQUATE (orange)
 * or GOOD (green).
 */
public enum ForwardLimitSourceValue
{
    /**
     * Use the forward limit switch pin on the limit switch connector.
     */
    LimitSwitchPin(0),
    /**
     * Use the forward limit switch attached to another Talon FX on the same CAN bus
     * (this also requires setting ForwardLimitRemoteSensorID).
     */
    RemoteTalonFX(1),
    /**
     * Use the forward limit switch attached to another CANifier on the same CAN bus
     * (this also requires setting ForwardLimitRemoteSensorID).
     */
    RemoteCANifier(2),
    /**
     * Use another CANcoder on the same CAN bus (this also requires setting
     * ForwardLimitRemoteSensorID).  The forward limit will assert when the CANcoder
     * magnet strength changes from BAD (red) to ADEQUATE (orange) or GOOD (green).
     */
    RemoteCANcoder(4),
    /**
     * Use another CANrange on the same CAN bus (this also requires setting
     * ForwardLimitRemoteSensorID).  The forward limit will assert when the CANrange
     * proximity detect is tripped.
     */
    RemoteCANrange(6),
    /**
     * Use another CTR Electronics' CANdi™ on the same CAN bus (this also requires
     * setting ForwardLimitRemoteSensorID).  The forward limit will assert when the
     * CTR Electronics' CANdi™ Signal 1 Input (S1IN) pin matches the configured
     * closed state.
     */
    RemoteCANdiS1(7),
    /**
     * Use another CTR Electronics' CANdi™ on the same CAN bus (this also requires
     * setting ForwardLimitRemoteSensorID).  The forward limit will assert when the
     * CTR Electronics' CANdi™ Signal 2 Input (S2IN) pin matches the configured
     * closed state.
     */
    RemoteCANdiS2(8),
    /**
     * Disable the forward limit switch.
     */
    Disabled(3),;

    public final int value;

    ForwardLimitSourceValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, ForwardLimitSourceValue> _map = null;
    static
    {
        _map = new HashMap<Integer, ForwardLimitSourceValue>();
        for (ForwardLimitSourceValue type : ForwardLimitSourceValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets ForwardLimitSourceValue from specified value
     * @param value Value of ForwardLimitSourceValue
     * @return ForwardLimitSourceValue of specified value
     */
    public static ForwardLimitSourceValue valueOf(int value)
    {
        ForwardLimitSourceValue retval = _map.get(value);
        if (retval != null) return retval;
        return ForwardLimitSourceValue.values()[0];
    }
}
