/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The behavior of the LEDs when the control signal is lost.
 */
public enum LossOfSignalBehaviorValue
{
    /**
     * LEDs remain enabled, and animations continue to run.
     */
    KeepRunning(0),
    /**
     * LEDs and animations are disabled after the control signal is lost.
     */
    DisableLEDs(1),;

    public final int value;

    LossOfSignalBehaviorValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, LossOfSignalBehaviorValue> _map = null;
    static
    {
        _map = new HashMap<Integer, LossOfSignalBehaviorValue>();
        for (LossOfSignalBehaviorValue type : LossOfSignalBehaviorValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets LossOfSignalBehaviorValue from specified value
     * @param value Value of LossOfSignalBehaviorValue
     * @return LossOfSignalBehaviorValue of specified value
     */
    public static LossOfSignalBehaviorValue valueOf(int value)
    {
        LossOfSignalBehaviorValue retval = _map.get(value);
        if (retval != null) return retval;
        return LossOfSignalBehaviorValue.values()[0];
    }
}
