/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Reverse Limit Pin.
 */
public enum ReverseLimitValue
{
    ClosedToGround(0),
    Open(1),;

    public final int value;

    ReverseLimitValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, ReverseLimitValue> _map = null;
    static
    {
        _map = new HashMap<Integer, ReverseLimitValue>();
        for (ReverseLimitValue type : ReverseLimitValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets ReverseLimitValue from specified value
     * @param value Value of ReverseLimitValue
     * @return ReverseLimitValue of specified value
     */
    public static ReverseLimitValue valueOf(int value)
    {
        ReverseLimitValue retval = _map.get(value);
        if (retval != null) return retval;
        return ReverseLimitValue.values()[0];
    }
}
