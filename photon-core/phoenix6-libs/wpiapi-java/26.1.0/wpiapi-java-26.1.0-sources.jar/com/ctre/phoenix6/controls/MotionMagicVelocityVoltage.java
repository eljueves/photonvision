/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.jni.ControlJNI;
import com.ctre.phoenix6.hardware.traits.*;

import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Requests Motion Magic® to target a final velocity using a motion profile. 
 * This allows smooth transitions between velocity set points.  Users can
 * optionally provide a voltage feedforward.
 * <p>
 * Motion Magic® Velocity produces a motion profile in real-time while attempting to honor the specified
 * Acceleration and (optional) Jerk.  This control mode does not use the CruiseVelocity, Expo_kV, or Expo_kA
 * configs.
 * <p>
 * If the specified acceleration is zero, the Acceleration under Motion Magic® configuration parameter is used
 * instead.  This allows for runtime adjustment of acceleration for advanced users.  Jerk is also specified in
 * the Motion Magic® persistent configuration values.  If Jerk is set to zero, Motion Magic® will produce a
 * trapezoidal acceleration profile.
 * <p>
 * Target velocity can also be changed on-the-fly and Motion Magic® will do its best to adjust the profile. 
 * This control mode is voltage-based, so relevant closed-loop gains will use Volts for the numerator.
 */
public final class MotionMagicVelocityVoltage implements ControlRequest, Cloneable {
    /**
     * Target velocity to drive toward in rotations per second.  This can be changed
     * on-the fly.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     */
    public double Velocity;
    /**
     * This is the absolute Acceleration to use generating the profile.  If this
     * parameter is zero, the Acceleration persistent configuration parameter is
     * used instead. Acceleration is in rotations per second squared.  If nonzero,
     * the signage does not matter as the absolute value is used.
     * 
     * <ul>
     *   <li> Units: rotations per second²
     * </ul>
     * 
     */
    public double Acceleration = 0.0;
    /**
     * Set to true to use FOC commutation (requires Phoenix Pro), which increases
     * peak power by ~15% on supported devices (see {@link SupportsFOC}). Set to
     * false to use trapezoidal commutation.
     * <p>
     * FOC improves motor performance by leveraging torque (current) control. 
     * However, this may be inconvenient for applications that require specifying
     * duty cycle or voltage.  CTR-Electronics has developed a hybrid method that
     * combines the performances gains of FOC while still allowing applications to
     * provide duty cycle or voltage demand.  This not to be confused with simple
     * sinusoidal control or phase voltage control which lacks the performance
     * gains.
     */
    public boolean EnableFOC = true;
    /**
     * Feedforward to apply in volts. This is added to the output of the onboard
     * feedforward terms.
     * 
     * <ul>
     *   <li> Units: Volts
     * </ul>
     * 
     */
    public double FeedForward = 0.0;
    /**
     * Select which gains are applied by selecting the slot.  Use the configuration
     * api to set the gain values for the selected slot before enabling this
     * feature. Slot must be within [0,2].
     */
    public int Slot = 0;
    /**
     * Set to true to static-brake the rotor when output is zero (or within
     * deadband).  Set to false to use the NeutralMode configuration setting
     * (default). This flag exists to provide the fundamental behavior of this
     * control when output is zero, which is to provide 0V to the motor.
     */
    public boolean OverrideBrakeDurNeutral = false;
    /**
     * Set to true to force forward limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     */
    public boolean LimitForwardMotion = false;
    /**
     * Set to true to force reverse limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     */
    public boolean LimitReverseMotion = false;
    /**
     * Set to true to ignore hardware limit switches and the LimitForwardMotion and
     * LimitReverseMotion parameters, instead allowing motion.
     * <p>
     * This can be useful on mechanisms such as an intake/feeder, where a limit
     * switch stops motion while intaking but should be ignored when feeding to a
     * shooter.
     * <p>
     * The hardware limit faults and Forward/ReverseLimit signals will still report
     * the values of the limit switches regardless of this parameter.
     */
    public boolean IgnoreHardwareLimits = false;
    /**
     * Set to true to ignore software limits, instead allowing motion.
     * <p>
     * This can be useful when calibrating the zero point of a mechanism such as an
     * elevator.
     * <p>
     * The software limit faults will still report the values of the software limits
     * regardless of this parameter.
     */
    public boolean IgnoreSoftwareLimits = false;
    /**
     * Set to true to delay applying this control request until a timesync boundary
     * (requires Phoenix Pro and CANivore). This eliminates the impact of
     * nondeterministic network delays in exchange for a larger but deterministic
     * control latency.
     * <p>
     * This requires setting the ControlTimesyncFreqHz config in MotorOutputConfigs.
     * Additionally, when this is enabled, the UpdateFreqHz of this request should
     * be set to 0 Hz.
     */
    public boolean UseTimesync = false;

    /**
     * The frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     */
    public double UpdateFreqHz = 100;

    /**
     * Requests Motion Magic® to target a final velocity using a motion profile. 
     * This allows smooth transitions between velocity set points.  Users can
     * optionally provide a voltage feedforward.
     * <p>
     * Motion Magic® Velocity produces a motion profile in real-time while
     * attempting to honor the specified Acceleration and (optional) Jerk.  This
     * control mode does not use the CruiseVelocity, Expo_kV, or Expo_kA configs.
     * <p>
     * If the specified acceleration is zero, the Acceleration under Motion Magic®
     * configuration parameter is used instead.  This allows for runtime adjustment
     * of acceleration for advanced users.  Jerk is also specified in the Motion
     * Magic® persistent configuration values.  If Jerk is set to zero, Motion
     * Magic® will produce a trapezoidal acceleration profile.
     * <p>
     * Target velocity can also be changed on-the-fly and Motion Magic® will do its
     * best to adjust the profile.  This control mode is voltage-based, so relevant
     * closed-loop gains will use Volts for the numerator.
     * 
     * @param Velocity Target velocity to drive toward in rotations per second. 
     *                 This can be changed on-the fly.
     */
    public MotionMagicVelocityVoltage(double Velocity) {
        this.Velocity = Velocity;
    }

    /**
     * Requests Motion Magic® to target a final velocity using a motion profile. 
     * This allows smooth transitions between velocity set points.  Users can
     * optionally provide a voltage feedforward.
     * <p>
     * Motion Magic® Velocity produces a motion profile in real-time while
     * attempting to honor the specified Acceleration and (optional) Jerk.  This
     * control mode does not use the CruiseVelocity, Expo_kV, or Expo_kA configs.
     * <p>
     * If the specified acceleration is zero, the Acceleration under Motion Magic®
     * configuration parameter is used instead.  This allows for runtime adjustment
     * of acceleration for advanced users.  Jerk is also specified in the Motion
     * Magic® persistent configuration values.  If Jerk is set to zero, Motion
     * Magic® will produce a trapezoidal acceleration profile.
     * <p>
     * Target velocity can also be changed on-the-fly and Motion Magic® will do its
     * best to adjust the profile.  This control mode is voltage-based, so relevant
     * closed-loop gains will use Volts for the numerator.
     * 
     * @param Velocity Target velocity to drive toward in rotations per second. 
     *                 This can be changed on-the fly.
     */
    public MotionMagicVelocityVoltage(AngularVelocity Velocity) {
        this(Velocity.in(RotationsPerSecond));
    }

    @Override
    public String getName() {
        return "MotionMagicVelocityVoltage";
    }

    @Override
    public String toString() {
        String ss = "Control: MotionMagicVelocityVoltage\n";
        ss += "    Velocity: " + Velocity + " rotations per second" + "\n";
        ss += "    Acceleration: " + Acceleration + " rotations per second²" + "\n";
        ss += "    EnableFOC: " + EnableFOC + "\n";
        ss += "    FeedForward: " + FeedForward + " Volts" + "\n";
        ss += "    Slot: " + Slot + "\n";
        ss += "    OverrideBrakeDurNeutral: " + OverrideBrakeDurNeutral + "\n";
        ss += "    LimitForwardMotion: " + LimitForwardMotion + "\n";
        ss += "    LimitReverseMotion: " + LimitReverseMotion + "\n";
        ss += "    IgnoreHardwareLimits: " + IgnoreHardwareLimits + "\n";
        ss += "    IgnoreSoftwareLimits: " + IgnoreSoftwareLimits + "\n";
        ss += "    UseTimesync: " + UseTimesync + "\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlMotionMagicVelocityVoltage(
                network, deviceHash, UpdateFreqHz, Velocity, Acceleration, EnableFOC, FeedForward, Slot, OverrideBrakeDurNeutral, LimitForwardMotion, LimitReverseMotion, IgnoreHardwareLimits, IgnoreSoftwareLimits, UseTimesync));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String, String>();
        controlInfo.put("Name", getName());
        controlInfo.put("Velocity", String.valueOf(this.Velocity));
        controlInfo.put("Acceleration", String.valueOf(this.Acceleration));
        controlInfo.put("EnableFOC", String.valueOf(this.EnableFOC));
        controlInfo.put("FeedForward", String.valueOf(this.FeedForward));
        controlInfo.put("Slot", String.valueOf(this.Slot));
        controlInfo.put("OverrideBrakeDurNeutral", String.valueOf(this.OverrideBrakeDurNeutral));
        controlInfo.put("LimitForwardMotion", String.valueOf(this.LimitForwardMotion));
        controlInfo.put("LimitReverseMotion", String.valueOf(this.LimitReverseMotion));
        controlInfo.put("IgnoreHardwareLimits", String.valueOf(this.IgnoreHardwareLimits));
        controlInfo.put("IgnoreSoftwareLimits", String.valueOf(this.IgnoreSoftwareLimits));
        controlInfo.put("UseTimesync", String.valueOf(this.UseTimesync));
        return controlInfo;
    }
    
    /**
     * Modifies this Control Request's Velocity parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Target velocity to drive toward in rotations per second.  This can be changed
     * on-the fly.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @param newVelocity Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withVelocity(double newVelocity) {
        Velocity = newVelocity;
        return this;
    }
    
    /**
     * Modifies this Control Request's Velocity parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Target velocity to drive toward in rotations per second.  This can be changed
     * on-the fly.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @param newVelocity Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withVelocity(AngularVelocity newVelocity) {
        Velocity = newVelocity.in(RotationsPerSecond);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's Velocity parameter converted
     * to a unit type. If not using the Java units library, {@link #Velocity}
     * can be accessed directly instead.
     * <p>
     * Target velocity to drive toward in rotations per second.  This can be changed
     * on-the fly.
     * 
     * <ul>
     *   <li> Units: rotations per second
     * </ul>
     * 
     *
     * @return Velocity
     */
    public AngularVelocity getVelocityMeasure() {
        return RotationsPerSecond.of(Velocity);
    }
    
    /**
     * Modifies this Control Request's Acceleration parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * This is the absolute Acceleration to use generating the profile.  If this
     * parameter is zero, the Acceleration persistent configuration parameter is
     * used instead. Acceleration is in rotations per second squared.  If nonzero,
     * the signage does not matter as the absolute value is used.
     * 
     * <ul>
     *   <li> Units: rotations per second²
     * </ul>
     * 
     *
     * @param newAcceleration Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withAcceleration(double newAcceleration) {
        Acceleration = newAcceleration;
        return this;
    }
    
    /**
     * Modifies this Control Request's Acceleration parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * This is the absolute Acceleration to use generating the profile.  If this
     * parameter is zero, the Acceleration persistent configuration parameter is
     * used instead. Acceleration is in rotations per second squared.  If nonzero,
     * the signage does not matter as the absolute value is used.
     * 
     * <ul>
     *   <li> Units: rotations per second²
     * </ul>
     * 
     *
     * @param newAcceleration Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withAcceleration(AngularAcceleration newAcceleration) {
        Acceleration = newAcceleration.in(RotationsPerSecondPerSecond);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's Acceleration parameter converted
     * to a unit type. If not using the Java units library, {@link #Acceleration}
     * can be accessed directly instead.
     * <p>
     * This is the absolute Acceleration to use generating the profile.  If this
     * parameter is zero, the Acceleration persistent configuration parameter is
     * used instead. Acceleration is in rotations per second squared.  If nonzero,
     * the signage does not matter as the absolute value is used.
     * 
     * <ul>
     *   <li> Units: rotations per second²
     * </ul>
     * 
     *
     * @return Acceleration
     */
    public AngularAcceleration getAccelerationMeasure() {
        return RotationsPerSecondPerSecond.of(Acceleration);
    }
    
    /**
     * Modifies this Control Request's EnableFOC parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to use FOC commutation (requires Phoenix Pro), which increases
     * peak power by ~15% on supported devices (see {@link SupportsFOC}). Set to
     * false to use trapezoidal commutation.
     * <p>
     * FOC improves motor performance by leveraging torque (current) control. 
     * However, this may be inconvenient for applications that require specifying
     * duty cycle or voltage.  CTR-Electronics has developed a hybrid method that
     * combines the performances gains of FOC while still allowing applications to
     * provide duty cycle or voltage demand.  This not to be confused with simple
     * sinusoidal control or phase voltage control which lacks the performance
     * gains.
     *
     * @param newEnableFOC Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withEnableFOC(boolean newEnableFOC) {
        EnableFOC = newEnableFOC;
        return this;
    }
    
    /**
     * Modifies this Control Request's FeedForward parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Feedforward to apply in volts. This is added to the output of the onboard
     * feedforward terms.
     * 
     * <ul>
     *   <li> Units: Volts
     * </ul>
     * 
     *
     * @param newFeedForward Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withFeedForward(double newFeedForward) {
        FeedForward = newFeedForward;
        return this;
    }
    
    /**
     * Modifies this Control Request's FeedForward parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Feedforward to apply in volts. This is added to the output of the onboard
     * feedforward terms.
     * 
     * <ul>
     *   <li> Units: Volts
     * </ul>
     * 
     *
     * @param newFeedForward Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withFeedForward(Voltage newFeedForward) {
        FeedForward = newFeedForward.in(Volts);
        return this;
    }
    
    /**
     * Helper method to get this Control Request's FeedForward parameter converted
     * to a unit type. If not using the Java units library, {@link #FeedForward}
     * can be accessed directly instead.
     * <p>
     * Feedforward to apply in volts. This is added to the output of the onboard
     * feedforward terms.
     * 
     * <ul>
     *   <li> Units: Volts
     * </ul>
     * 
     *
     * @return FeedForward
     */
    public Voltage getFeedForwardMeasure() {
        return Volts.of(FeedForward);
    }
    
    /**
     * Modifies this Control Request's Slot parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Select which gains are applied by selecting the slot.  Use the configuration
     * api to set the gain values for the selected slot before enabling this
     * feature. Slot must be within [0,2].
     *
     * @param newSlot Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withSlot(int newSlot) {
        Slot = newSlot;
        return this;
    }
    
    /**
     * Modifies this Control Request's OverrideBrakeDurNeutral parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to static-brake the rotor when output is zero (or within
     * deadband).  Set to false to use the NeutralMode configuration setting
     * (default). This flag exists to provide the fundamental behavior of this
     * control when output is zero, which is to provide 0V to the motor.
     *
     * @param newOverrideBrakeDurNeutral Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withOverrideBrakeDurNeutral(boolean newOverrideBrakeDurNeutral) {
        OverrideBrakeDurNeutral = newOverrideBrakeDurNeutral;
        return this;
    }
    
    /**
     * Modifies this Control Request's LimitForwardMotion parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to force forward limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     *
     * @param newLimitForwardMotion Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withLimitForwardMotion(boolean newLimitForwardMotion) {
        LimitForwardMotion = newLimitForwardMotion;
        return this;
    }
    
    /**
     * Modifies this Control Request's LimitReverseMotion parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to force reverse limiting.  This allows users to use other limit
     * switch sensors connected to robot controller.  This also allows use of active
     * sensors that require external power.
     *
     * @param newLimitReverseMotion Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withLimitReverseMotion(boolean newLimitReverseMotion) {
        LimitReverseMotion = newLimitReverseMotion;
        return this;
    }
    
    /**
     * Modifies this Control Request's IgnoreHardwareLimits parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to ignore hardware limit switches and the LimitForwardMotion and
     * LimitReverseMotion parameters, instead allowing motion.
     * <p>
     * This can be useful on mechanisms such as an intake/feeder, where a limit
     * switch stops motion while intaking but should be ignored when feeding to a
     * shooter.
     * <p>
     * The hardware limit faults and Forward/ReverseLimit signals will still report
     * the values of the limit switches regardless of this parameter.
     *
     * @param newIgnoreHardwareLimits Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withIgnoreHardwareLimits(boolean newIgnoreHardwareLimits) {
        IgnoreHardwareLimits = newIgnoreHardwareLimits;
        return this;
    }
    
    /**
     * Modifies this Control Request's IgnoreSoftwareLimits parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to ignore software limits, instead allowing motion.
     * <p>
     * This can be useful when calibrating the zero point of a mechanism such as an
     * elevator.
     * <p>
     * The software limit faults will still report the values of the software limits
     * regardless of this parameter.
     *
     * @param newIgnoreSoftwareLimits Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withIgnoreSoftwareLimits(boolean newIgnoreSoftwareLimits) {
        IgnoreSoftwareLimits = newIgnoreSoftwareLimits;
        return this;
    }
    
    /**
     * Modifies this Control Request's UseTimesync parameter and returns itself for
     * method-chaining and easier to use request API.
     * <p>
     * Set to true to delay applying this control request until a timesync boundary
     * (requires Phoenix Pro and CANivore). This eliminates the impact of
     * nondeterministic network delays in exchange for a larger but deterministic
     * control latency.
     * <p>
     * This requires setting the ControlTimesyncFreqHz config in MotorOutputConfigs.
     * Additionally, when this is enabled, the UpdateFreqHz of this request should
     * be set to 0 Hz.
     *
     * @param newUseTimesync Parameter to modify
     * @return Itself
     */
    public MotionMagicVelocityVoltage withUseTimesync(boolean newUseTimesync) {
        UseTimesync = newUseTimesync;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public MotionMagicVelocityVoltage withUpdateFreqHz(double newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz;
        return this;
    }

    /**
     * Sets the frequency at which this control will update.
     * This is designated in Hertz, with a minimum of 20 Hz
     * (every 50 ms) and a maximum of 1000 Hz (every 1 ms).
     * Some update frequencies are not supported and will be
     * promoted up to the next highest supported frequency.
     * <p>
     * If this field is set to 0 Hz, the control request will
     * be sent immediately as a one-shot frame. This may be useful
     * for advanced applications that require outputs to be
     * synchronized with data acquisition. In this case, we
     * recommend not exceeding 50 ms between control calls.
     *
     * @param newUpdateFreqHz Parameter to modify
     * @return Itself
     */
    @Override
    public MotionMagicVelocityVoltage withUpdateFreqHz(Frequency newUpdateFreqHz) {
        UpdateFreqHz = newUpdateFreqHz.in(Hertz);
        return this;
    }

    @Override
    public MotionMagicVelocityVoltage clone() {
        try {
            return (MotionMagicVelocityVoltage)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

