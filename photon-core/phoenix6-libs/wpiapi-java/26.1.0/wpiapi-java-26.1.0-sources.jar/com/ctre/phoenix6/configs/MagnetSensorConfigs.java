/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs that affect the magnet sensor and how to interpret it.
 * <p>
 * Includes sensor direction, the sensor discontinuity point, and the
 * magnet offset.
 */
public class MagnetSensorConfigs implements ParentConfiguration, Cloneable {
    /**
     * Direction of the sensor to determine positive rotation, as seen
     * facing the LED side of the CANcoder.
     * 
     */
    public SensorDirectionValue SensorDirection = SensorDirectionValue.CounterClockwise_Positive;
    /**
     * This offset is added to the reported position, allowing the
     * application to trim the zero position.  When set to the default
     * value of zero, position reports zero when magnet north pole aligns
     * with the LED.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double MagnetOffset = 0;
    /**
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double AbsoluteSensorDiscontinuityPoint = 0.5;
    
    /**
     * Modifies this configuration's SensorDirection parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Direction of the sensor to determine positive rotation, as seen
     * facing the LED side of the CANcoder.
     * 
     *
     * @param newSensorDirection Parameter to modify
     * @return Itself
     */
    public final MagnetSensorConfigs withSensorDirection(SensorDirectionValue newSensorDirection)
    {
        SensorDirection = newSensorDirection;
        return this;
    }
    
    /**
     * Modifies this configuration's MagnetOffset parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This offset is added to the reported position, allowing the
     * application to trim the zero position.  When set to the default
     * value of zero, position reports zero when magnet north pole aligns
     * with the LED.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newMagnetOffset Parameter to modify
     * @return Itself
     */
    public final MagnetSensorConfigs withMagnetOffset(double newMagnetOffset)
    {
        MagnetOffset = newMagnetOffset;
        return this;
    }
    
    /**
     * Modifies this configuration's MagnetOffset parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * This offset is added to the reported position, allowing the
     * application to trim the zero position.  When set to the default
     * value of zero, position reports zero when magnet north pole aligns
     * with the LED.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newMagnetOffset Parameter to modify
     * @return Itself
     */
    public final MagnetSensorConfigs withMagnetOffset(Angle newMagnetOffset)
    {
        MagnetOffset = newMagnetOffset.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's MagnetOffset parameter converted
     * to a unit type. If not using the Java units library, {@link #MagnetOffset}
     * can be accessed directly instead.
     * <p>
     * This offset is added to the reported position, allowing the
     * application to trim the zero position.  When set to the default
     * value of zero, position reports zero when magnet north pole aligns
     * with the LED.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return MagnetOffset
     */
    public final Angle getMagnetOffsetMeasure()
    {
        return Rotations.of(MagnetOffset);
    }
    
    /**
     * Modifies this configuration's AbsoluteSensorDiscontinuityPoint parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newAbsoluteSensorDiscontinuityPoint Parameter to modify
     * @return Itself
     */
    public final MagnetSensorConfigs withAbsoluteSensorDiscontinuityPoint(double newAbsoluteSensorDiscontinuityPoint)
    {
        AbsoluteSensorDiscontinuityPoint = newAbsoluteSensorDiscontinuityPoint;
        return this;
    }
    
    /**
     * Modifies this configuration's AbsoluteSensorDiscontinuityPoint parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newAbsoluteSensorDiscontinuityPoint Parameter to modify
     * @return Itself
     */
    public final MagnetSensorConfigs withAbsoluteSensorDiscontinuityPoint(Angle newAbsoluteSensorDiscontinuityPoint)
    {
        AbsoluteSensorDiscontinuityPoint = newAbsoluteSensorDiscontinuityPoint.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's AbsoluteSensorDiscontinuityPoint parameter converted
     * to a unit type. If not using the Java units library, {@link #AbsoluteSensorDiscontinuityPoint}
     * can be accessed directly instead.
     * <p>
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return AbsoluteSensorDiscontinuityPoint
     */
    public final Angle getAbsoluteSensorDiscontinuityPointMeasure()
    {
        return Rotations.of(AbsoluteSensorDiscontinuityPoint);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: MagnetSensor\n";
        ss += "    SensorDirection: " + SensorDirection + "\n";
        ss += "    MagnetOffset: " + MagnetOffset + " rotations" + "\n";
        ss += "    AbsoluteSensorDiscontinuityPoint: " + AbsoluteSensorDiscontinuityPoint + " rotations" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeint(SpnValue.CANcoder_SensorDirection.value, SensorDirection.value);
        ss += ConfigJNI.Serializedouble(SpnValue.CANCoder_MagnetOffset.value, MagnetOffset);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_AbsoluteSensorDiscontinuityPoint.value, AbsoluteSensorDiscontinuityPoint);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        SensorDirection = SensorDirectionValue.valueOf(ConfigJNI.Deserializeint(SpnValue.CANcoder_SensorDirection.value, to_deserialize));
        MagnetOffset = ConfigJNI.Deserializedouble(SpnValue.CANCoder_MagnetOffset.value, to_deserialize);
        AbsoluteSensorDiscontinuityPoint = ConfigJNI.Deserializedouble(SpnValue.Config_AbsoluteSensorDiscontinuityPoint.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public MagnetSensorConfigs clone() {
        try {
            return (MagnetSensorConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

