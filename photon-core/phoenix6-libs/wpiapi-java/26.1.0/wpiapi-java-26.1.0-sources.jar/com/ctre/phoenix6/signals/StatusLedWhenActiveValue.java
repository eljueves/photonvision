/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Whether the Status LED is enabled when the CANdle is actively being
 * controlled.
 */
public enum StatusLedWhenActiveValue
{
    /**
     * The status LED is enabled during control.
     */
    Enabled(0),
    /**
     * The status LED is disabled during control.
     */
    Disabled(1),;

    public final int value;

    StatusLedWhenActiveValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, StatusLedWhenActiveValue> _map = null;
    static
    {
        _map = new HashMap<Integer, StatusLedWhenActiveValue>();
        for (StatusLedWhenActiveValue type : StatusLedWhenActiveValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets StatusLedWhenActiveValue from specified value
     * @param value Value of StatusLedWhenActiveValue
     * @return StatusLedWhenActiveValue of specified value
     */
    public static StatusLedWhenActiveValue valueOf(int value)
    {
        StatusLedWhenActiveValue retval = _map.get(value);
        if (retval != null) return retval;
        return StatusLedWhenActiveValue.values()[0];
    }
}
