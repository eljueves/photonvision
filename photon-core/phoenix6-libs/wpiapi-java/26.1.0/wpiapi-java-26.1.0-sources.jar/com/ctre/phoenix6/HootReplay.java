/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6;

import java.io.IOException;
import java.util.Optional;
import java.util.function.DoubleFunction;

import com.ctre.phoenix6.StatusSignal.SignalMeasurement;
import com.ctre.phoenix6.jni.HootReplayJNI;

import edu.wpi.first.units.Measure;
import edu.wpi.first.units.Unit;
import edu.wpi.first.util.protobuf.Protobuf;
import edu.wpi.first.util.protobuf.ProtobufBuffer;
import edu.wpi.first.util.struct.Struct;
import edu.wpi.first.util.struct.StructBuffer;

/**
 * Static class for controlling Phoenix 6 hoot log replay.
 * <p>
 * This replays all signals in the given hoot log in simulation. Hoot logs can
 * be created by a robot program using {@link SignalLogger}. Only one hoot log,
 * corresponding to one CAN bus, may be replayed at a time.
 * <p>
 * The signal logger always runs while replay is running. All custom signals written
 * during replay will be automatically placed under {@code hoot_replay/}. Additionally,
 * the log will contain all status signals and custom signals from the original log.
 * <p>
 * During replay, all transmits from the robot program are ignored. This includes
 * features such as control requests, configs, and setting signal update frequency.
 * Additionally, Tuner X is not functional during log replay.
 * <p>
 * To use Hoot Replay, call {@link #loadFile(String)} before any devices are constructed
 * to load a hoot file and start replay. Alternatively, the {@link CANBus#CANBus(String, String)}
 * constructor can be used when constructing devices.
 * <p>
 * After devices are constructed, Hoot Replay can be controlled using {@link #play()},
 * {@link #pause()}, {@link #stop()}, and {@link #restart()}. Additionally, Hoot Replay
 * supports {@link #stepTiming(double)} while paused. The current file can be closed using
 * {@link #closeFile()}, after which a new file may be loaded.
 */
public class HootReplay {
    /**
     * Loads the given file and starts signal log replay. Only one hoot
     * log, corresponding to one CAN bus, may be replayed at a time.
     * <p>
     * This must be called before constructing any devices or checking
     * CAN bus status. The {@link CANBus#CANBus(String, String)}
     * constructor can be used when constructing devices to guarantee
     * that this API is called first.
     * <p>
     * When using relative paths, the file path is typically relative
     * to the top-level folder of the robot project.
     * <p>
     * This API is blocking on the file read.
     *
     * @param filepath Path and name of the hoot file to load
     * @return Status of opening and reading the file for replay
     * @throws IllegalArgumentException The file is invalid, unlicensed, or
     *                                  targets a different version of Phoenix 6
     */
    public static StatusCode loadFile(String filepath) {
        var retval = StatusCode.valueOf(HootReplayJNI.JNI_LoadFile(filepath));
        switch (retval) {
            case InvalidFile:
            case UnlicensedHootLog:
            case HootLogTooOld:
            case HootLogTooNew:
                throw new IllegalArgumentException(retval.getDescription());
            default:
                break;
        }
        return retval;
    }

    /**
     * Ends the hoot log replay. This stops the replay if it is running,
     * closes the hoot log, and clears all signals read from the file.
     */
    public static void closeFile() {
        HootReplayJNI.JNI_CloseFile();
    }

    /**
     * Gets whether a valid hoot log file is currently loaded.
     *
     * @return true if a valid hoot log file is loaded
     */
    public static boolean isFileLoaded() {
        return HootReplayJNI.JNI_IsFileLoaded();
    }

    /**
     * Starts or resumes the hoot log replay.
     *
     * @return Status of starting or resuming replay
     */
    public static StatusCode play() {
        return StatusCode.valueOf(HootReplayJNI.JNI_Play());
    }

    /**
     * Pauses the hoot log replay. This maintains the current position
     * in the log replay so it can be resumed later.
     *
     * @return Status of pausing replay
     */
    public static StatusCode pause() {
        return StatusCode.valueOf(HootReplayJNI.JNI_Pause());
    }

    /**
     * Stops the hoot log replay. This resets the current position in
     * the log replay to the start.
     *
     * @return Status of stopping replay
     */
    public static StatusCode stop() {
        return StatusCode.valueOf(HootReplayJNI.JNI_Stop());
    }

    /**
     * Restarts the hoot log replay from the start of the log.
     * This is equivalent to calling {@link #stop} followed by
     * {@link #play}.
     *
     * @return Status of restarting replay
     */
    public static StatusCode restart() {
        var retval = stop();
        if (retval.isOK()) {
            retval = play();
        }
        return retval;
    }

    /**
     * Gets whether hoot log replay is actively playing.
     * <p>
     * This API will return true in programs that do not support
     * replay, making it safe to call without first checking if
     * the program supports replay.
     *
     * @return true if replay is playing back signals
     */
    public static boolean isPlaying() {
        return waitForPlaying(0.0);
    }

    /**
     * Waits until hoot log replay is actively playing.
     * <p>
     * This API will immediately return true in programs that do
     * not support replay, making it safe to call without first
     * checking if the program supports replay.
     * <p>
     * Since this can block the calling thread, this should not
     * be called with a non-zero timeout on the main thread.
     * <p>
     * This can also be used with a timeout of 0 to perform
     * a non-blocking check, which is equivalent to {@link #isPlaying}.
     *
     * @param timeoutSeconds Max time to wait for replay to start playing
     * @return true if replay is playing back signals
     */
    public static boolean waitForPlaying(double timeoutSeconds) {
        return HootReplayJNI.JNI_IsPlaying(timeoutSeconds);
    }

    /**
     * Gets whether hoot log replay has reached the end of the log.
     *
     * @return true if replay has reached the end of the log, or
     *         if no log is currently loaded
     */
    public static boolean isFinished() {
        return HootReplayJNI.JNI_IsFinished();
    }

    /**
     * Sets the speed of the hoot log replay. A speed of 1.0 corresponds to
     * replaying the file in real time, and larger values increase the speed.
     *
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.01
     *   <li> <b>Maximum Value:</b> 100.0
     *   <li> <b>Default Value:</b> 1.0
     * </ul>
     *
     * @param speed Speed of the hoot log replay
     */
    public static void setSpeed(double speed) {
        HootReplayJNI.JNI_SetSpeed(speed);
    }

    /**
     * Advances the hoot log replay time by the given value. Replay must
     * be paused or stopped before advancing its time.
     *
     * @param stepTimeSeconds The amount of time to advance
     * @return Status of advancing the replay time
     */
    public static StatusCode stepTiming(double stepTimeSeconds) {
        return StatusCode.valueOf(HootReplayJNI.JNI_StepTiming(stepTimeSeconds));
    }

    /**
     * Gets a schema-serialized user signal.
     *
     * Users can call {@link #getStruct}, {@link #getStructArray}, and
     * {@link #getProtobuf} to directly get schema values instead.
     *
     * @param name Name of the signal
     * @param type Type of the schema, such as struct or protobuf
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<byte[]> getSchemaValue(String name, HootSchemaType type) {
        var retval = new SignalMeasurement<byte[]>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetSchemaValue(name, type.value));
        if (retval.status.isOK()) {
            retval.value = (byte[])jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = new byte[0];
        }
        return retval;
    }

    /**
     * Gets a WPILib Struct user signal.
     *
     * @param name Name of the signal
     * @param struct Struct deserialization implementation
     * @return Structure with all information about the signal
     */
    public static <T> SignalMeasurement<Optional<T>> getStruct(String name, Struct<T> struct) {
        var retval = new SignalMeasurement<Optional<T>>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetSchemaValue(name, HootSchemaType.Struct.value));
        if (retval.status.isOK()) {
            final byte[] data = (byte[])jni.data;
            if (data.length == struct.getSize()) {
                final StructBuffer<T> buf = StructBuffer.create(struct);
                retval.value = Optional.of(buf.read((byte[])jni.data));
                retval.timestamp = jni.timestampSec;
                retval.units = jni.units;
            } else {
                retval.value = Optional.empty();
                retval.status = StatusCode.InvalidParamValue;
            }
        } else {
            retval.value = Optional.empty();
        }
        return retval;
    }

    /**
     * Gets a WPILib Struct array user signal.
     *
     * @param name Name of the signal
     * @param struct Struct deserialization implementation
     * @return Structure with all information about the signal
     */
    public static <T> SignalMeasurement<Optional<T[]>> getStructArray(String name, Struct<T> struct) {
        var retval = new SignalMeasurement<Optional<T[]>>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetSchemaValue(name, HootSchemaType.Struct.value));
        if (retval.status.isOK()) {
            final byte[] data = (byte[])jni.data;
            if (data.length % struct.getSize() == 0) {
                final StructBuffer<T> buf = StructBuffer.create(struct);
                retval.value = Optional.of(buf.readArray((byte[])jni.data));
                retval.timestamp = jni.timestampSec;
                retval.units = jni.units;
            } else {
                retval.value = Optional.empty();
                retval.status = StatusCode.InvalidParamValue;
            }
        } else {
            retval.value = Optional.empty();
        }
        return retval;
    }

    /**
     * Gets a Protobuf user signal.
     *
     * @param name Name of the signal
     * @param proto Protobuf deserialization implementation
     * @return Structure with all information about the signal
     */
    public static <T> SignalMeasurement<Optional<T>> getProtobuf(String name, Protobuf<T, ?> proto) {
        var retval = new SignalMeasurement<Optional<T>>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetSchemaValue(name, HootSchemaType.Protobuf.value));
        if (retval.status.isOK()) {
            final ProtobufBuffer<T, ?> buf = ProtobufBuffer.create(proto);
            try {
                retval.value = Optional.of(buf.read((byte[])jni.data));
                retval.timestamp = jni.timestampSec;
                retval.units = jni.units;
            } catch (IOException e) {
                retval.value = Optional.empty();
                retval.status = StatusCode.InvalidParamValue;
            }
        } else {
            retval.value = null;
        }
        return retval;
    }

    /**
     * Gets a raw-bytes user signal.
     *
     * @param name Name of the signal
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<byte[]> getRaw(String name) {
        var retval = new SignalMeasurement<byte[]>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetRaw(name));
        if (retval.status.isOK()) {
            retval.value = (byte[])jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = new byte[0];
        }
        return retval;
    }

    /**
     * Gets a boolean user signal.
     *
     * @param name Name of the signal
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<Boolean> getBoolean(String name) {
        var retval = new SignalMeasurement<Boolean>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetBoolean(name));
        if (retval.status.isOK()) {
            retval.value = (Boolean)jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = false;
        }
        return retval;
    }

    /**
     * Gets an integer user signal.
     *
     * @param name Name of the signal
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<Long> getInteger(String name) {
        var retval = new SignalMeasurement<Long>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetInteger(name));
        if (retval.status.isOK()) {
            retval.value = (Long)jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = 0L;
        }
        return retval;
    }

    /**
     * Gets a float user signal.
     *
     * @param name Name of the signal
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<Float> getFloat(String name) {
        var retval = new SignalMeasurement<Float>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetFloat(name));
        if (retval.status.isOK()) {
            retval.value = (Float)jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = 0.0f;
        }
        return retval;
    }

    /**
     * Gets a double user signal.
     *
     * @param name Name of the signal
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<Double> getDouble(String name) {
        var retval = new SignalMeasurement<Double>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetDouble(name));
        if (retval.status.isOK()) {
            retval.value = (Double)jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = 0.0;
        }
        return retval;
    }

    /**
     * Gets a string user signal.
     *
     * @param name Name of the signal
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<String> getString(String name) {
        var retval = new SignalMeasurement<String>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetString(name));
        if (retval.status.isOK()) {
            retval.value = (String)jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = "";
        }
        return retval;
    }

    /**
     * Gets a unit value user signal.
     *
     * @param name Name of the signal
     * @param unitFactory Factory for creating the unit type, such as {@link Unit#of Rotations::of}
     * @return Structure with all information about the signal
     */
    public static
    <MEAS extends Measure<?>>
    SignalMeasurement<MEAS> getValue(String name, DoubleFunction<MEAS> unitFactory) {
        var retval = new SignalMeasurement<MEAS>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetDouble(name));
        if (retval.status.isOK()) {
            retval.value = unitFactory.apply((double)jni.data);
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = unitFactory.apply(0.0);
        }
        return retval;
    }

    /**
     * Gets a boolean user signal.
     *
     * @param name Name of the signal
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<boolean[]> getBooleanArray(String name) {
        var retval = new SignalMeasurement<boolean[]>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetBooleanArray(name));
        if (retval.status.isOK()) {
            retval.value = (boolean[])jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = new boolean[0];
        }
        return retval;
    }

    /**
     * Gets a boolean array user signal.
     *
     * @param name Name of the signal
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<long[]> getIntegerArray(String name) {
        var retval = new SignalMeasurement<long[]>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetIntegerArray(name));
        if (retval.status.isOK()) {
            retval.value = (long[])jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = new long[0];
        }
        return retval;
    }

    /**
     * Gets a float array user signal.
     *
     * @param name Name of the signal
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<float[]> getFloatArray(String name) {
        var retval = new SignalMeasurement<float[]>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetFloatArray(name));
        if (retval.status.isOK()) {
            retval.value = (float[])jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = new float[0];
        }
        return retval;
    }

    /**
     * Gets a double array user signal.
     *
     * @param name Name of the signal
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<double[]> getDoubleArray(String name) {
        var retval = new SignalMeasurement<double[]>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetDoubleArray(name));
        if (retval.status.isOK()) {
            retval.value = (double[])jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = new double[0];
        }
        return retval;
    }

    /**
     * Gets a string array user signal.
     *
     * @param name Name of the signal
     * @return Structure with all information about the signal
     */
    public static SignalMeasurement<String[]> getStringArray(String name) {
        var retval = new SignalMeasurement<String[]>();
        retval.name = name;

        var jni = new HootReplayJNI();
        retval.status = StatusCode.valueOf(jni.JNI_GetStringArray(name));
        if (retval.status.isOK()) {
            retval.value = (String[])jni.data;
            retval.timestamp = jni.timestampSec;
            retval.units = jni.units;
        } else {
            retval.value = new String[0];
        }
        return retval;
    }
}
