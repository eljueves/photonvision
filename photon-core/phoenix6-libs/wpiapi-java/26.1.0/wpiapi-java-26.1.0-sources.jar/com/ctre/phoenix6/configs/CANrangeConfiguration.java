/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;

/**
 * Class for CANrange, a CAN based Time of Flight (ToF) sensor that measures the
 * distance to the front of the device.
 *
 * This handles applying and refreshing the configurations for the {@link com.ctre.phoenix6.hardware.CANrange}.
 */
public class CANrangeConfiguration implements ParentConfiguration, Cloneable {
    /**
     * True if we should factory default newer unsupported configs,
     * false to leave newer unsupported configs alone.
     * <p>
     * This flag addresses a corner case where the device may have
     * firmware with newer configs that didn't exist when this
     * version of the API was built. If this occurs and this
     * flag is true, unsupported new configs will be factory
     * defaulted to avoid unexpected behavior.
     * <p>
     * This is also the behavior in Phoenix 5, so this flag
     * is defaulted to true to match.
     */
    public boolean FutureProofConfigs = true;

    
    /**
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     */
    public CustomParamsConfigs CustomParams = new CustomParamsConfigs();
    
    /**
     * Configs that affect the ToF sensor
     * <p>
     * Includes Update mode and frequency
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link ToFParamsConfigs#UpdateMode}
     *   <li> {@link ToFParamsConfigs#UpdateFrequency}
     * </ul>
     * 
     */
    public ToFParamsConfigs ToFParams = new ToFParamsConfigs();
    
    /**
     * Configs that affect the ToF Proximity detection
     * <p>
     * Includes proximity mode and the threshold for simple detection
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link ProximityParamsConfigs#ProximityThreshold}
     *   <li> {@link ProximityParamsConfigs#ProximityHysteresis}
     *   <li> {@link
     * ProximityParamsConfigs#MinSignalStrengthForValidMeasurement}
     * </ul>
     * 
     */
    public ProximityParamsConfigs ProximityParams = new ProximityParamsConfigs();
    
    /**
     * Configs that affect the ToF Field of View
     * <p>
     * Includes range and center configs
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link FovParamsConfigs#FOVCenterX}
     *   <li> {@link FovParamsConfigs#FOVCenterY}
     *   <li> {@link FovParamsConfigs#FOVRangeX}
     *   <li> {@link FovParamsConfigs#FOVRangeY}
     * </ul>
     * 
     */
    public FovParamsConfigs FovParams = new FovParamsConfigs();
    
    /**
     * Modifies this configuration's CustomParams parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Custom Params.
     * <p>
     * Custom paramaters that have no real impact on controller.
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link CustomParamsConfigs#CustomParam0}
     *   <li> {@link CustomParamsConfigs#CustomParam1}
     * </ul>
     * 
     *
     * @param newCustomParams Parameter to modify
     * @return Itself
     */
    public final CANrangeConfiguration withCustomParams(CustomParamsConfigs newCustomParams)
    {
        CustomParams = newCustomParams;
        return this;
    }
    
    /**
     * Modifies this configuration's ToFParams parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect the ToF sensor
     * <p>
     * Includes Update mode and frequency
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link ToFParamsConfigs#UpdateMode}
     *   <li> {@link ToFParamsConfigs#UpdateFrequency}
     * </ul>
     * 
     *
     * @param newToFParams Parameter to modify
     * @return Itself
     */
    public final CANrangeConfiguration withToFParams(ToFParamsConfigs newToFParams)
    {
        ToFParams = newToFParams;
        return this;
    }
    
    /**
     * Modifies this configuration's ProximityParams parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect the ToF Proximity detection
     * <p>
     * Includes proximity mode and the threshold for simple detection
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link ProximityParamsConfigs#ProximityThreshold}
     *   <li> {@link ProximityParamsConfigs#ProximityHysteresis}
     *   <li> {@link
     * ProximityParamsConfigs#MinSignalStrengthForValidMeasurement}
     * </ul>
     * 
     *
     * @param newProximityParams Parameter to modify
     * @return Itself
     */
    public final CANrangeConfiguration withProximityParams(ProximityParamsConfigs newProximityParams)
    {
        ProximityParams = newProximityParams;
        return this;
    }
    
    /**
     * Modifies this configuration's FovParams parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Configs that affect the ToF Field of View
     * <p>
     * Includes range and center configs
     * <p>
     * Parameter list:
     * 
     * <ul>
     *   <li> {@link FovParamsConfigs#FOVCenterX}
     *   <li> {@link FovParamsConfigs#FOVCenterY}
     *   <li> {@link FovParamsConfigs#FOVRangeX}
     *   <li> {@link FovParamsConfigs#FOVRangeY}
     * </ul>
     * 
     *
     * @param newFovParams Parameter to modify
     * @return Itself
     */
    public final CANrangeConfiguration withFovParams(FovParamsConfigs newFovParams)
    {
        FovParams = newFovParams;
        return this;
    }

    @Override
    public String toString() {
        String ss = "CANrangeConfiguration\n";
        ss += CustomParams.toString();
        ss += ToFParams.toString();
        ss += ProximityParams.toString();
        ss += FovParams.toString();
        return ss;
    }

    /**
     * Get the serialized form of this configuration.
     *
     * @return Serialized form of this config group
     */
    public final String serialize() {
        String ss = "";
        ss += CustomParams.serialize();
        ss += ToFParams.serialize();
        ss += ProximityParams.serialize();
        ss += FovParams.serialize();
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration.
     *
     * @return Return code of the deserialize method
     */
    public final StatusCode deserialize(String to_deserialize) {
        StatusCode err = StatusCode.OK;
        err = CustomParams.deserialize(to_deserialize);
        err = ToFParams.deserialize(to_deserialize);
        err = ProximityParams.deserialize(to_deserialize);
        err = FovParams.deserialize(to_deserialize);
        return err;
    }

    @Override
    public CANrangeConfiguration clone() {
        var retval = new CANrangeConfiguration();
        retval.FutureProofConfigs = FutureProofConfigs;
        retval.CustomParams = CustomParams.clone();
        retval.ToFParams = ToFParams.clone();
        retval.ProximityParams = ProximityParams.clone();
        retval.FovParams = FovParams.clone();
        return retval;
    }
}
