/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.sim;

import static edu.wpi.first.units.Units.*;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.hardware.core.CoreCANcoder;
import com.ctre.phoenix6.hardware.CANcoder;
import com.ctre.phoenix6.jni.PlatformJNI;
import com.ctre.phoenix6.signals.MagnetHealthValue;

import edu.wpi.first.units.measure.*;

/**
 * Class to control the state of a simulated {@link CANcoder}.
 */
public class CANcoderSimState {
    private static final DeviceType kDevType = DeviceType.P6_CANcoderType;

    private final int _id;

    /**
     * The orientation of the CANcoder relative to the robot chassis.
     * <p>
     * This value should not be changed based on the CANcoder invert.
     * Rather, this value should be changed when the mechanical linkage
     * between the CANcoder and the robot changes.
     */
    public ChassisReference Orientation;
    /**
     * The offset of the CANcoder position relative to the robot chassis,
     * in rotations. This offset is subtracted from the raw position, allowing
     * for a non-zero magnet offset config to behave correctly in simulation.
     * <p>
     * This value should not be changed after initialization unless the
     * mechanical linkage between the CANcoder and the robot changes.
     */
    public double SensorOffset = 0.0;

    /**
     * Creates an object to control the state of the given {@link CANcoder}.
     * <p>
     * This constructor defaults to a counter-clockwise positive orientation
     * relative to the robot chassis.
     * <p>
     * Note the recommended method of accessing simulation features is to use
     * {@link CANcoder#getSimState}.
     *
     * @param device Device to which this simulation state is attached
     */
    public CANcoderSimState(CoreCANcoder device) {
        this(device, ChassisReference.CounterClockwise_Positive);
    }
    /**
     * Creates an object to control the state of the given {@link CANcoder}.
     * <p>
     * Note the recommended method of accessing simulation features is to use
     * {@link CANcoder#getSimState}.
     *
     * @param device Device to which this simulation state is attached
     * @param orientation Orientation of the device relative to the robot chassis
     */
    public CANcoderSimState(CoreCANcoder device, ChassisReference orientation) {
        _id = device.getDeviceID();
        Orientation = orientation;
    }

    /**
     * Sets the simulated supply voltage of the CANcoder.
     * <p>
     * The minimum allowed supply voltage is 4 V - values below this
     * will be promoted to 4 V.
     *
     * @param volts The supply voltage in Volts
     * @return Status code
     */
    public final StatusCode setSupplyVoltage(double volts) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "SupplyVoltage", volts));
    }
    /**
     * Sets the simulated supply voltage of the CANcoder.
     * <p>
     * The minimum allowed supply voltage is 4 V - values below this
     * will be promoted to 4 V.
     *
     * @param voltage The supply voltage
     * @return Status code
     */
    public final StatusCode setSupplyVoltage(Voltage voltage) {
        return setSupplyVoltage(voltage.in(Volts));
    }

    /**
     * Sets the simulated raw position of the CANcoder.
     * <p>
     * Inputs to this function over time should be continuous, as user calls of {@link CANcoder#setPosition} will be accounted for in the callee.
     * <p>
     * The CANcoder integrates this to calculate the true reported position.
     * <p>
     * When using the WPI Sim GUI, you will notice a readonly {@code position} and settable {@code rawPositionInput}.
     * The readonly signal is the emulated position which will match self-test in Tuner and the hardware API.
     * Changes to {@code rawPositionInput} will be integrated into the emulated position.
     * This way a simulator can modify the position without overriding hardware API calls for home-ing the sensor.
     *
     * @param rotations The raw position in rotations
     * @return Status code
     */
    public final StatusCode setRawPosition(double rotations) {
        rotations -= SensorOffset;
        if (Orientation == ChassisReference.Clockwise_Positive) {
            rotations = -rotations;
        }
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "RawPosition", rotations));
    }
    /**
     * Sets the simulated raw position of the CANcoder.
     * <p>
     * Inputs to this function over time should be continuous, as user calls of {@link CANcoder#setPosition} will be accounted for in the callee.
     * <p>
     * The CANcoder integrates this to calculate the true reported position.
     * <p>
     * When using the WPI Sim GUI, you will notice a readonly {@code position} and settable {@code rawPositionInput}.
     * The readonly signal is the emulated position which will match self-test in Tuner and the hardware API.
     * Changes to {@code rawPositionInput} will be integrated into the emulated position.
     * This way a simulator can modify the position without overriding hardware API calls for home-ing the sensor.
     *
     * @param position The raw position
     * @return Status code
     */
    public final StatusCode setRawPosition(Angle position) {
        return setRawPosition(position.in(Rotations));
    }

    /**
     * Adds to the simulated position of the CANcoder.
     *
     * @param dRotations The change in position in rotations
     * @return Status code
     */
    public final StatusCode addPosition(double dRotations) {
        if (Orientation == ChassisReference.Clockwise_Positive) {
            dRotations = -dRotations;
        }
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "AddPosition", dRotations));
    }
    /**
     * Adds to the simulated position of the CANcoder.
     *
     * @param dPosition The change in position
     * @return Status code
     */
    public final StatusCode addPosition(Angle dPosition) {
        return addPosition(dPosition.in(Rotations));
    }

    /**
     * Sets the simulated velocity of the CANcoder.
     *
     * @param rps The new velocity in rotations per second
     * @return Status code
     */
    public final StatusCode setVelocity(double rps) {
        if (Orientation == ChassisReference.Clockwise_Positive) {
            rps = -rps;
        }
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "Velocity", rps));
    }
    /**
     * Sets the simulated velocity of the CANcoder.
     *
     * @param velocity The new velocity
     * @return Status code
     */
    public final StatusCode setVelocity(AngularVelocity velocity) {
        return setVelocity(velocity.in(RotationsPerSecond));
    }

    /**
     * Sets the simulated magnet health of the CANcoder.
     *
     * @param value The magnet health to simulate. This directly correlates to the 
     *              red/green/orange state of the simulated LED.
     * @return Status code
     */
    public final StatusCode setMagnetHealth(MagnetHealthValue value) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "MagnetHealth", value.value));
    }
}
