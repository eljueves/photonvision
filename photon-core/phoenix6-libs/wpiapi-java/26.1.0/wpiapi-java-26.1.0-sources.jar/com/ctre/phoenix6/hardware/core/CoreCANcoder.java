/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.hardware.core;

import com.ctre.phoenix6.hardware.ParentDevice;
import com.ctre.phoenix6.controls.*;
import com.ctre.phoenix6.configs.*;
import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.jni.PlatformJNI;
import com.ctre.phoenix6.sim.DeviceType;
import com.ctre.phoenix6.sim.CANcoderSimState;
import com.ctre.phoenix6.*;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;
import edu.wpi.first.units.*;
import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Class for CANcoder, a CAN based magnetic encoder that provides absolute and
 * relative position along with filtered velocity.
 * 
 * <pre>
 * // Constants used in CANcoder construction
 * final int kCANcoderId = 0;
 * final CANBus kCANcoderCANbus = new CANBus("canivore");
 * 
 * // Construct the CANcoder
 * final CANcoder cancoder = new CANcoder(kCANcoderId, kCANcoderCANbus);
 * 
 * // Configure the CANcoder for basic use
 * CANcoderConfiguration configs = new CANcoderConfiguration();
 * // This CANcoder should report absolute position from [-0.5, 0.5) rotations,
 * // with a 0.26 rotation offset, with clockwise being positive
 * configs.MagnetSensor.AbsoluteSensorRange = AbsoluteSensorRange.Signed_PlusMinusHalf;
 * configs.MountPose.MagnetOffset = 0.26;
 * configs.MountPose.SensorDirection = SensorDirectionValue.Clockwise_Positive;
 * 
 * // Write these configs to the CANcoder
 * cancoder.getConfigurator().apply(configs);
 * 
 * // Set the position to 0 rotations for initial use
 * cancoder.setPosition(0);
 * 
 * // Get Position and Velocity
 * var position = cancoder.getPosition();
 * var velocity = cancoder.getVelocity();
 * 
 * // Refresh and print these values
 * System.out.println("Position is " + position.refresh().toString());
 * System.out.println("Velocity is " + velocity.refresh().toString());
 * </pre>
 */
public class CoreCANcoder extends ParentDevice
{
    private CANcoderConfigurator _configurator;

    /**
     * Constructs a new CANcoder object.
     * <p>
     * Constructs the device using the default CAN bus for the system
     * (see {@link CANBus#CANBus()}).
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     */
    public CoreCANcoder(int deviceId)
    {
        this(deviceId, new CANBus());
    }

    /**
     * Constructs a new CANcoder object.
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     * @param canbus      Name of the CAN bus this device is on. Possible CAN bus strings are:
     *                    <ul>
     *                      <li>"rio" for the native roboRIO CAN bus
     *                      <li>CANivore name or serial number
     *                      <li>SocketCAN interface (non-FRC Linux only)
     *                      <li>"*" for any CANivore seen by the program
     *                      <li>empty string (default) to select the default for the system:
     *                      <ul>
     *                        <li>"rio" on roboRIO
     *                        <li>"can0" on Linux
     *                        <li>"*" on Windows
     *                      </ul>
     *                    </ul>
     *
     * @deprecated Constructing devices with a CAN bus string is deprecated for removal
     * in the 2027 season. Construct devices using a {@link CANBus} instance instead.
     */
    @Deprecated(since = "2026", forRemoval = true)
    public CoreCANcoder(int deviceId, String canbus)
    {
        this(deviceId, new CANBus(canbus));
    }

    /**
     * Constructs a new CANcoder object.
     *
     * @param deviceId    ID of the device, as configured in Phoenix Tuner
     * @param canbus      The CAN bus this device is on
     */
    public CoreCANcoder(int deviceId, CANBus canbus)
    {
        super(deviceId, "cancoder", canbus);
        _configurator = new CANcoderConfigurator(this.deviceIdentifier);
        PlatformJNI.JNI_SimCreate(DeviceType.P6_CANcoderType.value, deviceId);
    }

    /**
     * Gets the configurator to use with this device's configs
     *
     * @return Configurator for this object
     */
    public final CANcoderConfigurator getConfigurator()
    {
        return this._configurator;
    }


    private CANcoderSimState _simState = null;
    /**
     * Get the simulation state for this device.
     * <p>
     * This function reuses an allocated simulation state
     * object, so it is safe to call this function multiple
     * times in a robot loop.
     *
     * @return Simulation state
     */
    public final CANcoderSimState getSimState() {
        if (_simState == null)
            _simState = new CANcoderSimState(this);
        return _simState;
    }


        
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMajor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMajor()
    {
        return getVersionMajor(true);
    }
    
    /**
     * App Major Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMajor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMajor(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Major.value, "VersionMajor", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionMinor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMinor()
    {
        return getVersionMinor(true);
    }
    
    /**
     * App Minor Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionMinor Status Signal Object
     */
    public final StatusSignal<Integer> getVersionMinor(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Minor.value, "VersionMinor", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBugfix Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBugfix()
    {
        return getVersionBugfix(true);
    }
    
    /**
     * App Bugfix Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBugfix Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBugfix(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Bugfix.value, "VersionBugfix", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return VersionBuild Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBuild()
    {
        return getVersionBuild(true);
    }
    
    /**
     * App Build Version number.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 255
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return VersionBuild Status Signal Object
     */
    public final StatusSignal<Integer> getVersionBuild(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Build.value, "VersionBuild", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Version Status Signal Object
     */
    public final StatusSignal<Integer> getVersion()
    {
        return getVersion(true);
    }
    
    /**
     * Full Version of firmware in device.  The format is a four byte
     * value.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Version Status Signal Object
     */
    public final StatusSignal<Integer> getVersion(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_Full.value, "Version", Integer.class, val -> (int)val, false, refresh);
        return retval;
    }
        
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return FaultField Status Signal Object
     */
    public final StatusSignal<Integer> getFaultField()
    {
        return getFaultField(true);
    }
    
    /**
     * Integer representing all fault flags reported by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetFault_*() methods instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return FaultField Status Signal Object
     */
    public final StatusSignal<Integer> getFaultField(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.AllFaults.value, "FaultField", Integer.class, val -> (int)val, true, refresh);
        return retval;
    }
        
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFaultField Status Signal Object
     */
    public final StatusSignal<Integer> getStickyFaultField()
    {
        return getStickyFaultField(true);
    }
    
    /**
     * Integer representing all (persistent) sticky fault flags reported
     * by the device.
     * <p>
     * These are device specific and are not used directly in typical
     * applications. Use the signal specific GetStickyFault_*() methods
     * instead.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 4294967295
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFaultField Status Signal Object
     */
    public final StatusSignal<Integer> getStickyFaultField(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.AllStickyFaults.value, "StickyFaultField", Integer.class, val -> (int)val, true, refresh);
        return retval;
    }
        
    /**
     * Velocity of the device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Velocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getVelocity()
    {
        return getVelocity(true);
    }
    
    /**
     * Velocity of the device.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -512.0
     *   <li> <b>Maximum Value:</b> 511.998046875
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Velocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getVelocity(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANcoder_Velocity.value, "Velocity", AngularVelocity.class, val -> RotationsPerSecond.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Position of the device. This is initialized to the absolute
     * position on boot.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Position Status Signal Object
     */
    public final StatusSignal<Angle> getPosition()
    {
        return getPosition(true);
    }
    
    /**
     * Position of the device. This is initialized to the absolute
     * position on boot.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Position Status Signal Object
     */
    public final StatusSignal<Angle> getPosition(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANcoder_Position.value, "Position", Angle.class, val -> Rotations.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Absolute Position of the device. The possible range is documented
     * below; however, the exact expected range is determined by the
     * AbsoluteSensorDiscontinuityPoint. This position is only affected by
     * the MagnetSensor configs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0
     *   <li> <b>Maximum Value:</b> 0.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return AbsolutePosition Status Signal Object
     */
    public final StatusSignal<Angle> getAbsolutePosition()
    {
        return getAbsolutePosition(true);
    }
    
    /**
     * Absolute Position of the device. The possible range is documented
     * below; however, the exact expected range is determined by the
     * AbsoluteSensorDiscontinuityPoint. This position is only affected by
     * the MagnetSensor configs.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1.0
     *   <li> <b>Maximum Value:</b> 0.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 100.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return AbsolutePosition Status Signal Object
     */
    public final StatusSignal<Angle> getAbsolutePosition(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANcoder_AbsPosition.value, "AbsolutePosition", Angle.class, val -> Rotations.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The unfiltered velocity reported by CANcoder.
     * <p>
     * This is the unfiltered velocity reported by CANcoder. This signal
     * does not use the fusing algorithm.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -8000.0
     *   <li> <b>Maximum Value:</b> 7999.755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return UnfilteredVelocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getUnfilteredVelocity()
    {
        return getUnfilteredVelocity(true);
    }
    
    /**
     * The unfiltered velocity reported by CANcoder.
     * <p>
     * This is the unfiltered velocity reported by CANcoder. This signal
     * does not use the fusing algorithm.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -8000.0
     *   <li> <b>Maximum Value:</b> 7999.755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations per second
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return UnfilteredVelocity Status Signal Object
     */
    public final StatusSignal<AngularVelocity> getUnfilteredVelocity(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANCoder_RawVel.value, "UnfilteredVelocity", AngularVelocity.class, val -> RotationsPerSecond.of(val), true, refresh);
        return retval;
    }
        
    /**
     * The relative position reported by the CANcoder since boot.
     * <p>
     * This is the total displacement reported by CANcoder since power up.
     * This signal is relative and is not influenced by the fusing
     * algorithm.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return PositionSinceBoot Status Signal Object
     */
    public final StatusSignal<Angle> getPositionSinceBoot()
    {
        return getPositionSinceBoot(true);
    }
    
    /**
     * The relative position reported by the CANcoder since boot.
     * <p>
     * This is the total displacement reported by CANcoder since power up.
     * This signal is relative and is not influenced by the fusing
     * algorithm.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -16384.0
     *   <li> <b>Maximum Value:</b> 16383.999755859375
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return PositionSinceBoot Status Signal Object
     */
    public final StatusSignal<Angle> getPositionSinceBoot(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANCoder_RawPos.value, "PositionSinceBoot", Angle.class, val -> Rotations.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Measured supply voltage to the CANcoder.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 4
     *   <li> <b>Maximum Value:</b> 16.75
     *   <li> <b>Default Value:</b> 4
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return SupplyVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getSupplyVoltage()
    {
        return getSupplyVoltage(true);
    }
    
    /**
     * Measured supply voltage to the CANcoder.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 4
     *   <li> <b>Maximum Value:</b> 16.75
     *   <li> <b>Default Value:</b> 4
     *   <li> <b>Units:</b> V
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return SupplyVoltage Status Signal Object
     */
    public final StatusSignal<Voltage> getSupplyVoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANCoder_SupplyVoltage.value, "SupplyVoltage", Voltage.class, val -> Volts.of(val), true, refresh);
        return retval;
    }
        
    /**
     * Magnet health as measured by CANcoder.
     * <p>
     * Red indicates too close or too far, Orange is adequate but with
     * reduced accuracy, green is ideal. Invalid means the accuracy cannot
     * be determined.
     * 
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return MagnetHealth Status Signal Object
     */
    public final StatusSignal<MagnetHealthValue> getMagnetHealth()
    {
        return getMagnetHealth(true);
    }
    
    /**
     * Magnet health as measured by CANcoder.
     * <p>
     * Red indicates too close or too far, Orange is adequate but with
     * reduced accuracy, green is ideal. Invalid means the accuracy cannot
     * be determined.
     * 
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN 2.0:</b> 4.0 Hz
     *   <li> <b>CAN FD:</b> 100.0 Hz (TimeSynced with Pro)
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return MagnetHealth Status Signal Object
     */
    public final StatusSignal<MagnetHealthValue> getMagnetHealth(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.CANcoder_MagHealth.value, "MagnetHealth", MagnetHealthValue.class, val -> MagnetHealthValue.valueOf((int)val), true, refresh);
        return retval;
    }
        
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return IsProLicensed Status Signal Object
     */
    public final StatusSignal<Boolean> getIsProLicensed()
    {
        return getIsProLicensed(true);
    }
    
    /**
     * Whether the device is Phoenix Pro licensed.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return IsProLicensed Status Signal Object
     */
    public final StatusSignal<Boolean> getIsProLicensed(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Version_IsProLicensed.value, "IsProLicensed", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Hardware()
    {
        return getFault_Hardware(true);
    }
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Hardware(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_Hardware.value, "Fault_Hardware", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Hardware()
    {
        return getStickyFault_Hardware(true);
    }
    
    /**
     * Hardware fault occurred
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Hardware Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Hardware(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_Hardware.value, "StickyFault_Hardware", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Undervoltage()
    {
        return getFault_Undervoltage(true);
    }
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_Undervoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_Undervoltage.value, "Fault_Undervoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Undervoltage()
    {
        return getStickyFault_Undervoltage(true);
    }
    
    /**
     * Device supply voltage dropped to near brownout levels
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_Undervoltage Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_Undervoltage(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_Undervoltage.value, "StickyFault_Undervoltage", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootDuringEnable()
    {
        return getFault_BootDuringEnable(true);
    }
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BootDuringEnable(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_BootDuringEnable.value, "Fault_BootDuringEnable", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootDuringEnable()
    {
        return getStickyFault_BootDuringEnable(true);
    }
    
    /**
     * Device boot while detecting the enable signal
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BootDuringEnable Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BootDuringEnable(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_BootDuringEnable.value, "StickyFault_BootDuringEnable", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_UnlicensedFeatureInUse()
    {
        return getFault_UnlicensedFeatureInUse(true);
    }
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_UnlicensedFeatureInUse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_UnlicensedFeatureInUse.value, "Fault_UnlicensedFeatureInUse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse()
    {
        return getStickyFault_UnlicensedFeatureInUse(true);
    }
    
    /**
     * An unlicensed feature is in use, device may not behave as expected.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_UnlicensedFeatureInUse Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_UnlicensedFeatureInUse(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_UnlicensedFeatureInUse.value, "StickyFault_UnlicensedFeatureInUse", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * The magnet distance is not correct or magnet is missing
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return Fault_BadMagnet Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BadMagnet()
    {
        return getFault_BadMagnet(true);
    }
    
    /**
     * The magnet distance is not correct or magnet is missing
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return Fault_BadMagnet Status Signal Object
     */
    public final StatusSignal<Boolean> getFault_BadMagnet(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.Fault_CANCODER_BadMagnet.value, "Fault_BadMagnet", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }
        
    /**
     * The magnet distance is not correct or magnet is missing
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @return StickyFault_BadMagnet Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BadMagnet()
    {
        return getStickyFault_BadMagnet(true);
    }
    
    /**
     * The magnet distance is not correct or magnet is missing
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     * 
     * Default Rates:
     * <ul>
     *   <li> <b>CAN:</b> 4.0 Hz
     * </ul>
     * <p>
     * This refreshes and returns a cached StatusSignal object.
     * 
     * @param refresh Whether to refresh the StatusSignal before returning it;
     *                defaults to true
     * @return StickyFault_BadMagnet Status Signal Object
     */
    public final StatusSignal<Boolean> getStickyFault_BadMagnet(boolean refresh)
    {
        @SuppressWarnings("unchecked")
        var retval = super.lookupStatusSignal(SpnValue.StickyFault_CANCODER_BadMagnet.value, "StickyFault_BadMagnet", Boolean.class, val -> val != 0, true, refresh);
        return retval;
    }

    

    /**
     * Control device with generic control request object.
     * <p>
     * User must make sure the specified object is castable to a valid control request,
     * otherwise this function will fail at run-time and return the NotSupported StatusCode
     *
     * @param request Control object to request of the device
     * @return Status Code of the request, 0 is OK
     */
    public final StatusCode setControl(ControlRequest request)
    {
        
        return StatusCode.NotSupported;
    }

    
    /**
     * Sets the current position of the device.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(double newValue) {
        return setPosition(newValue, 0.100);
    }
    /**
     * Sets the current position of the device.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(double newValue, double timeoutSeconds) {
        return getConfigurator().setPosition(newValue, timeoutSeconds);
    }
    
    /**
     * Sets the current position of the device.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(Angle newValue) {
        return setPosition(newValue.in(Rotations));
    }
    /**
     * Sets the current position of the device.
     * 
     * @param newValue Value to set to. Units are in rotations.
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode setPosition(Angle newValue, double timeoutSeconds) {
        return setPosition(newValue.in(Rotations), timeoutSeconds);
    }
    
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults() {
        return clearStickyFaults(0.100);
    }
    /**
     * Clear the sticky faults in the device.
     * <p>
     * This typically has no impact on the device functionality.  Instead,
     * it just clears telemetry faults that are accessible via API and
     * Tuner Self-Test.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFaults(double timeoutSeconds) {
        return getConfigurator().clearStickyFaults(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Hardware fault occurred
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware() {
        return clearStickyFault_Hardware(0.100);
    }
    /**
     * Clear sticky fault: Hardware fault occurred
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Hardware(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Hardware(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage() {
        return clearStickyFault_Undervoltage(0.100);
    }
    /**
     * Clear sticky fault: Device supply voltage dropped to near brownout
     * levels
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_Undervoltage(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_Undervoltage(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable() {
        return clearStickyFault_BootDuringEnable(0.100);
    }
    /**
     * Clear sticky fault: Device boot while detecting the enable signal
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BootDuringEnable(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_BootDuringEnable(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse() {
        return clearStickyFault_UnlicensedFeatureInUse(0.100);
    }
    /**
     * Clear sticky fault: An unlicensed feature is in use, device may not
     * behave as expected.
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_UnlicensedFeatureInUse(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_UnlicensedFeatureInUse(timeoutSeconds);
    }
    
    /**
     * Clear sticky fault: The magnet distance is not correct or magnet is
     * missing
     * <p>
     * This will wait up to 0.100 seconds (100ms) by default.
     * 
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BadMagnet() {
        return clearStickyFault_BadMagnet(0.100);
    }
    /**
     * Clear sticky fault: The magnet distance is not correct or magnet is
     * missing
     * 
     * @param timeoutSeconds Maximum time to wait up to in seconds.
     * @return StatusCode of the set command
     */
    public final StatusCode clearStickyFault_BadMagnet(double timeoutSeconds) {
        return getConfigurator().clearStickyFault_BadMagnet(timeoutSeconds);
    }
}

