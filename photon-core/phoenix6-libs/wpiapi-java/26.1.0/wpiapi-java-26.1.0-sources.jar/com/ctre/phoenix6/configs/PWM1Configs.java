/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs related to the CANdi™ branded device's PWM interface on the
 * Signal 1 input (S1IN)
 * <p>
 * All the configs related to the PWM interface for the CANdi™ branded
 * device on S1, including absolute sensor offset, absolute sensor
 * discontinuity point and sensor direction.
 */
public class PWM1Configs implements ParentConfiguration, Cloneable {
    /**
     * The offset applied to the PWM sensor. This offset is added to the
     * reported sensor position.
     * <p>
     * This can be used to zero the sensor position in applications where
     * the sensor is 1:1 with the mechanism.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double AbsoluteSensorOffset = 0.0;
    /**
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double AbsoluteSensorDiscontinuityPoint = 0.5;
    /**
     * Direction of the PWM sensor to determine positive rotation. Invert
     * this so that forward motion on the mechanism results in an increase
     * in PWM position.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean SensorDirection = false;
    
    /**
     * Modifies this configuration's AbsoluteSensorOffset parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The offset applied to the PWM sensor. This offset is added to the
     * reported sensor position.
     * <p>
     * This can be used to zero the sensor position in applications where
     * the sensor is 1:1 with the mechanism.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newAbsoluteSensorOffset Parameter to modify
     * @return Itself
     */
    public final PWM1Configs withAbsoluteSensorOffset(double newAbsoluteSensorOffset)
    {
        AbsoluteSensorOffset = newAbsoluteSensorOffset;
        return this;
    }
    
    /**
     * Modifies this configuration's AbsoluteSensorOffset parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The offset applied to the PWM sensor. This offset is added to the
     * reported sensor position.
     * <p>
     * This can be used to zero the sensor position in applications where
     * the sensor is 1:1 with the mechanism.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newAbsoluteSensorOffset Parameter to modify
     * @return Itself
     */
    public final PWM1Configs withAbsoluteSensorOffset(Angle newAbsoluteSensorOffset)
    {
        AbsoluteSensorOffset = newAbsoluteSensorOffset.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's AbsoluteSensorOffset parameter converted
     * to a unit type. If not using the Java units library, {@link #AbsoluteSensorOffset}
     * can be accessed directly instead.
     * <p>
     * The offset applied to the PWM sensor. This offset is added to the
     * reported sensor position.
     * <p>
     * This can be used to zero the sensor position in applications where
     * the sensor is 1:1 with the mechanism.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return AbsoluteSensorOffset
     */
    public final Angle getAbsoluteSensorOffsetMeasure()
    {
        return Rotations.of(AbsoluteSensorOffset);
    }
    
    /**
     * Modifies this configuration's AbsoluteSensorDiscontinuityPoint parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newAbsoluteSensorDiscontinuityPoint Parameter to modify
     * @return Itself
     */
    public final PWM1Configs withAbsoluteSensorDiscontinuityPoint(double newAbsoluteSensorDiscontinuityPoint)
    {
        AbsoluteSensorDiscontinuityPoint = newAbsoluteSensorDiscontinuityPoint;
        return this;
    }
    
    /**
     * Modifies this configuration's AbsoluteSensorDiscontinuityPoint parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newAbsoluteSensorDiscontinuityPoint Parameter to modify
     * @return Itself
     */
    public final PWM1Configs withAbsoluteSensorDiscontinuityPoint(Angle newAbsoluteSensorDiscontinuityPoint)
    {
        AbsoluteSensorDiscontinuityPoint = newAbsoluteSensorDiscontinuityPoint.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's AbsoluteSensorDiscontinuityPoint parameter converted
     * to a unit type. If not using the Java units library, {@link #AbsoluteSensorDiscontinuityPoint}
     * can be accessed directly instead.
     * <p>
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return AbsoluteSensorDiscontinuityPoint
     */
    public final Angle getAbsoluteSensorDiscontinuityPointMeasure()
    {
        return Rotations.of(AbsoluteSensorDiscontinuityPoint);
    }
    
    /**
     * Modifies this configuration's SensorDirection parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Direction of the PWM sensor to determine positive rotation. Invert
     * this so that forward motion on the mechanism results in an increase
     * in PWM position.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newSensorDirection Parameter to modify
     * @return Itself
     */
    public final PWM1Configs withSensorDirection(boolean newSensorDirection)
    {
        SensorDirection = newSensorDirection;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: PWM1\n";
        ss += "    AbsoluteSensorOffset: " + AbsoluteSensorOffset + " rotations" + "\n";
        ss += "    AbsoluteSensorDiscontinuityPoint: " + AbsoluteSensorDiscontinuityPoint + " rotations" + "\n";
        ss += "    SensorDirection: " + SensorDirection + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_PWM1_AbsoluteSensorOffset.value, AbsoluteSensorOffset);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_PWM1_AbsoluteSensorDiscontinuityPoint.value, AbsoluteSensorDiscontinuityPoint);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_PWM1_SensorDirection.value, SensorDirection);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        AbsoluteSensorOffset = ConfigJNI.Deserializedouble(SpnValue.Config_PWM1_AbsoluteSensorOffset.value, to_deserialize);
        AbsoluteSensorDiscontinuityPoint = ConfigJNI.Deserializedouble(SpnValue.Config_PWM1_AbsoluteSensorDiscontinuityPoint.value, to_deserialize);
        SensorDirection = ConfigJNI.Deserializeboolean(SpnValue.Config_PWM1_SensorDirection.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public PWM1Configs clone() {
        try {
            return (PWM1Configs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

