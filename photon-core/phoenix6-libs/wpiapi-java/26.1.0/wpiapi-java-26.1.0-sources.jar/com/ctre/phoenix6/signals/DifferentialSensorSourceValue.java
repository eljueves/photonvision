/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * Choose what sensor source is used for differential control of a mechanism. 
 * The default is Disabled.  All other options require setting the
 * DifferentialTalonFXSensorID, as the average of this Talon FX's sensor and the
 * remote TalonFX's sensor is used for the differential controller's primary
 * targets.
 * <p>
 * Choose RemoteTalonFX_HalfDiff to use another TalonFX on the same CAN bus. 
 * Talon FX will update its differential position and velocity whenever the
 * remote TalonFX publishes its information on CAN bus.  The differential
 * controller will use half of the difference between this TalonFX's sensor and
 * the remote Talon FX's sensor for the differential component of the output.
 * <p>
 * Choose RemotePigeon2Yaw, RemotePigeon2Pitch, and RemotePigeon2Roll to use
 * another Pigeon2 on the same CAN bus (this also requires setting
 * DifferentialRemoteSensorID).  Talon FX will update its differential position
 * to match the selected value whenever Pigeon2 publishes its information on CAN
 * bus. Note that the Talon FX differential position will be in rotations and
 * not degrees.
 * <p>
 * Choose RemoteCANcoder to use another CANcoder on the same CAN bus (this also
 * requires setting DifferentialRemoteSensorID).  Talon FX will update its
 * differential position and velocity to match the CANcoder whenever CANcoder
 * publishes its information on CAN bus.
 */
public enum DifferentialSensorSourceValue
{
    /**
     * Disable differential control.
     */
    Disabled(0),
    /**
     * Use another TalonFX on the same CAN bus.  Talon FX will update its
     * differential position and velocity whenever the remote TalonFX publishes its
     * information on CAN bus.  The differential controller will use half of the
     * difference between this TalonFX's sensor and the remote Talon FX's sensor for
     * the differential component of the output.
     */
    RemoteTalonFX_HalfDiff(1),
    /**
     * Use another Pigeon2 on the same CAN bus (this also requires setting
     * DifferentialRemoteSensorID).  Talon FX will update its differential position
     * to match the Pigeon2 yaw whenever Pigeon2 publishes its information on CAN
     * bus. Note that the Talon FX differential position will be in rotations and
     * not degrees.
     */
    RemotePigeon2Yaw(2),
    /**
     * Use another Pigeon2 on the same CAN bus (this also requires setting
     * DifferentialRemoteSensorID).  Talon FX will update its differential position
     * to match the Pigeon2 pitch whenever Pigeon2 publishes its information on CAN
     * bus. Note that the Talon FX differential position will be in rotations and
     * not degrees.
     */
    RemotePigeon2Pitch(3),
    /**
     * Use another Pigeon2 on the same CAN bus (this also requires setting
     * DifferentialRemoteSensorID).  Talon FX will update its differential position
     * to match the Pigeon2 roll whenever Pigeon2 publishes its information on CAN
     * bus. Note that the Talon FX differential position will be in rotations and
     * not degrees.
     */
    RemotePigeon2Roll(4),
    /**
     * Use another CANcoder on the same CAN bus (this also requires setting
     * DifferentialRemoteSensorID).  Talon FX will update its differential position
     * and velocity to match the CANcoder whenever CANcoder publishes its
     * information on CAN bus.
     */
    RemoteCANcoder(5),
    /**
     * Use a pulse-width encoder remotely attached to the Sensor Input 1 (S1IN) on
     * the CTR Electronics' CANdi™ (this also requires setting the
     * DifferentialRemoteSensorID).  Talon FX will update its differential position
     * and velocity to match the CTR Electronics' CANdi™ whenever the CTR
     * Electronics' CANdi™ publishes its information on CAN bus.
     */
    RemoteCANdiPWM1(6),
    /**
     * Use a pulse-width encoder remotely attached to the Sensor Input 2 (S2IN) on
     * the CTR Electronics' CANdi™ (this also requires setting the
     * DifferentialRemoteSensorID).  Talon FX will update its differential position
     * and velocity to match the CTR Electronics' CANdi™ whenever the CTR
     * Electronics' CANdi™ publishes its information on CAN bus.
     */
    RemoteCANdiPWM2(7),
    /**
     * Use a quadrature encoder remotely attached to the two Sensor Inputs on the
     * CTR Electronics' CANdi™ (this also requires setting the
     * DifferentialRemoteSensorID).  Talon FX will update its differential position
     * and velocity to match the CTR Electronics' CANdi™ whenever the CTR
     * Electronics' CANdi™ publishes its information on CAN bus.
     */
    RemoteCANdiQuadrature(8),;

    public final int value;

    DifferentialSensorSourceValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, DifferentialSensorSourceValue> _map = null;
    static
    {
        _map = new HashMap<Integer, DifferentialSensorSourceValue>();
        for (DifferentialSensorSourceValue type : DifferentialSensorSourceValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets DifferentialSensorSourceValue from specified value
     * @param value Value of DifferentialSensorSourceValue
     * @return DifferentialSensorSourceValue of specified value
     */
    public static DifferentialSensorSourceValue valueOf(int value)
    {
        DifferentialSensorSourceValue retval = _map.get(value);
        if (retval != null) return retval;
        return DifferentialSensorSourceValue.values()[0];
    }
}
