/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.jni;

public class OrchestraJNI extends CtreJniWrapper {
    public int id = 0; // initialize with an invalid ID

    public native int JNI_Create();
    public native int JNI_Close();

    public native int JNI_AddDevice(String network, long deviceHash);
    public native int JNI_AddDeviceWithTrack(String network, long deviceHash, int trackNum);
    public native int JNI_ClearDevices();

    public native int JNI_LoadMusic(String filepath);

    public native int JNI_Play();
    public native int JNI_Pause();
    public native int JNI_Stop();

    public native boolean JNI_IsPlaying();
    public native double JNI_GetCurrentTime();
}
