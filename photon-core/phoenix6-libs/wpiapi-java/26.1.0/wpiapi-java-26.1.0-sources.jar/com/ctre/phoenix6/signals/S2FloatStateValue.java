/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The floating state of the Signal 2 input (S2IN).
 */
public enum S2FloatStateValue
{
    /**
     * The input will attempt to detect when it is floating. This is enabled by
     * default.
     */
    FloatDetect(0),
    /**
     * The input will be pulled high when not loaded by an outside device. This is
     * useful for NPN-style devices.
     */
    PullHigh(1),
    /**
     * The input will be pulled low when not loaded by an outside device. This is
     * useful for PNP-style devices.
     */
    PullLow(2),
    /**
     * The input will pull in the direction of the last measured state. This may be
     * useful for devices that can enter into a high-Z tri-state.
     */
    BusKeeper(3),;

    public final int value;

    S2FloatStateValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, S2FloatStateValue> _map = null;
    static
    {
        _map = new HashMap<Integer, S2FloatStateValue>();
        for (S2FloatStateValue type : S2FloatStateValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets S2FloatStateValue from specified value
     * @param value Value of S2FloatStateValue
     * @return S2FloatStateValue of specified value
     */
    public static S2FloatStateValue valueOf(int value)
    {
        S2FloatStateValue retval = _map.get(value);
        if (retval != null) return retval;
        return S2FloatStateValue.values()[0];
    }
}
