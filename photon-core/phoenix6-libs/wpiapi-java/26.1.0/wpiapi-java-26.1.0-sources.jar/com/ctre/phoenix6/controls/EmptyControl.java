/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.controls;

import java.util.HashMap;
import java.util.Map;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.controls.jni.ControlJNI;

import edu.wpi.first.units.measure.*;

/**
 * Generic Empty Control class used to do nothing.
 */
public final class EmptyControl implements ControlRequest, Cloneable {
    /**
     * Constructs an empty control request.
     */
    public EmptyControl() {
    }

    /**
     * Gets the name of this control request.
     *
     * @return Name of the control request
     */
    @Override
    public String getName() {
        return "EmptyControl";
    }

    @Override
    public String toString() {
        String ss = "class: EmptyControl\n";
        return ss;
    }

    @Override
    public StatusCode sendRequest(String network, int deviceHash) {
        return StatusCode.valueOf(ControlJNI.JNI_RequestControlEmpty(
                network, deviceHash, 0));
    }

    /**
     * Gets information about this control request.
     *
     * @return Map of control parameter names and corresponding applied values
     */
    @Override
    public Map<String, String> getControlInfo() {
        var controlInfo = new HashMap<String,String>();
        controlInfo.put("Name", getName());
        return controlInfo;
    }

    @Override
    public EmptyControl withUpdateFreqHz(double newUpdateFreqHz) {
        return this;
    }

    @Override
    public EmptyControl withUpdateFreqHz(Frequency newUpdateFreqHz) {
        return this;
    }

    @Override
    public EmptyControl clone() {
        return new EmptyControl();
    }
};
