/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;
import com.ctre.phoenix6.hardware.traits.CommonTalon;
import com.ctre.phoenix6.hardware.core.CoreCANcoder;
import com.ctre.phoenix6.hardware.core.CoreCANrange;
import com.ctre.phoenix6.hardware.core.CoreCANdi;

/**
 * Configs that change how the motor controller behaves under
 * different limit switch states.
 * <p>
 * Includes configs such as enabling limit switches, configuring the
 * remote sensor ID, the source, and the position to set on limit.
 */
public class HardwareLimitSwitchConfigs implements ParentConfiguration, Cloneable {
    /**
     * Determines if the forward limit switch is normally-open (default)
     * or normally-closed.
     * 
     */
    public ForwardLimitTypeValue ForwardLimitType = ForwardLimitTypeValue.NormallyOpen;
    /**
     * If enabled, the position is automatically set to a specific value,
     * specified by ForwardLimitAutosetPositionValue, when the forward
     * limit switch is asserted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean ForwardLimitAutosetPositionEnable = false;
    /**
     * The value to automatically set the position to when the forward
     * limit switch is asserted.  This has no effect if
     * ForwardLimitAutosetPositionEnable is false.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double ForwardLimitAutosetPositionValue = 0;
    /**
     * If enabled, motor output is set to neutral when the forward limit
     * switch is asserted and positive output is requested.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     */
    public boolean ForwardLimitEnable = true;
    /**
     * Determines where to poll the forward limit switch.  This defaults
     * to the forward limit switch pin on the limit switch connector.
     * <p>
     * Choose RemoteTalonFX to use the forward limit switch attached to
     * another Talon FX on the same CAN bus (this also requires setting
     * ForwardLimitRemoteSensorID).
     * <p>
     * Choose RemoteCANifier to use the forward limit switch attached to
     * another CANifier on the same CAN bus (this also requires setting
     * ForwardLimitRemoteSensorID).
     * <p>
     * Choose RemoteCANcoder to use another CANcoder on the same CAN bus
     * (this also requires setting ForwardLimitRemoteSensorID).  The
     * forward limit will assert when the CANcoder magnet strength changes
     * from BAD (red) to ADEQUATE (orange) or GOOD (green).
     * 
     */
    public ForwardLimitSourceValue ForwardLimitSource = ForwardLimitSourceValue.LimitSwitchPin;
    /**
     * Device ID of the remote device if using remote limit switch
     * features for the forward limit switch.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int ForwardLimitRemoteSensorID = 0;
    /**
     * Determines if the reverse limit switch is normally-open (default)
     * or normally-closed.
     * 
     */
    public ReverseLimitTypeValue ReverseLimitType = ReverseLimitTypeValue.NormallyOpen;
    /**
     * If enabled, the position is automatically set to a specific value,
     * specified by ReverseLimitAutosetPositionValue, when the reverse
     * limit switch is asserted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     */
    public boolean ReverseLimitAutosetPositionEnable = false;
    /**
     * The value to automatically set the position to when the reverse
     * limit switch is asserted.  This has no effect if
     * ReverseLimitAutosetPositionEnable is false.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double ReverseLimitAutosetPositionValue = 0;
    /**
     * If enabled, motor output is set to neutral when reverse limit
     * switch is asseted and negative output is requested.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     */
    public boolean ReverseLimitEnable = true;
    /**
     * Determines where to poll the reverse limit switch.  This defaults
     * to the reverse limit switch pin on the limit switch connector.
     * <p>
     * Choose RemoteTalonFX to use the reverse limit switch attached to
     * another Talon FX on the same CAN bus (this also requires setting
     * ReverseLimitRemoteSensorID).
     * <p>
     * Choose RemoteCANifier to use the reverse limit switch attached to
     * another CANifier on the same CAN bus (this also requires setting
     * ReverseLimitRemoteSensorID).
     * <p>
     * Choose RemoteCANcoder to use another CANcoder on the same CAN bus
     * (this also requires setting ReverseLimitRemoteSensorID).  The
     * reverse limit will assert when the CANcoder magnet strength changes
     * from BAD (red) to ADEQUATE (orange) or GOOD (green).
     * 
     */
    public ReverseLimitSourceValue ReverseLimitSource = ReverseLimitSourceValue.LimitSwitchPin;
    /**
     * Device ID of the remote device if using remote limit switch
     * features for the reverse limit switch.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int ReverseLimitRemoteSensorID = 0;
    
    /**
     * Modifies this configuration's ForwardLimitType parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Determines if the forward limit switch is normally-open (default)
     * or normally-closed.
     * 
     *
     * @param newForwardLimitType Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitType(ForwardLimitTypeValue newForwardLimitType)
    {
        ForwardLimitType = newForwardLimitType;
        return this;
    }
    
    /**
     * Modifies this configuration's ForwardLimitAutosetPositionEnable parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If enabled, the position is automatically set to a specific value,
     * specified by ForwardLimitAutosetPositionValue, when the forward
     * limit switch is asserted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newForwardLimitAutosetPositionEnable Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitAutosetPositionEnable(boolean newForwardLimitAutosetPositionEnable)
    {
        ForwardLimitAutosetPositionEnable = newForwardLimitAutosetPositionEnable;
        return this;
    }
    
    /**
     * Modifies this configuration's ForwardLimitAutosetPositionValue parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The value to automatically set the position to when the forward
     * limit switch is asserted.  This has no effect if
     * ForwardLimitAutosetPositionEnable is false.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newForwardLimitAutosetPositionValue Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitAutosetPositionValue(double newForwardLimitAutosetPositionValue)
    {
        ForwardLimitAutosetPositionValue = newForwardLimitAutosetPositionValue;
        return this;
    }
    
    /**
     * Modifies this configuration's ForwardLimitAutosetPositionValue parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The value to automatically set the position to when the forward
     * limit switch is asserted.  This has no effect if
     * ForwardLimitAutosetPositionEnable is false.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newForwardLimitAutosetPositionValue Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitAutosetPositionValue(Angle newForwardLimitAutosetPositionValue)
    {
        ForwardLimitAutosetPositionValue = newForwardLimitAutosetPositionValue.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's ForwardLimitAutosetPositionValue parameter converted
     * to a unit type. If not using the Java units library, {@link #ForwardLimitAutosetPositionValue}
     * can be accessed directly instead.
     * <p>
     * The value to automatically set the position to when the forward
     * limit switch is asserted.  This has no effect if
     * ForwardLimitAutosetPositionEnable is false.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return ForwardLimitAutosetPositionValue
     */
    public final Angle getForwardLimitAutosetPositionValueMeasure()
    {
        return Rotations.of(ForwardLimitAutosetPositionValue);
    }
    
    /**
     * Modifies this configuration's ForwardLimitEnable parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If enabled, motor output is set to neutral when the forward limit
     * switch is asserted and positive output is requested.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     *
     * @param newForwardLimitEnable Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitEnable(boolean newForwardLimitEnable)
    {
        ForwardLimitEnable = newForwardLimitEnable;
        return this;
    }
    
    /**
     * Modifies this configuration's ForwardLimitSource parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Determines where to poll the forward limit switch.  This defaults
     * to the forward limit switch pin on the limit switch connector.
     * <p>
     * Choose RemoteTalonFX to use the forward limit switch attached to
     * another Talon FX on the same CAN bus (this also requires setting
     * ForwardLimitRemoteSensorID).
     * <p>
     * Choose RemoteCANifier to use the forward limit switch attached to
     * another CANifier on the same CAN bus (this also requires setting
     * ForwardLimitRemoteSensorID).
     * <p>
     * Choose RemoteCANcoder to use another CANcoder on the same CAN bus
     * (this also requires setting ForwardLimitRemoteSensorID).  The
     * forward limit will assert when the CANcoder magnet strength changes
     * from BAD (red) to ADEQUATE (orange) or GOOD (green).
     * 
     *
     * @param newForwardLimitSource Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitSource(ForwardLimitSourceValue newForwardLimitSource)
    {
        ForwardLimitSource = newForwardLimitSource;
        return this;
    }
    
    /**
     * Modifies this configuration's ForwardLimitRemoteSensorID parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Device ID of the remote device if using remote limit switch
     * features for the forward limit switch.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newForwardLimitRemoteSensorID Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitRemoteSensorID(int newForwardLimitRemoteSensorID)
    {
        ForwardLimitRemoteSensorID = newForwardLimitRemoteSensorID;
        return this;
    }
    
    /**
     * Modifies this configuration's ReverseLimitType parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Determines if the reverse limit switch is normally-open (default)
     * or normally-closed.
     * 
     *
     * @param newReverseLimitType Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitType(ReverseLimitTypeValue newReverseLimitType)
    {
        ReverseLimitType = newReverseLimitType;
        return this;
    }
    
    /**
     * Modifies this configuration's ReverseLimitAutosetPositionEnable parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If enabled, the position is automatically set to a specific value,
     * specified by ReverseLimitAutosetPositionValue, when the reverse
     * limit switch is asserted.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> False
     * </ul>
     *
     * @param newReverseLimitAutosetPositionEnable Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitAutosetPositionEnable(boolean newReverseLimitAutosetPositionEnable)
    {
        ReverseLimitAutosetPositionEnable = newReverseLimitAutosetPositionEnable;
        return this;
    }
    
    /**
     * Modifies this configuration's ReverseLimitAutosetPositionValue parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The value to automatically set the position to when the reverse
     * limit switch is asserted.  This has no effect if
     * ReverseLimitAutosetPositionEnable is false.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newReverseLimitAutosetPositionValue Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitAutosetPositionValue(double newReverseLimitAutosetPositionValue)
    {
        ReverseLimitAutosetPositionValue = newReverseLimitAutosetPositionValue;
        return this;
    }
    
    /**
     * Modifies this configuration's ReverseLimitAutosetPositionValue parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The value to automatically set the position to when the reverse
     * limit switch is asserted.  This has no effect if
     * ReverseLimitAutosetPositionEnable is false.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newReverseLimitAutosetPositionValue Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitAutosetPositionValue(Angle newReverseLimitAutosetPositionValue)
    {
        ReverseLimitAutosetPositionValue = newReverseLimitAutosetPositionValue.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's ReverseLimitAutosetPositionValue parameter converted
     * to a unit type. If not using the Java units library, {@link #ReverseLimitAutosetPositionValue}
     * can be accessed directly instead.
     * <p>
     * The value to automatically set the position to when the reverse
     * limit switch is asserted.  This has no effect if
     * ReverseLimitAutosetPositionEnable is false.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -3.4e+38
     *   <li> <b>Maximum Value:</b> 3.4e+38
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return ReverseLimitAutosetPositionValue
     */
    public final Angle getReverseLimitAutosetPositionValueMeasure()
    {
        return Rotations.of(ReverseLimitAutosetPositionValue);
    }
    
    /**
     * Modifies this configuration's ReverseLimitEnable parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If enabled, motor output is set to neutral when reverse limit
     * switch is asseted and negative output is requested.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     *
     * @param newReverseLimitEnable Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitEnable(boolean newReverseLimitEnable)
    {
        ReverseLimitEnable = newReverseLimitEnable;
        return this;
    }
    
    /**
     * Modifies this configuration's ReverseLimitSource parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Determines where to poll the reverse limit switch.  This defaults
     * to the reverse limit switch pin on the limit switch connector.
     * <p>
     * Choose RemoteTalonFX to use the reverse limit switch attached to
     * another Talon FX on the same CAN bus (this also requires setting
     * ReverseLimitRemoteSensorID).
     * <p>
     * Choose RemoteCANifier to use the reverse limit switch attached to
     * another CANifier on the same CAN bus (this also requires setting
     * ReverseLimitRemoteSensorID).
     * <p>
     * Choose RemoteCANcoder to use another CANcoder on the same CAN bus
     * (this also requires setting ReverseLimitRemoteSensorID).  The
     * reverse limit will assert when the CANcoder magnet strength changes
     * from BAD (red) to ADEQUATE (orange) or GOOD (green).
     * 
     *
     * @param newReverseLimitSource Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitSource(ReverseLimitSourceValue newReverseLimitSource)
    {
        ReverseLimitSource = newReverseLimitSource;
        return this;
    }
    
    /**
     * Modifies this configuration's ReverseLimitRemoteSensorID parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Device ID of the remote device if using remote limit switch
     * features for the reverse limit switch.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newReverseLimitRemoteSensorID Parameter to modify
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitRemoteSensorID(int newReverseLimitRemoteSensorID)
    {
        ReverseLimitRemoteSensorID = newReverseLimitRemoteSensorID;
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteTalonFX
     * forward limit switch by passing in the CommonTalon object. When
     * using RemoteTalonFX, the Talon FX will use the forward limit switch
     * attached to another Talon FX on the same CAN bus.
     * 
     * @param device CommonTalon reference to use for RemoteTalonFX forward limit
     *               switch
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitRemoteTalonFX(CommonTalon device)
    {
        ForwardLimitSource = ForwardLimitSourceValue.RemoteTalonFX;
        ForwardLimitRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use
     * RemoteCANcoder forward limit switch by passing in the CANcoder
     * object. When using RemoteCANcoder, the Talon FX will use another
     * CANcoder on the same CAN bus. The forward limit will assert when
     * the CANcoder magnet strength changes from BAD (red) to ADEQUATE
     * (orange) or GOOD (green).
     * 
     * @param device CANcoder reference to use for RemoteCANcoder forward limit
     *               switch
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitRemoteCANcoder(CoreCANcoder device)
    {
        ForwardLimitSource = ForwardLimitSourceValue.RemoteCANcoder;
        ForwardLimitRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use the
     * RemoteCANrange by passing in the CANrange object. The forward limit
     * will assert when the CANrange proximity detect is tripped.
     * 
     * @param device CANrange reference to use for RemoteCANrange forward limit
     *               switch
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitRemoteCANrange(CoreCANrange device)
    {
        ForwardLimitSource = ForwardLimitSourceValue.RemoteCANrange;
        ForwardLimitRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteCANdi
     * forward limit switch on Signal 1 Input (S1IN) by passing in the
     * CANdi object. The forward limit will assert when the CANdi™ branded
     * device's Signal 1 Input (S1IN) pin matches the configured closed
     * state.
     * 
     * @param device CANdi reference to use for RemoteCANdi forward limit switch
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitRemoteCANdiS1(CoreCANdi device)
    {
        ForwardLimitSource = ForwardLimitSourceValue.RemoteCANdiS1;
        ForwardLimitRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteCANdi
     * forward limit switch on Signal 2 Input (S2IN) by passing in the
     * CANdi object. The forward limit will assert when the CANdi™ branded
     * device's Signal 2 Input (S2IN) pin matches the configured closed
     * state.
     * 
     * @param device CANdi reference to use for RemoteCANdi forward limit switch
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withForwardLimitRemoteCANdiS2(CoreCANdi device)
    {
        ForwardLimitSource = ForwardLimitSourceValue.RemoteCANdiS2;
        ForwardLimitRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteTalonFX
     * reverse limit switch by passing in the CommonTalon object. When
     * using RemoteTalonFX, the Talon FX will use the reverse limit switch
     * attached to another Talon FX on the same CAN bus.
     * 
     * @param device CommonTalon reference to use for RemoteTalonFX reverse limit
     *               switch
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitRemoteTalonFX(CommonTalon device)
    {
        ReverseLimitSource = ReverseLimitSourceValue.RemoteTalonFX;
        ReverseLimitRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use
     * RemoteCANcoder reverse limit switch by passing in the CANcoder
     * object. When using RemoteCANcoder, the Talon FX will use another
     * CANcoder on the same CAN bus. The reverse limit will assert when
     * the CANcoder magnet strength changes from BAD (red) to ADEQUATE
     * (orange) or GOOD (green).
     * 
     * @param device CANcoder reference to use for RemoteCANcoder reverse limit
     *               switch
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitRemoteCANcoder(CoreCANcoder device)
    {
        ReverseLimitSource = ReverseLimitSourceValue.RemoteCANcoder;
        ReverseLimitRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use the
     * RemoteCANrange by passing in the CANrange object. The reverse limit
     * will assert when the CANrange proximity detect is tripped.
     * 
     * @param device CANrange reference to use for RemoteCANrange reverse limit
     *               switch
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitRemoteCANrange(CoreCANrange device)
    {
        ReverseLimitSource = ReverseLimitSourceValue.RemoteCANrange;
        ReverseLimitRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteCANdi
     * reverse limit switch on Signal 1 Input (S1IN) by passing in the
     * CANdi object. The reverse limit will assert when the CANdi™ branded
     * device's Signal 1 Input (S1IN) pin matches the configured closed
     * state.
     * 
     * @param device CANdi reference to use for RemoteCANdi reverse limit switch
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitRemoteCANdiS1(CoreCANdi device)
    {
        ReverseLimitSource = ReverseLimitSourceValue.RemoteCANdiS1;
        ReverseLimitRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteCANdi
     * reverse limit switch on Signal 2 Input (S2IN) by passing in the
     * CANdi object. The reverse limit will assert when the CANdi™ branded
     * device's Signal 2 Input (S2IN) pin matches the configured closed
     * state.
     * 
     * @param device CANdi reference to use for RemoteCANdi reverse limit switch
     * @return Itself
     */
    public final HardwareLimitSwitchConfigs withReverseLimitRemoteCANdiS2(CoreCANdi device)
    {
        ReverseLimitSource = ReverseLimitSourceValue.RemoteCANdiS2;
        ReverseLimitRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    

    @Override
    public String toString() {
        String ss = "Config Group: HardwareLimitSwitch\n";
        ss += "    ForwardLimitType: " + ForwardLimitType + "\n";
        ss += "    ForwardLimitAutosetPositionEnable: " + ForwardLimitAutosetPositionEnable + "\n";
        ss += "    ForwardLimitAutosetPositionValue: " + ForwardLimitAutosetPositionValue + " rotations" + "\n";
        ss += "    ForwardLimitEnable: " + ForwardLimitEnable + "\n";
        ss += "    ForwardLimitSource: " + ForwardLimitSource + "\n";
        ss += "    ForwardLimitRemoteSensorID: " + ForwardLimitRemoteSensorID + "\n";
        ss += "    ReverseLimitType: " + ReverseLimitType + "\n";
        ss += "    ReverseLimitAutosetPositionEnable: " + ReverseLimitAutosetPositionEnable + "\n";
        ss += "    ReverseLimitAutosetPositionValue: " + ReverseLimitAutosetPositionValue + " rotations" + "\n";
        ss += "    ReverseLimitEnable: " + ReverseLimitEnable + "\n";
        ss += "    ReverseLimitSource: " + ReverseLimitSource + "\n";
        ss += "    ReverseLimitRemoteSensorID: " + ReverseLimitRemoteSensorID + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeint(SpnValue.Config_ForwardLimitType.value, ForwardLimitType.value);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_ForwardLimitAutosetPosEnable.value, ForwardLimitAutosetPositionEnable);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_ForwardLimitAutosetPosValue.value, ForwardLimitAutosetPositionValue);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_ForwardLimitEnable.value, ForwardLimitEnable);
        ss += ConfigJNI.Serializeint(SpnValue.Config_ForwardLimitSource.value, ForwardLimitSource.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_ForwardLimitRemoteSensorID.value, ForwardLimitRemoteSensorID);
        ss += ConfigJNI.Serializeint(SpnValue.Config_ReverseLimitType.value, ReverseLimitType.value);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_ReverseLimitAutosetPosEnable.value, ReverseLimitAutosetPositionEnable);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_ReverseLimitAutosetPosValue.value, ReverseLimitAutosetPositionValue);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_ReverseLimitEnable.value, ReverseLimitEnable);
        ss += ConfigJNI.Serializeint(SpnValue.Config_ReverseLimitSource.value, ReverseLimitSource.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_ReverseLimitRemoteSensorID.value, ReverseLimitRemoteSensorID);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        ForwardLimitType = ForwardLimitTypeValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_ForwardLimitType.value, to_deserialize));
        ForwardLimitAutosetPositionEnable = ConfigJNI.Deserializeboolean(SpnValue.Config_ForwardLimitAutosetPosEnable.value, to_deserialize);
        ForwardLimitAutosetPositionValue = ConfigJNI.Deserializedouble(SpnValue.Config_ForwardLimitAutosetPosValue.value, to_deserialize);
        ForwardLimitEnable = ConfigJNI.Deserializeboolean(SpnValue.Config_ForwardLimitEnable.value, to_deserialize);
        ForwardLimitSource = ForwardLimitSourceValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_ForwardLimitSource.value, to_deserialize));
        ForwardLimitRemoteSensorID = ConfigJNI.Deserializeint(SpnValue.Config_ForwardLimitRemoteSensorID.value, to_deserialize);
        ReverseLimitType = ReverseLimitTypeValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_ReverseLimitType.value, to_deserialize));
        ReverseLimitAutosetPositionEnable = ConfigJNI.Deserializeboolean(SpnValue.Config_ReverseLimitAutosetPosEnable.value, to_deserialize);
        ReverseLimitAutosetPositionValue = ConfigJNI.Deserializedouble(SpnValue.Config_ReverseLimitAutosetPosValue.value, to_deserialize);
        ReverseLimitEnable = ConfigJNI.Deserializeboolean(SpnValue.Config_ReverseLimitEnable.value, to_deserialize);
        ReverseLimitSource = ReverseLimitSourceValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_ReverseLimitSource.value, to_deserialize));
        ReverseLimitRemoteSensorID = ConfigJNI.Deserializeint(SpnValue.Config_ReverseLimitRemoteSensorID.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public HardwareLimitSwitchConfigs clone() {
        try {
            return (HardwareLimitSwitchConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

