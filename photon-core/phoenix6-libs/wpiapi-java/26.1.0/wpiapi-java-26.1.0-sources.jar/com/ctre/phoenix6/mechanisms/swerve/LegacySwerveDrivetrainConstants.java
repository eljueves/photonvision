/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.mechanisms.swerve;

import com.ctre.phoenix6.configs.Pigeon2Configuration;

/**
 * Common constants for a swerve drivetrain.
 */
public class LegacySwerveDrivetrainConstants {
    /**
     * Name of the CAN bus the swerve drive is on.
     * Possible CAN bus strings are:
     * <ul>
     *   <li>"rio" for the native roboRIO CAN bus
     *   <li>CANivore name or serial number
     *   <li>"*" for any CANivore seen by the program
     * </ul>
     */
    public String CANbusName = "rio";
    /** CAN ID of the Pigeon2 on the drivetrain. */
    public int Pigeon2Id = 0;
    /**
     * The Pigeon2 configuration object to apply to
     * the Pigeon2. This defaults to null. If this remains
     * null, then the Pigeon2 will not be configured
     * (and whatever configs are on it remain on it).
     * If this is non-null, the Pigeon2 will be
     * overwritten with these configs.
     */
    public Pigeon2Configuration Pigeon2Configs = null;

    /**
     * Sets the name of the CAN bus the swerve drive is on.
     * Possible CAN bus strings are:
     * <ul>
     *   <li>"rio" for the native roboRIO CAN bus
     *   <li>CANivore name or serial number
     *   <li>"*" for any CANivore seen by the program
     * </ul>
     *
     * @param name Name of the CAN bus the swerve drive is on
     * @return this object
     */
    public LegacySwerveDrivetrainConstants withCANbusName(String name) {
        this.CANbusName = name;
        return this;
    }

    /**
     * Sets the CAN ID of the Pigeon2 on the drivetrain.
     *
     * @param id CAN ID of the Pigeon2 on the drivetrain
     * @return this object
     */
    public LegacySwerveDrivetrainConstants withPigeon2Id(int id) {
        this.Pigeon2Id = id;
        return this;
    }

    /**
     * The Pigeon2 configuration object to apply to
     * the Pigeon2. This defaults to null. If this remains
     * null, then the Pigeon2 will not be configured
     * (and whatever configs are on it remain on it).
     * If this is non-null, the Pigeon2 will be
     * overwritten with these configs.
     *
     * @param configs The configs to apply to the Pigeon2
     * @return this object
     */
    public LegacySwerveDrivetrainConstants withPigeon2Configs(Pigeon2Configuration configs) {
        this.Pigeon2Configs = configs;
        return this;
    }
}
