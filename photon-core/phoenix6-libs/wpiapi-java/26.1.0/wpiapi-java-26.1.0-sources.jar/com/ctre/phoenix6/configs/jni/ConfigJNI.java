/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs.jni;

import com.ctre.phoenix6.jni.CtreJniWrapper;

public class ConfigJNI extends CtreJniWrapper {
    public String serializedString = ""; // don't let this be null

    public native int SetConfigs(String network, int deviceHash, double timeoutSeconds, boolean futureProofConfigs,
            boolean overrideIfDuplicate);

    public native int GetConfigs(String network, int deviceHash, double timeoutSeconds);

    public static native String Serializedouble(int spn, double val);

    public static native String Serializeint(int spn, int val);

    public static native String Serializeboolean(int spn, boolean val);

    public static native double Deserializedouble(int spn, String str);

    public static native int Deserializeint(int spn, String str);

    public static native boolean Deserializeboolean(int spn, String str);
}
