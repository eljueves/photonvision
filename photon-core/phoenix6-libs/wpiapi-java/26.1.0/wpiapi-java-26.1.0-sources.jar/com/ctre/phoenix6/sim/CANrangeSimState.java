/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.sim;

import static edu.wpi.first.units.Units.*;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.hardware.core.CoreCANrange;
import com.ctre.phoenix6.hardware.CANrange;
import com.ctre.phoenix6.jni.PlatformJNI;

import edu.wpi.first.units.measure.*;

/**
 * Class to control the state of a simulated {@link CANrange}.
 */
public class CANrangeSimState {
    private static final DeviceType kDevType = DeviceType.P6_CANrangeType;

    private final int _id;

    /**
     * Creates an object to control the state of the given {@link CANrange}.
     * <p>
     * Note the recommended method of accessing simulation features is to use
     * {@link CANrange#getSimState}.
     *
     * @param device Device to which this simulation state is attached
     */
    public CANrangeSimState(CoreCANrange device) {
        _id = device.getDeviceID();
    }

    /**
     * Sets the simulated supply voltage of the CANrange.
     * <p>
     * The minimum allowed supply voltage is 4 V - values below this
     * will be promoted to 4 V.
     *
     * @param volts The supply voltage in Volts
     * @return Status code
     */
    public final StatusCode setSupplyVoltage(double volts) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "SupplyVoltage", volts));
    }
    /**
     * Sets the simulated supply voltage of the CANrange.
     * <p>
     * The minimum allowed supply voltage is 4 V - values below this
     * will be promoted to 4 V.
     *
     * @param voltage The supply voltage
     * @return Status code
     */
    public final StatusCode setSupplyVoltage(Voltage voltage) {
        return setSupplyVoltage(voltage.in(Volts));
    }

    /**
     * Sets the simulated distance of the CANrange.
     *
     * @param meters The distance in meters
     * @return Status code
     */
    public final StatusCode setDistance(double meters) {
        return StatusCode.valueOf(PlatformJNI.JNI_SimSetPhysicsInput(kDevType.value, _id, "Distance", meters));
    }
    /**
     * Sets the simulated distance of the CANrange.
     *
     * @param distance The distance
     * @return Status code
     */
    public final StatusCode setDistance(Distance distance) {
        return setDistance(distance.in(Meters));
    }
}
