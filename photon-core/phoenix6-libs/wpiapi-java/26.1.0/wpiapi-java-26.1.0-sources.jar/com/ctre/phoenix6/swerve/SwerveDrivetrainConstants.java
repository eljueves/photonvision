/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.swerve;

import com.ctre.phoenix6.configs.Pigeon2Configuration;
import com.ctre.phoenix6.swerve.jni.SwerveJNI;

/**
 * Common constants for a swerve drivetrain.
 */
public class SwerveDrivetrainConstants {
    /**
     * Name of the CAN bus the swerve drive is on. Possible CAN bus strings are:
     * 
     * <ul>
     *   <li> "rio" for the native roboRIO CAN bus
     *   <li> CANivore name or serial number
     *   <li> SocketCAN interface (non-FRC Linux only)
     *   <li> "*" for any CANivore seen by the program
     *   <li> empty string (default) to select the default for the system:
     *   <ul>
     *     <li> "rio" on roboRIO
     *     <li> "can0" on Linux
     *     <li> "*" on Windows
     *   </ul>
     * </ul>
     * 
     * Note that all devices must be on the same CAN bus.
     */
    public String CANBusName = "";
    /**
     * CAN ID of the Pigeon2 on the drivetrain.
     */
    public int Pigeon2Id = 0;
    /**
     * The configuration object to apply to the Pigeon2. This defaults to null. If
     * this remains null, then the Pigeon2 will not be configured (and whatever
     * configs are on it remain on it). If this is not null, the Pigeon2 will be
     * overwritten with these configs.
     */
    public Pigeon2Configuration Pigeon2Configs = null;
    
    /**
     * Modifies the CANBusName parameter and returns itself.
     * <p>
     * Name of the CAN bus the swerve drive is on. Possible CAN bus strings are:
     * 
     * <ul>
     *   <li> "rio" for the native roboRIO CAN bus
     *   <li> CANivore name or serial number
     *   <li> SocketCAN interface (non-FRC Linux only)
     *   <li> "*" for any CANivore seen by the program
     *   <li> empty string (default) to select the default for the system:
     *   <ul>
     *     <li> "rio" on roboRIO
     *     <li> "can0" on Linux
     *     <li> "*" on Windows
     *   </ul>
     * </ul>
     * 
     * Note that all devices must be on the same CAN bus.
     *
     * @param newCANBusName Parameter to modify
     * @return this object
     */
    public SwerveDrivetrainConstants withCANBusName(String newCANBusName) {
        this.CANBusName = newCANBusName;
        return this;
    }
    
    /**
     * Modifies the Pigeon2Id parameter and returns itself.
     * <p>
     * CAN ID of the Pigeon2 on the drivetrain.
     *
     * @param newPigeon2Id Parameter to modify
     * @return this object
     */
    public SwerveDrivetrainConstants withPigeon2Id(int newPigeon2Id) {
        this.Pigeon2Id = newPigeon2Id;
        return this;
    }
    
    /**
     * Modifies the Pigeon2Configs parameter and returns itself.
     * <p>
     * The configuration object to apply to the Pigeon2. This defaults to null. If
     * this remains null, then the Pigeon2 will not be configured (and whatever
     * configs are on it remain on it). If this is not null, the Pigeon2 will be
     * overwritten with these configs.
     *
     * @param newPigeon2Configs Parameter to modify
     * @return this object
     */
    public SwerveDrivetrainConstants withPigeon2Configs(Pigeon2Configuration newPigeon2Configs) {
        this.Pigeon2Configs = newPigeon2Configs;
        return this;
    }
    
    final long createNativeInstance() {
        return SwerveJNI.JNI_CreateDrivetrainConstants(
            CANBusName,
            Pigeon2Id
        );
    }
}
