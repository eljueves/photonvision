/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs that directly affect current limiting features.
 * <p>
 * Contains the supply/stator current limit thresholds and whether to
 * enable them.
 */
public class CurrentLimitsConfigs implements ParentConfiguration, Cloneable {
    /**
     * The amount of current allowed in the motor (motoring and regen
     * current).  Note this requires StatorCurrentLimitEnable to be true.
     * <p>
     * For torque current control, this is applied in addition to the
     * PeakForwardTorqueCurrent and PeakReverseTorqueCurrent in
     * TorqueCurrentConfigs.
     * <p>
     * Stator current is directly proportional to torque, so this limit
     * can be used to restrict the torque output of the motor, such as
     * preventing wheel slip for a drivetrain.  Additionally, stator
     * current limits can prevent brownouts during acceleration; supply
     * current will never exceed the stator current limit and is often
     * significantly lower than stator current.
     * <p>
     * A reasonable starting point for a stator current limit is 120 A,
     * with values commonly ranging from 80-160 A. Mechanisms with a hard
     * stop may need a smaller limit to reduce the torque applied when
     * running into the hard stop.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800.0
     *   <li> <b>Default Value:</b> 120
     *   <li> <b>Units:</b> A
     * </ul>
     */
    public double StatorCurrentLimit = 120;
    /**
     * Enable motor stator current limiting.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     */
    public boolean StatorCurrentLimitEnable = true;
    /**
     * The absolute maximum amount of supply current allowed.  Note this
     * requires SupplyCurrentLimitEnable to be true.  Use
     * SupplyCurrentLowerLimit and SupplyCurrentLowerTime to reduce the
     * supply current limit after the time threshold is exceeded.
     * <p>
     * Supply current is the current drawn from the battery, so this limit
     * can be used to prevent breaker trips and improve battery longevity.
     *  Additionally, in scenarios where the robot experiences brownouts
     * despite configuring stator current limits, a supply current limit
     * can further help avoid brownouts. However, it is important to note
     * that such brownouts may be caused by a bad battery or poor power
     * wiring.
     * <p>
     * A reasonable starting point for a supply current limit is 70 A with
     * a lower limit of 40 A after 1.0 second. Supply current limits
     * commonly range from 20-80 A depending on the breaker used.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800.0
     *   <li> <b>Default Value:</b> 70
     *   <li> <b>Units:</b> A
     * </ul>
     */
    public double SupplyCurrentLimit = 70;
    /**
     * Enable motor supply current limiting.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     */
    public boolean SupplyCurrentLimitEnable = true;
    /**
     * The amount of supply current allowed after the regular
     * SupplyCurrentLimit is active for longer than
     * SupplyCurrentLowerTime.  This allows higher current draws for a
     * fixed period of time before reducing the current limit to protect
     * breakers.  This has no effect if SupplyCurrentLimit is lower than
     * this value or SupplyCurrentLowerTime is 0.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 500
     *   <li> <b>Default Value:</b> 40
     *   <li> <b>Units:</b> A
     * </ul>
     */
    public double SupplyCurrentLowerLimit = 40;
    /**
     * Reduces supply current to the SupplyCurrentLowerLimit after
     * limiting to SupplyCurrentLimit for this period of time.  If this is
     * set to 0, SupplyCurrentLowerLimit will be ignored.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 5.0
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> seconds
     * </ul>
     */
    public double SupplyCurrentLowerTime = 1.0;
    
    /**
     * Modifies this configuration's StatorCurrentLimit parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The amount of current allowed in the motor (motoring and regen
     * current).  Note this requires StatorCurrentLimitEnable to be true.
     * <p>
     * For torque current control, this is applied in addition to the
     * PeakForwardTorqueCurrent and PeakReverseTorqueCurrent in
     * TorqueCurrentConfigs.
     * <p>
     * Stator current is directly proportional to torque, so this limit
     * can be used to restrict the torque output of the motor, such as
     * preventing wheel slip for a drivetrain.  Additionally, stator
     * current limits can prevent brownouts during acceleration; supply
     * current will never exceed the stator current limit and is often
     * significantly lower than stator current.
     * <p>
     * A reasonable starting point for a stator current limit is 120 A,
     * with values commonly ranging from 80-160 A. Mechanisms with a hard
     * stop may need a smaller limit to reduce the torque applied when
     * running into the hard stop.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800.0
     *   <li> <b>Default Value:</b> 120
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newStatorCurrentLimit Parameter to modify
     * @return Itself
     */
    public final CurrentLimitsConfigs withStatorCurrentLimit(double newStatorCurrentLimit)
    {
        StatorCurrentLimit = newStatorCurrentLimit;
        return this;
    }
    
    /**
     * Modifies this configuration's StatorCurrentLimit parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The amount of current allowed in the motor (motoring and regen
     * current).  Note this requires StatorCurrentLimitEnable to be true.
     * <p>
     * For torque current control, this is applied in addition to the
     * PeakForwardTorqueCurrent and PeakReverseTorqueCurrent in
     * TorqueCurrentConfigs.
     * <p>
     * Stator current is directly proportional to torque, so this limit
     * can be used to restrict the torque output of the motor, such as
     * preventing wheel slip for a drivetrain.  Additionally, stator
     * current limits can prevent brownouts during acceleration; supply
     * current will never exceed the stator current limit and is often
     * significantly lower than stator current.
     * <p>
     * A reasonable starting point for a stator current limit is 120 A,
     * with values commonly ranging from 80-160 A. Mechanisms with a hard
     * stop may need a smaller limit to reduce the torque applied when
     * running into the hard stop.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800.0
     *   <li> <b>Default Value:</b> 120
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newStatorCurrentLimit Parameter to modify
     * @return Itself
     */
    public final CurrentLimitsConfigs withStatorCurrentLimit(Current newStatorCurrentLimit)
    {
        StatorCurrentLimit = newStatorCurrentLimit.in(Amps);
        return this;
    }
    
    /**
     * Helper method to get this configuration's StatorCurrentLimit parameter converted
     * to a unit type. If not using the Java units library, {@link #StatorCurrentLimit}
     * can be accessed directly instead.
     * <p>
     * The amount of current allowed in the motor (motoring and regen
     * current).  Note this requires StatorCurrentLimitEnable to be true.
     * <p>
     * For torque current control, this is applied in addition to the
     * PeakForwardTorqueCurrent and PeakReverseTorqueCurrent in
     * TorqueCurrentConfigs.
     * <p>
     * Stator current is directly proportional to torque, so this limit
     * can be used to restrict the torque output of the motor, such as
     * preventing wheel slip for a drivetrain.  Additionally, stator
     * current limits can prevent brownouts during acceleration; supply
     * current will never exceed the stator current limit and is often
     * significantly lower than stator current.
     * <p>
     * A reasonable starting point for a stator current limit is 120 A,
     * with values commonly ranging from 80-160 A. Mechanisms with a hard
     * stop may need a smaller limit to reduce the torque applied when
     * running into the hard stop.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800.0
     *   <li> <b>Default Value:</b> 120
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @return StatorCurrentLimit
     */
    public final Current getStatorCurrentLimitMeasure()
    {
        return Amps.of(StatorCurrentLimit);
    }
    
    /**
     * Modifies this configuration's StatorCurrentLimitEnable parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Enable motor stator current limiting.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     *
     * @param newStatorCurrentLimitEnable Parameter to modify
     * @return Itself
     */
    public final CurrentLimitsConfigs withStatorCurrentLimitEnable(boolean newStatorCurrentLimitEnable)
    {
        StatorCurrentLimitEnable = newStatorCurrentLimitEnable;
        return this;
    }
    
    /**
     * Modifies this configuration's SupplyCurrentLimit parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The absolute maximum amount of supply current allowed.  Note this
     * requires SupplyCurrentLimitEnable to be true.  Use
     * SupplyCurrentLowerLimit and SupplyCurrentLowerTime to reduce the
     * supply current limit after the time threshold is exceeded.
     * <p>
     * Supply current is the current drawn from the battery, so this limit
     * can be used to prevent breaker trips and improve battery longevity.
     *  Additionally, in scenarios where the robot experiences brownouts
     * despite configuring stator current limits, a supply current limit
     * can further help avoid brownouts. However, it is important to note
     * that such brownouts may be caused by a bad battery or poor power
     * wiring.
     * <p>
     * A reasonable starting point for a supply current limit is 70 A with
     * a lower limit of 40 A after 1.0 second. Supply current limits
     * commonly range from 20-80 A depending on the breaker used.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800.0
     *   <li> <b>Default Value:</b> 70
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newSupplyCurrentLimit Parameter to modify
     * @return Itself
     */
    public final CurrentLimitsConfigs withSupplyCurrentLimit(double newSupplyCurrentLimit)
    {
        SupplyCurrentLimit = newSupplyCurrentLimit;
        return this;
    }
    
    /**
     * Modifies this configuration's SupplyCurrentLimit parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The absolute maximum amount of supply current allowed.  Note this
     * requires SupplyCurrentLimitEnable to be true.  Use
     * SupplyCurrentLowerLimit and SupplyCurrentLowerTime to reduce the
     * supply current limit after the time threshold is exceeded.
     * <p>
     * Supply current is the current drawn from the battery, so this limit
     * can be used to prevent breaker trips and improve battery longevity.
     *  Additionally, in scenarios where the robot experiences brownouts
     * despite configuring stator current limits, a supply current limit
     * can further help avoid brownouts. However, it is important to note
     * that such brownouts may be caused by a bad battery or poor power
     * wiring.
     * <p>
     * A reasonable starting point for a supply current limit is 70 A with
     * a lower limit of 40 A after 1.0 second. Supply current limits
     * commonly range from 20-80 A depending on the breaker used.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800.0
     *   <li> <b>Default Value:</b> 70
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newSupplyCurrentLimit Parameter to modify
     * @return Itself
     */
    public final CurrentLimitsConfigs withSupplyCurrentLimit(Current newSupplyCurrentLimit)
    {
        SupplyCurrentLimit = newSupplyCurrentLimit.in(Amps);
        return this;
    }
    
    /**
     * Helper method to get this configuration's SupplyCurrentLimit parameter converted
     * to a unit type. If not using the Java units library, {@link #SupplyCurrentLimit}
     * can be accessed directly instead.
     * <p>
     * The absolute maximum amount of supply current allowed.  Note this
     * requires SupplyCurrentLimitEnable to be true.  Use
     * SupplyCurrentLowerLimit and SupplyCurrentLowerTime to reduce the
     * supply current limit after the time threshold is exceeded.
     * <p>
     * Supply current is the current drawn from the battery, so this limit
     * can be used to prevent breaker trips and improve battery longevity.
     *  Additionally, in scenarios where the robot experiences brownouts
     * despite configuring stator current limits, a supply current limit
     * can further help avoid brownouts. However, it is important to note
     * that such brownouts may be caused by a bad battery or poor power
     * wiring.
     * <p>
     * A reasonable starting point for a supply current limit is 70 A with
     * a lower limit of 40 A after 1.0 second. Supply current limits
     * commonly range from 20-80 A depending on the breaker used.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 800.0
     *   <li> <b>Default Value:</b> 70
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @return SupplyCurrentLimit
     */
    public final Current getSupplyCurrentLimitMeasure()
    {
        return Amps.of(SupplyCurrentLimit);
    }
    
    /**
     * Modifies this configuration's SupplyCurrentLimitEnable parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Enable motor supply current limiting.
     * 
     * <ul>
     *   <li> <b>Default Value:</b> True
     * </ul>
     *
     * @param newSupplyCurrentLimitEnable Parameter to modify
     * @return Itself
     */
    public final CurrentLimitsConfigs withSupplyCurrentLimitEnable(boolean newSupplyCurrentLimitEnable)
    {
        SupplyCurrentLimitEnable = newSupplyCurrentLimitEnable;
        return this;
    }
    
    /**
     * Modifies this configuration's SupplyCurrentLowerLimit parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The amount of supply current allowed after the regular
     * SupplyCurrentLimit is active for longer than
     * SupplyCurrentLowerTime.  This allows higher current draws for a
     * fixed period of time before reducing the current limit to protect
     * breakers.  This has no effect if SupplyCurrentLimit is lower than
     * this value or SupplyCurrentLowerTime is 0.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 500
     *   <li> <b>Default Value:</b> 40
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newSupplyCurrentLowerLimit Parameter to modify
     * @return Itself
     */
    public final CurrentLimitsConfigs withSupplyCurrentLowerLimit(double newSupplyCurrentLowerLimit)
    {
        SupplyCurrentLowerLimit = newSupplyCurrentLowerLimit;
        return this;
    }
    
    /**
     * Modifies this configuration's SupplyCurrentLowerLimit parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The amount of supply current allowed after the regular
     * SupplyCurrentLimit is active for longer than
     * SupplyCurrentLowerTime.  This allows higher current draws for a
     * fixed period of time before reducing the current limit to protect
     * breakers.  This has no effect if SupplyCurrentLimit is lower than
     * this value or SupplyCurrentLowerTime is 0.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 500
     *   <li> <b>Default Value:</b> 40
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @param newSupplyCurrentLowerLimit Parameter to modify
     * @return Itself
     */
    public final CurrentLimitsConfigs withSupplyCurrentLowerLimit(Current newSupplyCurrentLowerLimit)
    {
        SupplyCurrentLowerLimit = newSupplyCurrentLowerLimit.in(Amps);
        return this;
    }
    
    /**
     * Helper method to get this configuration's SupplyCurrentLowerLimit parameter converted
     * to a unit type. If not using the Java units library, {@link #SupplyCurrentLowerLimit}
     * can be accessed directly instead.
     * <p>
     * The amount of supply current allowed after the regular
     * SupplyCurrentLimit is active for longer than
     * SupplyCurrentLowerTime.  This allows higher current draws for a
     * fixed period of time before reducing the current limit to protect
     * breakers.  This has no effect if SupplyCurrentLimit is lower than
     * this value or SupplyCurrentLowerTime is 0.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 500
     *   <li> <b>Default Value:</b> 40
     *   <li> <b>Units:</b> A
     * </ul>
     *
     * @return SupplyCurrentLowerLimit
     */
    public final Current getSupplyCurrentLowerLimitMeasure()
    {
        return Amps.of(SupplyCurrentLowerLimit);
    }
    
    /**
     * Modifies this configuration's SupplyCurrentLowerTime parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Reduces supply current to the SupplyCurrentLowerLimit after
     * limiting to SupplyCurrentLimit for this period of time.  If this is
     * set to 0, SupplyCurrentLowerLimit will be ignored.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 5.0
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newSupplyCurrentLowerTime Parameter to modify
     * @return Itself
     */
    public final CurrentLimitsConfigs withSupplyCurrentLowerTime(double newSupplyCurrentLowerTime)
    {
        SupplyCurrentLowerTime = newSupplyCurrentLowerTime;
        return this;
    }
    
    /**
     * Modifies this configuration's SupplyCurrentLowerTime parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Reduces supply current to the SupplyCurrentLowerLimit after
     * limiting to SupplyCurrentLimit for this period of time.  If this is
     * set to 0, SupplyCurrentLowerLimit will be ignored.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 5.0
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newSupplyCurrentLowerTime Parameter to modify
     * @return Itself
     */
    public final CurrentLimitsConfigs withSupplyCurrentLowerTime(Time newSupplyCurrentLowerTime)
    {
        SupplyCurrentLowerTime = newSupplyCurrentLowerTime.in(Seconds);
        return this;
    }
    
    /**
     * Helper method to get this configuration's SupplyCurrentLowerTime parameter converted
     * to a unit type. If not using the Java units library, {@link #SupplyCurrentLowerTime}
     * can be accessed directly instead.
     * <p>
     * Reduces supply current to the SupplyCurrentLowerLimit after
     * limiting to SupplyCurrentLimit for this period of time.  If this is
     * set to 0, SupplyCurrentLowerLimit will be ignored.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 5.0
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @return SupplyCurrentLowerTime
     */
    public final Time getSupplyCurrentLowerTimeMeasure()
    {
        return Seconds.of(SupplyCurrentLowerTime);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: CurrentLimits\n";
        ss += "    StatorCurrentLimit: " + StatorCurrentLimit + " A" + "\n";
        ss += "    StatorCurrentLimitEnable: " + StatorCurrentLimitEnable + "\n";
        ss += "    SupplyCurrentLimit: " + SupplyCurrentLimit + " A" + "\n";
        ss += "    SupplyCurrentLimitEnable: " + SupplyCurrentLimitEnable + "\n";
        ss += "    SupplyCurrentLowerLimit: " + SupplyCurrentLowerLimit + " A" + "\n";
        ss += "    SupplyCurrentLowerTime: " + SupplyCurrentLowerTime + " seconds" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_StatorCurrentLimit.value, StatorCurrentLimit);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_StatorCurrLimitEn.value, StatorCurrentLimitEnable);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_SupplyCurrentLimit.value, SupplyCurrentLimit);
        ss += ConfigJNI.Serializeboolean(SpnValue.Config_SupplyCurrLimitEn.value, SupplyCurrentLimitEnable);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_SupplyCurrentLowerLimit.value, SupplyCurrentLowerLimit);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_SupplyCurrentLowerTime.value, SupplyCurrentLowerTime);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        StatorCurrentLimit = ConfigJNI.Deserializedouble(SpnValue.Config_StatorCurrentLimit.value, to_deserialize);
        StatorCurrentLimitEnable = ConfigJNI.Deserializeboolean(SpnValue.Config_StatorCurrLimitEn.value, to_deserialize);
        SupplyCurrentLimit = ConfigJNI.Deserializedouble(SpnValue.Config_SupplyCurrentLimit.value, to_deserialize);
        SupplyCurrentLimitEnable = ConfigJNI.Deserializeboolean(SpnValue.Config_SupplyCurrLimitEn.value, to_deserialize);
        SupplyCurrentLowerLimit = ConfigJNI.Deserializedouble(SpnValue.Config_SupplyCurrentLowerLimit.value, to_deserialize);
        SupplyCurrentLowerTime = ConfigJNI.Deserializedouble(SpnValue.Config_SupplyCurrentLowerTime.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public CurrentLimitsConfigs clone() {
        try {
            return (CurrentLimitsConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

