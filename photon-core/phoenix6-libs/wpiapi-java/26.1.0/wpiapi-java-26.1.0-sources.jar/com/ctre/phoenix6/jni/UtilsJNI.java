/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.jni;

public class UtilsJNI extends CtreJniWrapper {
    public static native double getCurrentTimeSeconds();
    public static native double getSystemTimeSeconds();
    public static native boolean isSimulation();
    public static native boolean isReplay();
}
