/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6;

import com.ctre.phoenix6.jni.CANBusJNI;

/**
 * Class for getting information about an available CAN bus.
 */
public class CANBus {
    /**
     * Contains status information about a CAN bus.
     */
    public static class CANBusStatus {
        /**
         * Status code response of getting the data
         */
        public StatusCode Status;

        /**
         * CAN bus utilization, from 0.0 to 1.0
         */
        public float BusUtilization;
        /**
         * Bus off count
         */
        public int BusOffCount;
        /**
         * Transmit buffer full count
         */
        public int TxFullCount;
        /**
         * Receive Error Counter (REC)
         */
        public int REC;
        /**
         * Transmit Error Counter (TEC)
         */
        public int TEC;
    }

    private final String _name;
    private CANBusStatus _status = null;
    private CANBusJNI _jni = null;

    /**
     * Creates a new CAN bus using the default for the system:
     * <ul>
     *   <li>"rio" on roboRIO
     *   <li>"can0" on Linux
     *   <li>"*" on Windows
     * </ul>
     */
    public CANBus() {
        this("");
    }

    /**
     * Creates a new CAN bus with the given name.
     * <p>
     * For the native roboRIO CAN bus, use {@link #roboRIO()} instead.
     *
     * @param canbus    Name of the CAN bus. Possible CAN bus strings are:
     *                  <ul>
     *                    <li>"rio" for the native roboRIO CAN bus
     *                    <li>CANivore name or serial number
     *                    <li>SocketCAN interface (non-FRC Linux only)
     *                    <li>"*" for any CANivore seen by the program
     *                    <li>empty string (default) to select the default for the system:
     *                    <ul>
     *                      <li>"rio" on roboRIO
     *                      <li>"can0" on Linux
     *                      <li>"*" on Windows
     *                    </ul>
     *                  </ul>
     */
    public CANBus(String canbus) {
        _name = canbus;
    }

    /**
     * Creates a new CAN bus with the given name, and loads an associated
     * hoot file for replay (equivalent to {@link HootReplay#loadFile}).
     * <p>
     * Only one hoot log may be replayed at a time. As a result, only one
     * CAN bus should be constructed with a hoot file.
     * <p>
     * When using relative paths, the file path is typically relative
     * to the top-level folder of the robot project.
     * <p>
     * For the native roboRIO CAN bus, use {@link #roboRIO(String)} instead.
     *
     * @param canbus    Name of the CAN bus. Possible CAN bus strings are:
     *                  <ul>
     *                    <li>"rio" for the native roboRIO CAN bus
     *                    <li>CANivore name or serial number
     *                    <li>SocketCAN interface (non-FRC Linux only)
     *                    <li>"*" for any CANivore seen by the program
     *                    <li>empty string (default) to select the default for the system:
     *                    <ul>
     *                      <li>"rio" on roboRIO
     *                      <li>"can0" on Linux
     *                      <li>"*" on Windows
     *                    </ul>
     *                  </ul>
     * @param hootFilepath Path and name of the hoot file to load
     */
    public CANBus(String canbus, String hootFilepath) {
        this(canbus);
        HootReplay.loadFile(hootFilepath);
    }

    /**
     * Creates a new CAN bus for the native roboRIO bus.
     *
     * @return The native roboRIO CAN bus
     */
    public static CANBus roboRIO() {
        return new CANBus("rio");
    }

    /**
     * Creates a new CAN bus for the native roboRIO bus, and
     * loads an associated hoot file for replay (equivalent to
     * {@link HootReplay#loadFile}).
     * <p>
     * Only one hoot log may be replayed at a time. As a result, only one
     * CAN bus should be constructed with a hoot file.
     * <p>
     * When using relative paths, the file path is typically relative
     * to the top-level folder of the robot project.
     *
     * @param hootFilepath Path and name of the hoot file to load
     * @return The native roboRIO CAN bus
     */
    public static CANBus roboRIO(String hootFilepath) {
        HootReplay.loadFile(hootFilepath);
        return roboRIO();
    }

    /**
     * Get the name used to construct this CAN bus.
     *
     * @return Name of the CAN bus
     */
    public final String getName() {
        return _name;
    }

    /**
     * Gets whether the network is CAN FD.
     *
     * @return True if the network is CAN FD
     */
    public final boolean isNetworkFD() {
        return CANBusJNI.JNI_IsNetworkFD(_name);
    }

    /**
     * Gets the status of the CAN bus, including the
     * bus utilization and the error counters.
     * <p>
     * This can block for up to 0.001 seconds (1 ms).
     * <p>
     * This function refreshes and returns a cached object.
     *
     * @return Status of the CAN bus
     */
    public final CANBusStatus getStatus() {
        if (_status == null) {
            _status = new CANBusStatus();
        }
        if (_jni == null) {
            _jni = new CANBusJNI();
        }
        var err = _jni.JNI_GetStatus(_name);

        _status.BusUtilization = _jni.busUtilization;
        _status.BusOffCount = _jni.busOffCount;
        _status.TxFullCount = _jni.txFullCount;
        _status.REC = _jni.rec;
        _status.TEC = _jni.tec;

        if (err != 0) {
            _status.Status = StatusCode.InvalidNetwork;
        } else {
            _status.Status = StatusCode.OK;
        }
        return _status;
    }

    @Override
    public String toString() {
        return getName();
    }
}
