/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

/**
 * Configs related to general CANdle features.
 * <p>
 * This includes configs such as disabling the 5V rail and the
 * behavior of VBat output.
 */
public class CANdleFeaturesConfigs implements ParentConfiguration, Cloneable {
    /**
     * Whether the 5V rail is enabled. Disabling the 5V rail will also
     * turn off the onboard LEDs.
     * 
     */
    public Enable5VRailValue Enable5VRail = Enable5VRailValue.Enabled;
    /**
     * The behavior of the VBat output. CANdle supports modulating VBat
     * output for single-color LED strips.
     * 
     */
    public VBatOutputModeValue VBatOutputMode = VBatOutputModeValue.On;
    /**
     * Whether the Status LED is enabled when the CANdle is actively being
     * controlled.
     * 
     */
    public StatusLedWhenActiveValue StatusLedWhenActive = StatusLedWhenActiveValue.Enabled;
    
    /**
     * Modifies this configuration's Enable5VRail parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Whether the 5V rail is enabled. Disabling the 5V rail will also
     * turn off the onboard LEDs.
     * 
     *
     * @param newEnable5VRail Parameter to modify
     * @return Itself
     */
    public final CANdleFeaturesConfigs withEnable5VRail(Enable5VRailValue newEnable5VRail)
    {
        Enable5VRail = newEnable5VRail;
        return this;
    }
    
    /**
     * Modifies this configuration's VBatOutputMode parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The behavior of the VBat output. CANdle supports modulating VBat
     * output for single-color LED strips.
     * 
     *
     * @param newVBatOutputMode Parameter to modify
     * @return Itself
     */
    public final CANdleFeaturesConfigs withVBatOutputMode(VBatOutputModeValue newVBatOutputMode)
    {
        VBatOutputMode = newVBatOutputMode;
        return this;
    }
    
    /**
     * Modifies this configuration's StatusLedWhenActive parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Whether the Status LED is enabled when the CANdle is actively being
     * controlled.
     * 
     *
     * @param newStatusLedWhenActive Parameter to modify
     * @return Itself
     */
    public final CANdleFeaturesConfigs withStatusLedWhenActive(StatusLedWhenActiveValue newStatusLedWhenActive)
    {
        StatusLedWhenActive = newStatusLedWhenActive;
        return this;
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: CANdleFeatures\n";
        ss += "    Enable5VRail: " + Enable5VRail + "\n";
        ss += "    VBatOutputMode: " + VBatOutputMode + "\n";
        ss += "    StatusLedWhenActive: " + StatusLedWhenActive + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializeint(SpnValue.Config_CANdle_5VRail.value, Enable5VRail.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_CANdle_VBatOutputMode.value, VBatOutputMode.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_CANdle_StatusLedWhenActive.value, StatusLedWhenActive.value);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        Enable5VRail = Enable5VRailValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_CANdle_5VRail.value, to_deserialize));
        VBatOutputMode = VBatOutputModeValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_CANdle_VBatOutputMode.value, to_deserialize));
        StatusLedWhenActive = StatusLedWhenActiveValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_CANdle_StatusLedWhenActive.value, to_deserialize));
        return  StatusCode.OK;
    }

    @Override
    public CANdleFeaturesConfigs clone() {
        try {
            return (CANdleFeaturesConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

