/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.jni;

public class CtreJniWrapper {
    static boolean libraryLoaded = false;

    static {
        if (!libraryLoaded) {
            // try to load real Tools, then Sim, then Replay
            try {
                System.loadLibrary("CTRE_PhoenixTools");
                System.loadLibrary("CTRE_Phoenix6");
            } catch (UnsatisfiedLinkError err) {
                try {
                    System.loadLibrary("CTRE_PhoenixTools_Sim");
                    System.loadLibrary("CTRE_Phoenix6_Sim");
                } catch (UnsatisfiedLinkError simErr) {
                    try {
                        System.loadLibrary("CTRE_PhoenixTools_Replay");
                        System.loadLibrary("CTRE_Phoenix6_Replay");
                    } catch (UnsatisfiedLinkError replayErr) {
                        err.printStackTrace();
                        simErr.printStackTrace();
                        replayErr.printStackTrace();
                        System.exit(1);
                    }
                }
            }
            libraryLoaded = true;
        }
    }
}
