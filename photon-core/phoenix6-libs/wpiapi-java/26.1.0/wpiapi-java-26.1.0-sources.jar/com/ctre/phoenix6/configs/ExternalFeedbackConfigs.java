/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;
import com.ctre.phoenix6.signals.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;
import com.ctre.phoenix6.hardware.core.CoreCANcoder;
import com.ctre.phoenix6.hardware.core.CorePigeon2;
import com.ctre.phoenix6.hardware.core.CoreCANdi;

/**
 * Configs that affect the external feedback sensor of this motor
 * controller.
 * <p>
 * Includes feedback sensor source, offsets and sensor phase for the
 * feedback sensor, and various ratios to describe the relationship
 * between the sensor and the mechanism for closed looping.
 */
public class ExternalFeedbackConfigs implements ParentConfiguration, Cloneable {
    /**
     * The ratio of sensor rotations to the mechanism's output, where a
     * ratio greater than 1 is a reduction.
     * <p>
     * This is equivalent to the mechanism's gear ratio if the sensor is
     * located on the input of a gearbox.  If sensor is on the output of a
     * gearbox, then this is typically set to 1.
     * <p>
     * We recommend against using this config to perform onboard unit
     * conversions.  Instead, unit conversions should be performed in
     * robot code using the units library.
     * <p>
     * If this is set to zero, the device will reset back to one.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1000
     *   <li> <b>Maximum Value:</b> 1000
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     */
    public double SensorToMechanismRatio = 1.0;
    /**
     * The ratio of motor rotor rotations to remote sensor rotations,
     * where a ratio greater than 1 is a reduction.
     * <p>
     * The Talon FX is capable of fusing a remote CANcoder with its rotor
     * sensor to produce a high-bandwidth sensor source.  This feature
     * requires specifying the ratio between the motor rotor and the
     * remote sensor.
     * <p>
     * If this is set to zero, the device will reset back to one.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1000
     *   <li> <b>Maximum Value:</b> 1000
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     */
    public double RotorToSensorRatio = 1.0;
    /**
     * Device ID of which remote device to use.  This is not used if the
     * Sensor Source is the internal rotor sensor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int FeedbackRemoteSensorID = 0;
    /**
     * The configurable time constant of the Kalman velocity filter. The
     * velocity Kalman filter will adjust to act as a low-pass with this
     * value as its time constant.
     * <p>
     * If the user is aiming for an expected cutoff frequency, the
     * frequency is calculated as 1 / (2 * π * τ) with τ being the time
     * constant.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     */
    public double VelocityFilterTimeConstant = 0;
    /**
     * The offset added to any absolute sensor connected to the Talon data
     * port. This is only supported when using the PulseWidth sensor
     * source.
     * <p>
     * This can be used to zero the sensor position in applications where
     * the sensor is 1:1 with the mechanism.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double AbsoluteSensorOffset = 0.0;
    /**
     * Choose what sensor source is reported via API and used by
     * closed-loop and limit features.  The default is Commutation, which
     * uses the external sensor used for motor commutation.
     * <p>
     * Choose Remote* to use another sensor on the same CAN bus (this also
     * requires setting FeedbackRemoteSensorID).  Talon will update its
     * position and velocity whenever the remote sensor publishes its
     * information on CAN bus, and the Talon commutation sensor will not
     * be used.
     * <p>
     * Choose Fused* (requires Phoenix Pro) and Talon will fuse another
     * sensor's information with the commutation sensor, which provides
     * the best possible position and velocity for accuracy and bandwidth
     * (this also requires setting FeedbackRemoteSensorID).  This was
     * developed for applications such as swerve-azimuth.
     * <p>
     * Choose Sync* (requires Phoenix Pro) and Talon will synchronize its
     * commutation sensor position against another sensor, then continue
     * to use the rotor sensor for closed loop control (this also requires
     * setting FeedbackRemoteSensorID).  The Talon will report if its
     * internal position differs significantly from the reported remote
     * sensor position.  This was developed for mechanisms where there is
     * a risk of the sensor failing in such a way that it reports a
     * position that does not match the mechanism, such as the sensor
     * mounting assembly breaking off.
     * <p>
     * Choose RemotePigeon2Yaw, RemotePigeon2Pitch, and RemotePigeon2Roll
     * to use another Pigeon2 on the same CAN bus (this also requires
     * setting FeedbackRemoteSensorID).  Talon will update its position to
     * match the selected value whenever Pigeon2 publishes its information
     * on CAN bus. Note that the Talon position will be in rotations and
     * not degrees.
     * <p>
     * Choose Quadrature to use a quadrature encoder directly attached to
     * the Talon data port. This provides velocity and relative position
     * measurements.
     * <p>
     * Choose PulseWidth to use a pulse-width encoder directly attached to
     * the Talon data port. This provides velocity and absolute position
     * measurements.
     * <p>
     * Note: When the feedback source is changed to Fused* or Sync*, the
     * Talon needs a period of time to fuse before sensor-based
     * (soft-limit, closed loop, etc.) features are used. This period of
     * time is determined by the update frequency of the remote sensor's
     * Position signal.
     * 
     */
    public ExternalFeedbackSensorSourceValue ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.Commutation;
    /**
     * The relationship between the motor controlled by a Talon and the
     * external sensor connected to the data port. This does not affect
     * the commutation sensor or remote sensors.
     * <p>
     * To determine the sensor phase, set this config to Aligned and drive
     * the motor with positive output. If the reported sensor velocity is
     * positive, then the phase is Aligned. If the reported sensor
     * velocity is negative, then the phase is Opposed.
     * <p>
     * The sensor direction is automatically inverted along with motor
     * invert, so the sensor phase does not need to be changed when motor
     * invert changes.
     * 
     */
    public SensorPhaseValue SensorPhase = SensorPhaseValue.Aligned;
    /**
     * The number of quadrature edges in one rotation for the quadrature
     * sensor connected to the Talon data port.
     * <p>
     * This is the total number of transitions from high-to-low or
     * low-to-high across both channels per rotation of the sensor. This
     * is also equivalent to the Counts Per Revolution when using 4x
     * decoding.
     * <p>
     * For example, the SRX Mag Encoder has 4096 edges per rotation, and a
     * US Digital 1024 CPR (Cycles Per Revolution) quadrature encoder has
     * 4096 edges per rotation.
     * <p>
     * On the Talon FXS, this can be at most 2,000,000,000 / Peak RPM.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 1
     *   <li> <b>Maximum Value:</b> 1000000
     *   <li> <b>Default Value:</b> 4096
     *   <li> <b>Units:</b> 
     * </ul>
     */
    public int QuadratureEdgesPerRotation = 4096;
    /**
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     */
    public double AbsoluteSensorDiscontinuityPoint = 0.5;
    
    /**
     * Modifies this configuration's SensorToMechanismRatio parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The ratio of sensor rotations to the mechanism's output, where a
     * ratio greater than 1 is a reduction.
     * <p>
     * This is equivalent to the mechanism's gear ratio if the sensor is
     * located on the input of a gearbox.  If sensor is on the output of a
     * gearbox, then this is typically set to 1.
     * <p>
     * We recommend against using this config to perform onboard unit
     * conversions.  Instead, unit conversions should be performed in
     * robot code using the units library.
     * <p>
     * If this is set to zero, the device will reset back to one.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1000
     *   <li> <b>Maximum Value:</b> 1000
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     *
     * @param newSensorToMechanismRatio Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withSensorToMechanismRatio(double newSensorToMechanismRatio)
    {
        SensorToMechanismRatio = newSensorToMechanismRatio;
        return this;
    }
    
    /**
     * Modifies this configuration's RotorToSensorRatio parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The ratio of motor rotor rotations to remote sensor rotations,
     * where a ratio greater than 1 is a reduction.
     * <p>
     * The Talon FX is capable of fusing a remote CANcoder with its rotor
     * sensor to produce a high-bandwidth sensor source.  This feature
     * requires specifying the ratio between the motor rotor and the
     * remote sensor.
     * <p>
     * If this is set to zero, the device will reset back to one.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1000
     *   <li> <b>Maximum Value:</b> 1000
     *   <li> <b>Default Value:</b> 1.0
     *   <li> <b>Units:</b> scalar
     * </ul>
     *
     * @param newRotorToSensorRatio Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withRotorToSensorRatio(double newRotorToSensorRatio)
    {
        RotorToSensorRatio = newRotorToSensorRatio;
        return this;
    }
    
    /**
     * Modifies this configuration's FeedbackRemoteSensorID parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Device ID of which remote device to use.  This is not used if the
     * Sensor Source is the internal rotor sensor.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 62
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newFeedbackRemoteSensorID Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withFeedbackRemoteSensorID(int newFeedbackRemoteSensorID)
    {
        FeedbackRemoteSensorID = newFeedbackRemoteSensorID;
        return this;
    }
    
    /**
     * Modifies this configuration's VelocityFilterTimeConstant parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The configurable time constant of the Kalman velocity filter. The
     * velocity Kalman filter will adjust to act as a low-pass with this
     * value as its time constant.
     * <p>
     * If the user is aiming for an expected cutoff frequency, the
     * frequency is calculated as 1 / (2 * π * τ) with τ being the time
     * constant.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newVelocityFilterTimeConstant Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withVelocityFilterTimeConstant(double newVelocityFilterTimeConstant)
    {
        VelocityFilterTimeConstant = newVelocityFilterTimeConstant;
        return this;
    }
    
    /**
     * Modifies this configuration's VelocityFilterTimeConstant parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The configurable time constant of the Kalman velocity filter. The
     * velocity Kalman filter will adjust to act as a low-pass with this
     * value as its time constant.
     * <p>
     * If the user is aiming for an expected cutoff frequency, the
     * frequency is calculated as 1 / (2 * π * τ) with τ being the time
     * constant.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newVelocityFilterTimeConstant Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withVelocityFilterTimeConstant(Time newVelocityFilterTimeConstant)
    {
        VelocityFilterTimeConstant = newVelocityFilterTimeConstant.in(Seconds);
        return this;
    }
    
    /**
     * Helper method to get this configuration's VelocityFilterTimeConstant parameter converted
     * to a unit type. If not using the Java units library, {@link #VelocityFilterTimeConstant}
     * can be accessed directly instead.
     * <p>
     * The configurable time constant of the Kalman velocity filter. The
     * velocity Kalman filter will adjust to act as a low-pass with this
     * value as its time constant.
     * <p>
     * If the user is aiming for an expected cutoff frequency, the
     * frequency is calculated as 1 / (2 * π * τ) with τ being the time
     * constant.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @return VelocityFilterTimeConstant
     */
    public final Time getVelocityFilterTimeConstantMeasure()
    {
        return Seconds.of(VelocityFilterTimeConstant);
    }
    
    /**
     * Modifies this configuration's AbsoluteSensorOffset parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The offset added to any absolute sensor connected to the Talon data
     * port. This is only supported when using the PulseWidth sensor
     * source.
     * <p>
     * This can be used to zero the sensor position in applications where
     * the sensor is 1:1 with the mechanism.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newAbsoluteSensorOffset Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withAbsoluteSensorOffset(double newAbsoluteSensorOffset)
    {
        AbsoluteSensorOffset = newAbsoluteSensorOffset;
        return this;
    }
    
    /**
     * Modifies this configuration's AbsoluteSensorOffset parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The offset added to any absolute sensor connected to the Talon data
     * port. This is only supported when using the PulseWidth sensor
     * source.
     * <p>
     * This can be used to zero the sensor position in applications where
     * the sensor is 1:1 with the mechanism.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newAbsoluteSensorOffset Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withAbsoluteSensorOffset(Angle newAbsoluteSensorOffset)
    {
        AbsoluteSensorOffset = newAbsoluteSensorOffset.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's AbsoluteSensorOffset parameter converted
     * to a unit type. If not using the Java units library, {@link #AbsoluteSensorOffset}
     * can be accessed directly instead.
     * <p>
     * The offset added to any absolute sensor connected to the Talon data
     * port. This is only supported when using the PulseWidth sensor
     * source.
     * <p>
     * This can be used to zero the sensor position in applications where
     * the sensor is 1:1 with the mechanism.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> -1
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0.0
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return AbsoluteSensorOffset
     */
    public final Angle getAbsoluteSensorOffsetMeasure()
    {
        return Rotations.of(AbsoluteSensorOffset);
    }
    
    /**
     * Modifies this configuration's ExternalFeedbackSensorSource parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * Choose what sensor source is reported via API and used by
     * closed-loop and limit features.  The default is Commutation, which
     * uses the external sensor used for motor commutation.
     * <p>
     * Choose Remote* to use another sensor on the same CAN bus (this also
     * requires setting FeedbackRemoteSensorID).  Talon will update its
     * position and velocity whenever the remote sensor publishes its
     * information on CAN bus, and the Talon commutation sensor will not
     * be used.
     * <p>
     * Choose Fused* (requires Phoenix Pro) and Talon will fuse another
     * sensor's information with the commutation sensor, which provides
     * the best possible position and velocity for accuracy and bandwidth
     * (this also requires setting FeedbackRemoteSensorID).  This was
     * developed for applications such as swerve-azimuth.
     * <p>
     * Choose Sync* (requires Phoenix Pro) and Talon will synchronize its
     * commutation sensor position against another sensor, then continue
     * to use the rotor sensor for closed loop control (this also requires
     * setting FeedbackRemoteSensorID).  The Talon will report if its
     * internal position differs significantly from the reported remote
     * sensor position.  This was developed for mechanisms where there is
     * a risk of the sensor failing in such a way that it reports a
     * position that does not match the mechanism, such as the sensor
     * mounting assembly breaking off.
     * <p>
     * Choose RemotePigeon2Yaw, RemotePigeon2Pitch, and RemotePigeon2Roll
     * to use another Pigeon2 on the same CAN bus (this also requires
     * setting FeedbackRemoteSensorID).  Talon will update its position to
     * match the selected value whenever Pigeon2 publishes its information
     * on CAN bus. Note that the Talon position will be in rotations and
     * not degrees.
     * <p>
     * Choose Quadrature to use a quadrature encoder directly attached to
     * the Talon data port. This provides velocity and relative position
     * measurements.
     * <p>
     * Choose PulseWidth to use a pulse-width encoder directly attached to
     * the Talon data port. This provides velocity and absolute position
     * measurements.
     * <p>
     * Note: When the feedback source is changed to Fused* or Sync*, the
     * Talon needs a period of time to fuse before sensor-based
     * (soft-limit, closed loop, etc.) features are used. This period of
     * time is determined by the update frequency of the remote sensor's
     * Position signal.
     * 
     *
     * @param newExternalFeedbackSensorSource Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withExternalFeedbackSensorSource(ExternalFeedbackSensorSourceValue newExternalFeedbackSensorSource)
    {
        ExternalFeedbackSensorSource = newExternalFeedbackSensorSource;
        return this;
    }
    
    /**
     * Modifies this configuration's SensorPhase parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The relationship between the motor controlled by a Talon and the
     * external sensor connected to the data port. This does not affect
     * the commutation sensor or remote sensors.
     * <p>
     * To determine the sensor phase, set this config to Aligned and drive
     * the motor with positive output. If the reported sensor velocity is
     * positive, then the phase is Aligned. If the reported sensor
     * velocity is negative, then the phase is Opposed.
     * <p>
     * The sensor direction is automatically inverted along with motor
     * invert, so the sensor phase does not need to be changed when motor
     * invert changes.
     * 
     *
     * @param newSensorPhase Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withSensorPhase(SensorPhaseValue newSensorPhase)
    {
        SensorPhase = newSensorPhase;
        return this;
    }
    
    /**
     * Modifies this configuration's QuadratureEdgesPerRotation parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The number of quadrature edges in one rotation for the quadrature
     * sensor connected to the Talon data port.
     * <p>
     * This is the total number of transitions from high-to-low or
     * low-to-high across both channels per rotation of the sensor. This
     * is also equivalent to the Counts Per Revolution when using 4x
     * decoding.
     * <p>
     * For example, the SRX Mag Encoder has 4096 edges per rotation, and a
     * US Digital 1024 CPR (Cycles Per Revolution) quadrature encoder has
     * 4096 edges per rotation.
     * <p>
     * On the Talon FXS, this can be at most 2,000,000,000 / Peak RPM.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 1
     *   <li> <b>Maximum Value:</b> 1000000
     *   <li> <b>Default Value:</b> 4096
     *   <li> <b>Units:</b> 
     * </ul>
     *
     * @param newQuadratureEdgesPerRotation Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withQuadratureEdgesPerRotation(int newQuadratureEdgesPerRotation)
    {
        QuadratureEdgesPerRotation = newQuadratureEdgesPerRotation;
        return this;
    }
    
    /**
     * Modifies this configuration's AbsoluteSensorDiscontinuityPoint parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newAbsoluteSensorDiscontinuityPoint Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withAbsoluteSensorDiscontinuityPoint(double newAbsoluteSensorDiscontinuityPoint)
    {
        AbsoluteSensorDiscontinuityPoint = newAbsoluteSensorDiscontinuityPoint;
        return this;
    }
    
    /**
     * Modifies this configuration's AbsoluteSensorDiscontinuityPoint parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @param newAbsoluteSensorDiscontinuityPoint Parameter to modify
     * @return Itself
     */
    public final ExternalFeedbackConfigs withAbsoluteSensorDiscontinuityPoint(Angle newAbsoluteSensorDiscontinuityPoint)
    {
        AbsoluteSensorDiscontinuityPoint = newAbsoluteSensorDiscontinuityPoint.in(Rotations);
        return this;
    }
    
    /**
     * Helper method to get this configuration's AbsoluteSensorDiscontinuityPoint parameter converted
     * to a unit type. If not using the Java units library, {@link #AbsoluteSensorDiscontinuityPoint}
     * can be accessed directly instead.
     * <p>
     * The positive discontinuity point of the absolute sensor in
     * rotations. This determines the point at which the absolute sensor
     * wraps around, keeping the absolute position (after offset) in the
     * range [x-1, x).
     * 
     * <ul>
     *   <li> Setting this to 1 makes the absolute position unsigned [0,
     * 1)
     *   <li> Setting this to 0.5 makes the absolute position signed
     * [-0.5, 0.5)
     *   <li> Setting this to 0 makes the absolute position always
     * negative [-1, 0)
     * </ul>
     * 
     * Many rotational mechanisms such as arms have a region of motion
     * that is unreachable. This should be set to the center of that
     * region of motion, in non-negative rotations. This affects the
     * position of the device at bootup.
     * <p>
     * For example, consider an arm which can travel from -0.2 to 0.6
     * rotations with a little leeway, where 0 is horizontally forward.
     * Since -0.2 rotations has the same absolute position as 0.8
     * rotations, we can say that the arm typically does not travel in the
     * range (0.6, 0.8) rotations. As a result, the discontinuity point
     * would be the center of that range, which is 0.7 rotations. This
     * results in an absolute sensor range of [-0.3, 0.7) rotations.
     * <p>
     * Given a total range of motion less than 1 rotation, users can
     * calculate the discontinuity point using mean(lowerLimit,
     * upperLimit) + 0.5. If that results in a value outside the range [0,
     * 1], either cap the value to [0, 1], or add/subtract 1.0 rotation
     * from your lower and upper limits of motion.
     * <p>
     * On a Talon motor controller, this is only supported when using the
     * PulseWidth sensor source.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0.0
     *   <li> <b>Maximum Value:</b> 1.0
     *   <li> <b>Default Value:</b> 0.5
     *   <li> <b>Units:</b> rotations
     * </ul>
     *
     * @return AbsoluteSensorDiscontinuityPoint
     */
    public final Angle getAbsoluteSensorDiscontinuityPointMeasure()
    {
        return Rotations.of(AbsoluteSensorDiscontinuityPoint);
    }
    
    /**
     * Helper method to configure this feedback group to use
     * RemoteCANcoder by passing in the CANcoder object.
     * <p>
     * When using RemoteCANcoder, the Talon will use another CANcoder on
     * the same CAN bus. The Talon will update its position and velocity
     * whenever CANcoder publishes its information on CAN bus, and the
     * Talon commutation sensor will not be used.
     * 
     * @param device CANcoder reference to use for RemoteCANcoder
     * @return Itself
     */
    public final ExternalFeedbackConfigs withRemoteCANcoder(CoreCANcoder device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.RemoteCANcoder;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use FusedCANcoder
     * by passing in the CANcoder object.
     * <p>
     * When using FusedCANcoder (requires Phoenix Pro), the Talon will
     * fuse another CANcoder's information with the commutation sensor,
     * which provides the best possible position and velocity for accuracy
     * and bandwidth. FusedCANcoder was developed for applications such as
     * swerve-azimuth.
     * 
     * @param device CANcoder reference to use for FusedCANcoder
     * @return Itself
     */
    public final ExternalFeedbackConfigs withFusedCANcoder(CoreCANcoder device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.FusedCANcoder;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use SyncCANcoder
     * by passing in the CANcoder object.
     * <p>
     * When using SyncCANcoder (requires Phoenix Pro), the Talon will
     * synchronize its commutation sensor position against another
     * CANcoder, then continue to use the rotor sensor for closed loop
     * control. The Talon will report if its internal position differs
     * significantly from the reported CANcoder position. SyncCANcoder was
     * developed for mechanisms where there is a risk of the CANcoder
     * failing in such a way that it reports a position that does not
     * match the mechanism, such as the sensor mounting assembly breaking
     * off.
     * 
     * @param device CANcoder reference to use for SyncCANcoder
     * @return Itself
     */
    public final ExternalFeedbackConfigs withSyncCANcoder(CoreCANcoder device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.SyncCANcoder;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use
     * RemotePigeon2Yaw by passing in the Pigeon2 object.
     * <p>
     * When using RemotePigeon2Yaw, the Talon will use another Pigeon2 on
     * the same CAN bus. The Talon will update its position to match the
     * Pigeon2 yaw whenever Pigeon2 publishes its information on CAN bus.
     * Note that the Talon position will be in rotations and not degrees.
     * 
     * @param device Pigeon2 reference to use for RemotePigeon2Yaw
     * @return Itself
     */
    public final ExternalFeedbackConfigs withRemotePigeon2Yaw(CorePigeon2 device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.RemotePigeon2Yaw;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use
     * RemotePigeon2Pitch by passing in the Pigeon2 object.
     * <p>
     * When using RemotePigeon2Pitch, the Talon will use another Pigeon2
     * on the same CAN bus. The Talon will update its position to match
     * the Pigeon2 pitch whenever Pigeon2 publishes its information on CAN
     * bus. Note that the Talon position will be in rotations and not
     * degrees.
     * 
     * @param device Pigeon2 reference to use for RemotePigeon2Pitch
     * @return Itself
     */
    public final ExternalFeedbackConfigs withRemotePigeon2Pitch(CorePigeon2 device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.RemotePigeon2Pitch;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use
     * RemotePigeon2Roll by passing in the Pigeon2 object.
     * <p>
     * When using RemotePigeon2Roll, the Talon will use another Pigeon2 on
     * the same CAN bus. The Talon will update its position to match the
     * Pigeon2 roll whenever Pigeon2 publishes its information on CAN bus.
     * Note that the Talon position will be in rotations and not degrees.
     * 
     * @param device Pigeon2 reference to use for RemotePigeon2Roll
     * @return Itself
     */
    public final ExternalFeedbackConfigs withRemotePigeon2Roll(CorePigeon2 device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.RemotePigeon2Roll;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteCANdi
     * PWM 1 by passing in the CANdi object.
     * <p>
     * When using RemoteCANdi, the Talon will use another CTR Electronics'
     * CANdi™ on the same CAN bus. The Talon will update its position and
     * velocity whenever the CTR Electronics' CANdi™ publishes its
     * information on CAN bus, and the Talon commutation sensor will not
     * be used.
     * 
     * @param device CANdi reference to use for RemoteCANdi
     * @return Itself
     */
    public final ExternalFeedbackConfigs withRemoteCANdiPWM1(CoreCANdi device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.RemoteCANdiPWM1;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteCANdi
     * PWM 2 by passing in the CANdi object.
     * <p>
     * When using RemoteCANdi, the Talon will use another CTR Electronics'
     * CANdi™ on the same CAN bus. The Talon will update its position and
     * velocity whenever the CTR Electronics' CANdi™ publishes its
     * information on CAN bus, and the Talon commutation sensor will not
     * be used.
     * 
     * @param device CANdi reference to use for RemoteCANdi
     * @return Itself
     */
    public final ExternalFeedbackConfigs withRemoteCANdiPWM2(CoreCANdi device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.RemoteCANdiPWM2;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use RemoteCANdi
     * Quadrature by passing in the CANdi object.
     * <p>
     * When using RemoteCANdi, the Talon will use another CTR Electronics'
     * CANdi™ on the same CAN bus. The Talon will update its position and
     * velocity whenever the CTR Electronics' CANdi™ publishes its
     * information on CAN bus, and the Talon commutation sensor will not
     * be used.
     * 
     * @param device CANdi reference to use for RemoteCANdi
     * @return Itself
     */
    public final ExternalFeedbackConfigs withRemoteCANdiQuadrature(CoreCANdi device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.RemoteCANdiQuadrature;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use FusedCANdi
     * PWM 1 by passing in the CANdi object.
     * <p>
     * When using FusedCANdi (requires Phoenix Pro), the Talon will fuse
     * another CANdi™ branded device's information with the internal
     * rotor, which provides the best possible position and velocity for
     * accuracy and bandwidth.
     * 
     * @param device CANdi reference to use for FusedCANdi
     * @return Itself
     */
    public final ExternalFeedbackConfigs withFusedCANdiPWM1(CoreCANdi device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.FusedCANdiPWM1;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use FusedCANdi
     * PWM 2 by passing in the CANdi object.
     * <p>
     * When using FusedCANdi (requires Phoenix Pro), the Talon will fuse
     * another CANdi™ branded device's information with the internal
     * rotor, which provides the best possible position and velocity for
     * accuracy and bandwidth.
     * 
     * @param device CANdi reference to use for FusedCANdi
     * @return Itself
     */
    public final ExternalFeedbackConfigs withFusedCANdiPWM2(CoreCANdi device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.FusedCANdiPWM2;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use FusedCANdi
     * Quadrature by passing in the CANdi object.
     * <p>
     * When using FusedCANdi (requires Phoenix Pro), the Talon will fuse
     * another CANdi™ branded device's information with the internal
     * rotor, which provides the best possible position and velocity for
     * accuracy and bandwidth.
     * 
     * @param device CANdi reference to use for FusedCANdi
     * @return Itself
     */
    public final ExternalFeedbackConfigs withFusedCANdiQuadrature(CoreCANdi device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.FusedCANdiQuadrature;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use SyncCANdi PWM
     * 1 by passing in the CANdi object.
     * <p>
     * When using SyncCANdi (requires Phoenix Pro), the Talon will
     * synchronize its internal rotor position against another CANdi™
     * branded device, then continue to use the rotor sensor for closed
     * loop control. The Talon will report if its internal position
     * differs significantly from the reported CANdi™ branded device's
     * position. SyncCANdi was developed for mechanisms where there is a
     * risk of the CANdi™ branded device failing in such a way that it
     * reports a position that does not match the mechanism, such as the
     * sensor mounting assembly breaking off.
     * 
     * @param device CANdi reference to use for SyncCANdi
     * @return Itself
     */
    public final ExternalFeedbackConfigs withSyncCANdiPWM1(CoreCANdi device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.SyncCANdiPWM1;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    /**
     * Helper method to configure this feedback group to use SyncCANdi PWM
     * 2 by passing in the CANdi object.
     * <p>
     * When using SyncCANdi (requires Phoenix Pro), the Talon will
     * synchronize its internal rotor position against another CANdi™
     * branded device, then continue to use the rotor sensor for closed
     * loop control. The Talon will report if its internal position
     * differs significantly from the reported CANdi™ branded device's
     * position. SyncCANdi was developed for mechanisms where there is a
     * risk of the CANdi™ branded device failing in such a way that it
     * reports a position that does not match the mechanism, such as the
     * sensor mounting assembly breaking off.
     * 
     * @param device CANdi reference to use for SyncCANdi
     * @return Itself
     */
    public final ExternalFeedbackConfigs withSyncCANdiPWM2(CoreCANdi device)
    {
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.SyncCANdiPWM2;
        FeedbackRemoteSensorID = device.getDeviceID();
        return this;
    }
    
    

    @Override
    public String toString() {
        String ss = "Config Group: ExternalFeedback\n";
        ss += "    SensorToMechanismRatio: " + SensorToMechanismRatio + " scalar" + "\n";
        ss += "    RotorToSensorRatio: " + RotorToSensorRatio + " scalar" + "\n";
        ss += "    FeedbackRemoteSensorID: " + FeedbackRemoteSensorID + "\n";
        ss += "    VelocityFilterTimeConstant: " + VelocityFilterTimeConstant + " seconds" + "\n";
        ss += "    AbsoluteSensorOffset: " + AbsoluteSensorOffset + " rotations" + "\n";
        ss += "    ExternalFeedbackSensorSource: " + ExternalFeedbackSensorSource + "\n";
        ss += "    SensorPhase: " + SensorPhase + "\n";
        ss += "    QuadratureEdgesPerRotation: " + QuadratureEdgesPerRotation + "\n";
        ss += "    AbsoluteSensorDiscontinuityPoint: " + AbsoluteSensorDiscontinuityPoint + " rotations" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_SensorToMechanismRatio.value, SensorToMechanismRatio);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_RotorToSensorRatio.value, RotorToSensorRatio);
        ss += ConfigJNI.Serializeint(SpnValue.Config_FeedbackRemoteSensorID.value, FeedbackRemoteSensorID);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_VelocityFilterTimeConstant.value, VelocityFilterTimeConstant);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_AbsoluteSensorOffset.value, AbsoluteSensorOffset);
        ss += ConfigJNI.Serializeint(SpnValue.Config_ExternalFeedbackSensorSource.value, ExternalFeedbackSensorSource.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_SensorPhase.value, SensorPhase.value);
        ss += ConfigJNI.Serializeint(SpnValue.Config_QuadratureEdgesPerRotation.value, QuadratureEdgesPerRotation);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_AbsoluteSensorDiscontinuityPoint.value, AbsoluteSensorDiscontinuityPoint);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        SensorToMechanismRatio = ConfigJNI.Deserializedouble(SpnValue.Config_SensorToMechanismRatio.value, to_deserialize);
        RotorToSensorRatio = ConfigJNI.Deserializedouble(SpnValue.Config_RotorToSensorRatio.value, to_deserialize);
        FeedbackRemoteSensorID = ConfigJNI.Deserializeint(SpnValue.Config_FeedbackRemoteSensorID.value, to_deserialize);
        VelocityFilterTimeConstant = ConfigJNI.Deserializedouble(SpnValue.Config_VelocityFilterTimeConstant.value, to_deserialize);
        AbsoluteSensorOffset = ConfigJNI.Deserializedouble(SpnValue.Config_AbsoluteSensorOffset.value, to_deserialize);
        ExternalFeedbackSensorSource = ExternalFeedbackSensorSourceValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_ExternalFeedbackSensorSource.value, to_deserialize));
        SensorPhase = SensorPhaseValue.valueOf(ConfigJNI.Deserializeint(SpnValue.Config_SensorPhase.value, to_deserialize));
        QuadratureEdgesPerRotation = ConfigJNI.Deserializeint(SpnValue.Config_QuadratureEdgesPerRotation.value, to_deserialize);
        AbsoluteSensorDiscontinuityPoint = ConfigJNI.Deserializedouble(SpnValue.Config_AbsoluteSensorDiscontinuityPoint.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public ExternalFeedbackConfigs clone() {
        try {
            return (ExternalFeedbackConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

