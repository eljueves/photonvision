/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.configs;

import com.ctre.phoenix6.StatusCode;
import com.ctre.phoenix6.configs.jni.ConfigJNI;
import com.ctre.phoenix6.spns.*;

import edu.wpi.first.units.*;

import edu.wpi.first.units.measure.*;
import static edu.wpi.first.units.Units.*;

/**
 * Configs that affect the open-loop control of this motor controller.
 * <p>
 * Open-loop ramp rates for the various control types.
 */
public class OpenLoopRampsConfigs implements ParentConfiguration, Cloneable {
    /**
     * If non-zero, this determines how much time to ramp from 0% output
     * to 100% during the open-loop DutyCycleOut control mode.
     * <p>
     * This provides an easy way to limit the acceleration of the motor.
     * However, the acceleration and current draw of the motor can be
     * better restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     */
    public double DutyCycleOpenLoopRampPeriod = 0;
    /**
     * If non-zero, this determines how much time to ramp from 0V output
     * to 12V during the open-loop VoltageOut control mode.
     * <p>
     * This provides an easy way to limit the acceleration of the motor.
     * However, the acceleration and current draw of the motor can be
     * better restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     */
    public double VoltageOpenLoopRampPeriod = 0;
    /**
     * If non-zero, this determines how much time to ramp from 0A output
     * to 300A during the open-loop TorqueCurrent control mode.
     * <p>
     * Since TorqueCurrent is directly proportional to acceleration, this
     * ramp limits jerk instead of acceleration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 10
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     */
    public double TorqueOpenLoopRampPeriod = 0;
    
    /**
     * Modifies this configuration's DutyCycleOpenLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0% output
     * to 100% during the open-loop DutyCycleOut control mode.
     * <p>
     * This provides an easy way to limit the acceleration of the motor.
     * However, the acceleration and current draw of the motor can be
     * better restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newDutyCycleOpenLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final OpenLoopRampsConfigs withDutyCycleOpenLoopRampPeriod(double newDutyCycleOpenLoopRampPeriod)
    {
        DutyCycleOpenLoopRampPeriod = newDutyCycleOpenLoopRampPeriod;
        return this;
    }
    
    /**
     * Modifies this configuration's DutyCycleOpenLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0% output
     * to 100% during the open-loop DutyCycleOut control mode.
     * <p>
     * This provides an easy way to limit the acceleration of the motor.
     * However, the acceleration and current draw of the motor can be
     * better restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newDutyCycleOpenLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final OpenLoopRampsConfigs withDutyCycleOpenLoopRampPeriod(Time newDutyCycleOpenLoopRampPeriod)
    {
        DutyCycleOpenLoopRampPeriod = newDutyCycleOpenLoopRampPeriod.in(Seconds);
        return this;
    }
    
    /**
     * Helper method to get this configuration's DutyCycleOpenLoopRampPeriod parameter converted
     * to a unit type. If not using the Java units library, {@link #DutyCycleOpenLoopRampPeriod}
     * can be accessed directly instead.
     * <p>
     * If non-zero, this determines how much time to ramp from 0% output
     * to 100% during the open-loop DutyCycleOut control mode.
     * <p>
     * This provides an easy way to limit the acceleration of the motor.
     * However, the acceleration and current draw of the motor can be
     * better restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @return DutyCycleOpenLoopRampPeriod
     */
    public final Time getDutyCycleOpenLoopRampPeriodMeasure()
    {
        return Seconds.of(DutyCycleOpenLoopRampPeriod);
    }
    
    /**
     * Modifies this configuration's VoltageOpenLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0V output
     * to 12V during the open-loop VoltageOut control mode.
     * <p>
     * This provides an easy way to limit the acceleration of the motor.
     * However, the acceleration and current draw of the motor can be
     * better restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newVoltageOpenLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final OpenLoopRampsConfigs withVoltageOpenLoopRampPeriod(double newVoltageOpenLoopRampPeriod)
    {
        VoltageOpenLoopRampPeriod = newVoltageOpenLoopRampPeriod;
        return this;
    }
    
    /**
     * Modifies this configuration's VoltageOpenLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0V output
     * to 12V during the open-loop VoltageOut control mode.
     * <p>
     * This provides an easy way to limit the acceleration of the motor.
     * However, the acceleration and current draw of the motor can be
     * better restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newVoltageOpenLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final OpenLoopRampsConfigs withVoltageOpenLoopRampPeriod(Time newVoltageOpenLoopRampPeriod)
    {
        VoltageOpenLoopRampPeriod = newVoltageOpenLoopRampPeriod.in(Seconds);
        return this;
    }
    
    /**
     * Helper method to get this configuration's VoltageOpenLoopRampPeriod parameter converted
     * to a unit type. If not using the Java units library, {@link #VoltageOpenLoopRampPeriod}
     * can be accessed directly instead.
     * <p>
     * If non-zero, this determines how much time to ramp from 0V output
     * to 12V during the open-loop VoltageOut control mode.
     * <p>
     * This provides an easy way to limit the acceleration of the motor.
     * However, the acceleration and current draw of the motor can be
     * better restricted using current limits instead of a ramp rate.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 1
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @return VoltageOpenLoopRampPeriod
     */
    public final Time getVoltageOpenLoopRampPeriodMeasure()
    {
        return Seconds.of(VoltageOpenLoopRampPeriod);
    }
    
    /**
     * Modifies this configuration's TorqueOpenLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0A output
     * to 300A during the open-loop TorqueCurrent control mode.
     * <p>
     * Since TorqueCurrent is directly proportional to acceleration, this
     * ramp limits jerk instead of acceleration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 10
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newTorqueOpenLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final OpenLoopRampsConfigs withTorqueOpenLoopRampPeriod(double newTorqueOpenLoopRampPeriod)
    {
        TorqueOpenLoopRampPeriod = newTorqueOpenLoopRampPeriod;
        return this;
    }
    
    /**
     * Modifies this configuration's TorqueOpenLoopRampPeriod parameter and returns itself for
     * method-chaining and easier to use config API.
     * <p>
     * If non-zero, this determines how much time to ramp from 0A output
     * to 300A during the open-loop TorqueCurrent control mode.
     * <p>
     * Since TorqueCurrent is directly proportional to acceleration, this
     * ramp limits jerk instead of acceleration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 10
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @param newTorqueOpenLoopRampPeriod Parameter to modify
     * @return Itself
     */
    public final OpenLoopRampsConfigs withTorqueOpenLoopRampPeriod(Time newTorqueOpenLoopRampPeriod)
    {
        TorqueOpenLoopRampPeriod = newTorqueOpenLoopRampPeriod.in(Seconds);
        return this;
    }
    
    /**
     * Helper method to get this configuration's TorqueOpenLoopRampPeriod parameter converted
     * to a unit type. If not using the Java units library, {@link #TorqueOpenLoopRampPeriod}
     * can be accessed directly instead.
     * <p>
     * If non-zero, this determines how much time to ramp from 0A output
     * to 300A during the open-loop TorqueCurrent control mode.
     * <p>
     * Since TorqueCurrent is directly proportional to acceleration, this
     * ramp limits jerk instead of acceleration.
     * 
     * <ul>
     *   <li> <b>Minimum Value:</b> 0
     *   <li> <b>Maximum Value:</b> 10
     *   <li> <b>Default Value:</b> 0
     *   <li> <b>Units:</b> seconds
     * </ul>
     *
     * @return TorqueOpenLoopRampPeriod
     */
    public final Time getTorqueOpenLoopRampPeriodMeasure()
    {
        return Seconds.of(TorqueOpenLoopRampPeriod);
    }

    

    @Override
    public String toString() {
        String ss = "Config Group: OpenLoopRamps\n";
        ss += "    DutyCycleOpenLoopRampPeriod: " + DutyCycleOpenLoopRampPeriod + " seconds" + "\n";
        ss += "    VoltageOpenLoopRampPeriod: " + VoltageOpenLoopRampPeriod + " seconds" + "\n";
        ss += "    TorqueOpenLoopRampPeriod: " + TorqueOpenLoopRampPeriod + " seconds" + "\n";
        return ss;
    }

    /**
     * Get the serialized form of this configuration group.
     *
     * @return Serialized form of this config group
     */
    @Override
    public final String serialize() {
        String ss = "";
        ss += ConfigJNI.Serializedouble(SpnValue.Config_DutyCycleOpenLoopRampPeriod.value, DutyCycleOpenLoopRampPeriod);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_VoltageOpenLoopRampPeriod.value, VoltageOpenLoopRampPeriod);
        ss += ConfigJNI.Serializedouble(SpnValue.Config_TorqueOpenLoopRampPeriod.value, TorqueOpenLoopRampPeriod);
        return ss;
    }

    /**
     * Take a string and deserialize it to this configuration group.
     *
     * @return Return code of the deserialize method
     */
    @Override
    public final StatusCode deserialize(String to_deserialize) {
        DutyCycleOpenLoopRampPeriod = ConfigJNI.Deserializedouble(SpnValue.Config_DutyCycleOpenLoopRampPeriod.value, to_deserialize);
        VoltageOpenLoopRampPeriod = ConfigJNI.Deserializedouble(SpnValue.Config_VoltageOpenLoopRampPeriod.value, to_deserialize);
        TorqueOpenLoopRampPeriod = ConfigJNI.Deserializedouble(SpnValue.Config_TorqueOpenLoopRampPeriod.value, to_deserialize);
        return  StatusCode.OK;
    }

    @Override
    public OpenLoopRampsConfigs clone() {
        try {
            return (OpenLoopRampsConfigs)super.clone();
        } catch (CloneNotSupportedException ex) {
            /* this should never happen */
            throw new RuntimeException(ex);
        }
    }
}

