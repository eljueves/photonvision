/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
package com.ctre.phoenix6.signals;

import java.util.HashMap;

/**
 * The behavior of the larson animation pocket of light when it reaches the end
 * of the strip.
 */
public enum LarsonBounceValue
{
    /**
     * The animation bounces as soon as the first LED reaches the end of the strip.
     */
    Front(0),
    /**
     * The animation bounces once it is midway through the end of the strip.
     */
    Center(1),
    /**
     * The animation bounces once all LEDs are off the strip.
     */
    Back(2),;

    public final int value;

    LarsonBounceValue(int initValue)
    {
        this.value = initValue;
    }

    private static HashMap<Integer, LarsonBounceValue> _map = null;
    static
    {
        _map = new HashMap<Integer, LarsonBounceValue>();
        for (LarsonBounceValue type : LarsonBounceValue.values())
        {
            _map.put(type.value, type);
        }
    }

    /**
     * Gets LarsonBounceValue from specified value
     * @param value Value of LarsonBounceValue
     * @return LarsonBounceValue of specified value
     */
    public static LarsonBounceValue valueOf(int value)
    {
        LarsonBounceValue retval = _map.get(value);
        if (retval != null) return retval;
        return LarsonBounceValue.values()[0];
    }
}
