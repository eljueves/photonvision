/*
 * Copyright (C) Cross The Road Electronics.  All rights reserved.
 * License information can be found in CTRE_LICENSE.txt
 * For support and suggestions contact support@ctr-electronics.com or file
 * an issue tracker at https://github.com/CrossTheRoadElec/Phoenix-Releases
 */
#pragma once

#include "ctre/phoenix6/CANBus.hpp"
#include "ctre/phoenix6/networking/Wrappers.hpp"

namespace ctre {
namespace phoenix6 {
namespace hardware {

    class DeviceIdentifier final {
    public:
        std::string network;
        std::string model;
        int deviceID;
        uint32_t deviceHash;

        DeviceIdentifier() = default;
        DeviceIdentifier(int deviceID, std::string model, CANBus canbus) :
            network{canbus.GetName()},
            model{std::move(model)},
            deviceID{deviceID},
            deviceHash{networking::Wrappers::CompileDeviceHash(deviceID, this->model.c_str(), this->network.c_str())}
        {}

        std::string ToString() const;
    };

}
}
}
